const FUSE_LINES = [
  ['Ext. Crystal/Resonator High Freq.; Start-up time: 16K CK + 64 ms; [CKSEL=1111 SUT=11]', 1],
  ['Ext. Crystal/Resonator High Freq.; Start-up time: 16K CK + 4 ms; [CKSEL=1111 SUT=10]', 0],
  ['Brown-out detection level at VCC=4.0 V; [BODLEVEL=0]', 1],
  ['Brown-out detection enabled; [BODEN=0]', 1],
  ['Reset Disabled (Enable PC6 as i/o pin); [RSTDISBL=0]', 0],
  ['Watch-dog Timer always on; [WDTON=0]', 0],
  ['Serial program downloading (SPI) enabled; [SPIEN=0]', 1],
  ['CKOPT fuse (operation dependent of CKSEL fuses); [CKOPT=0]', 0],
  ['Preserve EEPROM memory through the Chip Erase cycle; [EESAVE=0]', 1],
  ['Boot Flash section size=1024 words Boot start address=$0C00; [BOOTSZ=00]', 1]
];
function pgWindow(file, first) {
  const ck = (on, cls, label, n) => `<span class="${cls || ''}"><i>${on ? '✔' : ''}</i>${label}${n ? `<b class="cb">${n}</b>` : ''}</span>`;
  const list = FUSE_LINES.map(([t, on]) => `<div class="${on ? 'ck' : ''}"><i>${on ? '✓' : ''}</i>${t}</div>`).join('');
  return `<div class="pg">
  <div class="pg-title"><span class="ico"></span>PROGISP (Ver 1.6.6)<span class="x">_ ▢ ✕</span></div>
  <div class="pg-menu"><span>File</span><span>Command</span><span>Buffer</span><span>Select</span><span>About</span></div>
  <div class="pg-tabs"><span class="on">PROGRAM</span><span>BUFFER</span><span>CONFIG</span><span>Readme</span><span>Update</span></div>
  <div class="pg-body">
    <div>
      <div class="pg-list">${list}</div>
      <div class="pg-sub"><span>ConfigBit</span><span>Navigation</span></div>
      <div class="pg-fuse">
        <div class="pg-row">${first ? '<b class="cb">3</b>' : ''}LowValue <span class="pg-in ${first ? 'hot' : ''}">3F</span> HighValue <span class="pg-in ${first ? 'hot' : ''}">D1</span> ExtValue <span class="pg-in">0</span> &nbsp;Lock Value <span class="pg-in">FF</span></div>
        <div class="pg-row" style="margin-top:6px;gap:8px"><span class="pg-btn">Read</span><span class="pg-btn">Default</span><span class="pg-btn ${first ? 'hot' : ''}">Write</span><span style="flex:1"></span><span class="pg-btn">Read</span><span class="pg-btn">Write</span></div>
      </div>
      <div class="pg-site">www.zhifengsoft.com</div>
      <div class="pg-msg">Read signature OK: 1E 93 07</div>
    </div>
    <div>
      <div class="pg-top">
        <div>
          <div class="pg-group" style="margin-top:6px"><b>Programmer Interface</b><div style="margin-top:4px"><span class="pg-sel">USBASP</span></div><div style="margin-top:3px"><span class="pg-sel">usb</span></div></div>
          <div class="pg-group" style="margin-top:8px"><b>Select CPU</b><div style="margin-top:4px"><span class="pg-sel hot">ATmega8</span><b class="cb">1</b></div></div>
          <div class="pg-group" style="margin-top:8px"><b>Chip Signature</b><div style="margin-top:3px;font-weight:bold">1E : 93 : 07 <span class="pg-btn" style="min-width:0;padding:0 3px">RD</span></div></div>
        </div>
        <div class="pg-speed ${first ? 'hot' : ''}" style="margin-top:6px"><span style="color:#c8102e">Auto<br>High</span><div class="trk"><div class="knob" style="top:${first ? 48 : 4}px"></div></div><span style="color:#21a121">Low</span><b class="cb" style="margin-top:3px">2</b></div>
        <div class="pg-group pg-cal" style="margin-top:6px"><b>Calibration</b><div style="margin-top:4px">1.0 MHz <span>○</span></div><div>2.0 MHz <span>○</span></div><div>4.0 MHz <span>○</span></div><div>8.0 MHz <span>○</span></div><div style="justify-content:center"><span class="pg-btn" style="min-width:0">Read</span></div></div>
      </div>
      <div class="pg-row" style="justify-content:space-between;margin:4px 0 2px"><span><span class="pg-btn hot">Load Flash</span><b class="cb">4</b></span><span class="pg-btn">Load Eprom</span></div>
      <div class="pg-file">${file}</div>
      <div class="pg-row" style="justify-content:space-between;margin-bottom:4px"><span class="pg-btn">Read Flash</span><span class="pg-btn">Read Eprom</span></div>
      <div class="pg-row" style="justify-content:space-between;font-weight:bold;margin-bottom:6px"><span>Flash: ${FLASH_USED}/8192</span><span>Eprom: 0/512</span></div>
      <div class="pg-group" style="padding-top:8px"><b>Programming <b class="cb" style="position:static">5</b></b>
        <div class="pg-chk">
          ${ck(1, '', 'Read Signature')}${ck(0, '', 'Verify EEPROM')}
          ${ck(1, 'hot', 'Chip Erase')}${ck(first, first ? 'hot' : '', 'Program Fuse')}
          ${ck(0, '', 'Blank Check')}${ck(0, '', 'Lock Chip')}
          ${ck(1, '', 'Program FLASH')}${ck(1, '', 'Data Reload')}
          ${ck(0, 'bad hot', 'Program EEPROM ✕')}${ck(0, '', 'Enabled XTAL')}
          ${ck(1, '', 'Verify FLASH')}${ck(0, '', 'Image Data')}
        </div>
      </div>
      <div class="pg-act"><span class="pg-btn">Erase</span><span><span class="pg-btn hot">Auto</span><b class="cb">6</b></span></div>
    </div>
  </div>
  <div class="pg-status"><span>State</span><span>Ready</span><span style="margin-left:auto">Copyright(r) Zhifeng Software,Inc 2007</span></div>
</div>`;
}
