/* ---------- customer brochure (one per programmed panel) ---------- */
const PROJ = (() => { let v = {}; try { v = JSON.parse(localStorage.getItem('sooden_installer') || '{}'); } catch (e) { } return { customer: '', place: '', installer: v.installer || '', phone: v.phone || '' }; })();
function projSaveInstaller() { try { localStorage.setItem('sooden_installer', JSON.stringify({ installer: PROJ.installer, phone: PROJ.phone })); } catch (e) { } }
function faDate(d) { try { return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(d); } catch (e) { return fa(d.toISOString().slice(0, 10)); } }
function latinDate(d) {      /* 1405-07-20 for file names */
  try {
    const p = {}; new Intl.DateTimeFormat('en-US-u-ca-persian-nu-latn', { year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(d).forEach(x => p[x.type] = x.value);
    if (p.year && p.month && p.day) return `${p.year.replace(/\D/g, '')}-${p.month}-${p.day}`;
  } catch (e) { }
  return d.toISOString().slice(0, 10);
}
const poleLabel = (pn, k) => `${plab(pn, k)}${pn.poles[k] && pn.poles[k].name ? ` (${esc(pn.poles[k].name)})` : ''}`;
const poleList = (pn, mask) => { const a = []; for (let k = 0; k < pn.poles.length; k++) if (mask & (1 << k)) a.push(poleLabel(pn, k)); return a.join('، '); };
function panelTitle(t) { const pn = panelByKey(t.key); return (pn && pn.name) || (t.key === 'S' ? 'کلید' : 'پنل ' + t.key); }
function archiveName(t) {
  const clean = s => String(s || '').replace(/[\/\\:*?"<>|\x00-\x1f]/g, ' ').replace(/\s+/g, ' ').trim();
  const parts = [latinDate(new Date()), clean(PROJ.customer), clean(PROJ.place), clean(panelTitle(t))].filter(Boolean);
  return parts.join(' - ').slice(0, 140).replace(/[. ]+$/, '');
}
function brochureHtml(t) {
  const pn = panelByKey(t.key), c = t.cfg, m = t.model, big = !!pn.big, n = big ? pn.poles.length : m.n;
  const other = W.mode === 'pair' ? W.pair[t.key === 'A' ? 'B' : 'A'] : null, otherKey = t.key === 'A' ? 'B' : 'A';
  const otherName = other ? (other.name || 'پنل ' + otherKey) : '';
  /* poles */
  const poleDesc = i => {
    const p = pn.poles[i];
    if (p.type === 'm') return `<b>مستر:</b> با یک لمس ${poleList(pn, c.onmask[i])} با هم روشن می‌شوند؛ اگر یکی از آن‌ها روشن باشد، همه خاموش می‌شوند.`;
    if (p.type === 't') return `<b>سناریو سرویسی:</b> با لمس، ${c.offmask[i] ? poleList(pn, c.offmask[i]) + ' خاموش می‌شوند و ' : ''}${poleList(pn, c.onmask[i])} (هواکش) روشن می‌شود${c.minutes[i] ? ` و بعد از ${fa(c.minutes[i])} دقیقه خودکار خاموش می‌شود (لمس دوباره، زمان را از اول شروع می‌کند)` : ''}.`;
    if (p.type === 'ot') return `<b>تایمر خاموشی:</b> با لمس، شمارش ${fa(c.minutes[i])} دقیقه شروع می‌شود (چراغ قرمز روشن)؛ بعد از آن ${poleList(pn, c.offmask[i])} خاموش می‌شوند. لمس دوباره در این مدت، تایمر را لغو می‌کند.`;
    if (p.type === 'do') return `<b>خاموشی با تأخیر:</b> لمس اول روشن می‌کند. لمس دوم: چراغ ${fa(c.sec1[i])} ثانیه دیگر روشن می‌ماند و بعد خاموش می‌شود (در این مدت چراغ سفید چشمک می‌زند). لمس سوم در این مدت، فوری خاموش می‌کند.`;
    if (p.type === 'p') return `<b>شاسی:</b> با لمس، ${fa(c.sec2[i])} ثانیه وصل می‌شود و خودش قطع می‌شود.`;
    if (p.type === 'dl') return `<b>شاسی تأخیری:</b> با لمس، چراغ سفید چشمک می‌زند و بعد از ${fa(c.sec1[i])} ثانیه وصل می‌شود${c.sec2[i] ? ` و ${fa(c.sec2[i])} ثانیه وصل می‌ماند` : ' و تا لمس بعدی وصل می‌ماند'}. لمس در زمان چشمک، لغو می‌کند.`;
    if (p.type === 'co' || p.type === 'cc') return `<b>${p.type === 'co' ? 'پرده باز' : 'پرده بسته'}:</b> با لمس، پرده ${fa(c.sec1[i])} ثانیه ${p.type === 'co' ? 'باز' : 'بسته'} می‌شود و خودش می‌ایستد. در حین حرکت، لمس همین کلید یا کلید روبرو پرده را فقط متوقف می‌کند.`;
    if (p.type === 'ex' || p.type === 'sl') {
      const n = c.sec1[i] | (c.sec2[i] << 8), when = n < 60 ? `${fa(n)} ثانیه` : n % 60 ? `${fa(Math.floor(n / 60))} دقیقه و ${fa(n % 60)} ثانیه` : `${fa(n / 60)} دقیقه`;
      const lock = n < 60 ? ' در این مدت کلید و ریموت کار نمی‌کنند (دزدگیر کار می‌کند).' : ' لمس دوباره همین کلید در این مدت، آن را لغو می‌کند.';
      if (p.type === 'ex') return `<b>EXIT (خروج):</b> با لمس، چراغ قرمزش روشن می‌شود و بعد از ${when} همه پل‌ها خاموش می‌شوند${c.onmask[i] ? ' و پرده‌ها بسته می‌شوند' : ''}.${lock}`;
      return `<b>SLEEP (خواب):</b> با لمس، چراغ قرمزش روشن می‌شود و بعد از ${when} همه پل‌ها خاموش می‌شوند و ${poleList(pn, c.onmask[i])} به‌عنوان چراغ خواب روشن می‌ماند.${lock}`;
    }
    if (p.type === 'cu') return '<b>سناریو سفارشی:</b> پل‌هایی را که می‌خواهید روشن کنید و این کلید را ۴ ثانیه نگه دارید تا بوق تأیید بزند؛ وضعیت ذخیره شد. از آن به بعد با یک لمس، همان پل‌ها روشن و بقیه خاموش می‌شوند. از برنامه گوشی هم قابل تغییر است.';
    if (p.type === 'gr') return '<b>گروه:</b> پل‌های گروه را روشن کنید و این کلید را ۴ ثانیه نگه دارید تا بوق تأیید بزند. از آن به بعد با یک لمس همه با هم روشن می‌شوند؛ اگر یکی روشن باشد، همه خاموش می‌شوند. از برنامه گوشی هم قابل تغییر است.';
    if (p.type === 'pm') return '<b>پمپ کولر آبی:</b> لمس: روشن و خاموش (جدا از دور کند و تند).';
    if (p.type === 'x') return 'استفاده نمی‌شود.';
    if (p.type === 'el') return '<b>ELEVATOR (آسانسور):</b> کلید را ۱ ثانیه نگه دارید؛ با بوق کوتاه، آسانسور احضار شده است.';
    if (p.type === 'cs' || p.type === 'cf') return `<b>کولر ${p.type === 'cs' ? 'دور کند' : 'دور تند'}:</b> لمس: روشن و خاموش.${c.onmask[i] ? ` با روشن شدن، ${poleList(pn, c.onmask[i])} (پمپ) هم روشن می‌شود.` : ''} اگر دور دیگر روشن باشد، اول خاموش می‌شود و بعد از ۱ ثانیه این دور روشن می‌شود.`;
    let s = 'روشن و خاموش با لمس.';
    if (c.link[i] >= 0 && other) s += ` <b>دوطرفه</b> با پل ${fa(c.link[i] + 1)}${other.poles[c.link[i]] && other.poles[c.link[i]].name ? ` (${esc(other.poles[c.link[i]].name)})` : ''} در «${esc(otherName)}»: از هر دو کلید روشن و خاموش می‌شود.`;
    return s;
  };
  const cell = i => i < n ? `<div class="pc"><div class="pn">${fa(i + 1)}</div><div class="pt">${esc(pn.poles[i].name || 'پل ' + fa(i + 1))}</div></div>` : '<div class="pc empty"></div>';
  const grid = big ? `<div class="psv">${panelSVG(pn, { names: true })}</div>` : n > 2 ? `<div class="grid">${[0, 1, 2, 3].map(cell).join('')}</div>` : `<div class="grid g2">${[0, 1].slice(0, Math.max(1, n)).map(cell).join('')}</div>`;
  /* remotes */
  let rem = '', timerUsed = false;
  if (c.remote && pn.slots && pn.slots.length) {
    rem = pn.slots.map((sl, j) => {
      const lm = libModel(sl.model);
      const rows = lm ? lm.buttons.map(b => {
        const e = sl.map[b.id]; if (b.code === null || !e || !e.poles.length) return '';
        const mask = e.poles.reduce((a, k) => a | (1 << k), 0), single = e.poles.length === 1 && pn.poles[e.poles[0]].type !== 'n';
        let what = single ? `مثل لمس ${poleLabel(pn, e.poles[0])}` : `${poleList(pn, mask)}: ${e.poles.length === 1 && e.act === 't' ? 'روشن / خاموش' : ACT_LABEL[e.act]}`;
        let tm = '';
        if (timerOn(pn, e)) { timerUsed = true; tm = `نگه داشتن: تایمر (پیش‌فرض ${fa(c.tmin[e.td & 3])} دقیقه)`; }
        return `<tr><td>${esc(b.name)}</td><td>${what}</td><td>${tm || '—'}</td></tr>`;
      }).join('') : '';
      return `<div class="rm"><h3>ریموت ${fa(j + 1)} <span>${lm ? esc(lm.name) : ''}</span></h3>
        <table><tr><th>دکمه</th><th>کار</th><th>تایمر</th></tr>${rows || '<tr><td colspan="3">دکمه‌ای تعریف نشده</td></tr>'}</table></div>`;
    }).join('');
  }
  const tminRow = timerUsed ? `<table class="tm"><tr>${[0, 1, 2, 3].map(x => `<th>${fa(x + 1)} بار</th>`).join('')}</tr><tr>${c.tmin.map(v => `<td>${fa(v)} دقیقه</td>`).join('')}</tr></table>` : '';
  const general = [`با وصل شدن برق، چراغ‌های سفید ${big ? 'یکی‌یکی' : n > 2 ? 'به شکل دایره‌ای سه بار' : 'چند لحظه'} روشن می‌شوند؛ بعد کلید آماده است.`];
  if (c.dimsec) general.push(big ? `اگر ${fa(c.dimsec)} ثانیه با کلید کاری نشود و هیچ چراغ قرمزی (جز چراغ خواب و چراغ دزدگیر) روشن نباشد، چراغ‌های کلید یکی‌یکی خاموش می‌شوند. با اولین لمس فقط چراغ‌ها (یکی‌یکی) روشن می‌شوند؛ لمس دوباره کار همان کلید را انجام می‌دهد. فرمان ریموت همان لحظه اجرا می‌شود.`
    : `اگر ${fa(c.dimsec)} ثانیه کلید لمس نشود، نور چراغ‌ها یکی‌یکی کم می‌شود؛ با اولین لمس، نور برمی‌گردد و همان کلید هم کار می‌کند.`);
  if (big) general.push('کلید پایین راست (سناریو ۳): کار سناریو با برداشتن انگشت انجام می‌شود. اگر ۷ ثانیه نگه دارید (با یک بوق)، وای‌فای پنل روشن یا خاموش می‌شود؛ وضعیت وای‌فای با قطع برق حفظ می‌شود.');
  if (hasWifiPn(pn)) general.push(`وای‌فای این پنل: ${pn.ssid ? 'اسم <b dir="ltr">' + esc(pn.ssid) + '</b>' : 'اسمی که با <b dir="ltr">sooden-</b> شروع می‌شود (با ۴ رقم شناسه همین پنل)'}، رمز <b dir="ltr">sooden123</b>.`);
  if (c.beep) general.push(`لمس ${poleList(pn, c.beep)} با یک بوق کوتاه همراه است.`);
  if (c.stagMs && pn.poles.some(p => p.type !== 'n')) general.push('وقتی چند پل با هم روشن یا خاموش می‌شوند، یکی‌یکی و با فاصله کوتاه این کار انجام می‌شود (برای محافظت از برق).');
  const K1 = big ? 'کلید جای ۱ (بالا چپ)' : 'پل ۱', K2 = big ? 'کلید جای ۲ (بالا راست)' : 'پل ۲';
  const meta = [['مشتری', PROJ.customer], ['محل نصب', PROJ.place], ['کلید', panelTitle(t)], ['مدل', big ? bigSub(pn).name : m.name], ['تاریخ', faDate(new Date())], ['نصاب', PROJ.installer], ['تلفن پشتیبانی', PROJ.phone]]
    .filter(x => x[1]).map(x => `<div><span>${x[0]}</span><b>${esc(x[1])}</b></div>`).join('');
  return `<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>راهنمای کلید — ${esc(panelTitle(t))}</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
<style>
:root{--ink:#1d2433;--mute:#5d6678;--line:#d9dee8;--acc:#0b6e8a;--bg:#fff;--soft:#f3f6fa}
*{box-sizing:border-box}body{margin:0;background:#e9edf3;color:var(--ink);font:14px/1.75 Vazirmatn,Tahoma,sans-serif}
.page{max-width:800px;margin:16px auto;background:var(--bg);padding:28px 32px;border-radius:10px;box-shadow:0 2px 12px #0002}
header{display:flex;align-items:center;gap:16px;border-bottom:3px solid var(--acc);padding-bottom:12px}
header img{width:72px;height:auto}header h1{margin:0;font-size:22px}header p{margin:0;color:var(--mute)}
.meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:6px 18px;margin:14px 0;padding:10px 14px;background:var(--soft);border-radius:8px}
.meta span{color:var(--mute);margin-left:6px}
h2{font-size:17px;color:var(--acc);margin:22px 0 8px;border-right:4px solid var(--acc);padding-right:8px}
h3{font-size:15px;margin:10px 0 4px}h3 span{color:var(--mute);font-weight:400;font-size:13px}
.grid{direction:ltr;display:grid;grid-template-columns:1fr 1fr;gap:8px;width:280px;margin:8px auto 12px;padding:10px;border:2px solid var(--line);border-radius:14px}
.grid.g2{grid-template-columns:1fr 1fr}.psv{max-width:560px;margin:8px auto 12px}.psv svg{display:block;width:100%;height:auto;border-radius:8px}.pc{direction:rtl;border:1px solid var(--line);border-radius:10px;padding:8px;text-align:center;min-height:62px}
.pc.empty{border-style:dashed;opacity:.4}.pn{font-weight:700;color:var(--acc)}.pt{font-size:13px}
table{width:100%;border-collapse:collapse;margin:4px 0 8px}th,td{border:1px solid var(--line);padding:5px 8px;text-align:right;vertical-align:top}th{background:var(--soft)}
table.tm td,table.tm th{text-align:center}
ol,ul{margin:4px 0;padding-right:22px}li{margin:2px 0}.note{color:var(--mute);font-size:13px}
.bar{text-align:center;margin:12px}.bar button{font:inherit;padding:8px 22px;border:0;border-radius:8px;background:var(--acc);color:#fff;cursor:pointer}
footer{margin-top:22px;border-top:1px solid var(--line);padding-top:8px;color:var(--mute);font-size:12px;text-align:center}
@media (max-width:600px){.page{padding:18px 16px;margin:0;border-radius:0}.grid{width:100%}}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:none;padding:0}.bar{display:none}h2{break-after:avoid}.rm,table{break-inside:avoid}}
@page{size:A4;margin:14mm}
</style></head><body>
<div class="bar"><button onclick="print()">چاپ / ذخیره PDF</button></div>
<div class="page">
<header><img src="data:image/png;base64,${LOGOB64}" alt=""><div><h1>راهنمای کلید هوشمند</h1><p>گروه فنی مهندسی سودن</p></div></header>
<div class="meta">${meta}</div>
<h2>پل‌های این کلید</h2>${grid}
<table><tr><th>پل</th><th>کار</th></tr>${pn.poles.slice(0, n).map((p, i) => NOREL.includes(p.type) ? '' : `<tr><td>${poleLabel(pn, i)}</td><td>${poleDesc(i)}</td></tr>`).join('')}</table>
${rem ? `<h2>ریموت‌ها</h2><p class="note">ریموت‌ها به همین ترتیب روی کلید یاد داده شده‌اند؛ هر ریموت جدول دکمه‌های خودش را دارد.</p>${rem}` : ''}
${timerUsed ? `<h2>تایمر با ریموت</h2>
<ul><li><b>فشار کوتاه</b> دکمه: کار معمولی همان دکمه.</li>
<li><b>نگه داشتن ۵ ثانیه</b> تا چراغ‌های سفید پل‌های خاموش ۲ بار چشمک بزنند، بعد رها کنید: پل‌های آن دکمه روشن می‌شوند و بعد از زمان تایمر خودکار خاموش می‌شوند.</li>
<li>اگر در این مدت پل را با دست (لمس یا ریموت) خاموش کنید، تایمر لغو می‌شود.</li></ul>
<h3>عوض کردن زمان تایمر یک دکمه</h3>
<ol><li>دکمه را نگه دارید؛ بعد از ۵ ثانیه ۲ چشمک، ادامه دهید تا در ۱۵ ثانیه ۲ چشمک دیگر بزند؛ رها کنید.</li>
<li>همان دکمه را به تعداد زمان دلخواه (۱ تا ۴ بار) فشار دهید؛ هر فشار یک چشمک.</li>
<li>۱۰ ثانیه صبر کنید: زمان ذخیره می‌شود و چراغ به تعداد انتخاب شما چشمک می‌زند.</li></ol>
${tminRow}
<p class="note">اگر بعد از ورود به این حالت ۱۰ ثانیه دکمه‌ای نزنید، چیزی عوض نمی‌شود. زمان انتخاب‌شده با قطع برق پاک نمی‌شود.</p>` : ''}
${rem ? `<h2>یاد دادن و پاک کردن ریموت</h2>
<ol><li><b>یاد دادن ریموت جدید:</b> ${K1} را ۵ ثانیه نگه دارید تا چراغ سفیدش چشمک بزند؛ رها کنید و ظرف ۵ ثانیه یک دکمه ریموت را بزنید. ریموت در اولین جای خالی ذخیره می‌شود.</li>
<li><b>عوض کردن ریموت شماره N</b> (مثلاً ریموت گم‌شده): ${K1} را ۵ ثانیه نگه دارید؛ بعد از چشمک، ${big ? 'کلید جای N (جای ۱ تا ۴)' : 'پل N'} را لمس کنید و سپس دکمه ریموت جدید را بزنید. ریموت جدید کار همان ریموت قبلی را انجام می‌دهد.</li>
<li><b>پاک کردن همه ریموت‌ها:</b> ${K2} را ۵ ثانیه نگه دارید تا چشمک بزند؛ رها کنید و یک بار دیگر ${K2} را لمس کنید.</li></ol>
<p class="note">این کلید برای ${fa(c.nslot || n)} ریموت تنظیم شده است.</p>` : ''}
${c.alarm ? `<h2>دزدگیر</h2>
<ul><li><b>فعال کردن:</b> کلید ON / OFF را لمس کنید تا چراغ رقم‌ها روشن شود؛ رمز ۴ رقمی را بزنید. چراغ قرمز ON / OFF روشن می‌شود${c.alArm ? ` و دزدگیر ${fa(c.alArm)} ثانیه بعد فعال می‌شود (آژیر یک بوق کوتاه می‌زند)` : ' و دزدگیر همان لحظه فعال می‌شود (آژیر یک بوق کوتاه می‌زند)'}.</li>
<li><b>غیرفعال کردن:</b> ON / OFF را لمس کنید و رمز را بزنید؛ چراغ قرمز خاموش می‌شود.</li>
<li><b>ورود به خانه وقتی دزدگیر فعال است:</b> چراغ رقم‌ها خودش روشن می‌شود و قرمز ON / OFF چشمک می‌زند؛ ${fa(c.alEntry)} ثانیه برای زدن رمز وقت دارید. اگر رمز زده نشود، آژیر ${fa(c.alSiren)} ثانیه می‌زند و بعد دزدگیر دوباره آماده می‌شود.</li>
<li><b>رمز اشتباه:</b> چراغ رقم‌ها خاموش می‌شود؛ دوباره ON / OFF را لمس کنید و رمز را بزنید.</li>
<li><b>عوض کردن رمز</b> (فقط وقتی دزدگیر غیرفعال است): کلید change pass را ۲ ثانیه نگه دارید تا قرمزش روشن شود؛ رمز جدید ۴ رقمی را بزنید.</li>
<li>رقم‌ها فقط وقتی چراغشان روشن است رمز قبول می‌کنند. رمز اولیه: ۱۲۳۴. با قطع برق، رمز و فعال بودن دزدگیر پاک نمی‌شود.</li></ul>` : ''}
<h2>نکته‌ها</h2><ul>${general.map(x => `<li>${x}</li>`).join('')}</ul>
<footer>گروه فنی مهندسی سودن${PROJ.phone ? ' — پشتیبانی: ' + esc(PROJ.phone) : ''}</footer>
</div></body></html>`;
}
function openBrochure(t) {
  const w = window.open(URL.createObjectURL(new Blob([brochureHtml(t)], { type: 'text/html;charset=utf-8' })), '_blank');
  if (!w) alert('مرورگر پنجره جدید را بست؛ اجازه باز شدن پنجره (pop-up) را بده.');
}
function downloadBrochure(t) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([brochureHtml(t)], { type: 'text/html;charset=utf-8' })); a.download = archiveName(t) + '.html';
  document.body.appendChild(a); a.click(); a.remove();
}
async function archiveBrochure(t) {
  if (!HELPER.token) return { ok: false, code: 'nohelper' };
  try { return await helper('/api/archive?name=' + encodeURIComponent(archiveName(t)), { method: 'POST', body: brochureHtml(t) }); }
  catch (e) { return { ok: false, code: 'conn' }; }
}
function projHtml() {
  const f = (k, l, ph) => `<label class="pj"><span>${l}</span><input type="text" class="pjf" data-k="${k}" value="${esc(PROJ[k])}" placeholder="${ph}"></label>`;
  const names = targets().filter(t => t.cfg).map(t => { const pn = panelByKey(t.key);
    return `<label class="pj"><span>اسم ${t.key === 'S' ? 'کلید' : 'پنل ' + t.key}</span><input type="text" class="pjn" data-p="${t.key}" value="${esc(pn.name || '')}" placeholder="مثلاً کلید پذیرایی"></label>`; }).join('');
  return `<div class="pole projbox"><b>مشخصات پروژه (برای بروشور مشتری)</b>
    <div class="pjgrid">${f('customer', 'مشتری', 'مثلاً آقای رضایی')}${f('place', 'محل نصب', 'مثلاً تهران، واحد ۵')}${names}${f('installer', 'نصاب', 'اسم نصاب')}${f('phone', 'تلفن پشتیبانی', '۰۹۱۲…')}</div>
    <p class="locked" style="margin:4px 0 0">بعد از پروگرم موفق، بروشور هر پنل خودکار در پوشه archive کنار SoodenProg.exe ذخیره می‌شود. اسم پل‌ها را در مرحله برنامه پنل بنویس.</p></div>`;
}
function bindProj() {
  document.querySelectorAll('.pjf').forEach(c => c.oninput = () => { PROJ[c.dataset.k] = c.value.trim(); if (c.dataset.k === 'installer' || c.dataset.k === 'phone') projSaveInstaller(); });
  document.querySelectorAll('.pjn').forEach(c => c.oninput = () => { panelByKey(c.dataset.p).name = c.value.trim(); });
}
