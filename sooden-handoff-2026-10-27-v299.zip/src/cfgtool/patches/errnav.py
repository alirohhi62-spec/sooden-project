p='/home/claude/cfgtool/wizard.src.html'; s=open(p,encoding='utf-8').read()
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,(a[:90],s.count(a)); s=s.replace(a,b)
def cut(start,end,new):
    global s
    i=s.index(start); j=s.index(end,i); s=s[:i]+new+s[j:]

rep(""".confirm{border:2px solid var(--red);""",""".errgo{cursor:pointer}
.errgo:hover{filter:brightness(.95)}
.errgo .go{float:left;font-size:12px;text-decoration:underline;margin-right:10px}
.errfocus{outline:3px solid var(--red);outline-offset:2px;border-radius:8px;animation:errpulse .7s ease-in-out 4}
@keyframes errpulse{50%{outline-color:transparent}}
.errbub{position:absolute;z-index:50;max-width:340px;background:var(--red);color:#fff;padding:10px 12px;border-radius:10px;font-size:13px;line-height:1.8;box-shadow:0 6px 24px rgba(0,0,0,.25)}
.errbub:before{content:"";position:absolute;top:-7px;right:22px;border:7px solid transparent;border-top:0;border-bottom-color:var(--red)}
.errbub b{display:block;margin-bottom:2px}
.newmodel{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:8px;padding:8px;border:1px dashed var(--line);border-radius:10px}
.newmodel input,.newmodel select{font:inherit;border:1px solid var(--line);border-radius:8px;padding:5px 8px;background:var(--panel);color:var(--ink)}
.rtab input.scode{width:84px}
.confirm{border:2px solid var(--red);""")

rep("""const LIB_DEFAULT = { models: [{ id: 'm4', name: 'ریموت ۴ کانال (A B C D)', buttons: [
  { name: 'A', code: 1 }, { name: 'B', code: 2 }, { name: 'C', code: 4 }, { name: 'D', code: 8 }] }] };""",
"""const LIB_DEFAULT = { models: [{ id: 'm4', name: 'ریموت ۴ کانال (A B C D)', buttons: [
  { id: 'bA', name: 'A', code: 1 }, { id: 'bB', name: 'B', code: 2 }, { id: 'bC', name: 'C', code: 4 }, { id: 'bD', name: 'D', code: 8 }] }] };
let UID = 0;
const uid = p => p + Date.now().toString(36) + (UID++).toString(36);
/* every button gets a fixed id: a place's table points at buttons, not at codes, so a button
   whose code is not known yet can already be given its poles */
function libNormalize(lib) {
  (lib.models || []).forEach(m => { if (!m.id) m.id = uid('m'); (m.buttons || (m.buttons = [])).forEach(b => { if (!b.id) b.id = uid('b'); if (b.code === undefined) b.code = null; }); });
  return lib;
}
function newModel(name, n) {
  const m = { id: uid('m'), name: name || 'مدل جدید', buttons: [] };
  for (let i = 0; i < n; i++) m.buttons.push({ id: uid('b'), name: 'دکمه ' + fa(i + 1), code: null, raw: '' });
  LIB.models.push(m);
  return m;
}""")
rep("""  if (m) m.buttons.forEach((b, k) => { if (k < 4 && b.code !== null) map[b.code] = { poles: [k], act: 't' }; });""",
    """  if (m) m.buttons.forEach((b, k) => { if (k < 4) map[b.id] = { poles: [k], act: 't' }; });""")
rep("""  try { const v = JSON.parse(localStorage.getItem('sooden_remotes') || 'null'); if (v && v.models && v.models.length) LIB = v; } catch (e) { }
  if (!HELPER.token) return;
  try { const r = await helper('/api/lib'); if (r && r.models && r.models.length) { LIB = r; libSaveLocal(); render(); } } catch (e) { }""",
"""  try { const v = JSON.parse(localStorage.getItem('sooden_remotes') || 'null'); if (v && v.models && v.models.length) LIB = libNormalize(v); } catch (e) { }
  if (!HELPER.token) return;
  try { const r = await helper('/api/lib'); if (r && r.models && r.models.length) { LIB = libNormalize(r); libSaveLocal(); render(); } } catch (e) { }""")
rep("let LIB = JSON.parse(JSON.stringify(LIB_DEFAULT)), LIBOPEN = false, LIBSTATE = '';","let LIB, LIBOPEN = false, LIBSTATE = '';")
rep("function newSlot(modelId) {","LIB = JSON.parse(JSON.stringify(LIB_DEFAULT));\nfunction newSlot(modelId) {")

cut("  const slot = (sl, j) => {", "  return `<div class=\"pole\"><b>ریموت‌های این پنل", r'''  const slot = (sl, j) => {
    const m = libModel(sl.model), mi = LIB.models.indexOf(m);
    const opts = `<option value="">— مدل ریموت —</option>` + LIB.models.map(x => `<option value="${x.id}" ${x.id === sl.model ? 'selected' : ''}>${esc(x.name)} (${fa(x.buttons.length)} دکمه)</option>`).join('')
      + '<option value="__new">+ ساخت مدل جدید…</option>';
    const rows = m ? m.buttons.map((b, bi) => {
      const e = sl.map[b.id] || { poles: [], act: 't' };
      const poles = pn.poles.map((q, k) => `<label class="chk"><input type="checkbox" class="spole" data-p="${key}" data-s="${j}" data-bid="${b.id}" data-k="${k}" ${e.poles.includes(k) ? 'checked' : ''}>${fa(k + 1)}</label>`).join('');
      const single = e.poles.length === 1 && pn.poles[e.poles[0]].type !== 'n';
      return `<tr><td>${esc(b.name)}</td>
        <td><input type="text" class="scode" data-p="${key}" data-s="${j}" data-bid="${b.id}" data-m="${mi}" data-b="${bi}" value="${b.raw !== undefined && b.raw !== '' ? esc(b.raw) : b.code === null ? '' : b.code}" placeholder="کد">
          ${b.code === null ? '' : `<span class="locked">= ${fa(b.code)}</span>`}</td>
        <td>${poles}</td>
        <td>${!e.poles.length ? '<span class="locked">کاری نمی‌کند</span>' : single ? '<span class="locked">مثل لمس همان پل</span>' : `<select class="sact" data-p="${key}" data-s="${j}" data-bid="${b.id}">${Object.keys(ACT_LABEL).map(a => `<option value="${a}" ${e.act === a ? 'selected' : ''}>${ACT_LABEL[a]}</option>`).join('')}</select>`}</td></tr>`;
    }).join('') : '';
    const form = sl.creating ? `<div class="newmodel" data-p="${key}" data-s="${j}"><b>مدل جدید:</b>
        <input type="text" class="nmname" placeholder="اسم، مثلاً ریموت ۱۲ کانال" value="">
        <label>تعداد کانال <select class="nmcount">${[...Array(16)].map((_, i) => `<option value="${i + 1}" ${i === 3 ? 'selected' : ''}>${fa(i + 1)}</option>`).join('')}</select></label>
        <button class="btn sm primary nmok" data-p="${key}" data-s="${j}">ساخت</button><button class="btn sm nmno" data-p="${key}" data-s="${j}">انصراف</button></div>` : '';
    return `<div class="rtype" data-slot="${key}-${j}"><div class="pole-head"><h4 style="margin:0">ریموت ${fa(j + 1)}</h4><select class="smodel" data-p="${key}" data-s="${j}">${opts}</select>
        <button class="btn sm sdel" data-p="${key}" data-s="${j}">حذف</button></div>${form}
      <div class="locked" style="margin-top:4px">یاد دادن: نگه داشتن پل ۱ (۵ ثانیه) → اولین جای خالی؛ برای همین جای ${fa(j + 1)}: بعد از چشمک، پل ${fa(j + 1)} را لمس کن، بعد دکمه ریموت.</div>
      ${!sl.model ? '<div class="msg warn" style="margin-top:6px">مدل ریموت انتخاب نشده.</div>' : !m ? '<div class="msg err" style="margin-top:6px">این مدل در کتابخانه نیست.</div>'
        : `<table class="rtab"><tr><th>دکمه</th><th>کد (۰۱۰۰ یا ۴)</th><th>پل‌ها</th><th>کار</th></tr>${rows || '<tr><td colspan="4" class="locked">این مدل دکمه‌ای ندارد.</td></tr>'}</table>
           <div class="locked">کد دکمه‌ها در مدل «${esc(m.name)}» کتابخانه ذخیره می‌شود و برای همه پروژه‌ها می‌ماند.</div>`}</div>`;
  };
''')

rep("""  const ent = c => { const m = sl(c).map; return m[c.dataset.c] || (m[c.dataset.c] = { poles: [], act: 't' }); };
  root.querySelectorAll('.smodel').forEach(c => c.onchange = () => { panelByKey(c.dataset.p).slots[+c.dataset.s] = newSlot(c.value); render(); });""",
"""  const ent = c => { const m = sl(c).map; return m[c.dataset.bid] || (m[c.dataset.bid] = { poles: [], act: 't' }); };
  root.querySelectorAll('.smodel').forEach(c => c.onchange = () => {
    if (c.value === '__new') { sl(c).creating = true; render(); const f = document.querySelector(`.newmodel[data-p="${c.dataset.p}"][data-s="${c.dataset.s}"] .nmname`); if (f) f.focus(); return; }
    panelByKey(c.dataset.p).slots[+c.dataset.s] = newSlot(c.value); render();
  });
  root.querySelectorAll('.nmno').forEach(b => b.onclick = () => { sl(b).creating = false; render(); });
  root.querySelectorAll('.nmok').forEach(b => b.onclick = () => {
    const box = b.closest('.newmodel'), n = +box.querySelector('.nmcount').value, nm = box.querySelector('.nmname').value.trim() || ('ریموت ' + fa(n) + ' کانال');
    const m = newModel(nm, n);
    panelByKey(b.dataset.p).slots[+b.dataset.s] = newSlot(m.id);
    libSave().then(() => render()); render();
  });
  root.querySelectorAll('.scode').forEach(c => c.onchange = () => {
    const bt = LIB.models[+c.dataset.m].buttons[+c.dataset.b]; bt.raw = c.value.trim(); bt.code = parseCode(c.value);
    libSave().then(() => render()); render();
  });""")
rep("""  root.querySelectorAll('.lbadd').forEach(b => b.onclick = () => { const m = lm(b); m.buttons.push({ name: 'دکمه ' + fa(m.buttons.length + 1), code: null, raw: '' }); LIBOPEN = true; libChanged(); });""",
    """  root.querySelectorAll('.lbadd').forEach(b => b.onclick = () => { const m = lm(b); m.buttons.push({ id: uid('b'), name: 'دکمه ' + fa(m.buttons.length + 1), code: null, raw: '' }); LIBOPEN = true; libChanged(); });""")
rep("""  root.querySelectorAll('.lnew').forEach(b => b.onclick = () => { LIB.models.push({ id: 'm' + Date.now(), name: 'مدل جدید', buttons: [] }); LIBOPEN = true; libChanged(); });""",
    """  root.querySelectorAll('.lnew').forEach(b => b.onclick = () => { newModel('مدل جدید', 0); LIBOPEN = true; libChanged(); });""")
rep("""    f.text().then(t => { try { const v = JSON.parse(t); if (!v.models) throw 0; LIB = v; LIBOPEN = true; libChanged(); } catch (e) { alert('فایل کتابخانه معتبر نیست.'); } });""",
    """    f.text().then(t => { try { const v = JSON.parse(t); if (!v.models) throw 0; LIB = libNormalize(v); LIBOPEN = true; libChanged(); } catch (e) { alert('فایل کتابخانه معتبر نیست.'); } });""")
rep("""        if (mi === 'new') { LIB.models.push({ id: 'm' + Date.now(), name: 'مدل جدید', buttons: [] }); mi = LIB.models.length - 1; }""",
    """        if (mi === 'new') { newModel('مدل جدید', 0); mi = LIB.models.length - 1; }""")
rep("""        m.buttons.push({ name: out.querySelector('.lastn').value.trim() || ('دکمه ' + fa(code)), code, raw: code.toString(2).padStart(4, '0') });""",
    """        m.buttons.push({ id: uid('b'), name: out.querySelector('.lastn').value.trim() || ('دکمه ' + fa(code)), code, raw: code.toString(2).padStart(4, '0') });""")
rep("""      m.buttons.forEach(b => {
        const e = sl.map[b.code];
        if (b.code === null || !e || !e.poles.length) return;""","""      m.buttons.forEach(b => {
        const e = sl.map[b.id];
        if (b.code === null || !e || !e.poles.length) return;""")

cut("function checks() {", "function fwHex(id)", open('/home/claude/cfgtool/patches/checks.js',encoding='utf-8').read())
rep("""  h += errs.length ? errs.map(e => `<div class="msg err">${e}</div>`).join('') : '<div class="msg ok">همه تنظیمات معتبر است.</div>';""",
    """  h += errs.length ? `<div class="msg warn">برای پروگرم، ${fa(errs.length)} ایراد باید برطرف شود. روی هر خطا بزن تا به محلش بروی.</div>` + errs.map((e, i) => `<div class="msg err errgo" data-err="${i}" title="رفتن به محل خطا">خطا: ${esc(e.msg)}<span class="go">رفتن به محل خطا ←</span></div>`).join('') : '<div class="msg ok">همه تنظیمات معتبر است.</div>';""")
rep("""function bindFinish() {
  const ts = targets();""","""function bindFinish() {
  const ts = targets(), errs = checks();
  document.querySelectorAll('.errgo').forEach(d => d.onclick = () => goToError(errs[+d.dataset.err]));""")
rep("""  v[1]();
  renderFrame();""","""  v[1]();
  renderFrame();
  showErrFocus();""")
open(p,'w',encoding='utf-8').write(s)
print('ok')
