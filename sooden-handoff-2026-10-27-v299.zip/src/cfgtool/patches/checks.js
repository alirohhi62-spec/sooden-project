/* every error knows where it is (step + element) and how to fix it (help) */
function progStep() { return W.mode === 'single' ? 'prog' : W.mode === 'pair' ? 'pairprog' : 'cpuroles'; }
function checks() {
  const errs = [], E = (msg, sel, help, lib) => errs.push({ msg, sel, help, lib, step: progStep() });
  const roleErr = (pn, title, key) => pn.poles.forEach((p, i) => {
    if (p.type === 't' && !p.on.length) E(`${title} پل ${fa(i + 1)}: سناریو سرویس هیچ پلی برای روشن کردن ندارد.`, `.ptype[data-p="${key}"][data-i="${i}"]`,
      'برای سناریو سرویس حداقل یک پل را در ردیف «روشن کند» تیک بزن، یا نوع این پل را «پل معمولی» کن.');
    if (p.type === 'm' && !pn.poles.some((q, k) => k !== i && q.type === 'n')) E(`${title} پل ${fa(i + 1)}: مستر پل معمولی برای کنترل ندارد.`, `.ptype[data-p="${key}"][data-i="${i}"]`,
      'مستر فقط پل‌های معمولی را روشن و خاموش می‌کند. حداقل یکی از پل‌های دیگر را «پل معمولی» کن.');
  });
  const rmtErr = (pn, title, key) => {
    const m = MODEL(pn.model);
    if (!m.features.includes('remote') || !hasRemote(key) || !pn.slots) return;
    if (!pn.slots.length) E(`${title}: هیچ ریموتی تعریف نشده.`, `.sadd[data-p="${key}"]`,
      'این پنل ماژول ریموت دارد ولی هیچ ریموتی برایش تعریف نشده. «+ افزودن ریموت» را بزن و مدلش را انتخاب کن.');
    pn.slots.forEach((sl, t) => {
      const nm = `${title} ریموت ${fa(t + 1)}`, lm = libModel(sl.model);
      if (!lm) { E(`${nm}: مدل ریموت انتخاب نشده.`, `.smodel[data-p="${key}"][data-s="${t}"]`,
        'از این فهرست مدل ریموت را انتخاب کن. اگر مدلش نیست، «+ ساخت مدل جدید…» را انتخاب کن.'); return; }
      const seen = {};
      lm.buttons.forEach(b => {
        const at = `.scode[data-p="${key}"][data-s="${t}"][data-bid="${b.id}"]`;
        if (b.code === null) {
          E(`${nm} (${lm.name})، ${b.name}: کد دکمه وارد نشده یا نامعتبر است.`, at,
            (b.raw ? `«${b.raw}» قابل فهم نیست. ` : 'کد این دکمه خالی است. ') + 'کد را به شکل باینری ۴ رقمی (مثل 0100)، عدد ۰ تا ۱۵ (مثل 4) یا کد کامل ۶ رقمی وارد کن؛ یا دکمه ریموت را کنار پنل بزن و «خواندن آخرین دکمه از پنل» را بزن. اگر این دکمه را لازم نداری، در کتابخانه حذفش کن.');
          return;
        }
        if (seen[b.code]) E(`${nm} (${lm.name})، ${b.name}: کد ${fa(b.code)} تکراری است.`, at,
          `کد ${fa(b.code)} قبلاً برای «${seen[b.code]}» همین مدل وارد شده. هر دکمه کد خودش را دارد؛ کد درست را دوباره بخوان یا یکی را حذف کن.`);
        seen[b.code] = b.name;
        const e = sl.map[b.id];
        if (e && e.poles.length > 1 && e.poles.some(k => pn.poles[k].type !== 'n')) E(`${nm}، ${b.name}: پل سناریو با پل‌های دیگر روی یک دکمه آمده.`, `.spole[data-p="${key}"][data-s="${t}"][data-bid="${b.id}"]`,
          'پل مستر یا سرویس فقط به‌تنهایی روی یک دکمه می‌آید (مثل لمس همان پل). یا فقط همان پل را تیک بزن، یا آن را بردار.');
      });
    });
  };
  if (W.mode === 'single') { roleErr(W.single, 'پنل', 'S'); rmtErr(W.single, 'پنل', 'S'); }
  if (W.mode === 'pair') { roleErr(W.pair.A, 'پنل A', 'A'); roleErr(W.pair.B, 'پنل B', 'B'); rmtErr(W.pair.A, 'پنل A', 'A'); rmtErr(W.pair.B, 'پنل B', 'B'); }
  return errs;
}
/* go to an error: open its step, scroll to it, flash it and show a bubble with the fix */
let ERRFOCUS = null;
function goToError(e) {
  W.step = Math.max(0, steps().findIndex(s => s[0] === e.step));
  if (e.lib) LIBOPEN = true;
  ERRFOCUS = e; render();
}
function showErrFocus() {
  document.querySelectorAll('.errbub').forEach(x => x.remove());
  document.querySelectorAll('.errfocus').forEach(x => x.classList.remove('errfocus'));
  const e = ERRFOCUS; ERRFOCUS = null;
  if (!e) return;
  const el = document.querySelector(e.sel);
  if (!el) return;
  const box = el.closest('tr') || el.closest('.pole') || el;
  box.classList.add('errfocus');
  box.scrollIntoView({ block: 'center' });
  const r = el.getBoundingClientRect(), bub = document.createElement('div');
  bub.className = 'errbub';
  bub.innerHTML = `<b>${esc(e.msg)}</b>${esc(e.help)}`;
  document.body.appendChild(bub);
  const w = bub.offsetWidth;
  bub.style.top = (window.scrollY + r.bottom + 10) + 'px';
  bub.style.left = Math.max(8, Math.min(window.scrollX + r.right - w, window.scrollX + document.documentElement.clientWidth - w - 8)) + 'px';
  if (el.focus) try { el.focus({ preventScroll: true }); } catch (x) { }
  const done = () => { bub.remove(); box.classList.remove('errfocus'); document.removeEventListener('mousedown', close, true); };
  const close = ev => { if (!bub.contains(ev.target) && ev.target !== el) done(); };
  setTimeout(() => document.addEventListener('mousedown', close, true), 0);
  el.addEventListener('change', done, { once: true });
}
