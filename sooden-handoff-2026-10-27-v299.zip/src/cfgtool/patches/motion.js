/* ---------- programming motion: PCB traces from the ISP connector to the chip (Sooden logo) ---------- */
const PM_STEPS = [['شناسایی میکرو', 2000], ['فیوز', 2500], ['نوشتن فلش', 9000], ['بازخوانی و تأیید', 4000]];
function progMotion(box) {
  box.innerHTML = `<div class="pm"><svg class="pmsvg" viewBox="0 0 300 190">
      <rect class="pmic" x="14" y="50" width="96" height="90" rx="8"/>
      ${[0, 1, 2, 3, 4, 5].map(k => `<rect class="pmpin" x="6" y="${60 + k * 13}" width="8" height="5" rx="1"/><rect class="pmpin" x="110" y="${60 + k * 13}" width="8" height="5" rx="1"/>`).join('')}
      <image href="/*LOGO*/" x="24" y="58" width="76" height="68" preserveAspectRatio="xMidYMid meet"/>
      ${[40, 80, 120, 160].map(y => `<circle class="pmpad" cx="272" cy="${y}" r="7"/>`).join('')}
      <path class="pmtr" d="M265 40 H205 L175 70 H118"/><path class="pmtr" d="M265 80 H185 L170 88 H118"/>
      <path class="pmtr" d="M265 120 H185 L170 104 H118"/><path class="pmtr" d="M265 160 H205 L175 122 H118"/>
      <text class="pmisp" x="262" y="185">ISP</text></svg>
    <div class="pmst"><span class="pmlbl">۱/۴ — ${PM_STEPS[0][0]}…</span><b class="pmpc">۰٪</b></div><div class="pmbar"><i></i></div>
    <p class="locked" style="margin:6px 0 0">کابل را جدا نکن.</p></div>`;
  const svg = box.querySelector('svg'), base = [...svg.querySelectorAll('.pmtr')], pads = [...svg.querySelectorAll('.pmpad')];
  const live = base.map(p => { const e = p.cloneNode(); e.setAttribute('class', 'pmtr live'); svg.appendChild(e); return e; });
  const lens = base.map(p => p.getTotalLength ? p.getTotalLength() : 200);
  const lbl = box.querySelector('.pmlbl'), pc = box.querySelector('.pmpc'), bar = box.querySelector('.pmbar i'), pm = box.querySelector('.pm');
  const total = PM_STEPS.reduce((a, s) => a + s[1], 0), t0 = performance.now();
  let raf = 0, stopped = false;
  const draw = (i, f) => {
    live.forEach((e, k) => { const fr = k < i ? 1 : k === i ? f : 0; e.style.strokeDasharray = lens[k]; e.style.strokeDashoffset = lens[k] * (1 - fr); });
    pads.forEach((d, k) => d.classList.toggle('live', k <= i));
  };
  const tick = now => {
    if (stopped) return;
    let t = Math.max(0, now - t0), acc = 0, i = 0;
    while (i < PM_STEPS.length - 1 && t >= acc + PM_STEPS[i][1]) { acc += PM_STEPS[i][1]; i++; }
    const f = Math.min(0.95, (t - acc) / PM_STEPS[i][1]);           /* never shows "done" before the real result */
    draw(i, f);
    const p = Math.min(0.97, (acc + f * PM_STEPS[i][1]) / total);
    lbl.textContent = `${fa(i + 1)}/۴ — ${PM_STEPS[i][0]}…`; pc.textContent = fa(Math.round(p * 100)) + '٪'; bar.style.width = (p * 100) + '%';
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
  return {
    finish(ok, step) {
      stopped = true; cancelAnimationFrame(raf);
      if (ok) { draw(4, 1); pm.classList.add('ok'); lbl.textContent = 'پروگرم شد و تأیید شد ✔'; pc.textContent = '۱۰۰٪'; bar.style.width = '100%'; }
      else {
        const i = step === 'identify' ? 0 : step === 'fuses' ? 1 : step === 'flash' ? 2 : 0;
        draw(i, 0.5); pm.classList.add('bad'); lbl.textContent = `متوقف شد در مرحله ${fa(i + 1)}: ${PM_STEPS[i][0]}`;
      }
      box.querySelector('.locked').remove();
    }
  };
}
