/* ===================== project file: one HTML page for the customer's folder =====================
   It shows every panel (model, network number, chips, keys, links, remotes) with a download button for each hex,
   and carries the whole project (settings + the exact hex files) so the programmer can open it again. */
const PROJ_VER = 1;
let SAVED = null;                       /* opened project: { hex: { id: text } } */
const USE_NEW = {};                     /* id -> true: the newer firmware instead of the saved hex */
const tid = t => t.key + ':' + (t.step || 0);
function savedHexFor(t) { return SAVED && SAVED.hex[tid(t)] && !USE_NEW[tid(t)] ? SAVED.hex[tid(t)] : null; }
function freshHex(t) { const k = tid(t), u = USE_NEW[k]; USE_NEW[k] = true; try { return targetHex(t); } finally { if (u) USE_NEW[k] = u; else delete USE_NEW[k]; } }
function projName() {
  const clean = s => String(s || '').replace(/[\/\\:*?"<>|\x00-\x1f]/g, ' ').replace(/\s+/g, ' ').trim();
  return ['پروژه', latinDate(new Date()), clean(PROJ.customer), clean(PROJ.place)].filter(Boolean).join(' - ').slice(0, 140).replace(/[. ]+$/, '');
}
function hexFileName(t) {
  const clean = s => String(s || '').replace(/[\/\\:*?"<>|\x00-\x1f]/g, ' ').replace(/\s+/g, ' ').trim();
  return clean(groupTitle(t.key) + (t.step ? ' - مرحله ' + t.step : '') + (t.fname ? ' - ' + t.fname : '')) + '.hex';
}
/* readable description of a panel's keys */
function keyLines(pn, key) {
  if (!pn || !pn.poles) return [];
  const peer = W.mode === 'pair' ? W.pair[otherSide(key)] : null;
  return pn.poles.map((p, i) => {
    if (!p || (pn.big && pn.lay && pn.lay[i] && pn.lay[i][0] === 'x' && p.type === 'x')) return '';
    let d = TYPE_LABEL[p.type] || p.type;
    if (p.type === 'ex' || p.type === 'sl') d += ` — ${fa(p.secs | 0)} ثانیه`;
    if (['do', 'p', 'dl', 'co', 'cc'].includes(p.type)) d += ` — ${fa(p.sec | 0)} ثانیه`;
    if (p.type === 'ot' || p.type === 't') d += ` — ${fa(p.min | 0)} دقیقه`;
    if (W.mode === 'pair' && peer) { const l = peerOf(key, i); if (l >= 0) d += ` — تبدیل با ${otherSide(key)}${plabS(peer, l)}`; }
    return `<tr><td>${esc(plab(pn, i))}</td><td>${esc(p.name || '')}</td><td>${esc(d)}</td></tr>`;
  });
}
function remoteLines(pn) {
  if (!pn || !pn.slots || !pn.slots.length || pn.remote === false) return '';
  return '<ul>' + pn.slots.map((sl, j) => { const m = libModel(sl.model);
    return `<li>ریموت ${fa(j + 1)}: ${esc(m ? m.name : '—')}${m ? ' — ' + m.buttons.map(b => { const e = sl.map[b.id]; return esc(b.name) + ': ' + (e && e.poles.length ? e.poles.map(k => plabS(pn, k)).join('+') : '—'); }).join('، ') : ''}</li>`; }).join('') + '</ul>';
}
function projectHtml() {
  const ts = targets().filter(t => !t.pending), hex = {}, files = [];
  ts.forEach(t => { const h = targetHex(t); hex[tid(t)] = h; files.push({ id: tid(t), name: hexFileName(t) }); });
  const libUsed = { models: LIB.models.filter(m => JSON.stringify(W).includes(m.id)) };
  const data = { ver: PROJ_VER, app: 'SoodenProg', saved: new Date().toISOString(), W: Object.assign({}, W, { step: 0 }), LIB: libUsed, PROJ, hex, files };
  const keys = [...new Set(ts.map(t => t.key))];
  const sec = k => {
    const pn = panelByKey(k), st = ts.filter(t => t.key === k);
    return `<section><h2>${esc(groupTitle(k))}</h2>
      <table class="st"><tr><th>مرحله</th><th>میکرو</th><th>فیوز</th><th></th></tr>${st.map(t => { const c = chipOf(t.variant);
        return `<tr><td>${esc(t.label)}</td><td>${esc(t.variant.mcu)}</td><td>${c ? `L ${fhex(c.lfuse)} · H ${fhex(c.hfuse)}${c.efuse !== undefined ? ' · E ' + fhex(c.efuse) : ''}` : ''}</td><td><button data-id="${esc(tid(t))}">دانلود hex</button></td></tr>`; }).join('')}</table>
      <table><tr><th>کلید</th><th>اسم</th><th>کار</th></tr>${keyLines(pn, k).join('')}</table>${remoteLines(pn)}</section>`;
  };
  const json = JSON.stringify(data).replace(/</g, '\\u003c');
  return `<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(projName())}</title>
<style>body{font-family:Tahoma,Vazirmatn,sans-serif;background:#f4f4f6;color:#222;margin:0;padding:18px}h1{font-size:20px}section{background:#fff;border:2px solid #c8102e;border-radius:12px;padding:12px 16px;margin:14px 0}
h2{font-size:16px;color:#c8102e;margin:0 0 8px}table{border-collapse:collapse;width:100%;margin:6px 0;font-size:13px}td,th{border-bottom:1px solid #ddd;padding:5px 6px;text-align:right}
button{font:inherit;padding:4px 12px;border:1px solid #c8102e;background:#fff;color:#c8102e;border-radius:8px;cursor:pointer}.meta td{border:0;padding:2px 8px}.note{background:#fff7d6;border:1px solid #e3c96a;border-radius:8px;padding:8px 12px}</style></head><body>
<h1>پروژه سودن — ${esc(PROJ.customer || 'بدون اسم مشتری')}</h1>
<table class="meta"><tr><td>محل نصب</td><td>${esc(PROJ.place || '')}</td></tr><tr><td>تاریخ</td><td>${esc(faDate(new Date()))}</td></tr><tr><td>نصاب</td><td>${esc(PROJ.installer || '')} ${esc(PROJ.phone || '')}</td></tr><tr><td>نوع</td><td>${esc({ single: 'تک پنل', pair: 'دو پنل شبکه‌ای', seg: 'شبکه سون سگمنت', cpu: 'شبکه با CPU' }[W.mode] || '')}</td></tr></table>
<p class="note">پنل تعویضی: هگز همان پنل (و هر مرحله‌اش) را با دیپ‌سوئیچ روی همان میکرو بزن؛ بعد ریموت‌های مشتری را دوباره یاد بده (نقشه دکمه‌ها داخل هگز است). برای ویرایش، این فایل را در پروگرمر سودن با «باز کردن پروژه» باز کن.</p>
${keys.map(sec).join('')}
<script type="application/json" id="sooden-project">${json}<\/script>
<script>(function(){var d=JSON.parse(document.getElementById('sooden-project').textContent);document.querySelectorAll('button[data-id]').forEach(function(b){b.onclick=function(){var f=d.files.filter(function(x){return x.id===b.dataset.id})[0];var a=document.createElement('a');a.href=URL.createObjectURL(new Blob([d.hex[b.dataset.id]],{type:'text/plain'}));a.download=f?f.name:'panel.hex';document.body.appendChild(a);a.click();a.remove();};});})();<\/script>
</body></html>`;
}
async function saveProject(box) {
  const html = projectHtml(), name = projName();
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([html], { type: 'text/html;charset=utf-8' })); a.download = name + '.html';
  document.body.appendChild(a); a.click(); setTimeout(() => a.remove(), 1000);
  if (box) box.innerHTML = '<div class="msg ok">فایل پروژه دانلود شد: <b><bdi></bdi></b></div>', box.querySelector('bdi').textContent = name + '.html';
  if (HELPER.token) {
    try { const r = await helper('/api/archive?name=' + encodeURIComponent(name), { method: 'POST', body: html });
      if (box) { const d = document.createElement('div'); d.className = r.ok ? 'msg ok' : 'msg warn'; d.textContent = r.ok ? 'یک نسخه هم در پوشه archive ذخیره شد: ' + r.file.replace(/^archive\//, '') : 'در پوشه archive ذخیره نشد.'; box.appendChild(d); }
    } catch (e) { }
  }
}
let AUTO_SAVED = false;
function autoArchiveProject() { if (AUTO_SAVED || !HELPER.token) return; AUTO_SAVED = true; helper('/api/archive?name=' + encodeURIComponent(projName()), { method: 'POST', body: projectHtml() }).catch(() => { }); }
function openProject(file) {
  file.text().then(t => {
    const m = t.match(/<script type="application\/json" id="sooden-project">([\s\S]*?)<\/script>/);
    if (!m) { alert('این فایل، فایل پروژه سودن نیست.'); return; }
    let d; try { d = JSON.parse(m[1]); } catch (e) { alert('فایل پروژه خراب است.'); return; }
    if (!d.W || !d.hex) { alert('فایل پروژه خراب است.'); return; }
    (d.LIB && d.LIB.models || []).forEach(x => { if (!LIB.models.some(y => y.id === x.id)) LIB.models.push(x); });
    Object.keys(W).forEach(k => delete W[k]); Object.assign(W, d.W);
    Object.assign(PROJ, d.PROJ || {});
    SAVED = { hex: d.hex }; Object.keys(USE_NEW).forEach(k => delete USE_NEW[k]);
    W.step = steps().length - 1; render(); window.scrollTo(0, 0);
  });
}
/* finish page: saved vs newer firmware, per stage */
function savedChoice(t, i) {
  if (!SAVED || !SAVED.hex[tid(t)]) return '';
  let same = true; try { same = freshHex(t) === SAVED.hex[tid(t)]; } catch (e) { same = false; }
  if (same) return '<div class="locked" style="margin-top:4px">همان هگز ذخیره‌شده در فایل پروژه.</div>';
  const nw = !!USE_NEW[tid(t)];
  return `<div class="msg warn" style="margin-top:6px">برای این مرحله فرم‌ور جدیدتر یا تنظیم تازه‌تری از فایل پروژه هست:
    <label class="chk"><input type="radio" name="sv${i}" class="svpick" data-id="${esc(tid(t))}" value="old" ${nw ? '' : 'checked'}> نسخه ذخیره‌شده (نصب‌شده روی بقیه پنل‌ها)</label>
    <label class="chk"><input type="radio" name="sv${i}" class="svpick" data-id="${esc(tid(t))}" value="new" ${nw ? 'checked' : ''}> نسخه جدید</label></div>`;
}
