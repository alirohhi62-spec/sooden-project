/* ===================== «شبکه سون سگمنت»: the 12-pole SIM panel (main) + 1..9 panels of any model on its RS485 line =====================
   panel i of the list is number i + 1 on the main panel's 7-segment; its name is shown on OLED 1 of the main panel.
   keys: 'M' = the main panel, 'N0'..'N8' = the panels of the list. No two-panel links in this mode. */
function segInit() { W.seg = { main: newP12Panel(), count: 0, panels: [] }; }
const segPanel = i => W.seg.panels[i] && W.seg.panels[i].model ? W.seg.panels[i] : null;
const segName = i => (W.seg.panels[i] && W.seg.panels[i].name) || '';
function stSegDef() {
  const S = W.seg;
  return `<h2><span class="n">۲</span>پنل اصلی و تعداد پنل‌ها</h2><p class="hint">پنل اصلی شبکه سون سگمنت، دزدگیردار سیمکارتی است. پنل‌های متصل هر مدلی می‌توانند باشند؛ شماره هر کدام روی سون سگمنت پنل اصلی همان ترتیب فهرست است.</p>
    <div class="segmain"><div class="mdl selA" style="max-width:220px;cursor:default"><img class="p12img" src="${P12_IMG}" alt=""><div class="nm">دزدگیر سیمکارتی</div></div>
      <div><b>پنل اصلی: دزدگیر سیمکارتی</b> <span class="locked">(خودکار انتخاب شد)</span>
        <div style="margin-top:14px">تعداد پنل متصل <select id="segcount"><option value="0">— انتخاب کن —</option>${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<option value="${n}" ${S.count === n ? 'selected' : ''}>${fa(n)}</option>`).join('')}</select></div>
        <p class="locked" style="margin-top:8px">با انتخاب عدد، صفحه پنل ۱ باز می‌شود (مدل و جزئیات)، بعد پنل ۲ و … . در پایان همه به ترتیب، کنار پنل اصلی پروگرم می‌شوند.</p></div></div>`;
}
function bindSegDef() {
  $('segcount').onchange = () => {
    const n = +$('segcount').value, S = W.seg;
    S.count = n; S.panels = S.panels.slice(0, n);
    while (S.panels.length < n) S.panels.push({ name: '' });
    if (n) advance(); else render();
  };
}
function segRows() { return pairRows({ crystal: true, network: true }).filter(r => !r.m.p12); }
function stSegP(i) {
  const pn = segPanel(i), rows = segRows(), nm = segName(i), bm = roomBitmap(nm.trim() || ROOM_DEF(i + 1));
  const cur = r => pn && pn.model === r.id && (!r.sub || (pn.big && pn.sub === r.sub));
  const list = rows.map((r, j) => `<button class="plrow ${cur(r) ? 'on' : ''} ${r.free ? 'free' : ''}" data-j="${j}"><span class="rad"></span>
      <span class="nm"><b>${r.name}</b></span><span class="th">${r.m.big ? panelSVG(newBigPanel(r.id, r.sub), { mini: true }) : mini(r.m)}</span></button>`).join('');
  return `<h2><span class="n">${fa(W.step + 1)}</span>پنل ${fa(i + 1)} از ${fa(W.seg.count)}</h2>
    <div class="pole"><b>اسم این پنل</b> <span class="locked">(روی OLED ۱ پنل اصلی، کنار شماره ${fa(i + 1)} سون سگمنت)</span>
      <div style="margin-top:6px;display:flex;gap:14px;align-items:center;flex-wrap:wrap"><input type="text" class="segname" data-i="${i}" value="${esc(nm)}" maxlength="16" placeholder="${ROOM_DEF(i + 1)}" style="width:170px">
        ${bm.ok ? roomPreview(bm) : '<span class="msg err" style="padding:2px 8px">در OLED جا نمی‌شود؛ کوتاه‌ترش کن</span>'}</div></div>
    <div class="pole"><b>مدل این پنل</b><div class="pllist seglist">${list}</div>
      <p class="locked" style="margin:6px 0 0">پنل‌های ۱ تا ۴ پل در این حالت ریموت ندارند (حافظه ATmega8). در این حالت تبدیل نیست.</p></div>
    <div id="roles">${pn ? pbox(`پنل ${fa(i + 1)} شبکه — ${pnName(pn)}`, rolesEditor(pn, 'N' + i, 'پنل ' + fa(i + 1))) : '<div class="empty">اول مدل این پنل را انتخاب کن.</div>'}</div>`;
}
function bindSegP(i) {
  const rows = segRows();
  document.querySelectorAll('.seglist .plrow').forEach(e => e.onclick = () => {
    const r = rows[+e.dataset.j], old = W.seg.panels[i] || {}, pn = segPanel(i);
    if (!pn || pn.model !== r.id || (r.sub && pn.sub !== r.sub)) {
      const q = r.sub ? newBigPanel(r.id, r.sub) : newPanel(r.id);
      if (!q.big) q.remote = false;
      q.name = old.name || ''; q.room = i + 1;
      W.seg.panels[i] = q;
    }
    render();
  });
  document.querySelectorAll('.segname').forEach(c => c.onchange = () => { const p = W.seg.panels[i]; p.name = c.value.trim(); render(); });
  if ($('roles')) bindRoles($('roles'));
}
function stSegMain() {
  return `<h2><span class="n">${fa(W.step + 1)}</span>برنامه پنل اصلی</h2>
    <div id="roles">${pbox('پنل اصلی — دزدگیر سیمکارتی', rolesEditor(W.seg.main, 'M', 'پنل اصلی'))}</div>`;
}
function segTargets() {
  const out = p12Targets(W.seg.main, 'M', 'پنل اصلی — ', 0, null, null);
  W.seg.panels.forEach((pn, i) => {
    if (!pn || !pn.model) return;
    pn.room = i + 1;
    const m = MODEL(pn.model), v = variantFor(m, { crystal: true, network: true }), key = 'N' + i, lab = `پنل ${fa(i + 1)} — `;
    const main = { key, label: lab + pnName(pn), model: m, variant: v, cfg: v && v.fw ? firmwareCfg(pn, 0, null, null, pn.big ? true : false) : null };
    if (!m.big) { out.push(main); return; }
    out.push({ key, step: 1, label: lab + 'مرحله ۱ — میکروی تاچ (ATmega32)', model: m, variant: { mcu: 'ATmega32', crystal: true, fw: 'BIG' }, fixedHex: fwHex('fw_big_io32') },
      Object.assign(main, { step: 2, label: lab + 'مرحله ۲ — میکروی اصلی (ATmega64)', variant: { mcu: 'ATmega64', crystal: true, fw: 'BIG' } }));
  });
  return out;
}
