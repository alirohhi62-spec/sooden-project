/* ===================== 12-pole SIM panel («دزدگیر سیمکارتی»): M4 ATmega64 (logic) + M1/M2/M3 ATmega32 (OLED, relays) + alarm ATmega64 (SIM800) =====================
   key index k: 0..11 poles 1..12, 12..14 keys 13..15, 15..20 S1..S6 (S5 = exit), 21 master, 22 elevator, 23..26 curtain 1 open / close, curtain 2 open / close.
   network number of a key (pair links / keys of the other panel): P12_NET (20 keys) */
const P12_FIXED = { 21: 'm' };
MODELS.push({ id: 'SIM12', name: 'دزدگیر سیمکارتی', p12: true, n: 12, cols: 4, cells: Array.from({ length: 28 }, (_, i) => i < 27 ? i + 1 : 0), fixed: P12_FIXED,
  features: ['master', 'service', 'offtimer', 'deloff', 'pulse', 'delay', 'curtain', 'cooler', 'scn', 'dim', 'remote', 'beep'],
  variants: [{ crystal: true, remote: true, wifi: true, network: true, mcu: 'ATmega64', fw: 'P12' }] });
const P12_POLE_KINDS = ['n', 't', 'ot', 'do', 'p', 'dl', 'co', 'cc', 'cs', 'cf', 'x'];
const P12_ANY = ['cu', 'ex', 'ck', 'n', 't', 'ot', 'do', 'p', 'dl', 'co', 'cc', 'cs', 'cf', 'x'];   /* scenario keys and curtain keys: every kind */
const P12_NAME = k => k < 12 ? 'پل ' + fa(k + 1) : k < 15 ? 'کلید ' + fa(k + 1) : k < 21 ? 'سناریو ' + fa(k - 14)
  : k === 21 ? 'مستر' : k === 22 ? 'آسانسور' : ['پرده ۱ باز', 'پرده ۱ بسته', 'پرده ۲ باز', 'پرده ۲ بسته'][k - 23];
const P12_SHORT = k => k < 15 ? fa(k + 1) : k < 21 ? 'س' + fa(k - 14) : k === 21 ? 'مستر' : k === 22 ? 'آسانسور' : ['پ۱باز', 'پ۱بسته', 'پ۲باز', 'پ۲بسته'][k - 23];
/* where every key is on the photo (2000 x 1481) */
const P12_XY = (() => { const a = [], ry = [440, 560, 685, 795, 912, 1035];
  for (let k = 0; k < 12; k++) a[k] = [k % 2 ? 1250 : 1693, ry[k >> 1]];
  [295, 440, 588].forEach((x, j) => { a[12 + j] = [x, 1210]; });
  [1745, 1600, 1452, 1313, 1160, 1022].forEach((x, j) => { a[15 + j] = [x, 1210]; });
  a[21] = [815, 1215]; a[22] = [370, 315]; a[23] = [263, 520]; a[24] = [478, 520]; a[25] = [263, 693]; a[26] = [475, 693];
  return a; })();
const P12_IMG = 'data:image/jpeg;base64,/*P12IMG*/';
const ROOM_DEF = n => 'پنل ' + fa(n);
function newP12Panel(name) {
  const P = () => ({ type: 'n', masterLinked: true, off: [], on: [], min: 10, beep: false, name: '', sec: 1, sec2: 1, mode: 'perm', partner: -1, pump: -1 });
  const poles = Array.from({ length: 27 }, P);
  Object.keys(P12_FIXED).forEach(k => { poles[k].type = P12_FIXED[k]; poles[k].beep = true; });
  [15, 16, 17, 18].forEach(k => { poles[k].type = 'cu'; poles[k].beep = true; });
  poles[19].type = 'ex'; poles[19].beep = true; poles[20].type = 'ck';
  poles[19].secs = 20; poles[19].closeCur = true; poles[19].off = Array.from({ length: 12 }, (_, i) => i);
  poles[22].type = 'el';
  [[23, 24], [25, 26]].forEach(([o, c]) => { poles[o].type = 'co'; poles[c].type = 'cc'; poles[o].partner = c; poles[c].partner = o; poles[o].sec = poles[c].sec = 45; });
  const pn = { model: 'SIM12', p12: true, name: name || '', poles, remote: true, dim: 60, stag: 100, tpress: 2, tgap: 30, tmin: [5, 10, 30, 60], slots: [],
    room: 0,
    al: { zone2: false, zone3: false, siren: [1, 2, 4], magOn: false, magMsg: false, curSms: false, magSiren: 0, rem: [0x11, 0x40, 0, 0], exitS: 40, entryS: 30, sirenS: 180 } };
  pn.slots.push(newSlot(LIB.models[0] && LIB.models[0].id, pn));
  return pn;
}
/* kinds a key may take */
function p12Kinds(pn, k) {
  if (pn.poles[k].type === 'rl') return ['rl'];
  if (P12_FIXED[k]) return [P12_FIXED[k]];
  if (k === 22) return ['el', 'n', 'x'];
  if (k >= 15) return P12_ANY;
  return P12_POLE_KINDS;
}
/* ---------- room names: drawn here, written into M1 at 0x7000 (width, pages, columns page by page; at most 128 x 24) ---------- */
const RN_ADDR = 0x7000;
function roomBitmap(text) {
  const c = document.createElement('canvas'); c.width = 200; c.height = 64;
  const x = c.getContext('2d');
  for (let sz = 18; sz >= 14; sz--) {
    x.fillStyle = '#000'; x.fillRect(0, 0, 200, 64); x.fillStyle = '#fff';
    x.font = 'bold ' + sz + 'px Tahoma, "DejaVu Sans", Vazirmatn, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'alphabetic'; x.direction = 'rtl';
    x.fillText(text, 100, 44);
    const d = x.getImageData(0, 0, 200, 64).data, on = (i, j) => d[(j * 200 + i) * 4] > 70;
    let x0 = 200, x1 = -1, y0 = 64, y1 = -1;
    for (let j = 0; j < 64; j++) for (let i = 0; i < 200; i++) if (on(i, j)) { x0 = Math.min(x0, i); x1 = Math.max(x1, i); y0 = Math.min(y0, j); y1 = Math.max(y1, j); }
    if (x1 < 0) return { ok: false, why: 'خالی' };
    const w = x1 - x0 + 1, h = y1 - y0 + 1;
    if (w > 126 || h > 24) continue;
    const pages = Math.ceil(h / 8), bytes = [w, pages];
    for (let pg = 0; pg < pages; pg++) for (let i = 0; i < w; i++) { let v = 0; for (let b = 0; b < 8; b++) { const j = y0 + pg * 8 + b; if (j <= y1 && on(x0 + i, j)) v |= 1 << b; } bytes.push(v); }
    return { ok: true, w, h, sz, bytes };
  }
  return { ok: false, why: 'بلند' };
}
/* the name as the 1.3" OLED shows it (name at the top, status word below) */
function roomPreview(bm) {
  if (!bm.ok) return '';
  const W0 = 128, sx = 3, x0 = 64 - Math.floor(bm.w / 2), y0 = 6, pages = bm.bytes[1];
  let r = '';
  for (let pg = 0; pg < pages; pg++) for (let i = 0; i < bm.w; i++) { const v = bm.bytes[2 + pg * bm.w + i]; for (let b = 0; b < 8; b++) if (v & (1 << b)) r += `<rect x="${(x0 + i) * sx}" y="${(y0 + pg * 8 + b) * sx}" width="${sx}" height="${sx}"/>`; }
  return `<svg viewBox="0 0 ${W0 * sx} ${64 * sx}" width="192" height="96" style="background:#000;border-radius:4px;vertical-align:middle"><g fill="#9fd8ff">${r}</g>
    <text x="${64 * sx}" y="${50 * sx}" font-size="${11 * sx}" fill="#9fd8ff" text-anchor="middle" font-family="Tahoma,sans-serif">روشن شد</text></svg>`;
}
/* names on the 7-segment network: the panels of the list (seven-segment mode), else none */
function p12Rooms() { return W.mode === 'seg' ? W.seg.panels.map((q, i) => ({ on: true, name: q.name || '' })) : []; }
function roomsBlock(pn) {
  const mem = new Uint8Array(9 * 256).fill(0xFF), bad = [];
  p12Rooms().forEach((r, i) => {
    const bm = roomBitmap(r.name.trim() || ROOM_DEF(i + 1));
    if (!bm.ok) { bad.push(i); return; }
    bm.bytes.forEach((v, j) => { mem[i * 256 + j] = v; });
  });
  return { mem, bad };
}
/* ---------- the editor ---------- */
const AL_ZN = [[1, 'زون ۱'], [3, 'زون ۱ و ۲'], [5, 'زون ۱ و ۳'], [7, 'همه زون‌ها'], [2, 'زون ۲'], [4, 'زون ۳'], [6, 'زون ۲ و ۳']];
const AL_REM = [[0, 'کاری نمی‌کند'], [0x40, 'خاموش کردن دزدگیر'], [0x80, 'روشن (زون ۱) / خاموش'], [0x88, 'روشن سریع (زون ۱) / خاموش']]
  .concat(AL_ZN.map(([z, l]) => [0x10 | z, 'روشن: ' + l]), AL_ZN.map(([z, l]) => [0x18 | z, 'روشن سریع: ' + l]));   /* سریع: بدون مهلت خروج */
function p12Editor(pn, key, title) {
  const m = MODEL(pn.model);
  const row = k => {
    const p = pn.poles[k], kinds = p12Kinds(pn, k);
    let h = `<div class="pole" data-bk="${k}"><div class="pole-head"><span class="pn">${P12_NAME(k)}</span>`;
    h += kinds.length === 1 ? `<span class="locked">${kinds[0] === 'cu' ? 'سناریو سفارشی' : TYPE_LABEL[kinds[0]]} (ثابت)</span>`
      : `<select class="ptype" data-p="${key}" data-i="${k}">${kinds.map(t => `<option value="${t}" ${p.type === t ? 'selected' : ''}>${TYPE_LABEL[t]}</option>`).join('')}</select>`;
    if (p.type !== 'x') h += `<input type="text" class="pnm" data-p="${key}" data-i="${k}" value="${esc(p.name || '')}" placeholder="اسم (مثلاً لوستر)" maxlength="30" style="width:150px">`;
    if (p.type !== 'el' && p.type !== 'x') h += `<label class="chk" style="margin-inline-start:auto"><input type="checkbox" class="pbeep" data-p="${key}" data-i="${k}" ${p.beep ? 'checked' : ''}> بیپ با لمس</label>`;
    h += '</div>';
    if (p.type === 't') h += `<div class="sub"><div>خاموش کند: ${poleChecks('off', pn, k, key)}${peerChecks(key, k, 'poff')}</div><div>هواکش (روشن کند): ${poleChecks('on', pn, k, key)}${peerChecks(key, k, 'pon')}</div>
      <div>هواکش بعد از <input type="number" min="1" max="255" class="tmin" data-p="${key}" data-i="${k}" value="${p.min}"> دقیقه خاموش شود.</div></div>`;
    if (k === 21) h += `<div class="sub locked">مستر: پل‌های تیک‌خورده (از پل‌های معمولی ۱ تا ۱۲) را پله‌ای روشن و خاموش می‌کند (اول همه روشن)؛ تا آخرین پله همه کلیدها قفل‌اند.</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin:4px 0">${pn.poles.slice(0, 12).map((q, j) => q.type === 'n' ? `<label class="chk"><input type="checkbox" class="wm" data-p="${key}" data-i="${j}" ${q.withMaster !== false ? 'checked' : ''}> ${esc(q.name || plab(pn, j))}</label>` : '').join('')}</div>${peerChecks(key, k, 'pon', 'و این پل‌های پنل ' + otherSide(key))}`;
    else if (p.type === 'ex') h += `<div class="sub"><div>بعد از <input type="number" min="1" max="65535" class="psec" data-p="${key}" data-i="${k}" data-f="secs" value="${p.secs}" style="width:80px"> ثانیه (شمارش روی OLED ۱؛ در این مدت پنل قفل است و فقط ریموت دزدگیر کار می‌کند) این‌ها خاموش شوند:</div>
      <div>${poleChecks('off', pn, k, key)}${peerChecks(key, k, 'poff', 'در پنل ' + otherSide(key) + ' هم خاموش شوند')}</div>
      ${[23, 25].some(j => pn.poles[j].type === 'co') ? `<div><label class="chk"><input type="checkbox" class="pclose" data-p="${key}" data-i="${k}" ${p.closeCur ? 'checked' : ''}> پرده‌های باز بسته شوند</label></div>` : ''}</div>`;
    else if (p.type === 'rl') h += `<div class="sub locked">رله ${esc(P12_NAME(p.rlOf))} — این کلید فقط رله پرده است و لمسش کاری نمی‌کند.</div>`;
    else if (p.type === 'ck') h += '<div class="sub locked">قفل کودک: ۷ ثانیه نگه داشتن = قفل / باز شدن همه لمس‌ها (چراغ قرمز همین کلید روشن). در حالت قفل، ریموت دزدگیر کار می‌کند. لمس کوتاه کاری نمی‌کند.</div>';
    else if (p.type === 'cu') h += `<div class="sub locked">سناریو سفارشی: پل‌ها را روشن کن و این کلید را ۵ ثانیه نگه دار (ذخیره)؛ لمس بعدی همان حالت را برمی‌گرداند.</div>
      ${pxMode() ? `<div class="sub">${peerChecks(key, k, 'pon', 'روشن در پنل ' + otherSide(key))}${peerChecks(key, k, 'poff', 'خاموش در پنل ' + otherSide(key))}</div>` : ''}`;
    else if (p.type === 'el') h += '<div class="sub locked">لمس پیوسته ۱ ثانیه (بدون قطع): رله آسانسور ۱ ثانیه وصل می‌شود (بوق تأیید). وقتی ماژول سیمکارت پیامک می‌فرستد یا می‌گیرد، این کلید چند لحظه صبر می‌کند.</div>';
    else h += kindEditor(pn, p, k, key);
    return h + '</div>';
  };
  const grp = (t, ks) => `<h4 style="margin:14px 0 6px">${t}</h4>` + ks.map(row).join('');
  const range = (a, b) => Array.from({ length: b - a }, (_, i) => a + i);
  const al = pn.al, chk = (f, v, l) => `<label class="chk"><input type="checkbox" class="p12al" data-p="${key}" data-f="${f}" ${v ? 'checked' : ''}> ${l}</label>`;
  const sir = (f, z, v) => [0, 1, 2].map(s => `<label class="chk"><input type="checkbox" class="p12sir" data-p="${key}" data-f="${f}" data-z="${z}" data-s="${s}" ${v & (1 << s) ? 'checked' : ''}> آژیر ${fa(s + 1)}</label>`).join('');
  const num = (f, lo, hi, l, d) => `<div>${l} <input type="number" min="${lo}" max="${hi}" class="p12num" data-p="${key}" data-f="${f}" value="${al[f]}" style="width:80px"> ثانیه <span class="locked">(پیش‌فرض ${fa(d)})</span></div>`;
  const alarm = `<div class="pole" data-al="${key}"><b>دزدگیر</b> <span class="locked">(شماره‌ها و رمز فقط روی خود پنل تنظیم می‌شوند)</span>
    <div style="margin-top:6px">زون ۱ همیشه فعال · ${chk('zone2', al.zone2, 'زون ۲')} ${chk('zone3', al.zone3, 'زون ۳')}</div>
    ${[0, 1, 2].map(z => z && !(z === 1 ? al.zone2 : al.zone3) ? '' : `<div>آژیرهای زون ${fa(z + 1)}: ${sir('siren', z, al.siren[z])}</div>`).join('')}
    <div style="margin-top:6px">${chk('magOn', al.magOn, 'ورودی ۴ (مگنت) فعال')}</div>
    ${al.magOn ? `<div class="sub"><div>آژیر مگنت: ${sir('magSiren', 0, al.magSiren)}</div><div>${chk('magMsg', al.magMsg, 'وقتی دزدگیر خاموش است هم پیامک بفرستد')}</div></div>` : ''}
    <div>${chk('curSms', al.curSms, 'کنترل پرده‌ها با پیامک')}</div>
    <div style="margin-top:6px"><b>دکمه‌های ریموت دزدگیر</b></div>
    ${[0, 1, 2, 3].map(i => `<div>دکمه ${fa(i + 1)}: <select class="p12rem" data-p="${key}" data-i="${i}">${AL_REM.map(([v, l]) => `<option value="${v}" ${al.rem[i] === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>`).join('')}
    <div style="margin-top:6px">${num('exitS', 0, 255, 'مهلت خروج بعد از روشن کردن', 40)}${num('entryS', 1, 255, 'مهلت زدن رمز بعد از دیدن سنسور', 30)}${num('sirenS', 1, 65535, 'زمان آژیر', 180)}</div></div>`;
  return `<div><div class="sw-title">${esc(title)} <span class="tag">${m.name}</span></div>
    ${grp('پل‌ها و کلیدهای ۱۳ تا ۱۵', range(0, 15))}${grp('سناریوها، مستر و آسانسور', range(15, 23))}${grp('پرده‌ها', range(23, 27))}
    ${alarm}${rolesTail(pn, key, m)}</div>`;
}
function bindP12(root) {
  const pnOf = c => panelByKey(c.dataset.p);
  root.querySelectorAll('.p12al').forEach(c => c.onchange = () => { pnOf(c).al[c.dataset.f] = c.checked; render(); });
  root.querySelectorAll('.p12sir').forEach(c => c.onchange = () => {
    const al = pnOf(c).al, b = 1 << +c.dataset.s;
    if (c.dataset.f === 'siren') al.siren[+c.dataset.z] = c.checked ? al.siren[+c.dataset.z] | b : al.siren[+c.dataset.z] & ~b;
    else al.magSiren = c.checked ? al.magSiren | b : al.magSiren & ~b;
  });
  root.querySelectorAll('.p12num').forEach(c => c.oninput = () => { pnOf(c).al[c.dataset.f] = c.value === '' ? NaN : +c.value; });
  root.querySelectorAll('.p12rem').forEach(c => c.onchange = () => { pnOf(c).al.rem[+c.dataset.i] = +c.value; });
}
function roomEditor() { return ''; }
/* ---------- settings block of the M4 and of the alarm MCU ---------- */
const p12net = k => P12_NET.indexOf(k);
function firmwareCfgP12(pn, role, peer, links) {
  const NP = 27, Z = () => Array(NP).fill(0), b8 = v => Math.max(0, Math.min(255, v | 0));
  const c = { role, remote: true, type: Z(), link: Array(NP).fill(-1), offmask: Z(), onmask: Z(), minutes: Z(), sec1: Z(), sec2: Z(), beep: 0,
    dimsec: Math.max(0, Math.min(255, pn.dim | 0)), stagMs: Math.max(80, Math.min(1000, pn.stag | 0)), tpress: pn.tpress === undefined ? 2 : pn.tpress | 0, tgap: pn.tgap === undefined ? 30 : pn.tgap | 0,
    rooms: p12Rooms().reduce((a, r, i) => a | 1 << i, 0), clk: pn.poles.findIndex(p => p.type === 'ck') + 1, mdl: 'p12', lay: pn.poles.map(p => APP_CH[p.type] || '-').join('') };
  const relay = k => isRelayKind(pn.poles[k].type);
  pn.poles.forEach((p, i) => {
    c.type[i] = KIND[p.type][1];
    if (p.beep && p.type !== 'el' && p.type !== 'x') c.beep |= 1 << i;
    if (links && p12net(i) >= 0 && isN12(pn, i)) c.link[i] = links(i);
    if (p.type === 'm') for (let k = 0; k < 12; k++) if (pn.poles[k].type === 'n' && pn.poles[k].withMaster !== false) c.onmask[i] |= 1 << k;
    if (p.type === 't') { p.off.forEach(k => c.offmask[i] |= 1 << k); p.on.forEach(k => c.onmask[i] |= 1 << k); c.minutes[i] = b8(p.min); }
    if (p.type === 'ot') { p.off.forEach(k => c.offmask[i] |= 1 << k); c.minutes[i] = b8(p.min); }
    if (p.type === 'do') c.sec1[i] = b8(p.sec);
    if (p.type === 'p') { c.sec1[i] = 0; c.sec2[i] = b8(p.sec); }
    if (p.type === 'dl') { c.sec1[i] = b8(p.sec); c.sec2[i] = p.mode === 'mom' ? b8(p.sec2) : 0; }
    if (p.type === 'cu') for (let k = 0; k < NP; k++) if (k !== i && relay(k)) c.offmask[i] |= 1 << k;
    if (p.type === 'ex') {
      const n = Math.max(0, Math.min(65535, p.secs | 0)); c.sec1[i] = n & 255; c.sec2[i] = n >> 8;
      p.off.forEach(k => { if (relay(k)) c.offmask[i] |= 1 << k; });
      const cur = p.closeCur && [23, 25].some(j => pn.poles[j].type === 'co');
      c.minutes[i] = cur ? 1 : 0;
      if (cur) [23, 25].forEach(j => { if (pn.poles[j].type === 'co') c.offmask[i] |= 1 << j; });   /* an opening curtain stops, then closes */
    }
    if (PAIRED[p.type]) {
      if (p.partner >= 0) c.offmask[i] = 1 << p.partner;
      if (p.type === 'co' || p.type === 'cc') { c.sec1[i] = b8(p.sec); c.sec2[i] = 5; if (p.relay >= 0) c.onmask[i] = (1 << p.relay) >>> 0; }
      else { c.sec2[i] = 10; if (p.pump >= 0) c.onmask[i] = 1 << p.pump; }
    }
  });
  c.nslot = pn.slots.length; c.tmin = tminOf(pn).map(v => b8(v));
  c.rmap = Array.from({ length: 12 }, () => Array(16).fill(0)); c.tdef = Array.from({ length: 12 }, () => Array(16).fill(0));
  pn.slots.forEach((sl, t) => {
    const lm = libModel(sl.model); if (!lm || t >= 12) return;
    lm.buttons.forEach(b => {
      const e = sl.map[b.id];
      if (b.code === null || !e || e.poles.length !== 1) return;
      c.rmap[t][b.code] = (e.poles[0] + 1) | ({ t: 0, on: 1, off: 2 }[e.act] << 5);
      if (timerOn(pn, e)) { c.rmap[t][b.code] |= 0x80; c.tdef[t][b.code] = e.td & 3; }
    });
  });
  c.ssid = pn.ssid || '';
  if (W.mode === 'pair' && peer) c.px = { on: pn.poles.map(p => (p.pon || []).map(k => peerKeyNum(peer, k))), off: pn.poles.map(p => (p.poff || []).map(k => peerKeyNum(peer, k))) };
  return c;
}
const isN12 = (pn, i) => p12net(i) >= 0 && ['n', 'co', 'cc', 'el'].includes(pn.poles[i].type);
/* a key of the other panel as its own firmware numbers it on the network */
const peerKeyNum = (peer, k) => peer && peer.p12 ? p12net(k) : k;
function p12AlarmCfg(pn) { return buildAlarmCfg(pn.al); }
function p12Targets(pn, pre, lab, role, peer, links) {
  const v32 = { mcu: 'ATmega32', crystal: true, fw: 'P12' }, v64 = { mcu: 'ATmega64', crystal: true, fw: 'P12' }, m = MODEL('SIM12');
  const st = (n, id, fa_, note, extra) => Object.assign({ key: pre, p12: n, step: n, label: `${lab}مرحله ${fa(n)} — ${fa_}`, model: m, fa: fa_, dipNote: note, nobro: true }, extra);
  const rb = roomsBlock(pn);
  return [
    st(1, 'm1', 'M1 (مگا ۳۲ — OLED ۱، پل‌های ۱ تا ۴)', 'برنامه ثابت به‌اضافه اسم اتاق‌ها.', { variant: v32, fixedHex: patchHexAt(fwHex('fw_p12_m1'), rb.mem, RN_ADDR), fname: 'm1' }),
    st(2, 'm2', 'M2 (مگا ۳۲ — OLED ۲، پل‌های ۵ تا ۸)', 'برنامه ثابت.', { variant: v32, fixedHex: fwHex('fw_p12_m2'), fname: 'm2' }),
    st(3, 'm3', 'M3 (مگا ۳۲ — OLED ۳، پل‌های ۹ تا ۱۲)', 'برنامه ثابت.', { variant: v32, fixedHex: fwHex('fw_p12_m3'), fname: 'm3' }),
    st(4, 'm4', 'M4 (مگا ۶۴ — میکروی اصلی)', 'برنامه و تنظیمات کلیدها، ریموت‌ها و شبکه؛ ریموت‌های یادگرفته‌شده حفظ می‌شوند.', { variant: v64, cfg: firmwareCfgP12(pn, role, peer, links), fname: 'm4' }),
    st(5, 'al', 'دزدگیر (مگا ۶۴ — سیمکارت و کیپد)', 'برنامه و تنظیمات دزدگیر؛ شماره‌ها و رمز ذخیره‌شده در پنل حفظ می‌شوند.', { variant: v64, fixedHex: patchHexAt(fwHex('fw_p12_alarm'), buildAlarmCfg(pn.al), AL_ADDR), fname: 'alarm' })];
}
function p12Hex(t) {
  let h = patchHexAt(fwHex('fw_p12_m4'), buildCfgP12(t.cfg), BIG_ADDR);
  return t.cfg.px ? patchHexAt(h, buildPx(t.cfg.px, true, P12_NP), PX_ADDRB) : h;   /* alone: no block, the panel stays silent on the line (rooms only) */
}
function p12Checks(pn, title, E) {
  const al = pn.al, r8 = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  if (!r8(al.exitS, 0, 255)) E(`${title}: مهلت خروج دزدگیر باید ۰ تا ۲۵۵ ثانیه باشد.`, `.p12num[data-f="exitS"]`, 'عدد ثانیه را بنویس.');
  if (!r8(al.entryS, 1, 255)) E(`${title}: مهلت زدن رمز باید ۱ تا ۲۵۵ ثانیه باشد.`, `.p12num[data-f="entryS"]`, 'عدد ثانیه را بنویس.');
  if (!r8(al.sirenS, 1, 65535)) E(`${title}: زمان آژیر باید ۱ تا ۶۵۵۳۵ ثانیه باشد.`, `.p12num[data-f="sirenS"]`, 'عدد ثانیه را بنویس.');
  if (!(pn.stag >= 80 && pn.stag <= 1000)) E(`${title}: فاصله پله‌ای باید ۸۰ تا ۱۰۰۰ میلی‌ثانیه باشد.`, `.stag[data-p]`, 'پیش‌فرض ۱۰۰ است.');
  if (pn.slots.length > 12) E(`${title}: حداکثر ۱۲ ریموت.`, `.sadd[data-p]`, 'ریموت اضافه را حذف کن.');
  roomsBlock(pn).bad.forEach(i => E(`پنل ${fa(i + 1)} شبکه: اسمش در OLED پنل اصلی جا نمی‌شود.`, `.segname[data-i="${i}"]`, 'اسم کوتاه‌تری بنویس (حدود ۱۲ حرف).'));
  [['ex', 'سناریو خروج'], ['ck', 'قفل کودک']].forEach(([t, l]) => { const ks = pn.poles.map((p, k) => p.type === t ? k : -1).filter(k => k >= 0);
    if (ks.length > 1) E(`${title}: «${l}» فقط روی یک کلید (الان: ${ks.map(k => P12_NAME(k)).join('، ')}).`, `[data-bk="${ks[1]}"]`, 'یکی را نگه دار و بقیه را نوع دیگری بده.'); });
  pn.slots.forEach((sl, t) => {
    const lm = libModel(sl.model); if (!lm) return;
    lm.buttons.forEach(b => { const e = sl.map[b.id];
      if (e && e.poles.length > 1) E(`${title} ریموت ${fa(t + 1)}، ${b.name}: در این پنل هر دکمه فقط یک کلید را کنترل می‌کند.`, `.spole[data-s="${t}"][data-bid="${b.id}"]`, 'فقط یک کلید را تیک بزن؛ برای چند پل، یک سناریو بساز و دکمه را روی همان سناریو بگذار.'); });
  });
}
