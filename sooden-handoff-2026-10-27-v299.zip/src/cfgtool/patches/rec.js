function parseEeprom(hex) {
  const b = []; for (let i = 0; i < hex.length; i += 2) b.push(parseInt(hex.substr(i, 2), 16));
  const res = { rec: [], places: null };
  for (const base of [0x10, 0x50, 0x90]) {
    const c = b.slice(base, base + 14);
    if (c[0] === 0x60 && crc8(c, 13) === c[13]) {
      res.places = [0, 1, 2, 3].map(i => (c[1 + i * 3] << 16) | (c[2 + i * 3] << 8) | c[3 + i * 3]).map(v => v === 0xFFFFFF ? null : v);
      break;
    }
  }
  /* recorded buttons: ring of 100 x 3 bytes at 0xB3, magic 0xB5, next, count at 0xB0 */
  if (b[0xB0] === 0xB5 && b[0xB1] < 100 && b[0xB2] <= 100) {
    const next = b[0xB1], n = b[0xB2], start = n < 100 ? 0 : next;
    for (let k = 0; k < n; k++) { const i = (start + k) % 100, a = 0xB3 + i * 3; res.rec.push((b[a] << 16) | (b[a + 1] << 8) | b[a + 2]); }
  }
  return res;
}
const idHex = v => (v >> 4).toString(16).toUpperCase().padStart(5, '0');
const bin4 = c => c.toString(2).padStart(4, '0');

/* ---------- recorded remotes: read from the panel, edit, save to the library ---------- */
let REC = null;     /* { groups: [{ id, name, save, buttons: [{ name, code }] }], places } */
function recFromEeprom(e) {
  const groups = [];
  e.rec.forEach(code => {
    const id = code & 0xFFFFF0;
    let g = groups.find(x => x.id === id);
    if (!g) groups.push(g = { id, save: true, buttons: [] });
    if (!g.buttons.some(x => x.code === (code & 15))) g.buttons.push({ name: 'دکمه ' + fa(g.buttons.length + 1), code: code & 15 });
  });
  groups.forEach(g => { g.name = `ریموت ${fa(g.buttons.length)} کانال (${idHex(g.id)})`; });
  return { groups, places: e.places };
}
function sameModel(g) {
  const k = g.buttons.map(b => b.code).sort((a, b) => a - b).join();
  return LIB.models.find(m => m.buttons.map(b => b.code).filter(c => c !== null).sort((a, b) => a - b).join() === k);
}
function recHtml() {
  if (!REC) return '';
  if (!REC.groups.length) return '<div class="msg warn">هیچ ریموتی روی پنل ضبط نشده. برق اصلی پنل را قطع و وصل کن، در ۱۵ دقیقه بعد دکمه‌های هر ریموت را یکی‌یکی و به ترتیب بزن، بعد دوباره بخوان.</div>';
  const g = (x, gi) => {
    const same = sameModel(x);
    return `<div class="rtype"><div class="pole-head"><label class="chk"><input type="checkbox" class="rsave" data-g="${gi}" ${x.save ? 'checked' : ''}> ذخیره در کتابخانه</label>
        <input type="text" class="rgname" data-g="${gi}" value="${esc(x.name)}" style="flex:1"><span class="locked">شناسه ${idHex(x.id)} — ${fa(x.buttons.length)} دکمه</span></div>
      ${same ? `<div class="msg warn" style="margin-top:6px">مدلی با همین کدها در کتابخانه هست: «${esc(same.name)}».</div>` : ''}
      <table class="rtab"><tr><th>#</th><th>اسم دکمه</th><th>کد</th><th></th></tr>
      ${x.buttons.map((b, bi) => `<tr><td>${fa(bi + 1)}</td><td><input type="text" class="rbname" data-g="${gi}" data-b="${bi}" value="${esc(b.name)}"></td>
        <td>${fa(b.code)} <span class="locked">(${bin4(b.code)})</span></td>
        <td><button class="btn sm rmv" data-g="${gi}" data-b="${bi}" data-d="-1" ${bi ? '' : 'disabled'} title="بالا">▲</button>
            <button class="btn sm rmv" data-g="${gi}" data-b="${bi}" data-d="1" ${bi < x.buttons.length - 1 ? '' : 'disabled'} title="پایین">▼</button>
            <button class="btn sm rbdel" data-g="${gi}" data-b="${bi}">حذف</button></td></tr>`).join('')}</table></div>`;
  };
  const n = REC.groups.filter(x => x.save).length;
  return `<div class="msg ok">${fa(REC.groups.length)} ریموت روی پنل ضبط شده. ترتیب و اسم دکمه‌ها را درست کن؛ <b>در کتابخانه ذخیره شوند؟</b></div>
    ${REC.groups.map(g).join('')}
    <div class="actions"><button class="btn primary rsaveall" ${n ? '' : 'disabled'}>ذخیره ${fa(n)} ریموت در کتابخانه</button><button class="btn rclose">بستن</button></div>
    ${REC.places ? `<div class="locked">ریموت‌های یادگرفته‌شده روی پنل: ${REC.places.map((v, i) => `جای ${fa(i + 1)}: ${v === null ? 'خالی' : idHex(v)}`).join(' — ')}</div>` : ''}`;
}
function renderRec() {
  document.querySelectorAll('.recbox').forEach(box => {
    box.innerHTML = recHtml();
    const G = c => REC.groups[+c.dataset.g];
    box.querySelectorAll('.rsave').forEach(c => c.onchange = () => { G(c).save = c.checked; renderRec(); });
    box.querySelectorAll('.rgname').forEach(c => c.onchange = () => { G(c).name = c.value.trim() || G(c).name; });
    box.querySelectorAll('.rbname').forEach(c => c.onchange = () => { G(c).buttons[+c.dataset.b].name = c.value.trim(); });
    box.querySelectorAll('.rmv').forEach(c => c.onclick = () => {
      const a = G(c).buttons, i = +c.dataset.b, j = i + +c.dataset.d;
      [a[i], a[j]] = [a[j], a[i]]; renderRec();
    });
    box.querySelectorAll('.rbdel').forEach(c => c.onclick = () => { G(c).buttons.splice(+c.dataset.b, 1); renderRec(); });
    const all = box.querySelector('.rsaveall');
    if (all) all.onclick = () => {
      const names = [];
      REC.groups.filter(x => x.save && x.buttons.length).forEach(x => {
        LIB.models.push({ id: uid('m'), name: x.name, buttons: x.buttons.map(b => ({ id: uid('b'), name: b.name, code: b.code, raw: bin4(b.code) })) });
        names.push(x.name);
      });
      REC = null;
      libSave().then(() => { render(); document.querySelectorAll('.recbox').forEach(bx => { bx.innerHTML = `<div class="msg ok">در کتابخانه ذخیره شد: ${names.map(esc).join('، ')}. حالا در منوی هر ریموت قابل انتخاب‌اند.</div>`; }); });
    };
    const cl = box.querySelector('.rclose');
    if (cl) cl.onclick = () => { REC = null; renderRec(); };
  });
}
async function readRecorded(box) {
  if (!HELPER.token) { box.innerHTML = '<div class="msg warn">برای خواندن از پنل، صفحه را از SoodenProg.exe باز کن.</div>'; return; }
  if (HELPER.busy) return; HELPER.busy = true;
  box.innerHTML = '<p><span class="spin"></span> در حال خواندن ریموت‌های ضبط‌شده از پنل…</p>';
  try {
    const r = await helper('/api/eeprom?part=m8', { method: 'POST' });
    if (!r.ok) box.innerHTML = `<div class="msg err">${PERR[r.code] || PERR.error}</div>`;
    else { REC = recFromEeprom(parseEeprom(r.eeprom)); HELPER.busy = false; renderRec(); return; }
  } catch (e) { box.innerHTML = '<div class="msg err">ارتباط با SoodenProg قطع شد.</div>'; }
  HELPER.busy = false;
}

