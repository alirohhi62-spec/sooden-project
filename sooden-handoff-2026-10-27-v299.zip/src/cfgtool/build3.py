import pathlib
d=pathlib.Path('/home/claude/cfgtool'); fw=pathlib.Path('/home/claude/fw/out')
src=(d/'wizard.src.html').read_text(encoding='utf-8')
out=(src.replace('/*STYLE*/',(d/'parts_style.css').read_text(encoding='utf-8'))
        .replace('/*GENSTYLE*/',(d/'parts_general.css').read_text(encoding='utf-8'))
        .replace('/*P12*/',(d/'patches'/'p12.js').read_text(encoding='utf-8'))
        .replace('/*SEG*/',(d/'patches'/'seg.js').read_text(encoding='utf-8'))
        .replace('/*PROJ*/',(d/'patches'/'proj.js').read_text(encoding='utf-8'))
        .replace('/*CFGCORE*/',pathlib.Path('/home/claude/avrsim/cfgcore.js').read_text(encoding='utf-8')))
tags=''.join('<script id="fw-%s" type="text/plain">%s</script>\n' % (h.stem, h.read_text().strip()) for h in sorted(fw.glob('*.hex')))
out=out.replace('<!--FWTAGS-->',tags)
import base64
out=out.replace('/*BROCHURE*/',(d/'patches'/'brochure.js').read_text(encoding='utf-8'))
out=out.replace('/*P12IMG*/',base64.b64encode((d/'sim12_small.jpg').read_bytes()).decode())
out=out.replace('/*LOGOB64*/',base64.b64encode((d/'logo_brochure.png').read_bytes()).decode())
for t in ['T13_1POL','T13_2POL','T13_BELL']:
    out=out.replace('/*'+t+'*/','')      # archived models: no hex embedded
assert '/*FW' not in out
pathlib.Path('/home/claude/out/sooden-programmer.html').write_text(out,encoding='utf-8')
print(len(out))
