import pathlib
src = pathlib.Path('/home/claude/cfgtool/configurator.src.html').read_text(encoding='utf-8')
core = pathlib.Path('/home/claude/avrsim/cfgcore.js').read_text(encoding='utf-8')
hexs = pathlib.Path('/home/claude/fw/fw.hex').read_text().strip()
assert '/*FWHEX*/' in src and '/*CFGCORE*/' in src
out = src.replace('/*FWHEX*/', hexs).replace('/*CFGCORE*/', core)
pathlib.Path('/home/claude/out/sooden-tabdil-config.html').write_text(out, encoding='utf-8')
print(len(out))
