import pathlib
d=pathlib.Path('/home/claude/cfgtool')
src=(d/'general.src.html').read_text(encoding='utf-8')
out=(src.replace('/*STYLE*/',(d/'parts_style.css').read_text(encoding='utf-8'))
        .replace('/*PGJS*/',(d/'parts_pg.js').read_text(encoding='utf-8'))
        .replace('/*CFGCORE*/',pathlib.Path('/home/claude/avrsim/cfgcore.js').read_text(encoding='utf-8'))
        .replace('/*FWHEX*/',pathlib.Path('/home/claude/fw/fw.hex').read_text().strip()))
assert '/*' not in out[:200] or True
pathlib.Path('/home/claude/out/sooden-tabdil-general.html').write_text(out,encoding='utf-8')
print(len(out))
