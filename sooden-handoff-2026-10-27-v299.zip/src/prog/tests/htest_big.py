import json, urllib.request, os, shutil
B='/home/claude/prog/build'; port, tok = open(B+'/conn.txt').read().split()
def call(path, body=b'', mode='ok'):
    open(B+'/mode.txt','w').write(mode)
    r = urllib.request.Request('http://127.0.0.1:%s%s' % (port, path), data=body, method='POST', headers={'X-Sooden-Token': tok})
    try: return json.loads(urllib.request.urlopen(r, timeout=30).read())
    except urllib.error.HTTPError as e: return {'http': e.code, 'body': e.read().decode()}
fails = 0
def check(c, m):
    global fails
    print(('  ok   ' if c else '  FAIL ') + m); fails += 0 if c else 1
for part in ('m32', 'm64'): shutil.rmtree(B+'/state/'+part, ignore_errors=True)
io = open('/home/claude/fw/out/fw_big_io32.hex').read()
mn = open('/home/claude/fw/out/fw_big.hex').read()
r = call('/api/probe?part=m32'); check(r.get('ok') and r['signature'] == '1E9502' and r['efuse'] == -1, 'probe m32: %s' % {k: r.get(k) for k in ('ok','signature','lfuse','hfuse','efuse')})
r = call('/api/probe?part=m64'); check(r.get('ok') and r['signature'] == '1E9602' and r['efuse'] == 0xFD, 'probe m64 reads extended fuse (factory FD)')
r = call('/api/probe?part=m64', mode='swapped'); check(not r['ok'] and r['code'] == 'wrong_chip', 'm64 expected but m32 answers -> wrong_chip (DIP switch on the wrong chip)')
r = call('/api/program?part=m32&l=3F&h=C1', io.encode(), mode='swapped'); check(not r['ok'] and r['code'] == 'wrong_chip' and r['step'] == 'identify', 'program m32 on the m64: nothing written')
r = call('/api/program?part=m32&l=3F&h=C1&e=FF', io.encode()); check(r.get('code') == 'fuse_not_allowed', 'm32 with an extended fuse refused')
r = call('/api/program?part=m64&l=3F&h=C1', mn.encode()); check(r.get('code') == 'fuse_not_allowed', 'm64 without extended fuse refused')
r = call('/api/program?part=m64&l=3F&h=C1&e=FD', mn.encode()); check(r.get('code') == 'fuse_not_allowed', 'm64 with ATmega103 mode refused')
r = call('/api/program?part=m64&l=3F&h=D1&e=FF', mn.encode()); check(r.get('code') == 'fuse_not_allowed', 'm64 with JTAG on refused')
r = call('/api/program?part=m8&l=3F&h=D1', mn.encode()); check(r.get('code') == 'bad_hex', 'm64 hex on m8 refused (too big)')
open(B+'/lastargs.txt','w').write('')
r = call('/api/program?part=m32&l=3F&h=C1', io.encode()); la = open(B+'/lastargs.txt').read()
check(r.get('ok') and r['fuseWritten'] and 'efuse' not in la, 'm32 programmed (%s bytes), no extended fuse touched' % r.get('bytes'))
check(open(B+'/state/m32/lfuse').read() == '0x3f' and open(B+'/state/m32/hfuse').read() == '0xc1', 'm32 fuses 3F/C1')
open(B+'/lastargs.txt','w').write('')
r = call('/api/program?part=m64&l=3F&h=C1&e=FF', mn.encode()); la = open(B+'/lastargs.txt').read().splitlines()
fl = [l for l in la if 'fuse:w' in l]
check(r.get('ok') and r['fuseWritten'] and r['efuse'] == 255 and r['bytes'] > 8000, 'm64 programmed (%s bytes)' % r.get('bytes'))
check(len(fl) == 1 and fl[0].index('efuse:w:0xFF') < fl[0].index('hfuse:w') < fl[0].index('lfuse:w'), 'order: extended, high, low')
check(open(B+'/state/m64/efuse').read() == '0xff', 'm64 extended fuse now FF')
check(open(B+'/state/m64/flash.hex').read() == mn and open(B+'/state/m32/flash.hex').read() == io, 'each chip got its own hex')
open(B+'/lastargs.txt','w').write('')
r = call('/api/program?part=m64&l=3F&h=C1&e=FF', mn.encode()); la = open(B+'/lastargs.txt').read()
check(r.get('ok') and not r['fuseWritten'] and 'fuse:w' not in la, 'second time: fuses already right')
open(B+'/state/m64/efuse','w').write('0xfd')
r = call('/api/program?part=m64&l=3F&h=C1&e=FF', mn.encode(), mode='fusestuck'); check(not r['ok'] and r['step'] == 'fuses' and r['efuse'] == 0xFD, 'extended fuse not taken -> stop before flash')
r = call('/api/eeprom?part=m64'); check(r.get('ok') and len(r['eeprom']) == 4096, 'm64 EEPROM read: 2048 bytes')
r = call('/api/eeprom?part=m32'); check(r.get('ok') and len(r['eeprom']) == 2048, 'm32 EEPROM read: 1024 bytes')
print('fails', fails)
