// six-pole crystal (ATmega32, crystal): remote / wifi / network, settings block at 0x7F00, fuses DE/D1
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const url = 'file:///home/claude/out/sooden-programmer.html';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  const blk = () => p.evaluate(() => { const t = targets()[0]; const m = parseHex(t.fixedHex); const a = []; for (let i = 0; i < 184; i++) a.push(m.get(0x7F00 + i)); return { a, c: chipOf(t.variant), fw: t.variant.fw }; });
  for (const [mods, ids] of [['remote', ['T6PR', 'T6PN']], ['wifi', ['T6PW']], ['both', ['T6PW']]]) {
    await p.goto(url);
    await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click(`.choice[data-k="${mods}"]`);
    for (const id of ['T6PR', 'T6PW', 'T6PN']) check((await p.$(`.mdl[data-id="${id}"]`) !== null) === ids.includes(id), `${mods}: ${id} ${ids.includes(id) ? 'offered' : 'hidden'}`);
    for (const id of ids) {
      await p.goto(url);
      await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click(`.choice[data-k="${mods}"]`);
      await p.click(`.mdl[data-id="${id}"]`);
      let r = await blk();
      check(r.c.part === 'm32' && r.c.lfuse === 0xDE && r.c.hfuse === 0xD1, id + ' fuses DE/D1, fw ' + r.fw);
      check(r.a[0] === 0xA7 && r.a.slice(2, 8).join() === '1,1,1,1,1,1' && r.a[20] === 20 && r.a[22] === 63 && r.a[24] === 100 && r.a[26] === 255 && r.a.slice(27, 33).every(x => x === 255), id + ' defaults ' + r.a.slice(0, 34).join());
      const ed = await p.$('.sxx-t'); check(ed !== null, id + ' editor on the program page');
      if (id === 'T6PN') check(await p.$('#sxx-room') === null && (await p.$$('.sxx-px')).length === 0 && (await p.$$('.ppeer')).length === 0, 'network alone: no room / link page (links in the two-panel mode)');
      await p.evaluate(() => { const d = sixX(); d.t[0] = 3; d.m[0] = 10; d.ms[5] = 0; d.xs[2] = 0; d.exit = 90; });
      r = await blk();
      check(r.a[2] === 3 && r.a[14] === 10 && r.a[20] === 90 && r.a[22] === 0x1F && r.a[23] === 0x3B, id + ' edited: master poles 1..5, exit without pole 3');
      check(r.a[26] === 255 && r.a.slice(27, 33).every(x => x === 255), id + ': alone, the line stays silent (role FF, no links)');
      r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, id + ' no errors ' + r.join('|'));
      // remote table (as the 4-pole panel)
      const rem = mods !== 'wifi';
      check((await p.$('.rtab') !== null) === rem && (await p.$('.rtimer') !== null) === rem && (await p.$('.rlast') !== null) === rem, id + (rem ? ' remote table + timer + recorded remotes (as the 4-pole panel)' : ' no remote table (no remote module)'));
      r = await blk();
      if (rem) {
        check(r.a[33] === 1, id + ' 1 remote place by default (' + r.a[33] + ')');
        const rowOf = (a, k) => a.slice(48 + 16 * k, 64 + 16 * k);
        check([1, 2, 4, 8].map(c => rowOf(r.a, 0)[c]).join() === '1,2,4,8', id + ' default A B C D -> poles 1..4: ' + rowOf(r.a, 0).join());
        await p.click('.sadd'); await p.check('.spole[data-s="1"][data-k="5"]'); await p.check('.spole[data-s="1"][data-k="4"]');
        await p.selectOption('.sact[data-s="1"]', 'on');
        r = await blk();
        check(r.a[33] === 2 && (rowOf(r.a, 1)[1] & 0x3F) === 0x31 && rowOf(r.a, 1)[1] >> 6 === 1, id + ' place 2, button A: poles 1+5+6 only on: ' + rowOf(r.a, 1)[1].toString(16));
        // hold timer on place 1, button B (poles 2): tick, time 2; the 4 times
        await p.check('.stm[data-s="0"][data-bid="bB"]'); await p.selectOption('.std[data-s="0"][data-bid="bB"]', '1');
        await p.fill('.rtmin[data-x="0"]', '15'); await p.dispatchEvent('.rtmin[data-x="0"]', 'change');
        r = await blk();
        check(((r.a[172 + (2 >> 3)] >> 2) & 1) === 1 && ((r.a[144] >> 4) & 3) === 1 && r.a.slice(168, 172).join() === '15,30,90,180', id + ' hold timer: flag, time 2, times ' + r.a.slice(168, 172).join() + ' [' + r.a[172] + ',' + r.a[144] + ']');
        await p.selectOption('.sxx-t[data-i="5"]', '3');
        r = await p.evaluate(() => checks().map(e => e.msg)); check(r.some(m => m.includes('غیرمعمولی')), id + ' service pole 6 with other poles on one button -> error');
        await p.selectOption('.sxx-t[data-i="5"]', '1');
        r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 1 && r[0].includes('غیرمعمولی'), id + ' pole 1 is a service pole (edited above): still one error');
        await p.uncheck('.spole[data-s="1"][data-k="0"]');
        r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, id + ' fixed: no errors ' + r.join('|'));
      } else check(r.a[33] === 0, id + ' no remote module: 0 places');
      require('fs').writeFileSync(`/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/${id}.hex`, await p.evaluate(() => targetHex(targets()[0])));
    }
  }
  // pair mode: only the network 6-pole
  await p.goto(url); let r = await p.evaluate(() => { W.mode = 'pair'; return ['T6PR', 'T6PW', 'T6PN'].map(id => !!variantFor(MODEL(id), need())); });
  check(r.join() === 'false,false,true', 'pair mode: only the network 6-pole offered ' + r.join());
  await b.close(); console.log('fails ' + fails);
})();
