// 12 economic (E12) in the two-panel network: with a 4-pole panel, and two E12 panels; hexes for avrsim/te12pair_e2e.js
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
const url = 'file:///home/claude/out/sooden-programmer.html';
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  const go = st => p.evaluate(st => { W.step = steps().findIndex(s => s[0] === st); render(); }, st);
  await p.goto(url); await p.click('.choice[data-k="pair"]');
  check(await p.locator('.plrow[data-side="A"][data-id="E12"]').count() === 1, 'E12 in the two-panel list');
  await p.click('.plrow[data-side="A"][data-id="E12"]'); await p.click('.plrow[data-side="B"][data-id="P4"][data-sub=""]');
  let r = await p.evaluate(() => ({ px: pxMode(), ar: W.pair.A.remote, br: W.pair.B.remote, wifi: W.pair.wifiOn }));
  check(r.px && r.ar && !r.br && r.wifi === 'A', 'network v2, E12 keeps its remote and the Wi-Fi, 4-pole without remote ' + JSON.stringify(r));
  check((await p.textContent('.plcols')).includes('ATmega64 · ۱۲ پل'), 'hero: ATmega64 · 12 poles');
  await go('pairprog');
  check(await p.locator('#plates .bigplate').first().locator('.kk:not(.e)').count() === 15 && await p.locator('#plates button.kk[data-s="A"]').count() === 12, 'E12 plate: 15 keys as on the glass, the 12 poles linkable');
  await p.click('#plates button.kk[data-s="A"][data-i="0"]'); await p.click('#plates button.kk[data-s="B"][data-i="0"]');
  await p.evaluate(() => { const A = W.pair.A, B = W.pair.B; A.poles[21].type = 'm'; A.poles[21].pon = [1]; B.poles[3].type = 'm'; B.poles[3].pon = [4, 5]; render(); });
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  r = await p.evaluate(() => targets().map(t => [t.key, t.variant.mcu, fwNameFor(t)]));
  check(JSON.stringify(r) === JSON.stringify([['A', 'ATmega64', 'fw_e12_p'], ['B', 'ATmega8', 'fw_4p_px']]), 'targets: E12 one chip (fw_e12_p) + 4-pole ' + JSON.stringify(r));
  r = await p.evaluate(() => { const t = targets(); return { la: t[0].cfg.link[0], lb: t[1].cfg.link[0], pa: t[0].cfg.px.on[21], pb: t[1].cfg.px.on[3], pm: t[0].cfg.px.pmdl, e: t[0].cfg.e12 }; });
  check(r.la === 0 && r.lb === 0 && r.pa.join() === '1' && r.pb.join() === '4,5' && r.pm === 'p4' && r.e, 'links, master on both sides, app sees the 4-pole ' + JSON.stringify(r));
  fs.writeFileSync(S + 'pr_e12A.hex', await p.evaluate(() => targetHex(targets()[0])));
  fs.writeFileSync(S + 'pr_e12B4.hex', await p.evaluate(() => targetHex(targets()[1])));
  await p.screenshot({ path: S + 'e12-pair.png', fullPage: true });
  /* two E12 */
  await p.goto(url); await p.click('.choice[data-k="pair"]');
  await p.click('.plrow[data-side="A"][data-id="E12"]'); await p.click('.plrow[data-side="B"][data-id="E12"]');
  await go('pairprog');
  await p.click('#plates button.kk[data-s="A"][data-i="11"]'); await p.click('#plates button.kk[data-s="B"][data-i="8"]');
  r = await p.evaluate(() => [W.pair.links[11], checks().length, targets().map(t => fwNameFor(t)).join()]);
  check(r[0] === 8 && r[1] === 0 && r[2] === 'fw_e12_p,fw_e12_p', 'two E12: pole 12 <-> pole 9, both fw_e12_p ' + JSON.stringify(r));
  await b.close(); console.log('fails ' + fails);
})();
