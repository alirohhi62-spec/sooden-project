const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const core = require('/home/claude/avrsim/cfgcore.js');
const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  p.on('dialog', d => d.accept());
  fs.writeFileSync(B + 'mode.txt', 'ok');
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]');
  // the user's case: an extra empty button in the 4-ch model
  await p.locator('.libbox summary').click();
  await p.locator('.lbadd').first().click();
  await p.click('#next');
  const fin = await p.textContent('#stage');
  check(fin.includes('خطا:') && fin.includes('کد دکمه وارد نشده'), 'finish lists the error');
  await p.screenshot({ path: '/home/claude/out/err-list.png' });
  await p.click('.errgo[data-err="0"]');
  await p.waitForTimeout(400);
  check((await p.textContent('#stage')).includes('ریموت‌های این پنل'), 'click -> back to the program step');
  const bub = p.locator('.errbub');
  check(await bub.count() === 1 && (await bub.textContent()).includes('کد این دکمه خالی است'), 'bubble explains how to fix');
  check(await p.locator('tr.errfocus .scode').count() === 1, 'the row with the empty code is highlighted');
  const focused = await p.evaluate(() => document.activeElement && document.activeElement.className);
  check(focused === 'scode', 'cursor is in the code field');
  const vis = await p.locator('tr.errfocus').evaluate(el => { const r = el.getBoundingClientRect(); return r.top >= 0 && r.bottom <= innerHeight; });
  check(vis, 'scrolled into view');
  await p.screenshot({ path: '/home/claude/out/err-bubble.png' });
  // fix it right there
  await p.locator('tr.errfocus .scode').fill('0011'); await p.locator('tr.errfocus .scode').dispatchEvent('change');
  await p.waitForTimeout(300);
  check(await p.locator('.errbub').count() === 0, 'bubble closes after the fix');
  // new 12-channel model from the place menu
  await p.click('.sadd');
  await p.locator('.smodel').nth(1).selectOption('__new');
  check(await p.locator('.newmodel').count() === 1, 'new-model form appears');
  await p.fill('.newmodel .nmname', 'ریموت ۱۲ کانال سفید');
  await p.selectOption('.newmodel .nmcount', '12');
  await p.click('.newmodel .nmok');
  await p.waitForTimeout(300);
  const slot2 = p.locator('.rtype[data-slot="S-1"]');
  check(await slot2.locator('tr').count() === 13, '12 button rows created at once');
  check((await p.locator('.smodel').nth(1).inputValue()) !== '' && (await p.locator('.smodel').nth(1).textContent()).includes('ریموت ۱۲ کانال سفید (۱۲ دکمه)'), 'place 2 uses the new model');
  // fill codes 1..12 for the 12 buttons in the place table
  for (let i = 0; i < 12; i++) {
    const inp = slot2.locator('.scode').nth(i);
    await inp.fill(String(i + 1)); await inp.dispatchEvent('change'); await p.waitForTimeout(60);
  }
  // button 9 -> poles 2+3 only off; button 1 default -> pole 1
  await slot2.locator('.spole').nth(8 * 4 + 1).check(); await slot2.locator('.spole').nth(8 * 4 + 2).check();
  await slot2.locator('.sact').nth(1).selectOption('off').catch(() => {});
  await p.click('#next');
  check((await p.textContent('#stage')).includes('همه تنظیمات معتبر است'), 'all valid now ' + (await p.evaluate(() => checks().map(e => e.msg).join(' / '))));
  // duplicate code -> error -> navigate
  await p.click('.pc[data-i="4"]');
  const s2 = p.locator('.rtype[data-slot="S-1"] .scode');
  await s2.nth(11).fill('1'); await s2.nth(11).dispatchEvent('change'); await p.waitForTimeout(300);
  await p.click('#next');
  check((await p.textContent('#stage')).includes('تکراری'), 'duplicate code reported');
  await p.click('.errgo');
  await p.waitForTimeout(300);
  check((await p.locator('.errbub').textContent()).includes('قبلاً برای'), 'duplicate bubble names the other button');
  await p.locator('tr.errfocus .scode').fill('12'); await p.locator('tr.errfocus .scode').dispatchEvent('change');
  await p.click('#next');
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pgbox .msg', { timeout: 30000 });
  check((await p.textContent('.pgbox')).includes('پروگرم شد'), 'programmed');
  const fl = core.parseHex(fs.readFileSync(B + 'state/flash.hex', 'utf8'));
  const c = [...Array(128)].map((_, i) => fl.get(0x1F80 + i));
  check(c[31] === 2 && c[127] === core.crc8(c, 127), '2 places, crc ok');
  check(c[32 + 3] === 0 && c[32 + 1] === 1, 'place 1: the extra button (code 3) has no poles -> nothing');
  check(c[48 + 1] === 0x01 && c[48 + 2] === 0x22 && c[48 + 3] === 0x04 && c[48 + 4] === 0x08 && c[48 + 9] === 0x06 && c[48 + 12] === 0, 'place 2: buttons 1-4 -> poles 1-4, button 2 only-off, button 9 -> poles 2+3, others nothing');
  const lib = JSON.parse(fs.readFileSync(B + 'sooden_remotes.json', 'utf8'));
  check(lib.models.length === 2 && lib.models[1].buttons.length === 12 && lib.models[1].buttons.every((x, i) => x.code === i + 1), 'library file: 12-ch model with codes 1..12');
  await b.close();
  console.log('fails', fails);
})();
