const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  const r = await p.evaluate(() => {
    W.mode = 'pair'; W.pair.A = newPanel('P4', 'کلید ورودی'); W.pair.B = newPanel('P4', 'کلید خواب');
    W.pair.A.poles[0].name = 'لوستر'; W.pair.A.remote = false; W.pair.B.poles[2].name = 'هال';
    W.pair.A.poles[3].type = 'm'; W.pair.B.poles[1].type = 't'; W.pair.B.poles[1].on = [0]; W.pair.B.poles[1].off = [3]; W.pair.B.poles[1].min = 7;
    W.pair.links = {}; 
    const ts = targets();
    return ts.map(t => ({ link: t.cfg && t.cfg.link, html: t.cfg ? brochureHtml(t) : '' }));
  });
  check(r.length === 2 && r[0].html.includes('کلید ورودی') && r[1].html.includes('کلید خواب'), 'pair: one brochure per panel');
  check(r[0].html.includes('مستر:'), 'master described');
  check(r[1].html.includes('سناریو سرویس') && r[1].html.includes('۷ دقیقه'), 'service scenario described');
  check(!r[0].html.includes('ریموت‌ها'), 'no remote section when the panel has no remote');
  // brochure with a link
  const r2 = await p.evaluate(() => { const old = peerOf; window.__pk = 1; const t = targets()[0]; t.cfg.link[0] = 2; return brochureHtml(t); });
  check(r2.includes('دوطرفه') && r2.includes('(هال)') && r2.includes('کلید خواب'), 'two-way link names the other panel and pole');
  await b.close(); console.log('fails', fails);
})();
