// 23-key board (ATmega32 + ATmega64) in the programmer: models, editor, config, two-step programming
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
const mode = m => fs.writeFileSync(B + 'mode.txt', m);
(async () => {
  for (const d of ['m32', 'm64']) fs.rmSync(B + 'state/' + d, { recursive: true, force: true });
  fs.rmSync(B + 'archive', { recursive: true, force: true });
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  mode('ok');
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]');
  await p.click('.choice[data-k="remote"]');
  check(await p.locator('.mdl[data-id="ALARM"]').count() === 0, 'remote-only path: 23-key models not offered (they need wifi + remote)');
  await p.click('#back'); await p.click('.choice[data-k="both"]');
  check(await p.locator('.mdl[data-id="ALARM"]').count() === 1 && await p.locator('.mdl[data-id="P20"]').count() === 1, 'wifi + remote path: both 23-key cards');
  check(await p.locator('.mdl[data-id="P4"]').count() === 0, 'P4 (no wifi version) not in this path');
  await p.click('.mdl[data-id="ALARM"]');
  check(await p.locator('#bsub .bmodel').count() === 5 && await p.locator('#bsub2 .bmodel.custom').count() === 2, 'alarm: 5 fixed + 2 custom layouts (custom marked)');
  await p.screenshot({ path: '/home/claude/out/it10-models.png', fullPage: true });
  await p.click('.bmodel[data-s="a14"]');
  check((await p.textContent('#sidefuse')).includes('دزدگیردار ۱۴ پل'), 'path shows the layout');
  check(await p.locator('.bigsvg .kb').count() === 23, 'panel drawn with 23 keys');
  let cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type.slice(0, 12).every(t => t === 1) && cfg.type[12] === 9 && cfg.type[13] === 10 && cfg.type.slice(14, 18).every(t => t === 8), 'a14: 12 normal poles, ON/OFF, change pass, 4 digits');
  check(cfg.sec1.slice(14, 18).join() === '1,2,3,4', 'keypad keys carry their digit');
  check(cfg.type[18] === 7 && cfg.type[19] === 7 && cfg.offmask[18] === 1 << 19 && cfg.offmask[19] === 1 << 18 && cfg.sec1[18] === 45, 'curtain pair 19/20, 45 s');
  check(cfg.type[20] === 0 && cfg.type[21] === 0 && cfg.type[22] === 0 && cfg.alarm === 1, 'no scenario chosen by default; alarm flag');
  check(cfg.alArm === 20 && cfg.alEntry === 30 && cfg.alSiren === 60 && cfg.dimsec === 60, 'alarm 20 / 30 / 60 s, panel dark after 60 s');
  check(await p.evaluate(() => fwNameFor(targets()[1])) === 'fw_big_a_i', 'alarm hex with curtain group: fw_big_a_i');
  let m = await p.evaluate(() => { const m = parseHex(targetHex(targets()[1])); return [593, 594, 595].map(a => m.get(0xF000 + a)); });
  check(m.join() === '20,30,60', 'alarm times in the hex');
  // default remote: buttons A-D -> poles 1-4
  check(cfg.rmap[0][1] === 1 && cfg.rmap[0][2] === 2 && cfg.rmap[0][4] === 4 && cfg.rmap[0][8] === 8, 'default remote: A..D -> poles 1..4');
  // fixed key: no kind select; name
  await p.click('.bigsvg .kb[data-k="4"]');
  check(await p.locator('.bked .ptype').count() === 0 && (await p.textContent('.bked')).includes('ثابت'), 'fixed pole: kind locked');
  await p.fill('.bked .pnm', 'لوستر'); await p.click('.bigsvg .kb[data-k="4"]');
  check((await p.textContent('.bigsvg')).includes('لوستر'), 'pole name shown on the panel');
  // keypad key info
  await p.click('.bigsvg .kb[data-k="15"]');
  check((await p.textContent('.bked')).includes('آژیر') && (await p.textContent('.bked')).includes('رقم رمز'), 'keypad key 16: digit, siren pin note');
  // ---- the three scenarios
  await p.click('.bigsvg .kb[data-k="20"]');
  check(await p.locator('.bked .ptype option[value="el"]').count() === 0, 'scenario 1: ELEVATOR not offered');
  await p.selectOption('.bked .ptype', 'ex');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[20] === 11 && cfg.sec1[20] === 20 && cfg.sec2[20] === 0 && cfg.onmask[20] === 1 << 19 && cfg.offmask[20] === (0xFFF | 1 << 18), 'EXIT 20 s: all poles off, curtain close started');
  check((await p.textContent('.bked')).includes('قفل'), 'under 60 s: the editor says the panel locks');
  await p.uncheck('.bked .pclose');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.onmask[20] === 0 && cfg.offmask[20] === (0xFFF | 3 << 18), 'without closing: curtains only stopped');
  await p.fill('.bked .psec[data-f="secs"]', '300'); await p.press('.bked .psec[data-f="secs"]', 'Tab');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.sec1[20] === 300 % 256 && cfg.sec2[20] === 1 && (await p.textContent('.bked')).includes('لغو'), '300 s: 16 bit time; editor says a touch cancels');
  await p.click('.bigsvg .kb[data-k="21"]'); await p.selectOption('.bked .ptype', 'el');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[21] === 13 && cfg.onmask[21] === 1 << 20, 'ELEVATOR on scenario 2: relay on scenario 1 red pin');
  check(await p.evaluate(() => fwNameFor(targets()[1])) === 'fw_big_a_ix', 'hex: alarm + curtain + scenarios (fw_big_a_ix)');
  await p.click('.bigsvg .kb[data-k="22"]'); await p.selectOption('.bked .ptype', 'sl');
  check(await p.evaluate(() => checks().some(e => e.msg.includes('چراغ خواب انتخاب نشده'))), 'SLEEP without a night light -> error');
  await p.selectOption('.bked .psel[data-f="night"]', '5');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[22] === 12 && cfg.sec1[22] === 30 && cfg.onmask[22] === 1 << 5 && !(cfg.offmask[22] & 1 << 5) && (cfg.offmask[22] & 1), 'SLEEP 30 s: night light pole 6 kept on');
  check(!(await p.evaluate(() => checks().length)), 'no errors');
  await p.click('.bigsvg .kb[data-k="20"]'); await p.selectOption('.bked .ptype', 'p');
  check(await p.evaluate(() => checks().some(e => e.msg.includes('رله آسانسور'))), 'scenario 1 with a relay of its own while the elevator uses its pin -> error');
  await p.selectOption('.bked .ptype', 'm');
  // scenario 1: move to the bottom right, kind service
  await p.click('.bigsvg .kb[data-k="20"]');
  await p.selectOption('.bked .bmove', '22');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[22] === 2 && cfg.type[20] === 12 && cfg.onmask[20] === 1 << 5 && await p.evaluate(() => W.single.lay[22].join()) === 's,1', 'scenario 1 moved to the bottom right key (SLEEP went to the left, night light kept)');
  await p.selectOption('.bked .ptype', 't');
  await p.click('#next');
  check((await p.textContent('#stage')).includes('سناریو سرویس هیچ پلی برای روشن کردن ندارد'), 'service without fan -> error on finish');
  await p.click('.errgo');
  check(await p.evaluate(() => W.single.sel) === 22 && await p.locator('.bked [data-bk="22"]').count() === 1, 'error -> back to the editor with that key chosen');
  await p.check('.bked input[data-pk="on"][data-k="11"]'); await p.check('.bked input[data-pk="off"][data-k="0"]');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[22] === 3 && cfg.onmask[22] === 1 << 11 && cfg.offmask[22] === 1, 'service: off pole 1, fan pole 12');
  // scenario move to centre (no relay): pulse not offered
  await p.click('.bigsvg .kb[data-k="21"]');
  check(await p.locator('.bked .ptype option[value="p"]').count() === 0, 'bottom centre key: no pulse (no relay)');
  // ---- 8 pole: empty keys and remote mapping
  await p.click('#back');
  await p.click('.bmodel[data-s="a8"]');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[0] === 0 && cfg.type[1] === 0 && cfg.type[10] === 0 && cfg.type[11] === 0 && cfg.type.slice(2, 10).every(t => t === 1), 'a8: places 1,2,11,12 empty, poles at 3..10');
  check(cfg.rmap[0][1] === 1 << 2 && cfg.rmap[0][8] === 1 << 5, 'a8 remote: A -> pole 1 (place 3), D -> pole 4 (place 6)');
  check(await p.evaluate(() => fwNameFor(targets()[1])) === 'fw_big_a', 'no special kinds: fw_big_a');
  await p.click('.bigsvg .kb[data-k="20"]'); await p.selectOption('.bked .ptype', 'm');
  const opts = await p.locator('.bked .bmove option').allTextContents();
  check(opts.length === 7, 'scenario 1 may go to the 2 other bottom keys or the 4 empty places (' + (opts.length - 1) + ')');
  await p.selectOption('.bked .bmove', '0');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[0] === 2 && cfg.type[20] === 0, 'scenario 1 now on place 1');
  // ---- custom: free keys take any kind
  await p.click('#back');
  await p.click('.bmodel[data-s="ac"]');
  await p.click('.bigsvg .kb[data-k="0"]');
  await p.selectOption('.bked .ptype', 'co');
  await p.selectOption('.bked .psel[data-f="partner"]', '1');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[0] === 7 && cfg.type[1] === 7 && cfg.offmask[0] === 2 && cfg.offmask[1] === 1, 'custom: places 1/2 made a curtain pair');
  check(await p.evaluate(() => W.single.lay[0][0] + W.single.lay[1][0]) === 'cocc', 'drawn as curtain open / close');
  await p.click('.bigsvg .kb[data-k="19"]');
  await p.selectOption('.bked .ptype', 'cs');
  await p.selectOption('.bked .psel[data-f="partner"]', '18');
  await p.selectOption('.bked .psel[data-f="pump"]', '4');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[19] === 7 && cfg.type[18] === 7 && cfg.onmask[19] === 1 << 4 && cfg.sec2[19] === 10, 'custom: cooler on 19/20 with pump on pole 5');
  await p.click('.bigsvg .kb[data-k="12"]');
  check(await p.locator('.bked .ptype').count() === 0, 'custom alarm: keypad keys stay fixed');
  await p.click('.bigsvg .kb[data-k="2"]'); await p.selectOption('.bked .ptype', 'x');
  check(await p.evaluate(() => targets()[1].cfg.type[2]) === 0, 'free key made empty');
  // remote on an empty key -> error
  check(await p.locator('.spole[data-s="0"][data-k="2"]:checked').count() === 1, 'remote button C still points at the key made empty (shown so it can be removed)');
  check(await p.evaluate(() => checks().some(e => e.msg.includes('بدون رله'))), 'remote button on an empty key -> error');
  await p.click('.spole[data-s="0"][data-k="2"]');
  check(await p.locator('.spole[data-s="0"][data-k="2"]').count() === 0 && !(await p.evaluate(() => checks().some(e => e.msg.includes('بدون رله')))), 'unticked: empty key no longer listed, error gone');
  // remote slots: at most 4
  for (let i = 0; i < 5; i++) { const a = p.locator('.sadd'); if (await a.isEnabled()) await a.click(); }
  check(await p.locator('.rtype[data-slot]').count() === 4, 'at most 4 remotes');
  // hold timer flag lands on bit 26
  await p.check('.stm[data-s="0"][data-bid="bD"]');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.rmap[0][8] === (0x04000000 | 1 << 3), 'hold timer -> bit 26 on the 23-key board');
  await p.selectOption('.sact[data-s="0"][data-bid="bD"]', 'on');
  check(await p.evaluate(() => targets()[1].cfg.rmap[0][8]) === (0x04000000 | 1 << 24 | 1 << 3), '"only on" -> action bits 24-25');
  // ---- 20 pole family
  await p.click('#back');
  await p.click('.mdl[data-id="P20"]');
  check(await p.locator('#bsub .bmodel').count() === 2 && await p.locator('#bsub2 .bmodel').count() === 1, '20 pole: 2 fixed + 1 custom');
  await p.click('.bmodel[data-s="p14"]');
  await p.click('.bigsvg .kb[data-k="14"]');
  await p.selectOption('.bked .ptype', 'm');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type[14] === 2 && cfg.alarm === 0 && cfg.type.slice(15, 20).every(t => t === 14), 'custom scenario 1 = master; others custom scenarios (default); no alarm');
  await p.click('#back'); await p.click('.bmodel[data-s="p20"]');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.type.slice(0, 20).every(t => t === 1) && cfg.alarm === 0, '20 pole: 20 normal poles, no alarm');
  await p.click('.bigsvg .kb[data-k="20"]'); await p.selectOption('.bked .ptype', 'm');
  cfg = await p.evaluate(() => targets()[1].cfg);
  check(cfg.onmask[20] === 0xFFFFF && await p.evaluate(() => fwNameFor(targets()[1])) === 'fw_big', 'master on all 20; hex fw_big (no alarm)');
  // ---- finish: two steps
  await p.click('#next');
  check(await p.locator('[data-pg]').count() === 2, 'finish: two program buttons');
  const txt = await p.textContent('#stage');
  check(txt.includes('مرحله ۱ — میکروی تاچ') && txt.includes('مرحله ۲ — میکروی اصلی') && txt.includes('Ext FF'), 'steps named, extended fuse shown');
  const io = fs.readFileSync('/home/claude/fw/out/fw_big_io32.hex', 'utf8').trim();
  const nl = t => t.replace(/\r/g, '').trim();
  check(nl(await p.evaluate(() => targetHex(targets()[0]))) === nl(io), 'step 1 hex = ATmega32 program');
  fs.writeFileSync('/home/claude/out/it10_main.hex', await p.evaluate(() => targetHex(targets()[1])));
  // probe with the DIP on the ATmega64
  mode('dip64');
  await p.click('#probe'); await p.waitForSelector('#presult .msg', { timeout: 20000 });
  const pr = await p.textContent('#presult');
  check(pr.includes('مگا ۶۴ (میکروی اصلی) پیدا شد') && pr.includes('Ext'), 'probe: the ATmega64 answered, found and named: ' + pr.slice(0, 120));
  await p.waitForTimeout(800);
  mode('ok');
  // program step 1 with the DIP on the wrong chip
  mode('dip64');
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pgbox[data-i="0"] .pmres .msg', { timeout: 30000 });
  check((await p.textContent('.pgbox[data-i="0"]')).includes('دیپ‌سوئیچ انتخاب میکرو را روی مگا ۳۲'), 'wrong chip -> DIP switch hint');
  mode('ok');
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pgbox[data-i="0"] .pmres .msg.ok', { timeout: 30000 });
  check((await p.textContent('.pgbox[data-i="0"]')).includes('مرحله ۲'), 'step 1 programmed; asks for step 2');
  await p.click('[data-pg="1"]'); await p.click('[data-go]');
  await p.waitForSelector('.pgbox[data-i="1"] .pmres .msg.ok', { timeout: 30000 });
  await p.waitForTimeout(500);
  check(nl(fs.readFileSync(B + 'state/m64/flash.hex', 'utf8')) === nl(fs.readFileSync('/home/claude/out/it10_main.hex', 'utf8')), 'step 2: ATmega64 got the patched hex');
  check(!fs.existsSync(B + 'state/m32/flash.hex') || nl(fs.readFileSync(B + 'state/m32/flash.hex', 'utf8')) === nl(io), 'the ATmega32 never got the main program');
  check(fs.readFileSync(B + 'state/m64/efuse', 'utf8') === '0xff', 'ATmega64 extended fuse FF written');
  check(fs.existsSync(B + 'archive') && fs.readdirSync(B + 'archive').length === 1, 'brochure archived after step 2');
  const br = await p.evaluate(() => brochureHtml(targets()[1]));
  check(br.includes('<svg') && br.includes('۲۰ پل') && br.includes('کلید جای ۱ (بالا چپ)'), 'brochure: panel picture, model, remote learning key');
  await p.screenshot({ path: '/home/claude/out/it10-finish.png', fullPage: true });
  await p.click('#back');
  await p.click('.bigsvg .kb[data-k="20"]');
  await p.screenshot({ path: '/home/claude/out/it10-editor.png', fullPage: false });
  await b.close(); console.log('fails', fails);
})();
