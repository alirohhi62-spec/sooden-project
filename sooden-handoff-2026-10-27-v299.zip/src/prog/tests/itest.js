const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
const url = fs.readFileSync('/home/claude/prog/build/url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 1000 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  fs.writeFileSync('/home/claude/prog/build/mode.txt', 'ok');
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]');
  check(await p.locator('.rtype').count() === 2, 'two remote type tables');
  check(await p.locator('.rtab tr').count() === 10, '4 default rows per type (+headers)');
  await p.click('.rlast');
  await p.waitForSelector('.rlastres .msg', { timeout: 15000 });
  const t = await p.textContent('.rlastres');
  check(t.includes('کد ۱۲') && t.includes('نوع ۲'), 'last button read: code 12 of a type-2 remote');
  check(t.includes('11111') && t.includes('2222A'), 'learned remotes listed');
  await p.click('[data-addt="1"]');
  const rows = p.locator('.rtype').nth(1).locator('tr');
  check(await rows.count() === 6, 'row for code 12 added to type 2');
  // select poles 1 and 4 for it, action only-on
  await p.locator('.rtype').nth(1).locator('tr').nth(5).locator('.rpole[data-k="0"]').check();
  await p.locator('.rtype').nth(1).locator('tr').nth(5).locator('.rpole[data-k="3"]').check();
  await p.locator('.rtype').nth(1).locator('tr').nth(5).locator('.ract').selectOption('on');
  // remove default row 'دکمه ۴' of type 2 to test deletion
  await p.locator('.rtype').nth(1).locator('.rdel').nth(3).click();
  await p.fill('.stag', '300');
  await p.screenshot({ path: '/home/claude/out/remote-editor.png', fullPage: true });
  await p.click('#next');
  check((await p.textContent('#stage')).includes('همه تنظیمات معتبر است'), 'settings valid');
  await p.click('[data-pg="0"]');
  check((await p.textContent('.pgbox')).includes('کریستال'), 'confirmation shows crystal warning');
  await p.screenshot({ path: '/home/claude/out/program-confirm.png', fullPage: true });
  await p.click('[data-go]');
  await p.waitForSelector('.pgbox .msg', { timeout: 30000 });
  const r = await p.textContent('.pgbox');
  check(r.includes('پروگرم شد') && r.includes('فیوزها نوشته شدند'), 'programmed, fuses written: ' + r.slice(0, 80));
  await p.screenshot({ path: '/home/claude/out/program-done.png', fullPage: true });
  // flashed image -> config block
  const core = require('/home/claude/avrsim/cfgcore.js');
  const m = core.parseHex(fs.readFileSync('/home/claude/prog/build/state/flash.hex', 'utf8'));
  const c = [...Array(64)].map((_, i) => m.get(0x1FC0 + i));
  check(c[2] === 2 && c[63] === core.crc8(c, 63), 'flashed config v2 with valid crc');
  check(c[30] === 30, 'stagger 300 ms in flash');
  check(c[31 + 1] === 0x01 && c[31 + 2] === 0x02 && c[31 + 4] === 0x04 && c[31 + 8] === 0x08, 'type1 default table');
  check(c[47 + 12] === (0x09 | 0x10) && c[47 + 8] === 0 && c[47 + 4] === 0x04, 'type2: code12 -> poles 1+4 only-on, code8 row deleted');
  check(fs.readFileSync('/home/claude/prog/build/state/lfuse', 'utf8') === '0x3f' && fs.readFileSync('/home/claude/prog/build/state/hfuse', 'utf8') === '0xd1', 'fuses 3F/D1 on chip');
  check(fs.readFileSync('/home/claude/prog/build/state/eeprom.bin')[0x10] === 0x5F, 'learned remotes kept in EEPROM');
  // error path
  fs.writeFileSync('/home/claude/prog/build/mode.txt', 'notarget');
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pgbox .msg', { timeout: 30000 });
  check((await p.textContent('.pgbox')).includes('چیزی روی فلش نوشته نشد'), 'no panel: clear error, nothing written');
  // duplicate code error
  await p.click('.pc[data-i="4"]');
  await p.locator('.rtype').nth(0).locator('.rcode').nth(1).selectOption('1');
  await p.click('#next');
  check((await p.textContent('#stage')).includes('دو بار تعریف شده'), 'duplicate code is reported');
  check(await p.locator('[data-pg]').count() === 0, 'no program button while settings invalid');
  fs.writeFileSync('/home/claude/prog/build/mode.txt', 'ok');
  await b.close();
  console.log('fails', fails);
})();
