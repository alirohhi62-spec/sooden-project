// 12 economic panel (E12): card, its own panel picture, pole kinds (1..8 light / empty, 9..12 also curtain or scenario),
// the three scenarios, one ATmega64 step with fuses 3F/C1/FF; the hexes go to the end-to-end simulation (avrsim/te12_e2e.js)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
const url = 'file:///home/claude/out/sooden-programmer.html';
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]');
  await p.click('.choice[data-k="both"]');
  check(await p.locator('.mdl[data-id="E12"]').count() === 1, 'wifi + remote path: the 12 economic card');
  await p.screenshot({ path: S + 'e12-models.png', fullPage: true });
  await p.click('.mdl[data-id="E12"]');
  check(await p.locator('.bigsvg .kb').count() === 15, 'its own picture: 12 poles + 3 scenarios (15 keys)');
  let t = await p.evaluate(() => targets());
  check(t.length === 1 && t[0].variant.mcu === 'ATmega64', 'one step: ATmega64');
  let c = await p.evaluate(() => { const x = chipOf(targets()[0].variant); return [x.lfuse, x.hfuse, x.efuse]; });
  check(c.join() === '63,193,255', 'fuses 3F / C1 / FF (as the alarm panel)');
  let cfg = t[0].cfg;
  check(cfg.type.slice(0, 12).every(x => x === 1) && cfg.type.slice(12, 20).every(x => x === 0), 'default: 12 lights, places 13..20 not on this panel');
  check(await p.evaluate(() => fwNameFor(targets()[0])) === 'fw_e12', 'hex fw_e12');
  check(await p.evaluate(() => firmwareCfg(W.single, 0, null, null, true).mdl) === 'e12', 'the app sees model e12');
  // pole 5: only light / empty
  await p.click('.bigsvg .kb[data-k="4"]');
  let opts = await p.$$eval('.bked .e12k option', o => o.map(x => x.value));
  check(opts.join() === 'n,x', 'pole 5: light or empty only');
  for (const k of [4, 5, 6, 7]) { await p.click(`.bigsvg .kb[data-k="${k}"]`); await p.selectOption('.bked .e12k', 'x'); }
  // pole 9: curtain -> 10 follows
  await p.click('.bigsvg .kb[data-k="8"]');
  opts = await p.$$eval('.bked .e12k option', o => o.map(x => x.value));
  check(['co', 'cu', 'm', 'ex', 'sl'].every(x => opts.includes(x)) && !opts.includes('cc'), 'pole 9: curtain open, custom and other scenarios');
  await p.selectOption('.bked .e12k', 'co');
  let r = await p.evaluate(() => [W.single.poles[8].type, W.single.poles[9].type, W.single.poles[8].partner, W.single.poles[9].partner]);
  check(r.join() === 'co,cc,9,8', 'pole 9 open + pole 10 close: one curtain');
  await p.fill('.bked .psec[data-f="sec"]', '30'); await p.press('.bked .psec[data-f="sec"]', 'Tab');
  // pole 11: custom scenario, 12 light
  await p.click('.bigsvg .kb[data-k="10"]'); await p.selectOption('.bked .e12k', 'cu');
  // scenarios: s1 EXIT (closes the curtain), s2 elevator, s3 SLEEP night light pole 2
  await p.click('.bigsvg .kb[data-k="21"]');
  check(await p.locator('.bked .ptype option[value="el"]').count() === 1, 'centre key: ELEVATOR offered');
  await p.selectOption('.bked .ptype', 'el');
  await p.click('.bigsvg .kb[data-k="20"]');
  check(await p.locator('.bked .ptype option[value="el"]').count() === 0, 's1: no elevator');
  await p.selectOption('.bked .ptype', 'ex');
  await p.fill('.bked .psec[data-f="secs"]', '5'); await p.press('.bked .psec[data-f="secs"]', 'Tab');
  await p.click('.bigsvg .kb[data-k="22"]'); await p.selectOption('.bked .ptype', 'sl');
  await p.fill('.bked .psec[data-f="secs"]', '6'); await p.press('.bked .psec[data-f="secs"]', 'Tab');
  await p.selectOption('.bked .psel[data-f="night"]', '1');
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  cfg = await p.evaluate(() => targets()[0].cfg);
  check(cfg.type[4] === 0 && cfg.type[8] === 7 && cfg.type[9] === 7 && cfg.offmask[8] === 1 << 9 && cfg.sec1[8] === 30 && cfg.sec1[9] === 30, 'cfg: 5..8 empty, curtain 9/10 (30 s both ways)');
  check(cfg.type[10] === 14 && cfg.type[21] === 13 && cfg.onmask[21] === 1 << 21, 'cfg: custom on 11, elevator on its own relay');
  check(cfg.type[20] === 11 && cfg.sec1[20] === 5 && (cfg.onmask[20] & (1 << 9)), 'cfg: EXIT 5 s closes the curtain');
  check(cfg.type[22] === 12 && cfg.onmask[22] === 1 << 1, 'cfg: SLEEP, night light pole 2');
  check(await p.evaluate(() => fwNameFor(targets()[0])) === 'fw_e12_ix', 'hex fw_e12_ix (curtain + scenarios)');
  r = await p.evaluate(() => layOf(W.single)); check(r === 'LLLL----UWSL--------XEZ', 'app layout ' + r);
  // 12 remote places, every button of place k -> pole k
  r = await p.evaluate(() => { const c = targets()[0].cfg; return { n: c.nslot, e: c.e12, r0: c.rmap[0].slice(0, 9), r11: c.rmap[11].slice(0, 9) }; });
  check(r.e && r.n === 12 && r.r0[1] === 1 && r.r0[2] === 1 && r.r0[4] === 1 && r.r0[8] === 1 && r.r11[1] === 12, '12 remote places; place 1: A..D -> pole 1, place 12 -> pole 12 ' + JSON.stringify(r));
  check(await p.locator('.sadd').isDisabled(), 'no 13th remote');
  await p.locator('.rtype[data-slot="S-0"] .spole[data-k="1"]').first().check();
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.some(m => m.includes('فقط یک کلید')), 'two poles on one button -> error');
  await p.locator('.rtype[data-slot="S-0"] .spole[data-k="1"]').first().uncheck();
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'fixed ' + r.join('|'));
  await p.screenshot({ path: S + 'e12-prog.png', fullPage: true });
  fs.writeFileSync(S + 'pr_e12.hex', await p.evaluate(() => targetHex(targets()[0])));
  // not in the network modes yet
  r = await p.evaluate(() => { W.mode = 'pair'; const a = !!variantFor(MODEL('E12'), need()); W.mode = 'single'; return a; });
  check(r, 'two-panel mode: offered (itest_e12pair.js)');
  await b.close(); console.log('fails ' + fails);
})();
