// 23-key board: the programmer writes each key's role letter and the model id for the phone app
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const url = fs.readFileSync('/home/claude/prog/build/url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="both"]');
  await p.click('.mdl[data-id="ALARM"]'); await p.click('.bmodel[data-s="a14"]');
  let c = await p.evaluate(() => targets()[1].cfg);
  check(c.mdl === 'a14' && c.lay === 'LLLLLLLLLLLLnc1234UW---', `a14: model "${c.mdl}", keys ${c.lay}`);
  const bytes = await p.evaluate(() => Array.from(buildCfgBig(targets()[1].cfg).slice(596, 627)));
  check(String.fromCharCode(...bytes.slice(0, 23)) === c.lay && String.fromCharCode(...bytes.slice(23, 26)) === 'a14' && bytes[26] === 0,
    'settings block: letters at 596, model at 619');
  /* scenarios chosen: S1 EXIT, S2 ELEVATOR, S3 SLEEP */
  const sel = async (k, v) => { await p.evaluate(([k, v]) => { const pn = W.single; pn.poles[k].type = v; if (v === 'sl') pn.poles[k].night = 0; }, [k, v]); };
  await sel(20, 'ex'); await sel(21, 'el'); await sel(22, 'sl');
  c = await p.evaluate(() => targets()[1].cfg);
  check(c.lay.slice(20) === 'XEZ', 'scenario keys: EXIT X, ELEVATOR E, SLEEP Z (' + c.lay + ')');
  await p.click('#back'); await p.click('#back').catch(() => {});
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="both"]');
  await p.click('.mdl[data-id="ALARM"]'); await p.click('.bmodel[data-s="a12"]');
  c = await p.evaluate(() => targets()[1].cfg);
  check(c.mdl === 'a12' && c.lay.slice(12, 20) === 'nc123456', 'a12 (6 digit keypad): ' + c.lay);
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="both"]');
  await p.click('.mdl[data-id="P20"]'); await p.click('.bmodel[data-s="p20"]');
  c = await p.evaluate(() => targets()[1].cfg);
  check(c.mdl === 'p20' && /^L{20}---$/.test(c.lay), 'p20: ' + c.lay);
  await p.evaluate(() => { const pn = W.single; pn.poles[0].type = 'm'; pn.poles[1].type = 'p'; pn.poles[2].type = 'dl'; pn.poles[3].type = 'ot'; pn.poles[4].type = 'do'; pn.poles[5].type = 't'; pn.poles[3].off = []; pn.poles[5].off = []; pn.poles[5].on = []; });
  c = await p.evaluate(() => targets()[1].cfg);
  check(c.lay.slice(0, 6) === 'MPYODT', 'kinds -> letters: master M, push P, delay Y, off timer O, delayed off D, service T (' + c.lay.slice(0, 6) + ')');
  await b.close(); console.log('fails', fails);
})();
