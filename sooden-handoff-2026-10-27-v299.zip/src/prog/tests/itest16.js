// ATtiny13 models in the programmer: 4 fixed programs, bell time written into the hex, fuses 62/FF
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const url = 'file:///home/claude/out/sooden-programmer.html';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="false"]');
  for (const id of ['T1P', 'T2P', 'TBELL', 'TLOGO']) check(await p.$(`.mdl[data-id="${id}"]`) !== null, 'model ' + id + ' offered without crystal');
  await p.click('.mdl[data-id="TBELL"]');
  check(await p.$('#belltime') !== null, 'bell: time box');
  let r = await p.evaluate(() => { const t = targets()[0]; const m = parseHex(t.fixedHex); return { l: t.label, b: [0x3F8, 0x3F9, 0x3FA].map(a => m.get(a)), c: chipOf(t.variant) }; });
  check(r.b.join() === '181,30,0' && r.c.lfuse === 0x62 && r.c.hfuse === 0xFF, 'default 3 s, fuses 62/FF ' + r.b.join() + ' ' + r.l);
  await p.fill('#belltime', '50'); await p.dispatchEvent('#belltime', 'change');
  r = await p.evaluate(() => { const m = parseHex(targets()[0].fixedHex); return [0x3F8, 0x3F9, 0x3FA].map(a => m.get(a)); });
  check(r.join() === '181,244,1', '50 s -> 500 tenths ' + r.join());
  await p.fill('#belltime', '0.5'); await p.dispatchEvent('#belltime', 'change');
  r = await p.evaluate(() => { const m = parseHex(targets()[0].fixedHex); return [0x3F9, 0x3FA].map(a => m.get(a)); });
  check(r.join() === '5,0', '0.5 s ' + r.join());
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  require('fs').writeFileSync('/tmp/bell05.hex', await p.evaluate(() => targetHex(targets()[0])));
  await b.close(); console.log('fails ' + fails);
})();
