import os
S='/home/claude/prog/build/state'; os.makedirs(S, exist_ok=True)
import shutil
for f in os.listdir(S): (shutil.rmtree if os.path.isdir(os.path.join(S,f)) else os.remove)(os.path.join(S,f))
def crc8(b):
    c=0
    for x in b:
        c^=x
        for _ in range(8): c=((c<<1)^7)&0xFF if c&0x80 else (c<<1)&0xFF
    return c
ee=bytearray(b'\xff'*512)
log=[0xA7,0x22,0x22,0xAC]; ee[0:5]=bytes(log+[crc8(log)])
pl=[0x60, 0x11,0x11,0x10] + [0xFF]*9
pl=pl+[crc8(pl)]
for base in (0x10,0x50,0x90): ee[base:base+14]=bytes(pl)
open(S+'/eeprom.bin','wb').write(ee); open(S+'/lfuse','w').write('0xff'); open(S+'/hfuse','w').write('0xd9')
