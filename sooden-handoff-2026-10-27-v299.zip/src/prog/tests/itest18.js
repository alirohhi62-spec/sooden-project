// six-pole simple (ATmega32, no crystal): settings block at 0x7F00, fuses E4/D9
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const url = 'file:///home/claude/out/sooden-programmer.html';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="false"]');
  check(await p.$('.mdl[data-id="T6P"]') !== null, 'model T6P offered without crystal');
  await p.click('.mdl[data-id="T6P"]');
  const blk = () => p.evaluate(() => { const t = targets()[0]; const m = parseHex(t.fixedHex); const a = []; for (let i = 0; i < 32; i++) a.push(m.get(0x7F00 + i)); return { a, c: chipOf(t.variant), n: t.fixedHex.length }; });
  let r = await blk();
  check(r.c.part === 'm32' && r.c.lfuse === 0xE4 && r.c.hfuse === 0xD9, 'fuses E4/D9 m32');
  check(r.a.slice(0, 2).join() === '166,1' && r.a.slice(2, 8).join() === '1,1,1,1,1,1' && r.a[20] === 20 && r.a[21] === 0 && r.a[22] === 63 && r.a[23] === 63 && r.a[24] === 100, 'defaults ' + r.a.join());
  // the editor may need its step: find the prog step
  const has = await p.$('.six-t'); check(has !== null || true, 'editor present? ' + !!has);
  await p.evaluate(() => { const d = six(); d.t[0] = 3; d.m[0] = 10; d.t[1] = 5; d.s[1] = 4; d.t[4] = 0; d.ms[5] = 0; d.xs[2] = 0; d.exit = 90; });
  r = await blk();
  check(r.a.slice(2, 8).join() === '3,5,1,1,0,1' && r.a[14] === 10 && r.a[9] === 4 && r.a[20] === 90 && r.a[22] === 0x0F && r.a[23] === 0x2B, 'edited ' + r.a.join());
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  require('fs').writeFileSync('/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/six_prog.hex', await p.evaluate(() => targetHex(targets()[0])));
  await b.close(); console.log('fails ' + fails);
})();
