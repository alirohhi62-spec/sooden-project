const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
const core = require('/home/claude/avrsim/cfgcore.js');
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  fs.writeFileSync(B + 'mode.txt', 'ok');
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]');
  const opts = await p.locator('.ptype[data-i="0"] option').allTextContents();
  check(opts.length === 14 && opts.includes('EXIT (خروج)') && opts.includes('پرده باز') && opts.includes('کولر دور تند') && opts.includes('سناریو سرویسی'), 'menu has 14 kinds: ' + opts.join('، '));
  // curtain on 1+2
  await p.selectOption('.ptype[data-i="0"]', 'co');
  await p.selectOption('.psel[data-i="0"][data-f="partner"]', '1');
  check(await p.inputValue('.ptype[data-i="1"]') === 'cc', 'choosing the partner makes pole 2 "curtain close"');
  check(await p.inputValue('.psec[data-i="0"][data-f="sec"]') === '45', 'curtain default 45 s');
  // pulse on 3, off timer on 4
  await p.selectOption('.ptype[data-i="2"]', 'p'); await p.fill('.psec[data-i="2"][data-f="sec"]', '2'); await p.dispatchEvent('.psec[data-i="2"][data-f="sec"]', 'change');
  await p.selectOption('.ptype[data-i="3"]', 'ot'); await p.fill('.psec[data-i="3"][data-f="min"]', '20'); await p.dispatchEvent('.psec[data-i="3"][data-f="min"]', 'change');
  await p.click('#next');
  check((await p.textContent('#stage')).includes('هیچ پلی برای خاموش کردن انتخاب نشده'), 'off timer without poles -> error');
  await p.click('#back').catch(async () => { await p.click('text=مرحله قبل'); });
  await p.check('input[data-pk="off"][data-i="3"][data-k="0"]'); await p.check('input[data-pk="off"][data-i="3"][data-k="1"]');
  await p.screenshot({ path: '/home/claude/out/ui-kinds.png', fullPage: true });
  await p.click('#next');
  check((await p.textContent('#stage')).includes('همه تنظیمات معتبر است'), 'valid');
  const r = await p.evaluate(() => { const t = targets()[0]; const m = parseHex(targetHex(t)); const b = []; for (let i = 0; i < 128; i++) b.push(m.get(0x1F80 + i)); return { name: fwNameFor(t), b }; });
  check(r.name === 'fw_4p_r_si', 'hex with both groups: ' + r.name);
  const c = r.b;
  check(c.slice(8, 12).join() === '7,7,6,4', 'types 7,7,6,4');
  check(c[16] === 2 && c[17] === 1 && c[19] === 3, 'curtain partners + off-timer poles');
  check(c[116] === 45 && c[117] === 45 && c[120] === 5 && c[121] === 5 && c[122] === 2 && c[118] === 0, 'seconds: 45/45, pause 0.5, pulse 2 s');
  check(c[27] === 20 && c[127] === core.crc8(c, 127), 'off timer 20 min, crc ok');
  const html = await p.evaluate(() => brochureHtml(targets()[0]));
  check(html.includes('پرده باز') && html.includes('تایمر خاموشی') && html.includes('۲ ثانیه وصل'), 'brochure describes the new kinds');
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pmres .msg.ok', { timeout: 30000 });
  check((await p.textContent('.pmres')).includes('پروگرم شد'), 'programmed');
  // cooler: 1 pump, 2 slow, 3 fast
  await p.evaluate(() => { W.step = steps().findIndex(s => s[0] === 'prog'); render(); });
  await p.selectOption('.ptype[data-i="0"]', 'n'); await p.selectOption('.ptype[data-i="2"]', 'n');
  await p.selectOption('.ptype[data-i="1"]', 'cs');
  await p.selectOption('.psel[data-i="1"][data-f="partner"]', '2');
  await p.selectOption('.psel[data-i="1"][data-f="pump"]', '0');
  check(await p.inputValue('.ptype[data-i="2"]') === 'cf' && await p.inputValue('.psel[data-i="2"][data-f="pump"]') === '0', 'fast pole set, same pump');
  await p.click('#next');
  const c2 = await p.evaluate(() => { const t = targets()[0]; return { cfg: t.cfg, name: fwNameFor(t) }; });
  check(c2.cfg.type.join() === '1,7,7,4' && c2.cfg.offmask[1] === 4 && c2.cfg.offmask[2] === 2 && c2.cfg.onmask[1] === 1 && c2.cfg.onmask[2] === 1 && c2.cfg.sec2[1] === 10, 'cooler config (interlock, pump, 1 s)');
  check(c2.name === 'fw_4p_r_i', 'only the _i group: ' + c2.name);
  // pair + remote: does not fit
  const e = await p.evaluate(() => { W.mode = 'pair'; W.pair.A = newPanel('P4', 'A'); W.pair.B = newPanel('P4', 'B'); W.pair.links = {}; setKind(W.pair.A, 0, 'p'); return checks().map(x => x.msg); });
  check(e.some(x => x.includes('جا نمی‌شوند')), 'pair + remote + push button -> clear error');
  const e2 = await p.evaluate(() => { W.pair.A.remote = false; return { m: checks().map(x => x.msg), n: fwNameFor(targets()[0]) }; });
  check(!e2.m.some(x => x.includes('جا نمی‌شوند')) && e2.n === 'fw_4p_pair_s', 'pair without remote: fits (' + e2.n + ')');
  await b.close(); console.log('fails', fails);
})();
