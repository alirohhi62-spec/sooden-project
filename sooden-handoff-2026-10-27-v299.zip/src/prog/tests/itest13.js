// 23-key board: custom scenario / group (places 13..20), 20 pole "use" ticks, poles + custom scenarios model, water cooler preset
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const url = fs.readFileSync('/home/claude/prog/build/url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  const open = async sub => {
    await p.goto(url);
    await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="both"]');
    await p.click('.mdl[data-id="P20"]'); await p.click(`.bmodel[data-s="${sub}"]`);
  };
  const cfg = () => p.evaluate(() => targets()[1].cfg);
  const key = async k => { await p.click(`.bigsvg .kb[data-k="${k}"]`); };

  console.log('20 poles: use ticks');
  await open('p20');
  await key(4);
  check(await p.locator('.buse').count() === 1, 'place 5 has the "use" tick');
  await p.uncheck('.buse');
  let c = await cfg();
  check(c.type[4] === 0 && c.lay[4] === '-' && !(c.beep & 16), 'unticked: no kind, app letter "-", no beep');
  check(c.type[5] === 1 && c.lay[5] === 'L', 'place 6 still a pole');
  check(await p.locator('.bigsvg .kb[data-k="4"] text', { hasText: 'استفاده نمی‌شود' }).count() === 1, 'drawn as not used');
  check(!(await p.evaluate(() => checks().length)), 'no errors');
  await p.check('.buse'); c = await cfg(); check(c.type[4] === 1, 'ticked again: pole');

  console.log('poles + custom scenarios');
  await open('p14');
  c = await cfg();
  check(c.type.slice(12, 14).every(t => t === 1) && c.type.slice(14, 20).every(t => t === 14), 'default: 14 poles, places 15..20 custom scenarios');
  check(c.lay === 'LLLLLLLLLLLLLLSSSSSS---', 'app letters ' + c.lay);
  check(await p.evaluate(() => fwNameFor(targets()[1])).then(n => /_x/.test(n) || /x/.test(n.split('_').pop())), 'hex with the scenario group');
  await p.selectOption('.bstart', '17');
  c = await cfg();
  check(c.type.slice(12, 16).every(t => t === 1) && c.type.slice(16, 20).every(t => t === 14), 'start 17: 16 poles, 4 scenarios');
  await key(17);
  const opts = await p.locator('.ptype[data-i="17"] option').evaluateAll(o => o.map(x => x.value));
  check(opts.includes('cu') && opts.includes('gr') && opts.includes('ex'), 'scenario place: custom, group, EXIT ... ' + opts.join(','));
  await p.selectOption('.ptype[data-i="17"]', 'gr');
  c = await cfg(); check(c.type[17] === 15 && c.lay[17] === 'Q', 'group on place 18');
  await key(20);
  const bo = await p.locator('.ptype[data-i="20"] option').evaluateAll(o => o.map(x => x.value));
  check(!bo.includes('cu') && !bo.includes('gr'), 'bottom keys: no custom scenario / group');
  await p.selectOption('.bstart', '13'); c = await cfg();
  check(c.type.slice(12, 20).every(t => t === 14 || t === 15), 'start 13: 8 scenarios');
  check(!(await p.evaluate(() => checks().length)), 'no errors');

  console.log('custom 20 poles: kinds and the water cooler');
  await open('pc');
  await key(3);
  let o3 = await p.locator('.ptype[data-i="3"] option').evaluateAll(o => o.map(x => x.value));
  check(!o3.includes('cu') && !o3.includes('gr') && o3.includes('pm'), 'place 4: no custom scenario (only 13..20); pump offered');
  await key(14);
  o3 = await p.locator('.ptype[data-i="14"] option').evaluateAll(o => o.map(x => x.value));
  check(o3.includes('cu') && o3.includes('gr'), 'place 15: custom scenario and group offered');
  await p.selectOption('.ptype[data-i="14"]', 'cu');
  await key(6);
  check(await p.locator('.bcool').count() === 1, 'water cooler button on place 7');
  await p.click('.bcool');
  c = await cfg();
  check(c.type[6] === 1 && c.type[7] === 7 && c.type[8] === 7 && c.offmask[7] === 1 << 8 && c.offmask[8] === 1 << 7 && c.onmask[7] === 0 && c.sec2[7] === 10,
    'places 7 pump, 8 slow, 9 fast (interlocked, pump independent)');
  check(c.lay.slice(6, 9) === 'KFG' && c.lay[14] === 'S', 'app letters ' + c.lay);
  check(!(await p.evaluate(() => checks().length)), 'no errors');
  await p.evaluate(() => { W.single.poles[2].type = 'cu'; });
  check(await p.evaluate(() => checks().some(e => e.msg.includes('۱۳ تا ۲۰'))), 'custom scenario on place 3 -> error');
  await p.evaluate(() => { W.single.poles[2].type = 'n'; });
  const br = await p.evaluate(() => brochureHtml(targets()[1]));
  check(br.includes('سناریو سفارشی') && br.includes('۴ ثانیه') && br.includes('پمپ کولر آبی'), 'brochure explains custom scenario and pump');
  await b.close(); console.log('fails', fails);
})();
