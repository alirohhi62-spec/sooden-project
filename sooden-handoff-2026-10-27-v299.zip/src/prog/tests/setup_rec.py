import os
S='/home/claude/prog/build/state'; os.makedirs(S, exist_ok=True)
import shutil
for f in os.listdir(S): (shutil.rmtree if os.path.isdir(os.path.join(S,f)) else os.remove)(os.path.join(S,f))
def crc8(b):
    c=0
    for x in b:
        c^=x
        for _ in range(8): c=((c<<1)^7)&0xFF if c&0x80 else (c<<1)&0xFF
    return c
ee=bytearray(b'\xff'*512)
pl=[0x60, 0x11,0x11,0x10] + [0xFF]*9; pl=pl+[crc8(pl)]
for base in (0x10,0x50,0x90): ee[base:base+14]=bytes(pl)
codes=[0x2222A0|c for c in [1,2,3,5,4,6,7,8,9,10,11,12]] + [0x5A3C10|c for c in [8,4,2,1]]
ee[0xB0]=0xB5; ee[0xB1]=len(codes); ee[0xB2]=len(codes)
for i,c in enumerate(codes): ee[0xB3+i*3:0xB6+i*3]=bytes([c>>16,(c>>8)&255,c&255])
open(S+'/eeprom.bin','wb').write(ee); open(S+'/lfuse','w').write('0x3f'); open(S+'/hfuse','w').write('0xd1')
