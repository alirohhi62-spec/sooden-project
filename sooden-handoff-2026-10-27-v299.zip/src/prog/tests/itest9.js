const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="false"]'); await p.click('.mdl[data-id="P4"]');
  check(await p.inputValue('.tpress') === '2' && await p.inputValue('.tgap') === '30', 'defaults 2 / 30 shown');
  let c = await p.evaluate(() => { const m = parseHex(targetHex(targets()[0])); return [m.get(0x1F80 + 124), m.get(0x1F80 + 125)]; });
  check(c.join() === '2,15', 'default bytes 2 / 15 (30 ms)');
  await p.fill('.tpress', '6'); await p.fill('.tgap', '80');
  c = await p.evaluate(() => { const m = parseHex(targetHex(targets()[0])); return [m.get(0x1F80 + 124), m.get(0x1F80 + 125)]; });
  check(c.join() === '6,40', 'changed: 6 ms / 80 ms -> bytes 6 / 40');
  await p.fill('.tgap', '5'); await p.click('#next');
  check((await p.textContent('#stage')).includes('فاصله دو لمس باید ۱۰ تا ۵۰۰'), 'out-of-range gap -> error');
  await b.close(); console.log('fails', fails);
})();
