// every Wi-Fi panel: its own network name in the programmer (empty = automatic), checks, written in the hex
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  const U = 'file:///home/claude/out/sooden-programmer.html';
  const ss = (key, addr, n) => p.evaluate(([key, addr, n]) => { const t = targets().find(x => x.p12 === 4) || targets().find(x => x.key === key && (x.cfg || x.fixedHex)); const m = parseHex(targetHex(t)); let r = ''; for (let i = 0; i < n; i++) { const v = m.get(addr + i); if (!v || v === 255) break; r += String.fromCharCode(v); } return r; }, [key, addr, n]);
  for (const [nm, setup] of [['E12', () => { W.mode = 'single'; W.single = newBigPanel('E12', 'e12'); }], ['a14', () => { W.mode = 'single'; W.single = newBigPanel('ALARM', 'a14'); }],
                              ['SIM12', () => { W.mode = 'single'; W.single = newP12Panel(); }], ['T6PW', () => { W.mode = 'single'; W.flags = W.flags || {}; W.single = newPanel('T6PW'); }]]) {
    await p.goto(U);
    await p.evaluate(f => { eval('(' + f + ')')(); W.step = steps().findIndex(s => s[0] === 'prog'); render(); }, setup.toString());
    check(await p.locator('.pssid').count() === 1, nm + ': Wi-Fi name field');
    const addr = nm === 'T6PW' ? 0x7F00 + 192 : 0xF000 + 751, key = 'S';
    if (nm !== 'T6PW') check(await ss(key, addr, 16) === '', nm + ': empty = automatic (nothing written)');
    await p.fill('.pssid', 'sooden-test1');
    const r = await p.evaluate(() => checks().map(e => e.msg)).catch(e => ['ERR ' + e.message]);
    check(!r.some(m => m.includes('وای‌فای')), nm + ': no error for sooden-test1');
    if (nm !== 'T6PW') check(await ss(key, addr, 16) === 'sooden-test1', nm + ': name in the hex');
    else { const v = await p.evaluate(() => sixXBlock(W.single, null).slice(192, 204).map(x => String.fromCharCode(x)).join('')); check(v === 'sooden-test1', nm + ': name at 192 of the 6-pole block ' + v); }
    await p.fill('.pssid', 'bad name');
    check((await p.evaluate(() => checks().map(e => e.msg))).some(m => m.includes('اسم وای‌فای')), nm + ': a name with a space -> error');
  }
  await b.close(); console.log('fails ' + fails);
})();
