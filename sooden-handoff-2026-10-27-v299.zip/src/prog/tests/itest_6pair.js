// two-panel network with the 6-pole crystal (T6PN): pair page, links, master / EXIT reaching the other panel, the hexes
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const url = 'file:///home/claude/out/sooden-programmer.html';
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  const blk = s => p.evaluate(s => { const t = targets().find(t => t.key === s); const m = parseHex(t.fixedHex); const a = []; for (let i = 0; i < 192; i++) a.push(m.get(0x7F00 + i)); return { a, c: chipOf(t.variant), fw: t.variant.fw }; }, s);
  const toPair = async () => { await p.goto(url); await p.click('.choice[data-k="pair"]'); };
  const go = st => p.evaluate(st => { W.step = steps().findIndex(s => s[0] === st); render(); }, st);
  /* 1) 6-pole A, 4-pole B */
  await toPair();
  for (const id of ['T6PR', 'T6PW']) check(await p.locator(`.plrow[data-side="A"][data-id="${id}"]`).count() === 0, id + ' not in the pair list');
  check(await p.locator('.plrow[data-side="A"][data-id="T6PN"]').count() === 1, 'T6PN in the pair list');
  await p.click('.plrow[data-side="A"][data-id="T6PN"]'); await p.click('.plrow[data-side="B"][data-id="P4"][data-sub=""]');
  let r = await p.evaluate(() => ({ px: pxMode(), ar: W.pair.A.remote, br: W.pair.B.remote, n: W.pair.A.poles.length }));
  check(r.px && r.ar && !r.br && r.n === 8, 'network v2, 6-pole keeps its remote, the 4-pole has none ' + JSON.stringify(r));
  check((await p.textContent('.plcols')).includes('ATmega32'), 'hero: ATmega32');
  check(await p.locator('.prem[data-s="A"]').count() === 1 && await p.locator('.prem[data-s="B"]').count() === 0, 'remote checkbox on the 6-pole only');
  await go('pairprog');
  check(await p.locator('.sxx-t[data-p="A"]').count() === 6, '6-pole editor on the program page');
  check(await p.locator('.ppeer[data-p="A"][data-i="7"][data-w="pon"]').count() === 4 && await p.locator('.ppeer[data-p="A"][data-i="6"][data-w="poff"]').count() === 4, 'master / EXIT: the 4 poles of B to pick');
  check(await p.locator('.spole[data-p="A"]').count() === 24 && await p.locator('.spole[data-p="A"][data-k="6"]').count() === 0, 'remote table of A: 4 buttons x 6 poles (no EXIT / master)');
  /* link A1 <-> B1 on the plates */
  await p.click('#plates button.kk[data-s="A"][data-i="0"]'); await p.click('#plates button.kk[data-s="B"][data-i="0"]');
  check(await p.evaluate(() => W.pair.links[0]) === 0, 'link A1 <-> B1');
  await p.check('.ppeer[data-p="A"][data-i="7"][data-k="1"]'); await p.check('.ppeer[data-p="A"][data-i="6"][data-k="2"]');
  await p.evaluate(() => { const B = W.pair.B; B.poles[3].type = 'm'; B.poles[3].pon = [4, 5]; render(); });
  await p.fill('.sxx-exit[data-p="A"]', '5'); await p.dispatchEvent('.sxx-exit[data-p="A"]', 'change');
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  r = await blk('A');
  check(r.c.part === 'm32' && r.c.lfuse === 0xDE && r.c.hfuse === 0xD1 && r.fw === 'fw_6p_net', 'A: fw_6p_net, m32 DE/D1');
  check(r.a[0] === 0xA7 && r.a[20] === 5 && r.a[26] === 0 && r.a.slice(27, 33).join() === '0,255,255,255,255,255', 'A: role 0, pole 1 -> key 1 of B ' + r.a.slice(26, 33).join());
  check(r.a.slice(184, 190).join() === '2,0,0,4,0,0', 'A: master -> B pole 2, EXIT -> B pole 3 ' + r.a.slice(184, 190).join());
  check(r.a[33] === 1, 'A: 1 remote place');
  r = await p.evaluate(() => { const t = targets().find(t => t.key === 'B'); return { link: t.cfg.link, pp: t.cfg.peerpoles, on: t.cfg.px && t.cfg.px.on[3], rem: t.cfg.remote, fw: t.variant.fw }; });
  check(r.link[0] === 0 && r.pp === 8 && r.on.join() === '4,5' && !r.rem, 'B: link 1 -> A pole 1, peer 8 keys, master -> A poles 5, 6 ' + JSON.stringify(r));
  const fs = require('fs');
  fs.writeFileSync(S + 'pr_A6.hex', await p.evaluate(() => targetHex(targets().find(t => t.key === 'A'))));
  fs.writeFileSync(S + 'pr_B4.hex', await p.evaluate(() => targetHex(targets().find(t => t.key === 'B'))));
  /* the 6-pole: master pole kinds change -> the other panel keeps only valid keys */
  await p.selectOption('.sxx-t[data-p="A"][data-i="0"]', '0');
  check(await p.evaluate(() => W.pair.links[0]) === undefined, 'pole 1 of A without a job: its link gone');
  /* 2) alarm a14 A, 6-pole B */
  await toPair();
  await p.click('.plrow[data-side="A"][data-id="ALARM"][data-sub="a14"]'); await p.click('.plrow[data-side="B"][data-id="T6PN"]');
  await go('pairprog');
  await p.evaluate(() => { W.pair.links = { 4: 1 }; render(); });
  await p.check('.ppeer[data-p="B"][data-i="7"][data-k="0"]'); await p.check('.ppeer[data-p="B"][data-i="7"][data-k="1"]');
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'a14 + 6-pole: no errors ' + r.join('|'));
  r = await blk('B');
  check(r.a[26] === 1 && r.a.slice(27, 33).join() === '255,4,255,255,255,255' && r.a.slice(184, 187).join() === '3,0,0', 'B: role 1, pole 2 -> place 5, master -> places 1, 2 ' + r.a.slice(26, 33).join());
  r = await p.evaluate(() => { const t = targets().find(t => t.key === 'A' && t.cfg); return { px: t.cfg.px, l: t.cfg.link[4] }; });
  check(r.px.pmdl === 'p6' && r.px.play === 'LLLLLLXM' && r.px.pnp === 8 && r.l === 1, 'A (23 keys): the app sees the 6-pole (p6, LLLLLLXM, 8) ' + JSON.stringify([r.px.pmdl, r.px.play, r.px.pnp]));
  fs.writeFileSync(S + 'pr_A14.hex', await p.evaluate(() => targetHex(targets().find(t => t.key === 'A' && t.cfg))));
  fs.writeFileSync(S + 'pr_B6.hex', await p.evaluate(() => targetHex(targets().find(t => t.key === 'B'))));
  /* 3) two 6-pole panels */
  await toPair();
  await p.click('.plrow[data-side="A"][data-id="T6PN"]'); await p.click('.plrow[data-side="B"][data-id="T6PN"]');
  await go('pairprog');
  r = await p.evaluate(() => ({ px: pxMode(), a: W.pair.A.remote, b: W.pair.B.remote }));
  check(r.px && r.a && r.b, 'two 6-pole panels: network v2, both with remotes');
  await p.click('#plates button.kk[data-s="A"][data-i="1"]'); await p.click('#plates button.kk[data-s="B"][data-i="1"]');
  r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  r = [await blk('A'), await blk('B')];
  check(r[0].a[26] === 0 && r[1].a[26] === 1 && r[0].a[28] === 1 && r[1].a[28] === 1, 'roles 0 / 1, pole 2 <-> pole 2');
  await b.close(); console.log('fails ' + fails);
})();
