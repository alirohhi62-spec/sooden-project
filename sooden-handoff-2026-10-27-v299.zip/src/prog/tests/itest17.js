// ATmega8 network bell push (P1B) in the programmer: bell time into the settings block, its own hex
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const url = 'file:///home/claude/out/sooden-programmer.html';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  let r = await p.evaluate(() => {
    W.mode = 'pair'; W.pair = { A: newPanel('P1B'), B: newPanel('P2'), links: {}, wifiOn: 'none', pick: null, fam: { A: null, B: null } };
    W.pair.A.bellS = 50; W.step = steps().findIndex(s => s[0] === 'pairprog'); render();
    const t = targets(); const a = t.find(x => x.key === 'A'), bb = t.find(x => x.key === 'B');
    return { box: !!document.querySelector('.pbelln'), fa: fwNameFor(a), fb: fwNameFor(bb), s1: a.cfg.sec1[0], s2: a.cfg.sec2[0], n: a.cfg.npoles, e: checks().map(e => e.msg), c: chipOf(a.variant), px: pxMode(), names: MODELS.filter(m => m.variants.some(v => v.network && v.crystal)).map(m => m.id).join() };
  });
  console.log('  ' + JSON.stringify(r).slice(0, 300));
  check(r.names.includes('P1B'), 'bell push is a crystal network model');
  check(r.box, 'bell time box on the panel page');
  check(r.fa === 'fw_2p_bell' && r.fb === 'fw_2p_px' && r.px, 'A: bell hex, B: 2-pole network v2');
  check(r.s1 === (500 & 255) && r.s2 === 1 && r.n === 1, '50 s = 500 tenths, 1 pole');
  check(r.e.length === 0 && r.c.lfuse === 0x4F && r.c.hfuse === 0xD1, 'no errors, fuses 4F/D1 ' + r.e.join('|'));
  const f4 = await p.evaluate(() => chipOf(MODEL('P4').variants[1]).lfuse); check(f4 === 0x3F, '4-pole keeps 3F');
  await b.close(); console.log('fails ' + fails);
})();
