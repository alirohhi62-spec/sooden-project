// SIM12: choose the poles of the master (standing rule for every panel)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 950 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto('file:///home/claude/out/sooden-programmer.html');
  await p.evaluate(() => { W.mode = 'single'; W.single = newP12Panel(); W.step = steps().findIndex(s => s[0] === 'prog'); render(); });
  const m4 = () => p.evaluate(() => targets().find(t => t.p12 === 4).cfg.onmask[21]);
  check(await m4() === 0xFFF, 'default: master switches poles 1..12');
  await p.click('[data-bk="21"]').catch(() => {});
  check(await p.locator('.wm[data-i="2"]').count() === 1 && await p.locator('.wm').count() === 12, 'master: 12 pole ticks');
  await p.uncheck('.wm[data-i="2"]'); await p.uncheck('.wm[data-i="11"]');
  check(await m4() === (0xFFF & ~(1 << 2) & ~(1 << 11)), 'poles 3 and 12 unticked: not in the master ' + (await m4()).toString(16));
  const r = await p.evaluate(() => checks().map(e => e.msg)); check(r.length === 0, 'no errors ' + r.join('|'));
  require('fs').writeFileSync('/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/p12m4_master.hex', await p.evaluate(() => targetHex(targets().find(t => t.p12 === 4))));
  await b.close(); console.log('fails ' + fails);
})();
