// master: choose its poles (4-pole and 23-key panels)
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const url = 'file:///home/claude/out/sooden-programmer.html';
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  // 3 poles + master (P3M): master on key 4
  let r = await p.evaluate(() => { W.mode = 'single'; W.crystal = true; W.mods = 'remote'; W.single = newPanel('P3M'); const c0 = firmwareCfg(W.single, 0, null, null, true).onmask[3];
    W.single.poles[1].withMaster = false; const c1 = firmwareCfg(W.single, 0, null, null, true).onmask[3];
    document.body.insertAdjacentHTML('beforeend', '<div id="tst">' + rolesEditor(W.single, 'S', 'پنل') + '</div>'); bindRoles(document.getElementById('tst'));
    return { c0, c1, n: document.querySelectorAll('#tst .wm').length }; });
  check(r.c0 === 7 && r.c1 === 5, `P3M master mask all ${r.c0}, without pole 2 ${r.c1}`);
  check(r.n === 3, 'P3M: 3 checkboxes under the master');
  await p.click('#tst .wm[data-i="0"]'); r = await p.evaluate(() => firmwareCfg(W.single, 0, null, null, true).onmask[3]);
  check(r === 4, 'unticking pole 1 in the page -> mask ' + r);
  r = await p.evaluate(() => { W.single.poles[2].withMaster = false; return checks().map(e => e.msg).filter(m => m.includes('مستر')); });
  check(r.length === 1, 'no pole ticked -> error: ' + r.join('|'));
  // 23-key: master on a bottom key
  r = await p.evaluate(() => { document.getElementById('tst').remove(); W.single = newBigPanel('P20', 'p20'); const pn = W.single; pn.poles[20].type = 'm'; syncBigRoles && syncBigRoles(pn);
    const c0 = firmwareCfg(pn, 0, null, null, true).onmask[20]; pn.poles[0].withMaster = false; pn.poles[5].withMaster = false; const c1 = firmwareCfg(pn, 0, null, null, true).onmask[20];
    pn.sel = 20; document.body.insertAdjacentHTML('beforeend', '<div id="tst2">' + rolesEditor(pn, 'S', 'پنل') + '</div>');
    return { c0, c1, n: document.querySelectorAll('#tst2 .wm').length, off: [...document.querySelectorAll('#tst2 .wm')].filter(x => !x.checked).map(x => +x.dataset.i) }; });
  check(r.c0 === 0xFFFFF && r.c1 === (0xFFFFF & ~1 & ~32), `23-key master mask all ${r.c0.toString(16)}, without places 1 and 6 ${r.c1.toString(16)}`);
  check(r.n === 20 && r.off.join() === '0,5', `23-key: ${r.n} checkboxes, unticked ${r.off}`);
  await b.close(); console.log('fails ' + fails);
})();
