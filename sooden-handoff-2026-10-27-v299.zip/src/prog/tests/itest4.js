const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs');
const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  fs.writeFileSync(B + 'mode.txt', 'ok');
  await p.goto(url);
  // finish page: connection test brings the recorded list and asks
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]'); await p.click('#next');
  await p.click('#probe');
  await p.waitForSelector('#presult .recbox .rtype', { timeout: 20000 });
  const t = await p.textContent('#presult .recbox');
  check(t.includes('۲ ریموت روی پنل ضبط شده') && t.includes('در کتابخانه ذخیره شوند؟'), 'after connecting: list of 2 recorded remotes + question');
  check(t.includes('2222A') && t.includes('۱۲ دکمه') && t.includes('5A3C1') && t.includes('۴ دکمه'), 'grouped by remote id with button counts');
  const g1 = p.locator('#presult .recbox .rtype').nth(0);
  const codes = async g => (await g.locator('tr td:nth-child(3)').allTextContents()).map(x => x.trim().split(' ')[0]);
  check((await codes(g1)).join() === '۱,۲,۳,۵,۴,۶,۷,۸,۹,۱۰,۱۱,۱۲', 'buttons in the order they were pressed');
  // fix order: move code 4 (row 5) up
  await g1.locator('.rmv[data-b="4"][data-d="-1"]').click();
  check((await codes(p.locator('#presult .recbox .rtype').nth(0))).join() === '۱,۲,۳,۴,۵,۶,۷,۸,۹,۱۰,۱۱,۱۲', 'reordered with ▲');
  await p.screenshot({ path: '/home/claude/out/recorded.png', fullPage: true });
  // rename the 4-ch one and delete its last button; don't save the 12-ch one? save both
  const g2 = p.locator('#presult .recbox .rtype').nth(1);
  await g2.locator('.rgname').fill('ریموت سفید ۴ دکمه'); await g2.locator('.rgname').dispatchEvent('change');
  await g2.locator('.rbname').nth(0).fill('بالا'); await g2.locator('.rbname').nth(0).dispatchEvent('change');
  await p.click('#presult .rsaveall');
  await p.waitForTimeout(400);
  const lib = JSON.parse(fs.readFileSync(B + 'sooden_remotes.json', 'utf8'));
  check(lib.models.length === 3, '2 models added to the library file');
  const m12 = lib.models[1], m4 = lib.models[2];
  check(m12.buttons.map(x => x.code).join() === '1,2,3,4,5,6,7,8,9,10,11,12' && m12.name.includes('۱۲ کانال'), '12-ch model saved in corrected order');
  check(m4.name === 'ریموت سفید ۴ دکمه' && m4.buttons[0].name === 'بالا' && m4.buttons.map(x => x.code).join() === '8,4,2,1', '4-ch model saved with its names');
  check((await p.textContent('#presult')).includes('در کتابخانه ذخیره شد'), 'confirmation shown');
  // the new models are selectable for the remote places
  await p.click('.pc[data-i="4"]');
  const opts = await p.locator('.smodel').first().textContent();
  check(opts.includes('ریموت سفید ۴ دکمه') && opts.includes('۱۲ کانال'), 'new models in the place menu');
  // same codes again -> warning about an existing model
  await p.click('.rlast'); await p.waitForSelector('.lastbtn .recbox .rtype', { timeout: 20000 });
  check((await p.textContent('.lastbtn .recbox')).includes('مدلی با همین کدها در کتابخانه هست'), 'warns when the same model is already in the library');
  // empty recording
  const S = B + 'state/eeprom.bin', ee = fs.readFileSync(S); ee[0xB0] = 0xFF; fs.writeFileSync(S, ee);
  await p.click('.lastbtn .rclose');
  await p.click('.rlast'); await p.waitForSelector('.lastbtn .recbox .msg', { timeout: 20000 });
  check((await p.textContent('.lastbtn .recbox')).includes('هیچ ریموتی روی پنل ضبط نشده'), 'nothing recorded -> explains how to record');
  await b.close();
  console.log('fails', fails);
})();
