const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const core = require('/home/claude/avrsim/cfgcore.js');
const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 1000 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  p.on('dialog', d => d.accept());
  fs.writeFileSync(B + 'mode.txt', 'ok');
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]');
  check(await p.locator('.smodel').count() === 1, 'one remote place by default');
  check(await p.locator('.rtype').first().locator('tr').count() === 5, 'default 4-ch model: 4 buttons');
  // read last button -> new model
  await p.click('.rlast'); await p.waitForSelector('.rlastres .msg', { timeout: 15000 });
  const t = await p.textContent('.rlastres');
  check(t.includes('2222A') && t.includes('۱۲') && t.includes('1100'), 'last button: id 2222A, code 12, binary 1100');
  check(t.includes('جای ۱: 11111') && t.includes('جای ۲: خالی'), 'places on panel listed');
  await p.selectOption('.lastm', 'new'); await p.fill('.lastn', 'دکمه ۱۲'); await p.click('.lastadd');
  await p.waitForTimeout(300);
  check(fs.existsSync(B + 'sooden_remotes.json') && JSON.parse(fs.readFileSync(B + 'sooden_remotes.json', 'utf8')).models.length === 2, 'library saved next to SoodenProg (2 models)');
  // rename + add buttons with typed codes
  await p.locator('.lname').nth(1).fill('ریموت ۱۲ کانال'); await p.locator('.lname').nth(1).dispatchEvent('change');
  for (const [nm, raw] of [['دکمه ۴', '0100'], ['دکمه ۵', '2222A5'], ['دکمه ۱۰', '10'], ['غلط', '99']]) {
    await p.locator('.lbadd').nth(1).click();
    const n = await p.locator('.rtype').filter({ has: p.locator('.lname') }).nth(1).locator('.lbname').count();
    await p.locator('.rtype').filter({ has: p.locator('.lname') }).nth(1).locator('.lbname').nth(n - 1).fill(nm);
    await p.locator('.rtype').filter({ has: p.locator('.lname') }).nth(1).locator('.lbname').nth(n - 1).dispatchEvent('change');
    await p.locator('.rtype').filter({ has: p.locator('.lname') }).nth(1).locator('.lbcode').nth(n - 1).fill(raw);
    await p.locator('.rtype').filter({ has: p.locator('.lname') }).nth(1).locator('.lbcode').nth(n - 1).dispatchEvent('change');
  }
  await p.waitForTimeout(300);
  const lib = JSON.parse(fs.readFileSync(B + 'sooden_remotes.json', 'utf8'));
  const m12 = lib.models[1];
  check(m12.name === 'ریموت ۱۲ کانال' && m12.buttons.map(x => x.code).join() === '12,4,5,10,', 'codes parsed: 1100->12, 0100->4, 2222A5->5, 10->10, 99 invalid');
  check((await p.textContent('.libbox')).includes('نامعتبر'), 'invalid code shown');
  // place 2 with the 12-ch model
  await p.click('.sadd');
  await p.locator('.smodel').nth(1).selectOption(m12.id);
  const tab2 = p.locator('.rtype').filter({ has: p.locator('.smodel') }).nth(1);
  check(await tab2.locator('tr').count() === 6, 'place 2 table lists all 5 buttons (one without a valid code)');
  await tab2.locator('tr').nth(1).locator('.spole[data-k="3"]').check();
  await tab2.locator('tr').nth(1).locator('.sact').selectOption('on');
  await p.click('#next');
  check((await p.textContent('#stage')).includes('نامعتبر'), 'invalid library code blocks programming');
  await p.click('.pc[data-i="4"]');
  await p.locator('.libbox').evaluate(d => d.open = true);
  const libm = p.locator('.rtype').filter({ has: p.locator('.lname') }).nth(1);
  await libm.locator('.lbdel').nth(4).click();
  await p.waitForTimeout(200);
  await p.screenshot({ path: '/home/claude/out/remote-places.png', fullPage: true });
  await p.click('#next');
  check((await p.textContent('#stage')).includes('همه تنظیمات معتبر است'), 'valid after removing the bad button');
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pgbox .msg', { timeout: 30000 });
  check((await p.textContent('.pgbox')).includes('پروگرم شد'), 'programmed');
  const fl = core.parseHex(fs.readFileSync(B + 'state/flash.hex', 'utf8'));
  const c = [...Array(128)].map((_, i) => fl.get(0x1F80 + i));
  check(c[2] === 3 && c[127] === core.crc8(c, 127) && c[31] === 2, 'config v3, crc ok, 2 remote places');
  check(c[32 + 1] === 1 && c[32 + 2] === 2 && c[32 + 4] === 4 && c[32 + 8] === 8, 'place 1: 4-ch default table');
  check(c[48 + 12] === (0x09 | 0x10) && c[48 + 4] === 0x02 && c[48 + 5] === 0x04 && c[48 + 10] === 0x08, 'place 2: 12->poles 1+4 only on, 4->2, 5->3, 10->4');
  const ref = core.parseHex(fs.readFileSync('/home/claude/fw/out/fw_4p_r.hex', 'utf8'));
  let diff = 0; for (const [a, v] of ref) if (a < 0x1F80 && fl.get(a) !== v) diff++;
  check(diff === 0, 'programmed code = fw_4p_r (single panel + remote, no network code)');
  check(fs.readFileSync(B + 'state/eeprom.bin')[0x11] === 0x11, 'remotes on panel kept');
  // reload: library comes back from the file
  await p.goto(url);
  await p.waitForTimeout(500);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]');
  check((await p.locator('.smodel').first().innerHTML()).includes('ریموت ۱۲ کانال'), 'library reloaded from SoodenProg file');
  // no-crystal path uses fw_4p
  await p.click('.pc[data-i="0"]'); await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="false"]'); await p.click('.mdl[data-id="P4"]'); await p.click('#next');
  await p.click('[data-pg="0"]'); await p.click('[data-go]'); await p.waitForSelector('.pgbox .msg', { timeout: 30000 });
  const fl2 = core.parseHex(fs.readFileSync(B + 'state/flash.hex', 'utf8')), ref2 = core.parseHex(fs.readFileSync('/home/claude/fw/out/fw_4p.hex', 'utf8'));
  diff = 0; for (const [a, v] of ref2) if (a < 0x1F80 && fl2.get(a) !== v) diff++;
  check(diff === 0 && fl2.get(0x1F80 + 7) === 0 && fs.readFileSync(B + 'state/lfuse', 'utf8') === '0x24', 'no crystal: fw_4p, no remote, fuse 24');
  await b.close();
  console.log('fails', fails);
})();
