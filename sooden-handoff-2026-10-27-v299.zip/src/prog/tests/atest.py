import json, urllib.request, urllib.parse, os, shutil
B='/home/claude/prog/build'; port, tok = open(B+'/conn.txt').read().split()
def call(path, body=b''):
    r = urllib.request.Request('http://127.0.0.1:%s%s' % (port, path), data=body, method='POST', headers={'X-Sooden-Token': tok})
    try: return json.loads(urllib.request.urlopen(r, timeout=30).read())
    except urllib.error.HTTPError as e: return {'http': e.code}
fails=0
def check(c,m):
    global fails; print(('  ok   ' if c else '  FAIL ')+m); fails += 0 if c else 1
A=B+'/archive'; shutil.rmtree(A, ignore_errors=True)
doc='<!DOCTYPE html><html><body>بروشور تست</body></html>'.encode()
q=lambda n: '/api/archive?name='+urllib.parse.quote(n)
r=call(q('1405-07-20 آقای رضایی - پنل پذیرایی'),doc); check(r.get('ok') and os.path.exists(A+'/1405-07-20 آقای رضایی - پنل پذیرایی.html'),'saved with Persian name: '+str(r))
r=call(q('1405-07-20 آقای رضایی - پنل پذیرایی'),doc); check(r.get('ok') and r['file'].endswith('(2).html'),'same name: not overwritten -> (2)')
for bad in ['CON','nul.txt','com3','../x','a/b','a\\b','c:x','x?y','<x>','\x01a','...','  ']:
    r=call(q(bad),doc); check(not r.get('ok'),'refused name %r'%bad)
r=call('/api/archive?name=%FF%FE',doc); check(not r.get('ok'),'bad UTF-8 refused')
r=call(q('ok'),b'just text not html'); check(r.get('code')=='bad_doc','non-HTML body refused')
check(sorted(os.listdir(A))==sorted(['1405-07-20 آقای رضایی - پنل پذیرایی.html','1405-07-20 آقای رضایی - پنل پذیرایی (2).html']),'nothing else written')
check(not os.path.exists(B+'/x.html') and not os.path.exists('/home/claude/prog/x.html'),'nothing outside archive')
r=urllib.request.Request('http://127.0.0.1:%s%s'%(port,q('t')),data=doc,method='POST',headers={'X-Sooden-Token':'bad'})
try: urllib.request.urlopen(r); check(False,'no token refused')
except urllib.error.HTTPError as e: check(e.code==403,'no token refused')
print('\n%d failed'%fails)
