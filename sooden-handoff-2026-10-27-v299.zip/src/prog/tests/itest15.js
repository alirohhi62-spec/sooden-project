// 12-pole SIM panel in the programmer: editor, 5 stages, settings blocks, room names, pair with a 4-pole panel
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const url = 'file:///home/claude/out/sooden-programmer.html';
const OUT = '/home/claude/p12/sim/prog/'; fs.mkdirSync(OUT, { recursive: true });
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1300, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="wifi"]');
  check(await p.$('.mdl[data-id="SIM12"]') !== null, 'model card «دزدگیر سیمکارتی» offered');
  await p.click('.mdl[data-id="SIM12"]');
  check(await p.$$eval('#roles [data-bk]', e => e.length) === 27, '27 keys in the editor');
  check(await p.$('.smodel') !== null, 'remote editor shown (always on this panel)');
  check(await p.$('.p12rname') === null, 'no room names here (seven-segment mode only)');
  // defaults -> settings block equals the firmware's own defaults where they meet
  let r = await p.evaluate(() => { const t = targets(); const c = buildCfgP12(t[3].cfg); return { n: t.length, steps: t.map(x => x.step).join(), c: Array.from(c), e: checks().map(e => e.msg) }; });
  check(r.n === 5 && r.steps === '1,2,3,4,5', '5 stages: M1 M2 M3 M4 alarm');
  check(r.e.length === 0, 'no errors with the defaults ' + r.e.join(' | '));
  const c = r.c, u32 = o => (c[o] | c[o + 1] << 8 | c[o + 2] << 16 | c[o + 3] << 24) >>> 0;
  check(c.slice(8, 35).join() === '1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,14,14,14,14,11,0,2,13,7,7,7,7', 'key types ' + c.slice(8, 35).join());
  check(u32(62 + 4 * 19) === (0x0FFF | 1 << 23 | 1 << 25) >>> 0 && c[278 + 19] === 1 && c[305 + 19] === 20, 'exit S5: poles 1..12 + opening curtains off, close flag, 20 s');
  check(u32(170 + 4 * 21) === 0x0FFF, 'master: poles 1..12');
  check(u32(62 + 4 * 23) === 1 << 24 && c[305 + 23] === 45 && c[332 + 23] === 5, 'curtain 1 open: partner close, 45 s');
  check(u32(62 + 4 * 15) === (0x7FFF | 0xF << 23) >>> 0, 'S1 custom: keys 1..15 + curtains');
  check(c[364] === 10 && c[363] === 60 && c[652] === 0 && c[653] === 0 && c[654] === 21, 'step 100 ms, standby 60 s, no rooms alone, child lock on S6');
  check(c[767] === (() => { let x = 0; for (let k = 0; k < 767; k++) { x ^= c[k]; for (let i = 0; i < 8; i++) x = x & 0x80 ? ((x << 1) ^ 7) & 255 : (x << 1) & 255; } return x; })(), 'crc');
  { const hx0 = await p.evaluate(() => targets().map(t => targetHex(t))); ['m1', 'm2', 'm3', 'm4', 'alarm'].forEach((n, i) => fs.writeFileSync(OUT + 'fw_p12_' + n + '.hex', hx0[i])); }
  // changes: curtain 2 -> plain poles, elevator -> pole, exit without curtains, alarm settings, a room name
  await p.selectOption('.ptype[data-i="25"]', 'n');
  await p.selectOption('.ptype[data-i="22"]', 'n');
  await p.fill('.psec[data-i="19"][data-f="secs"]', '35'); await p.dispatchEvent('.psec[data-i="19"][data-f="secs"]', 'change');
  await p.uncheck('.pclose[data-i="19"]');
  await p.check('.p12al[data-f="zone2"]'); await p.check('.p12al[data-f="magOn"]'); await p.check('.p12al[data-f="curSms"]');
  await p.check('.p12sir[data-f="magSiren"][data-s="2"]');
  await p.selectOption('.p12rem[data-i="2"]', '128');
  await p.fill('.p12num[data-f="sirenS"]', '300');
  await p.selectOption('.p12rem[data-i="3"]', String(0x19));
  await p.selectOption('.ptype[data-i="16"]', 'n');                       /* S2 -> a plain pole (it has a relay) */
  await p.selectOption('.ptype[data-i="26"]', 'p');                       /* a curtain key -> push button */
  await p.selectOption('.ptype[data-i="15"]', 'ck');
  r = await p.evaluate(() => checks().map(e => e.msg));
  check(r.some(m => m.includes('قفل کودک') && m.includes('فقط روی یک کلید')), 'two child-lock keys: error');
  await p.selectOption('.ptype[data-i="20"]', 'cu'); 
  r = await p.evaluate(() => { const t = targets(); return { c: Array.from(buildCfgP12(t[3].cfg)), e: checks().map(e => e.msg), al: Array.from(parseHex(t[4].fixedHex).entries()).filter(([a]) => a >= 0xF000 && a < 0xF00F).map(x => x[1]) }; });
  const d = r.c, U = o => (d[o] | d[o + 1] << 8 | d[o + 2] << 16 | d[o + 3] << 24) >>> 0;
  check(r.e.length === 0, 'no errors after the changes ' + r.e.join(' | '));
  check(d[8 + 25] === 1 && d[8 + 22] === 1 && d[8 + 23] === 7, 'curtain 2 open key and elevator are normal poles, curtain 1 still a curtain');
  check(d[8 + 16] === 1 && d[8 + 26] === 6 && d[8 + 15] === 0 && d[8 + 20] === 14 && d[654] === 16, 'S2 pole, curtain key push button, child lock moved to S1 (clk 16), S6 custom');
  check(d[278 + 19] === 0 && d[305 + 19] === 35 && U(62 + 4 * 19) === 0x0FFF, 'exit: 35 s, no curtain closing');
  check(r.al.join() === [0xA5, 2, 1, 2, 4, 1 | 4, 4, 0x11, 0x40, 0x80, 0x19, 40, 30, 300 & 255, 1].join(), 'alarm block (button 4 = quick arm zone 1) ' + r.al.join());
  // write the hexes for the simulator
  const hx = await p.evaluate(() => targets().map(t => targetHex(t)));
  fs.mkdirSync(OUT + '../prog2', { recursive: true }); ['m1', 'm2', 'm3', 'm4', 'alarm'].forEach((n, i) => fs.writeFileSync(OUT + '../prog2/fw_p12_' + n + '.hex', hx[i]));
  // finish page: 5 stages with their own DIP text, no brochure buttons
  await p.evaluate(() => { W.step = steps().findIndex(s => s[0] === 'finish'); render(); });
  const li = await p.$$eval('ul.check li', e => e.map(x => x.textContent));
  check(li.length === 5 && li[0].includes('M1') && li[4].includes('دزدگیر'), 'finish: 5 stages');
  check(await p.$('[data-br]') === null, 'no brochure buttons');
  // pair: 12-pole A with a 4-pole B, links by network number
  await p.goto(url); await p.click('.choice[data-k="pair"]');
  await p.click('.plrow[data-side="A"][data-id="SIM12"]'); await p.click('.plrow[data-side="B"][data-id="P4"]');
  await p.evaluate(() => { W.pair.B.remote = false; W.pair.links = { 0: 0, 23: 1, 22: 2 }; W.pair.A.poles[21].pon = [3]; W.pair.B.poles[0].type = 'n'; W.step = steps().findIndex(s => s[0] === 'pairprog'); render(); });
  r = await p.evaluate(() => { const t = targets(); const a = t.find(x => x.p12 === 4), bb = t.find(x => x.key === 'B');
    return { px: pxMode(), aL: buildCfgP12(a.cfg).slice(35, 62), bL: bb.cfg.link, apx: a.cfg.px.on[21], e: checks().map(e => e.msg), name: fwNameFor(bb), plates: document.querySelectorAll('#plates .kk12').length, boxes: document.querySelectorAll('.pbox').length }; });
  { const hx = await p.evaluate(() => targets().map(t => targetHex(t))); fs.mkdirSync(OUT + '../prog3', { recursive: true });
    ['m1', 'm2', 'm3', 'm4', 'alarm'].forEach((n, i) => fs.writeFileSync(OUT + '../prog3/fw_p12_' + n + '.hex', hx[i])); fs.writeFileSync(OUT + '../prog3/b.hex', hx[5]); }
  check(r.px, 'network v2');
  check(r.aL[0] === 0 && r.aL[23] === 1 && r.aL[22] === 2 && r.aL[1] === 255, '12-pole links: pole 1 -> 1, curtain open -> 2, elevator -> 3');
  check(r.bL.slice(0, 3).join() === '0,15,19', '4-pole links in network numbers ' + r.bL.join());
  check(r.apx.join() === '3', 'master also switches B4');
  check(r.name === 'fw_4p_px', 'B hex ' + r.name);
  check(r.e.length === 0, 'pair: no errors ' + r.e.join(' | '));
  check(r.plates === 20, 'P12 plate on the photo: 20 linkable keys (' + r.plates + ')');
  check(r.boxes === 2, 'each panel in its own frame');
  // seven-segment network: main + 3 panels (2 pole, 20 pole, 4 pole)
  await p.goto(url); await p.click('.choice[data-k="seg"]');
  check(await p.$('.choice[data-k="single"]') === null, 'seg: no mode page any more');
  await p.selectOption('#segcount', '3');
  const pick = async (name, id, sub) => { await p.fill('.segname', name); await p.dispatchEvent('.segname', 'change');
    await p.evaluate(([id, sub]) => { const rows = segRows(); const j = rows.findIndex(r => r.id === id && (!sub || r.sub === sub)); document.querySelectorAll('.seglist .plrow')[j].click(); }, [id, sub]); };
  await pick('پذیرایی', 'P2'); await p.click('#next'); await pick('آشپزخانه', 'P20', 'p20'); await p.click('#next'); await pick('خواب', 'P4');
  check((await p.textContent('#stage')).includes('پنل ۳ از ۳'), 'seg: page of panel 3');
  await p.click('#next'); await p.click('#next');
  r = await p.evaluate(() => { const t = targets(); const mm = buildCfgP12(t[3].cfg), m1 = parseHex(t[0].fixedHex);
    const n = k => t.filter(x => x.key === k && x.cfg).map(x => ({ name: fwNameFor(x), hex: parseHex(targetHex(x)) }))[0];
    const a = n('N0'), bg = n('N1'), c4 = n('N2');
    return { keys: t.map(x => x.key).join(), e: checks().map(e => e.msg), rooms: mm[652], w: [0, 1, 2, 3].map(i => m1.get(0x7000 + i * 256)),
      a: [a.name, a.hex.get(0x1F80 + 126)], bg: [bg.name, bg.hex.get(0xF000 + 627)], c4: [c4.name, c4.hex.get(0x1F80 + 126), c4.hex.get(0x1F80 + 7)], boxes: document.querySelectorAll('.pbox').length, step: steps()[W.step][0] }; });
  check(r.step === 'finish' && r.e.length === 0, 'seg: finish, no errors ' + r.e.join(' | '));
  check(r.keys === 'M,M,M,M,M,N0,N1,N1,N2', 'seg: main 5 stages, then the panels in order ' + r.keys);
  check(r.rooms === 7, 'main: numbers 1..3 on the 7-segment');
  check(r.w[0] > 10 && r.w[1] > 10 && r.w[2] > 10 && r.w[3] === 255, 'main M1: the 3 names, nothing for 4 ' + r.w.join());
  check(r.a.join() === 'fw_2p_px,1' && r.bg.join() === 'fw_big_p,2' && r.c4.join() === 'fw_4p_px,3,0', 'panels: v2 hex, numbers 1 2 3, 4-pole without remote ' + JSON.stringify([r.a, r.bg, r.c4]));
  check(r.boxes === 4, 'finish: 4 frames (main + 3)');
  { const hx = await p.evaluate(() => targets().map(t => targetHex(t))); fs.mkdirSync(OUT + '../prog4', { recursive: true });
    ['m1', 'm2', 'm3', 'm4', 'alarm'].forEach((n, i) => fs.writeFileSync(OUT + '../prog4/fw_p12_' + n + '.hex', hx[i])); fs.writeFileSync(OUT + '../prog4/n3.hex', hx[8]); }
  // project file: save, open again, same hex
  const before = await p.evaluate(() => targets().map(t => targetHex(t)).join('|'));
  const html = await p.evaluate(() => projectHtml());
  fs.writeFileSync('/tmp/itest15_proj.html', html);
  check(html.startsWith('<!DOCTYPE html>') && html.includes('خواب') && html.includes('sooden-project'), 'project file: one HTML page with the details and the data');
  const q = await b.newPage(); q.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  await q.goto(url); await q.setInputFiles('#openproj', '/tmp/itest15_proj.html'); await q.waitForTimeout(600);
  const after = await q.evaluate(() => targets().map(t => targetHex(t)).join('|'));
  check(after === before && await q.evaluate(() => steps()[W.step][0]) === 'finish', 'project opened again: same hex, at the finish page');
  check(await q.evaluate(() => document.querySelectorAll('.svpick').length) === 0, 'no saved / new choice when nothing changed');
  await q.evaluate(() => { SAVED.hex['N2:0'] = SAVED.hex['N2:0'].replace(/\r?\n:00000001FF/, '\n:00000001FF\n'); render(); });
  check(await q.evaluate(() => document.querySelectorAll('.svpick').length) === 2, 'a newer firmware for one panel: choice saved / new');
  check(await q.evaluate(() => targetHex(targets()[8]) === SAVED.hex['N2:0']), 'default: the saved hex');
  await b.close(); console.log('fails', fails);
})();
