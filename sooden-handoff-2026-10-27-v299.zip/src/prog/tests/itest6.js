const { chromium } = require('/opt/node-tools/node_modules/playwright');
const fs = require('fs'); const B = '/home/claude/prog/build/';
const url = fs.readFileSync(B + 'url.txt', 'utf8').trim();
let fails = 0; const check = (c, m) => { if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1250, height: 900 } });
  p.on('pageerror', e => { fails++; console.log('  PAGE ERROR ' + e.message); });
  fs.writeFileSync(B + 'mode.txt', 'ok');
  await p.goto(url);
  await p.evaluate(() => localStorage.clear());
  await p.goto(url);
  await p.click('.choice[data-k="single"]'); await p.click('.choice[data-v="true"]'); await p.click('.choice[data-k="remote"]'); await p.click('.mdl[data-id="P4"]');
  // pole names
  const names = ['لوستر', 'هالوژن', 'آباژور', 'راهرو'];
  for (let i = 0; i < 4; i++) await p.fill(`.pnm[data-p="S"][data-i="${i}"]`, names[i]);
  check(await p.locator('.rtmin').count() === 4, '4 timer lengths shown');
  check((await p.locator('.rtmin').evaluateAll(e => e.map(x => x.value))).join() === '10,30,90,180', 'default 10/30/90/180');
  // button A (code 1 -> pole 1): hold timer, default length 2
  const bidA = await p.evaluate(() => libModel(W.single.slots[0].model).buttons[0].id);
  await p.check(`.stm[data-bid="${bidA}"]`);
  await p.selectOption(`.std[data-bid="${bidA}"]`, '1');
  // button B: make it only-off -> no timer possible
  const bidB = await p.evaluate(() => libModel(W.single.slots[0].model).buttons[1].id);
  await p.check(`.spole[data-bid="${bidB}"][data-k="2"]`);
  await p.selectOption(`.sact[data-bid="${bidB}"]`, 'off');
  check(await p.locator(`.stm[data-bid="${bidB}"]`).count() === 0 && (await p.textContent(`tr:has(.sact[data-bid="${bidB}"])`)).includes('فقط خاموش'), 'only-off button: no timer tick');
  await p.selectOption(`.sact[data-bid="${bidB}"]`, 'on');
  await p.check(`.stm[data-bid="${bidB}"]`);
  await p.fill('.rtmin[data-x="0"]', '5'); await p.dispatchEvent('.rtmin[data-x="0"]', 'change');
  await p.fill('.rtmin[data-x="3"]', ''); await p.dispatchEvent('.rtmin[data-x="3"]', 'change');
  await p.screenshot({ path: '/home/claude/out/ui-timer.png', fullPage: true });
  await p.click('#next');
  check((await p.textContent('#stage')).includes('زمان ۴ تایمر ریموت باید عدد ۱ تا ۲۵۵'), 'empty length -> error');
  await p.click('.errgo'); await p.waitForTimeout(300);
  check(await p.locator('.errbub').count() === 1, 'error leads to the length box');
  await p.fill('.rtmin[data-x="3"]', '200'); await p.dispatchEvent('.rtmin[data-x="3"]', 'change');
  await p.click('#next');
  check((await p.textContent('#stage')).includes('همه تنظیمات معتبر است'), 'valid now');
  // config bytes
  const cfg = await p.evaluate(() => { const m = parseHex(targetHex(targets()[0])); const b = []; for (let i = 0; i < 128; i++) b.push(m.get(0x1F80 + i)); return b; });
  check(cfg[32 + 1] === (0x01 | 0x40), 'A: pole1 + hold timer (0x41)');
  check(cfg[32 + 2] === (0x06 | 0x10 | 0x40), 'B: poles 2+3 only-on + timer (0x56)');
  check(cfg[32 + 4] === 0x04 && cfg[32 + 8] === 0x08, 'C, D unchanged, no timer');
  check(cfg.slice(96, 100).join() === '5,30,90,200', 'lengths 5/30/90/200');
  check(cfg[100] === (1 << 2), 'A default = length 2 (2 bits per button)');
  check(cfg[127] === require('/home/claude/avrsim/cfgcore.js').crc8(cfg, 127), 'crc ok');
  // project info + brochure
  await p.fill('.pjf[data-k="customer"]', 'آقای رضایی'); await p.fill('.pjf[data-k="place"]', 'تهران، واحد ۵');
  await p.fill('.pjn[data-p="S"]', 'کلید پذیرایی'); await p.fill('.pjf[data-k="phone"]', '۰۹۱۲۰۰۰۰۰۰۰');
  const html = await p.evaluate(() => brochureHtml(targets()[0]));
  check(html.includes('لوستر') && html.includes('آقای رضایی') && html.includes('کلید پذیرایی'), 'brochure has names and customer');
  check(html.includes('تایمر با ریموت') && html.includes('۵ دقیقه') && html.includes('۲۰۰ دقیقه') && html.includes('پیش‌فرض ۳۰ دقیقه'), 'brochure timer section with lengths and default');
  check(html.includes('پاک کردن همه ریموت‌ها'), 'brochure learn/erase section');
  const bp = await b.newPage({ viewport: { width: 900, height: 1200 } });
  await bp.setContent(html); await bp.waitForTimeout(500);
  await bp.screenshot({ path: '/home/claude/out/brochure.png', fullPage: true });
  await bp.pdf({ path: '/home/claude/out/brochure.pdf', format: 'A4' });
  // program -> archive
  await p.click('[data-pg="0"]'); await p.click('[data-go]');
  await p.waitForSelector('.pmres .msg.ok >> nth=1', { timeout: 30000 });
  const res = await p.textContent('.pmres');
  check(res.includes('بروشور مشتری در پوشه archive ذخیره شد'), 'archived after programming: ' + res.slice(res.indexOf('بروشور')).slice(0, 120));
  const files = fs.existsSync(B + 'archive') ? fs.readdirSync(B + 'archive') : [];
  check(files.length === 1 && /^\d{4}-\d\d-\d\d - آقای رضایی - تهران، واحد ۵ - کلید پذیرایی\.html$/.test(files[0]), 'archive file name: ' + files[0]);
  check(files.length && fs.readFileSync(B + 'archive/' + files[0], 'utf8').includes('لوستر'), 'archive content is the brochure');
  await p.locator('.pgbox').screenshot({ path: '/home/claude/out/archived.png' });
  await b.close(); console.log('fails', fails);
})();
