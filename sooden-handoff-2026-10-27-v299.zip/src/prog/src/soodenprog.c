/* SoodenProg - local helper for the Sooden configurator page.
 *
 * - serves www/index.html on http://127.0.0.1:<port>/
 * - runs avrdude (next to the exe) for fixed operations only
 * - every API call must carry the random token of this run (X-Sooden-Token)
 *   and a Host header of 127.0.0.1/localhost, so other web pages cannot use it
 *
 * Stage 1: /api/ping, /api/probe (read signature + fuses, writes nothing)
 * Stage 2: /api/eeprom  (read signature + EEPROM, writes nothing)
 *          /api/program (fuses from a fixed whitelist, then flash erase/write/verify;
 *                        never writes lock bits or EEPROM; EESAVE is set before the erase)
 *          /api/lib     remote models library, kept in sooden_remotes.json next to the exe
 * Stage 3: /api/archive  saves a customer brochure (HTML) in the "archive" folder next to the exe
 *          /api/openarchive  opens that folder in Explorer
 */
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <shellapi.h>
#include <bcrypt.h>
typedef SOCKET sock_t;
#define CLOSESOCK closesocket
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>
typedef int sock_t;
#define INVALID_SOCKET (-1)
#define CLOSESOCK close
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdint.h>

#define APP_VERSION "2.4"
#define PORT_FIRST 47810
#define PORT_LAST  47829
#define MAX_REQ    (256 * 1024)
#define AVRDUDE_TIMEOUT_MS 60000
#define PROGRAM_TIMEOUT_MS 240000   /* old USBasp on its slow jumper speed is slow */
static int g_timeout = AVRDUDE_TIMEOUT_MS;

#ifdef _WIN32
static CRITICAL_SECTION g_lock;
#define LOCK() EnterCriticalSection(&g_lock)
#define UNLOCK() LeaveCriticalSection(&g_lock)
#else
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
#define LOCK() pthread_mutex_lock(&g_lock)
#define UNLOCK() pthread_mutex_unlock(&g_lock)
#endif
static char g_dir[1024];     /* folder of the exe, with trailing separator */
static char g_token[33];
static int  g_port;

/* ------------------------------------------------------------------ utils */
static void die(const char *m) { fprintf(stderr, "ERROR: %s\n", m); exit(1); }

static void random_token(void)
{
    unsigned char b[16];
#ifdef _WIN32
    if (BCryptGenRandom(NULL, b, sizeof b, BCRYPT_USE_SYSTEM_PREFERRED_RNG) != 0) die("no random source");
#else
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f || fread(b, 1, sizeof b, f) != sizeof b) die("no random source");
    fclose(f);
#endif
    for (int i = 0; i < 16; i++) sprintf(g_token + i * 2, "%02x", b[i]);
}

static void exe_dir(const char *argv0)
{
#ifdef _WIN32
    (void)argv0;
    DWORD n = GetModuleFileNameA(NULL, g_dir, sizeof g_dir);
    if (!n || n >= sizeof g_dir) die("cannot find program folder");
    char *p = strrchr(g_dir, '\\');
    if (p) p[1] = 0;
#else
    snprintf(g_dir, sizeof g_dir, "%s", argv0);
    char *p = strrchr(g_dir, '/');
    if (p) p[1] = 0; else strcpy(g_dir, "./");
#endif
}

static char *read_file(const char *path, long *len)
{
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *b = malloc((size_t)n + 1);
    if (!b) { fclose(f); return NULL; }
    if (fread(b, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(b); return NULL; }
    fclose(f);
    b[n] = 0;
    if (len) *len = n;
    return b;
}

/* growable string */
typedef struct { char *p; size_t n, cap; } Str;
static void s_add(Str *s, const char *t, size_t n)
{
    if (s->n + n + 1 > s->cap) {
        s->cap = (s->n + n + 1) * 2;
        s->p = realloc(s->p, s->cap);
        if (!s->p) die("out of memory");
    }
    memcpy(s->p + s->n, t, n);
    s->n += n;
    s->p[s->n] = 0;
}
static void s_cat(Str *s, const char *t) { s_add(s, t, strlen(t)); }
static void s_json(Str *s, const char *t)          /* JSON string literal */
{
    s_cat(s, "\"");
    for (const unsigned char *c = (const unsigned char *)t; *c; c++) {
        char e[8];
        if (*c == '"' || *c == '\\') { e[0] = '\\'; e[1] = (char)*c; s_add(s, e, 2); }
        else if (*c == '\n') s_cat(s, "\\n");
        else if (*c == '\r') continue;
        else if (*c == '\t') s_cat(s, "\\t");
        else if (*c < 0x20) { sprintf(e, "\\u%04x", *c); s_cat(s, e); }
        else s_add(s, (const char *)c, 1);
    }
    s_cat(s, "\"");
}

/* ------------------------------------------------------------ avrdude run */
typedef struct { int exitcode; int timedout; char *out; char *err; } RunResult;

#ifdef _WIN32
static RunResult run_avrdude(const char *args)
{
    RunResult r = { -1, 0, NULL, NULL };
    char tmp[MAX_PATH], outp[MAX_PATH], errp[MAX_PATH];
    GetTempPathA(sizeof tmp, tmp);
    snprintf(outp, sizeof outp, "%ssoodenprog_%lu_out.txt", tmp, (unsigned long)GetCurrentProcessId());
    snprintf(errp, sizeof errp, "%ssoodenprog_%lu_err.txt", tmp, (unsigned long)GetCurrentProcessId());

    SECURITY_ATTRIBUTES sa = { sizeof sa, NULL, TRUE };
    HANDLE ho = CreateFileA(outp, GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY, NULL);
    HANDLE he = CreateFileA(errp, GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY, NULL);
    if (ho == INVALID_HANDLE_VALUE || he == INVALID_HANDLE_VALUE) { r.err = _strdup("cannot create temp files"); return r; }

    char cmd[4096];
    snprintf(cmd, sizeof cmd, "\"%savrdude.exe\" -C \"%savrdude.conf\" %s", g_dir, g_dir, args);
    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof si); si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
    si.hStdOutput = ho; si.hStdError = he;
    if (!CreateProcessA(NULL, cmd, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, g_dir, &si, &pi)) {
        CloseHandle(ho); CloseHandle(he);
        r.err = _strdup("avrdude.exe could not be started (is it next to SoodenProg.exe?)");
        return r;
    }
    if (WaitForSingleObject(pi.hProcess, (DWORD)g_timeout) == WAIT_TIMEOUT) {
        TerminateProcess(pi.hProcess, 99);
        WaitForSingleObject(pi.hProcess, 5000);
        r.timedout = 1;
    }
    DWORD code = 0;
    GetExitCodeProcess(pi.hProcess, &code);
    r.exitcode = (int)code;
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    CloseHandle(ho); CloseHandle(he);
    r.out = read_file(outp, NULL);
    r.err = read_file(errp, NULL);
    DeleteFileA(outp); DeleteFileA(errp);
    if (!r.out) r.out = _strdup("");
    if (!r.err) r.err = _strdup("");
    return r;
}
#else
static RunResult run_avrdude(const char *args)
{
    RunResult r = { -1, 0, NULL, NULL };
    char outp[256], errp[256], cmd[4096];
    snprintf(outp, sizeof outp, "/tmp/soodenprog_%d_out.txt", (int)getpid());
    snprintf(errp, sizeof errp, "/tmp/soodenprog_%d_err.txt", (int)getpid());
    snprintf(cmd, sizeof cmd, "cd '%s' && timeout %d '%savrdude' -C '%savrdude.conf' %s >'%s' 2>'%s'",
             g_dir, g_timeout / 1000, g_dir, g_dir, args, outp, errp);
    int st = system(cmd);
    r.exitcode = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    if (r.exitcode == 124) r.timedout = 1;
    r.out = read_file(outp, NULL); r.err = read_file(errp, NULL);
    unlink(outp); unlink(errp);
    if (!r.out) r.out = strdup("");
    if (!r.err) r.err = strdup("");
    return r;
}
#endif

/* find "Device signature = 1E 93 07" or "= 0x1e9307" in the log */
static int parse_signature(const char *log, char *sig /* "1E9307" */)
{
    const char *p = log;
    while ((p = strstr(p, "ignature")) != NULL) {
        const char *q = strchr(p, '=');
        if (!q) break;
        q++;
        char hex[7]; int n = 0;
        while (*q && *q != '\n' && n < 6) {
            if (q[0] == '0' && (q[1] == 'x' || q[1] == 'X')) { q += 2; continue; }
            if (isxdigit((unsigned char)*q)) hex[n++] = (char)toupper((unsigned char)*q);
            else if (*q != ' ' && n) break;
            q++;
        }
        if (n == 6) { hex[6] = 0; strcpy(sig, hex); return 1; }
        p = q;
    }
    return 0;
}

/* fuse values printed by -U xxx:r:-:h, one per line: 0x3f */
static int parse_bytes(const char *out, int *v, int max)
{
    int n = 0;
    const char *p = out;
    while (*p && n < max) {
        while (*p && !(p[0] == '0' && (p[1] == 'x' || p[1] == 'X'))) p++;
        if (!*p) break;
        unsigned x;
        if (sscanf(p + 2, "%2x", &x) == 1) v[n++] = (int)x;
        p += 2;
    }
    return n;
}

static const char *classify(const char *log, int haveSig, const char *sig, const char *want)
{
    if (strstr(log, "cannot open USB device"))
        return "driver";                       /* USBasp seen but Windows refuses access */
    if (strstr(log, "could not find USB device") || strstr(log, "cannot find USB device") ||
        strstr(log, "unable to open programmer") || strstr(log, "unable to open port"))
        return "no_programmer";
    if (haveSig && (!strcmp(sig, "000000") || !strcmp(sig, "FFFFFF"))) return "no_target";
    if (strstr(log, "target doesn't answer") || strstr(log, "initialization failed") ||
        strstr(log, "program enable"))
        return "no_target";
    if (haveSig && strcmp(sig, want)) return "wrong_chip";
    return "error";
}

/* supported chips: avrdude part id + expected signature (fixed list, nothing else is accepted) */
typedef struct { const char *part, *sig; int flash, eeprom, slowB, hasE; int fuses[3][3]; } Chip;
/* fuses: the only (low, high) pairs this program will ever write; {-1,-1} ends the list
   m8:  3F/D1 = 8 MHz crystal, BOD 4 V, EESAVE   24/D1 = 8 MHz internal RC, BOD 4 V, EESAVE
        4F/D1 = 8 MHz crystal, short start-up, no BOD, EESAVE (1/2-pole board: less relay tick at power-up)
   t13: 62/FF = 9.6 MHz RC, short start-up (no relay tick at power-up); 6A/FF = original switch fuses (9.6 MHz RC / 8)
   m32: 3F/C1 = 8 MHz crystal, BOD 4 V, JTAG off, EESAVE (23-key board, touch chip); E4/D9 = 8 MHz RC (6-pole simple)
        DE/D1 = 8 MHz crystal, no BOD, JTAG off, EESAVE (6-pole crystal: learned remotes kept)
   m64: 3F/C1 + extended FF = same, ATmega103 mode off (the factory turns it on) (23-key board, main chip)
   m64 DE/D1/FF: SIM12 panel (M4, alarm): no BOD (the GSM module dips the supply), EESAVE kept
   third value = extended fuse, -1 when the chip has none */
static const Chip CHIPS[] = {
    { "m8",  "1E9307", 8192,  512,  4,  0, { { 0x3F, 0xD1, -1 }, { 0x24, 0xD1, -1 }, { 0x4F, 0xD1, -1 } } },
    { "t13", "1E9007", 1024,  64,   32, 0, { { 0x62, 0xFF, -1 }, { 0x6A, 0xFF, -1 }, { -1, -1, -1 } } },
    { "m32", "1E9502", 32768, 1024, 4,  0, { { 0x3F, 0xC1, -1 }, { 0xE4, 0xD9, -1 }, { 0xDE, 0xD1, -1 } } },
    { "m64", "1E9602", 65536, 2048, 4,  1, { { 0x3F, 0xC1, 0xFF }, { 0xDE, 0xD1, 0xFF }, { -1, -1, -1 } } }
};
/* avrdude read command: signature, fuses (extended too when the chip has it), lock */
/* only bits 0..1 of the ATmega64 extended fuse exist; avrdude may show the others either way */
#define E_DIFF(a, b) ((((a) ^ (b)) & 0x03) != 0 || (a) < 0)
static void read_args(char *args, size_t n, const Chip *chip)
{
    snprintf(args, n, "-c usbasp -p %s -B 32 -U signature:r:-:h -U lfuse:r:-:h -U hfuse:r:-:h%s -U lock:r:-:h",
             chip->part, chip->hasE ? " -U efuse:r:-:h" : "");
}

static const Chip *chip_from_path(const char *path)
{
    const char *q = strstr(path, "?part=");
    if (!q) q = strstr(path, "&part=");
    if (!q) return &CHIPS[0];
    q += 6;
    for (unsigned i = 0; i < sizeof CHIPS / sizeof CHIPS[0]; i++) {
        size_t n = strlen(CHIPS[i].part);
        if (!strncmp(q, CHIPS[i].part, n) && (q[n] == 0 || q[n] == '&')) return &CHIPS[i];
    }
    return NULL;
}

static void api_probe(Str *body, const Chip *chip)
{
    /* -B 32: ~31 kHz ISP clock, safe for a new chip on its 1 MHz internal clock.
       Old USBasp firmware cannot change the clock: avrdude then prints an error about
       the SCK period but still works at the jumper speed, so success is judged only by
       the data that was actually read, not by avrdude's exit code. */
    char args[256];
    read_args(args, sizeof args, chip);
    RunResult r = run_avrdude(args);
    int v[7] = { -1, -1, -1, -1, -1, -1, -1 }, want = chip->hasE ? 7 : 6;
    int nv = parse_bytes(r.out, v, want);
    char sig[8] = "";
    int haveSig = 0;
    if (nv >= 3) { snprintf(sig, sizeof sig, "%02X%02X%02X", v[0], v[1], v[2]); haveSig = 1; }
    else haveSig = parse_signature(r.err, sig);
    int ok = !r.timedout && nv == want && haveSig && !strcmp(sig, chip->sig);
    int oldfw = strstr(r.err, "cannot set sck") != NULL;
    char tmp[160];
    s_cat(body, "{\"ok\":"); s_cat(body, ok ? "true" : "false");
    s_cat(body, ",\"code\":"); s_json(body, ok ? "ok" : r.timedout ? "timeout" : classify(r.err, haveSig, sig, chip->sig));
    s_cat(body, ",\"signature\":"); s_json(body, sig);
    int full = nv == want;
    snprintf(tmp, sizeof tmp, ",\"lfuse\":%d,\"hfuse\":%d,\"efuse\":%d,\"lock\":%d,\"oldFirmware\":%s,\"exit\":%d,\"log\":",
             full ? v[3] : -1, full ? v[4] : -1, full && chip->hasE ? v[5] : -1, full ? v[want - 1] : -1,
             oldfw ? "true" : "false", r.exitcode);
    s_cat(body, tmp);
    Str lg = { 0 };
    s_cat(&lg, r.err);
    s_cat(&lg, "\n--- data ---\n");
    s_cat(&lg, r.out);
    s_json(body, lg.p);
    free(lg.p);
    s_cat(body, "}");
    free(r.out); free(r.err);
}

/* old USBasp firmware always complains about the SCK period (and avrdude then exits with 1);
   any other error line means a real problem */
static int only_sck_errors(const char *err)
{
    const char *p = err;
    while (*p) {
        const char *e = strchr(p, '\n');
        size_t n = e ? (size_t)(e - p) : strlen(p);
        char line[512];
        size_t k = n < sizeof line - 1 ? n : sizeof line - 1;
        memcpy(line, p, k); line[k] = 0;
        for (char *c = line; *c; c++) *c = (char)tolower((unsigned char)*c);
        if ((strstr(line, "error") || strstr(line, "mismatch") || strstr(line, "failed")) && !strstr(line, "sck"))
            return 0;
        if (!e) break;
        p = e + 1;
    }
    return 1;
}

static void tmp_name(char *out, size_t n, const char *base)     /* inside the program folder, relative to avrdude's cwd */
{
    snprintf(out, n, "%s", base);
}
static void tmp_full(char *out, size_t n, const char *base) { snprintf(out, n, "%s%s", g_dir, base); }

/* read signature + fuses; returns 1 when the right chip answered */
typedef struct { int ok; char sig[8]; int l, h, e, lock; int oldfw; const char *code; } ChipState;
static ChipState read_state(const Chip *chip, Str *log)
{
    ChipState cs; memset(&cs, 0, sizeof cs); cs.l = cs.h = cs.e = cs.lock = -1;
    char args[256];
    read_args(args, sizeof args, chip);
    RunResult r = run_avrdude(args);
    int v[7] = { -1, -1, -1, -1, -1, -1, -1 }, want = chip->hasE ? 7 : 6;
    int nv = parse_bytes(r.out, v, want), haveSig = 0;
    if (nv >= 3) { snprintf(cs.sig, sizeof cs.sig, "%02X%02X%02X", v[0], v[1], v[2]); haveSig = 1; }
    else haveSig = parse_signature(r.err, cs.sig);
    cs.ok = !r.timedout && nv == want && haveSig && !strcmp(cs.sig, chip->sig);
    if (cs.ok) { cs.l = v[3]; cs.h = v[4]; if (chip->hasE) cs.e = v[5]; cs.lock = v[want - 1]; }
    cs.oldfw = strstr(r.err, "cannot set sck") != NULL;
    cs.code = cs.ok ? "ok" : r.timedout ? "timeout" : classify(r.err, haveSig, cs.sig, chip->sig);
    s_cat(log, "### read signature/fuses\n"); s_cat(log, r.err); s_cat(log, "\n--- data ---\n"); s_cat(log, r.out); s_cat(log, "\n");
    free(r.out); free(r.err);
    return cs;
}

static void json_end(Str *body, Str *log)
{
    s_cat(body, ",\"log\":"); s_json(body, log->p ? log->p : ""); s_cat(body, "}");
    free(log->p);
}

/* POST /api/eeprom?part=m8 : signature + whole EEPROM as hex text (writes nothing) */
static void api_eeprom(Str *body, const Chip *chip)
{
    Str log = { 0 };
    ChipState cs = read_state(chip, &log);
    if (!cs.ok) {
        s_cat(body, "{\"ok\":false,\"code\":"); s_json(body, cs.code);
        s_cat(body, ",\"signature\":"); s_json(body, cs.sig);
        json_end(body, &log); return;
    }
    char rel[64], full[1200], args[256];
    tmp_name(rel, sizeof rel, "sooden_ee.bin"); tmp_full(full, sizeof full, rel);
    remove(full);
    snprintf(args, sizeof args, "-c usbasp -p %s -B 32 -U eeprom:r:%s:r", chip->part, rel);
    RunResult r = run_avrdude(args);
    s_cat(&log, "### read eeprom\n"); s_cat(&log, r.err); s_cat(&log, "\n");
    long n = -1;
    char *data = read_file(full, &n);
    remove(full);
    int ok = !r.timedout && data && n >= 0 && n <= chip->eeprom && (r.exitcode == 0 || only_sck_errors(r.err));
    s_cat(body, "{\"ok\":"); s_cat(body, ok ? "true" : "false");
    s_cat(body, ",\"code\":"); s_json(body, ok ? "ok" : r.timedout ? "timeout" : "error");
    s_cat(body, ",\"signature\":"); s_json(body, cs.sig);
    s_cat(body, ",\"eeprom\":\"");
    if (ok) {
        char h[3];
        for (int i = 0; i < chip->eeprom; i++) {      /* avrdude may leave out trailing 0xFF bytes */
            snprintf(h, sizeof h, "%02X", i < n ? (unsigned char)data[i] : 0xFF);
            s_cat(body, h);
        }
    }
    s_cat(body, "\"");
    free(data); free(r.out); free(r.err);
    json_end(body, &log);
}

static int hexval(const char *p, int n)
{
    int v = 0;
    for (int i = 0; i < n; i++) {
        int c = p[i], d;
        if (c >= '0' && c <= '9') d = c - '0';
        else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
        else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
        else return -1;
        v = v * 16 + d;
    }
    return v;
}

/* Intel hex check: record types 0/1 only, checksums, every byte inside the flash; returns bytes or -1 */
static long check_hex(const char *t, int flash)
{
    long total = 0; int end = 0;
    const char *p = t;
    while (*p) {
        while (*p == '\r' || *p == '\n' || *p == ' ') p++;
        if (!*p) break;
        if (*p != ':' || end) return -1;
        const char *q = p + 1;
        int n = hexval(q, 2), a = hexval(q + 2, 4), ty = hexval(q + 6, 2);
        if (n < 0 || a < 0 || ty < 0) return -1;
        int sum = n + (a >> 8) + (a & 0xFF) + ty;
        for (int i = 0; i < n + 1; i++) { int b = hexval(q + 8 + i * 2, 2); if (b < 0) return -1; sum += b; }
        if (sum & 0xFF) return -1;
        if (ty == 0) { if (a + n > flash) return -1; total += n; }
        else if (ty == 1) end = 1;
        else return -1;
        p = q + 8 + (n + 1) * 2;
        if (*p && *p != '\r' && *p != '\n') return -1;
    }
    return end && total > 0 ? total : -1;
}

/* POST /api/program?part=m8&l=3F&h=D1[&e=FF] , body = Intel hex (e = extended fuse, only for chips that have one) */
static void api_program(Str *body, const Chip *chip, const char *path, const char *hex)
{
    Str log = { 0 };
    const char *lp = strstr(path, "&l="), *hp = strstr(path, "&h=");
    const char *ep = strstr(path, "&e=");
    int L = lp ? hexval(lp + 3, 2) : -1, H = hp ? hexval(hp + 3, 2) : -1, E = ep ? hexval(ep + 3, 2) : -1, allowed = 0;
    if (!chip->hasE && ep) E = -2;                       /* an extended fuse for a chip without one: refused */
    for (int i = 0; i < 3 && chip->fuses[i][0] >= 0; i++)
        if (chip->fuses[i][0] == L && chip->fuses[i][1] == H && chip->fuses[i][2] == E) allowed = 1;
    long nbytes = check_hex(hex, chip->flash);
    if (!allowed || nbytes < 0) {
        s_cat(body, "{\"ok\":false,\"code\":"); s_json(body, !allowed ? "fuse_not_allowed" : "bad_hex");
        json_end(body, &log); return;
    }
    /* 1. right chip? */
    ChipState cs = read_state(chip, &log);
    char tmp[200];
    if (!cs.ok) {
        s_cat(body, "{\"ok\":false,\"step\":\"identify\",\"code\":"); s_json(body, cs.code);
        s_cat(body, ",\"signature\":"); s_json(body, cs.sig);
        json_end(body, &log); return;
    }
    /* 2. fuses (extended first: ATmega103 mode off; then high: EESAVE protects the EEPROM before anything is erased) */
    int fuseWritten = 0;
    if (cs.l != L || cs.h != H || (chip->hasE && E_DIFF(cs.e, E))) {
        char args[256], ex[40] = "";
        if (chip->hasE) snprintf(ex, sizeof ex, " -U efuse:w:0x%02X:m", E);
        snprintf(args, sizeof args, "-c usbasp -p %s -B 32%s -U hfuse:w:0x%02X:m -U lfuse:w:0x%02X:m", chip->part, ex, H, L);
        RunResult r = run_avrdude(args);
        s_cat(&log, "### write fuses\n"); s_cat(&log, r.err); s_cat(&log, "\n");
        free(r.out); free(r.err);
        ChipState c2 = read_state(chip, &log);
        if (!c2.ok || c2.l != L || c2.h != H || (chip->hasE && E_DIFF(c2.e, E))) {
            snprintf(tmp, sizeof tmp, "{\"ok\":false,\"step\":\"fuses\",\"code\":\"fuse_write\",\"lfuse\":%d,\"hfuse\":%d,\"efuse\":%d", c2.l, c2.h, c2.e);
            s_cat(body, tmp); json_end(body, &log); return;
        }
        fuseWritten = 1;
    }
    /* 3. flash: erase + write + verify (avrdude verifies after writing) */
    char rel[64], full[1200], args[300];
    tmp_name(rel, sizeof rel, "sooden_flash.hex"); tmp_full(full, sizeof full, rel);
    FILE *f = fopen(full, "wb");
    if (!f || fputs(hex, f) < 0) { if (f) fclose(f); s_cat(body, "{\"ok\":false,\"step\":\"flash\",\"code\":\"tempfile\""); json_end(body, &log); return; }
    fclose(f);
    snprintf(args, sizeof args, "-c usbasp -p %s -B %d -U flash:w:%s:i", chip->part, chip->slowB, rel);
    g_timeout = PROGRAM_TIMEOUT_MS;
    RunResult r = run_avrdude(args);
    g_timeout = AVRDUDE_TIMEOUT_MS;
    remove(full);
    s_cat(&log, "### write flash\n"); s_cat(&log, r.err); s_cat(&log, "\n");
    int verified = strstr(r.err, "of flash verified") != NULL;
    int ok = !r.timedout && verified && (r.exitcode == 0 || only_sck_errors(r.err));
    snprintf(tmp, sizeof tmp, "{\"ok\":%s,\"step\":\"flash\",\"code\":\"%s\",\"bytes\":%ld,\"fuseWritten\":%s,\"lfuse\":%d,\"hfuse\":%d,\"efuse\":%d,\"oldFirmware\":%s",
             ok ? "true" : "false", ok ? "ok" : r.timedout ? "timeout" : verified ? "error" : "verify", nbytes,
             fuseWritten ? "true" : "false", L, H, chip->hasE ? E : -1, cs.oldfw ? "true" : "false");
    s_cat(body, tmp);
    free(r.out); free(r.err);
    json_end(body, &log);
}

/* remote models library: one JSON file next to the exe (written by this program only) */
#define LIB_FILE "sooden_remotes.json"
#define LIB_MAX  (128 * 1024)
static void api_lib_get(Str *body)
{
    char full[1200]; long n = 0;
    tmp_full(full, sizeof full, LIB_FILE);
    char *t = read_file(full, &n);
    if (t && n > 1 && t[0] == '{') s_cat(body, t); else s_cat(body, "{}");
    free(t);
}
static void api_lib_put(Str *body, const char *data)
{
    size_t n = strlen(data);
    if (n < 2 || n > LIB_MAX || data[0] != '{') { s_cat(body, "{\"ok\":false,\"code\":\"bad_lib\"}"); return; }
    char full[1200], tmpf[1200];
    tmp_full(full, sizeof full, LIB_FILE);
    tmp_full(tmpf, sizeof tmpf, LIB_FILE ".tmp");
    FILE *f = fopen(tmpf, "wb");
    int ok = f && fwrite(data, 1, n, f) == n;
    if (f) fclose(f);
    if (ok) { remove(full); ok = rename(tmpf, full) == 0; }     /* old file kept until the new one is complete */
    s_cat(body, ok ? "{\"ok\":true}" : "{\"ok\":false,\"code\":\"write\"}");
}


/* customer brochures: archive/<name>.html next to the exe. The name comes from the page and is
   checked here: UTF-8 text only, no path characters, so nothing can be written outside the folder */
#define ARC_DIR "archive"
static int hexv(int c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }
static int arc_name(const char *path, char *out, size_t n)
{
    const char *q = strstr(path, "?name=");
    if (!q) return 0;
    q += 6;
    size_t k = 0;
    while (*q && *q != '&') {
        int ch = (unsigned char)*q;
        if (ch == '%') { int a = hexv(q[1]), b = a < 0 ? -1 : hexv(q[2]); if (b < 0) return 0; ch = a * 16 + b; q += 3; }
        else { if (ch == '+') ch = ' '; q++; }
        if (ch < 0x20 || ch == 0x7F || strchr("/\\:*?\"<>|", ch)) return 0;
        if (k + 1 >= n) return 0;
        out[k++] = (char)ch;
    }
    out[k] = 0;
    /* well-formed UTF-8 */
    for (size_t i = 0; i < k;) {
        unsigned char c = (unsigned char)out[i];
        int len = c < 0x80 ? 1 : (c & 0xE0) == 0xC0 ? 2 : (c & 0xF0) == 0xE0 ? 3 : (c & 0xF8) == 0xF0 ? 4 : 0;
        if (!len || i + len > k) return 0;
        for (int j = 1; j < len; j++) if (((unsigned char)out[i + j] & 0xC0) != 0x80) return 0;
        i += len;
    }
    /* no leading/trailing dots or spaces (Windows drops them) */
    while (k && (out[k - 1] == '.' || out[k - 1] == ' ')) out[--k] = 0;
    size_t s0 = 0; while (out[s0] == '.' || out[s0] == ' ') s0++;
    if (s0) memmove(out, out + s0, k - s0 + 1), k -= s0;
    /* Windows device names (CON, NUL, COM1...) cannot be files */
    static const char *dev[] = { "CON", "PRN", "AUX", "NUL", "COM", "LPT" };
    for (int d = 0; d < 6; d++) {
        size_t L = 0;
        while (L < 3 && toupper((unsigned char)out[L]) == dev[d][L]) L++;
        if (L == 3 && (d < 4 ? (out[3] == 0 || out[3] == '.' || out[3] == ' ') : (out[3] >= '1' && out[3] <= '9' && (out[4] == 0 || out[4] == '.' || out[4] == ' ')))) return 0;
    }
    return k > 0 && k <= 150;
}
#ifdef _WIN32
static int wpath(const char *u, wchar_t *w, int n) { return MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, u, -1, w, n) > 0; }
static FILE *ufopen(const char *u, const wchar_t *mode) { wchar_t w[1200]; return wpath(u, w, 1200) ? _wfopen(w, mode) : NULL; }
static int uexists(const char *u) { wchar_t w[1200]; return wpath(u, w, 1200) && GetFileAttributesW(w) != INVALID_FILE_ATTRIBUTES; }
static void umkdir(const char *u) { wchar_t w[1200]; if (wpath(u, w, 1200)) CreateDirectoryW(w, NULL); }
#define UMODE_WB L"wb"
#define SEP "\\"
#else
#include <sys/stat.h>
static FILE *ufopen(const char *u, const char *mode) { return fopen(u, mode); }
static int uexists(const char *u) { struct stat st; return stat(u, &st) == 0; }
static void umkdir(const char *u) { mkdir(u, 0755); }
#define UMODE_WB "wb"
#define SEP "/"
#endif
static void api_archive(Str *body, const char *path, const char *data)
{
    char name[200], dir[1100], full[1400];
    size_t n = strlen(data);
    if (!arc_name(path, name, sizeof name)) { s_cat(body, "{\"ok\":false,\"code\":\"bad_name\"}"); return; }
    if (n < 20 || n > MAX_REQ - 4096 || (strncmp(data, "<!DOCTYPE", 9) && strncmp(data, "<html", 5))) { s_cat(body, "{\"ok\":false,\"code\":\"bad_doc\"}"); return; }
    snprintf(dir, sizeof dir, "%s" ARC_DIR, g_dir);
    umkdir(dir);
    char shown[260];
    for (int i = 1; i < 100; i++) {           /* never overwrite an older brochure */
        if (i == 1) snprintf(shown, sizeof shown, "%s.html", name);
        else snprintf(shown, sizeof shown, "%s (%d).html", name, i);
        snprintf(full, sizeof full, "%s" SEP "%s", dir, shown);
        if (!uexists(full)) break;
    }
    FILE *f = uexists(full) ? NULL : ufopen(full, UMODE_WB);
    int ok = f && fwrite(data, 1, n, f) == n;
    if (f) fclose(f);
    if (!ok) { remove(full); s_cat(body, "{\"ok\":false,\"code\":\"write\"}"); return; }
    printf("  archive: %s\n", full); fflush(stdout);
    s_cat(body, "{\"ok\":true,\"file\":\"" ARC_DIR "/"); s_cat(body, shown); s_cat(body, "\"}");
}
static void api_open_archive(Str *body)
{
    char dir[1100];
    snprintf(dir, sizeof dir, "%s" ARC_DIR, g_dir);
    umkdir(dir);
#ifdef _WIN32
    wchar_t w[1200];
    if (wpath(dir, w, 1200)) ShellExecuteW(NULL, L"open", w, NULL, NULL, SW_SHOWNORMAL);
#endif
    s_cat(body, "{\"ok\":true}");
}

/* ------------------------------------------------------------------- http */
static void send_all(sock_t c, const char *p, size_t n)
{
    while (n) {
        int k = send(c, p, (int)(n > 65536 ? 65536 : n), 0);
        if (k <= 0) return;
        p += k; n -= (size_t)k;
    }
}

static void respond(sock_t c, int status, const char *ctype, const char *body, size_t len)
{
    char h[512];
    const char *st = status == 200 ? "OK" : status == 403 ? "Forbidden" : status == 404 ? "Not Found" : "Bad Request";
    int n = snprintf(h, sizeof h,
        "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %lu\r\nCache-Control: no-store\r\n"
        "X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n",
        status, st, ctype, (unsigned long)len);
    send_all(c, h, (size_t)n);
    send_all(c, body, len);
}

static const char *header(const char *req, const char *name, char *out, size_t outsz)
{
    size_t nl = strlen(name);
    const char *p = req;
    while ((p = strstr(p, "\r\n")) != NULL) {
        p += 2;
        if (p[0] == '\r') break;
#ifdef _WIN32
        if (!_strnicmp(p, name, nl) && p[nl] == ':') {
#else
        if (!strncasecmp(p, name, nl) && p[nl] == ':') {
#endif
            const char *v = p + nl + 1;
            while (*v == ' ') v++;
            size_t i = 0;
            while (v[i] && v[i] != '\r' && i + 1 < outsz) { out[i] = v[i]; i++; }
            out[i] = 0;
            return out;
        }
    }
    return NULL;
}

static int host_ok(const char *req)
{
    char h[128], a[64], b[64];
    if (!header(req, "Host", h, sizeof h)) return 0;
    snprintf(a, sizeof a, "127.0.0.1:%d", g_port);
    snprintf(b, sizeof b, "localhost:%d", g_port);
    return !strcmp(h, a) || !strcmp(h, b);
}

static void handle_req(sock_t c, char *req)
{
    int n = 0;
    /* read headers (and small body) */
    while (n < MAX_REQ) {
        int k = recv(c, req + n, MAX_REQ - n, 0);
        if (k <= 0) break;
        n += k; req[n] = 0;
        char *he = strstr(req, "\r\n\r\n");
        if (he) {
            char cl[32];
            long want = header(req, "Content-Length", cl, sizeof cl) ? atol(cl) : 0;
            if (want < 0 || want > MAX_REQ) { respond(c, 400, "text/plain", "too big", 7); return; }
            if ((long)(n - (he + 4 - req)) >= want) break;
        }
    }
    req[n] = 0;
    if (n == 0) return;
    char method[8] = "", path[2048] = "";
    if (sscanf(req, "%7s %2047s", method, path) != 2) { respond(c, 400, "text/plain", "bad", 3); return; }
    if (!host_ok(req)) { respond(c, 403, "text/plain", "forbidden host", 14); return; }

    if (!strcmp(method, "GET") && (!strcmp(path, "/") || !strncmp(path, "/?", 2) || !strncmp(path, "/index.html", 11))) {
        char fp[1200];
        snprintf(fp, sizeof fp, "%swww%cindex.html", g_dir,
#ifdef _WIN32
                 '\\'
#else
                 '/'
#endif
        );
        long len = 0;
        char *page = read_file(fp, &len);
        if (!page) { const char *m = "www/index.html not found next to SoodenProg.exe"; respond(c, 404, "text/plain; charset=utf-8", m, strlen(m)); return; }
        respond(c, 200, "text/html; charset=utf-8", page, (size_t)len);
        free(page);
        return;
    }
    if (!strncmp(path, "/api/", 5)) {
        char tok[64];
        if (!header(req, "X-Sooden-Token", tok, sizeof tok) || strcmp(tok, g_token)) {
            respond(c, 403, "application/json", "{\"ok\":false,\"code\":\"token\"}", 28);
            return;
        }
        Str body = { 0 };
        if (!strcmp(method, "GET") && !strcmp(path, "/api/ping")) {
            s_cat(&body, "{\"ok\":true,\"app\":\"SoodenProg\",\"version\":\"" APP_VERSION "\"}");
        } else if (!strcmp(method, "POST") && !strncmp(path, "/api/probe", 10) && (path[10] == 0 || path[10] == '?')) {
            const Chip *chip = chip_from_path(path);
            if (!chip) { respond(c, 400, "application/json", "{\"ok\":false,\"code\":\"part\"}", 27); return; }
            LOCK();
            printf("  probe %s: reading signature and fuses...\n", chip->part); fflush(stdout);
            api_probe(&body, chip);
            UNLOCK();
            printf("  probe: done\n"); fflush(stdout);
        } else if (!strcmp(method, "GET") && !strcmp(path, "/api/lib")) {
            LOCK(); api_lib_get(&body); UNLOCK();
        } else if (!strcmp(method, "POST") && !strcmp(path, "/api/lib")) {
            const char *b = strstr(req, "\r\n\r\n");
            LOCK(); api_lib_put(&body, b ? b + 4 : ""); UNLOCK();
        } else if (!strcmp(method, "POST") && !strncmp(path, "/api/archive?", 13)) {
            const char *b = strstr(req, "\r\n\r\n");
            LOCK(); api_archive(&body, path, b ? b + 4 : ""); UNLOCK();
        } else if (!strcmp(method, "POST") && !strcmp(path, "/api/openarchive")) {
            api_open_archive(&body);
        } else if (!strcmp(method, "POST") && !strncmp(path, "/api/eeprom", 11) && (path[11] == 0 || path[11] == '?')) {
            const Chip *chip = chip_from_path(path);
            if (!chip) { respond(c, 400, "application/json", "{\"ok\":false,\"code\":\"part\"}", 27); return; }
            LOCK();
            printf("  eeprom %s: reading...\n", chip->part); fflush(stdout);
            api_eeprom(&body, chip);
            UNLOCK();
            printf("  eeprom: done\n"); fflush(stdout);
        } else if (!strcmp(method, "POST") && !strncmp(path, "/api/program?", 13)) {
            const Chip *chip = chip_from_path(path);
            if (!chip) { respond(c, 400, "application/json", "{\"ok\":false,\"code\":\"part\"}", 27); return; }
            const char *b = strstr(req, "\r\n\r\n");
            LOCK();
            printf("  program %s: fuses + flash...\n", chip->part); fflush(stdout);
            api_program(&body, chip, path, b ? b + 4 : "");
            UNLOCK();
            printf("  program: done\n"); fflush(stdout);
        } else {
            respond(c, 404, "application/json", "{\"ok\":false,\"code\":\"unknown\"}", 30);
            return;
        }
        respond(c, 200, "application/json; charset=utf-8", body.p, body.n);
        free(body.p);
        return;
    }
    respond(c, 404, "text/plain", "not found", 9);
}

static void handle(sock_t c)
{
    char *req = malloc(MAX_REQ + 1);
    if (!req) return;
    handle_req(c, req);
    free(req);
}

#ifdef _WIN32
static DWORD WINAPI conn_thread(LPVOID arg)
{
    sock_t c = (sock_t)(UINT_PTR)arg;
    DWORD tmo = 15000;                       /* idle browser pre-connections must not block */
    setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tmo, sizeof tmo);
    handle(c);
    CLOSESOCK(c);
    return 0;
}
#else
static void *conn_thread(void *arg)
{
    sock_t c = (sock_t)(intptr_t)arg;
    struct timeval tv = { 15, 0 };
    setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    handle(c);
    CLOSESOCK(c);
    return NULL;
}
#endif

int main(int argc, char **argv)
{
    (void)argc;
    exe_dir(argv[0]);
    random_token();
#ifdef _WIN32
    WSADATA w;
    if (WSAStartup(MAKEWORD(2, 2), &w)) die("network start failed");
    InitializeCriticalSection(&g_lock);
    SetConsoleTitleA("Sooden Programmer");
#else
    signal(SIGPIPE, SIG_IGN);
#endif
    sock_t s = INVALID_SOCKET;
    for (g_port = PORT_FIRST; g_port <= PORT_LAST; g_port++) {
        s = socket(AF_INET, SOCK_STREAM, 0);
        if (s == INVALID_SOCKET) die("socket failed");
        struct sockaddr_in a;
        memset(&a, 0, sizeof a);
        a.sin_family = AF_INET;
        a.sin_port = htons((unsigned short)g_port);
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);     /* this computer only */
#ifdef _WIN32
        BOOL ex = TRUE;
        setsockopt(s, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, (const char *)&ex, sizeof ex);
#endif
        if (bind(s, (struct sockaddr *)&a, sizeof a) == 0 && listen(s, 8) == 0) break;
        CLOSESOCK(s);
        s = INVALID_SOCKET;
    }
    if (s == INVALID_SOCKET) die("no free port");

    char url[128];
    snprintf(url, sizeof url, "http://127.0.0.1:%d/?t=%s", g_port, g_token);
    printf("Sooden Programmer %s\n", APP_VERSION);
    printf("Running on %s\n", url);
    printf("Keep this window open while programming. Close it when you are done.\n\n");
    fflush(stdout);
#ifdef _WIN32
    ShellExecuteA(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
#else
    if (getenv("SOODEN_URLFILE")) { FILE *f = fopen(getenv("SOODEN_URLFILE"), "w"); if (f) { fputs(url, f); fclose(f); } }
#endif
    for (;;) {
        sock_t c = accept(s, NULL, NULL);
        if (c == INVALID_SOCKET) continue;
#ifdef _WIN32
        HANDLE th = CreateThread(NULL, 0, conn_thread, (LPVOID)(UINT_PTR)c, 0, NULL);
        if (th) CloseHandle(th); else CLOSESOCK(c);
#else
        pthread_t th;
        if (pthread_create(&th, NULL, conn_thread, (void *)(intptr_t)c) == 0) pthread_detach(th);
        else CLOSESOCK(c);
#endif
    }
}
