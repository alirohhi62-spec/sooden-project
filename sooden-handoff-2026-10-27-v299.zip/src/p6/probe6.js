const H = require('./h'); const c = H(process.argv[2] || 'orig.hex');
const all = () => ['A','B','C','D'].map(p => (c.cpu.data[{A:0x3B,B:0x38,C:0x35,D:0x32}[p]]).toString(2).padStart(8,'0')).join(' ');
c.run(3000); console.log('3s ', all()); c.run(70000); console.log('73s', all());
c.tap(3,300); c.run(500); console.log('pole1', all()); c.run(70000); console.log('+70s pole1 on', all());
