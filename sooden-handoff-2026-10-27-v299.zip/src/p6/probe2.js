const H = require('./h');
for (const code of [0,1,2,3,4,5,6,7]) { const c = H(process.argv[2]||'orig.hex'); c.run(3000); c.tap(code, 400); c.run(3000); const s1 = c.state(); c.tap(code, 400); c.run(3000); console.log('code', code, s1, '|', c.state()); }
