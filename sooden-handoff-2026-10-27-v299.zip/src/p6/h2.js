// h.js + ATmega32 USART (for the Wi-Fi / network builds)
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
module.exports = function (file) {
  const c = require('./h')(file);
  c.u = new AVRUSART(c.cpu, { rxCompleteInterrupt: 26, dataRegisterEmptyInterrupt: 28, txCompleteInterrupt: 30,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x40, UBRRL: 0x29, UBRRH: 0x22, UDR: 0x2C }, 8000000);
  c.u.UDRE.constant = true;                     /* UDRE stays set while its interrupt runs (as the real chip) */
  const h = c.cpu.writeHooks[0x2B]; c.cpu.writeHooks[0x2B] = (v, o) => { const udre = c.cpu.data[0x2B] & 0x20; const r = h(v, o); c.cpu.data[0x2B] |= udre; return r; };
  c.txs = ''; c.u.onByteTransmit = b => { c.txs += String.fromCharCode(b); };
  return c;
};
