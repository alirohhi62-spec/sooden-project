/* Sooden 6-pole touch switch, simple (no crystal): ATmega32, internal RC 8 MHz (fuses Low E4, High D9)
 *
 * touch IC (coded, like BS818A): PC4 low = a key is touched, PC5 PC6 PC7 = its code (bit 2 1 0)
 *   code 3 pole 1, 4 pole 2, 2 pole 3, 5 pole 4, 0 pole 5, 7 pole 6, 1 key 7 = EXIT, 6 key 8 = MASTER
 * pole i: red LED + relay (ULN) on one pin, white LED on another (white = pole off)
 *   pole 1 PB0 / PA0, 2 PD6 / PD7, 3 PB2 / PB1, 4 PD4 / PD5, 5 PA2 / PA3, 6 PC1 / PC2
 *
 * rules (as the other Sooden panels): several poles always switch one by one, 100 ms apart;
 * master: all its poles on, only when every one is on already: all off; EXIT: after its time the exit poles off
 * (while it counts and until its last pole is off no key works). Key 7 LEDs: white PA1 (on, off while EXIT runs), red PC0 (on while EXIT runs).
 * Settings: 32 bytes the programmer writes at 0x7F00 (erased = defaults). */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#define NP 6
enum { T_OFF = 0, T_NORMAL = 1, T_TIMER = 3, T_DELOFF = 5, T_PUSH = 6 };
typedef struct {
    uint8_t magic, ver;          /* 0xA6, 1 */
    uint8_t type[NP];            /* T_xxx */
    uint8_t sec[NP];             /* T_DELOFF: blink seconds before off; T_PUSH: relay seconds */
    uint8_t min[NP];             /* T_TIMER: minutes on */
    uint8_t exitLo, exitHi;      /* EXIT seconds */
    uint8_t mMask, xMask;        /* poles of the master, poles the EXIT switches off (bit 0 = pole 1) */
    uint8_t stepMs;              /* step between poles, ms (0 = 100) */
    uint8_t res[5];
} Cfg;
const uint8_t cfg_flash[32] __attribute__((section(".p6cfg"), used)) = { [0 ... 31] = 0xFF };
static Cfg C;
static void cfg_load(void)
{
    for (uint8_t i = 0; i < sizeof C; i++) ((uint8_t *)&C)[i] = pgm_read_byte(&cfg_flash[i]);
    if (C.magic == 0xA6) { if (!C.stepMs) C.stepMs = 100; return; }
    for (uint8_t i = 0; i < NP; i++) { C.type[i] = T_NORMAL; C.sec[i] = 3; C.min[i] = 5; }
    C.exitLo = 20; C.exitHi = 0; C.mMask = 0x3F; C.xMask = 0x3F; C.stepMs = 100;
}

/* ---------------- pins ---------------- */
static volatile uint8_t *const RPORT[NP] = { &PORTB, &PORTD, &PORTB, &PORTD, &PORTA, &PORTC };
static const uint8_t RBIT[NP] = { 0, 6, 2, 4, 2, 1 };
static volatile uint8_t *const WPORT[NP] = { &PORTA, &PORTD, &PORTB, &PORTD, &PORTA, &PORTC };
static const uint8_t WBIT[NP] = { 0, 7, 1, 5, 3, 2 };
static void pin(volatile uint8_t *p, uint8_t b, uint8_t on) { if (on) *p |= (uint8_t)(1 << b); else *p &= (uint8_t)~(1 << b); }
static uint8_t on, wh = 0x3F, blinkMask, exitRun;   /* exitRun: 1 counting, 2 its poles going off */          /* poles on (relay), white LEDs wanted, whites that blink */
static volatile uint32_t ms;
static uint8_t motionOn = 1, standby;               /* standby: every LED dark (the master key's own LED is not ours) */                      /* power-up motion: the EXIT white waits */
ISR(TIMER0_COMP_vect) { ms++; }
static uint32_t now(void) { uint32_t v; cli(); v = ms; sei(); return v; }
static void show(void)
{
    uint8_t bl = (now() / 250) & 1;
    for (uint8_t i = 0; i < NP; i++) {
        pin(RPORT[i], RBIT[i], (on >> i) & 1);
        uint8_t w = standby ? 0 : (wh >> i) & 1;
        if ((blinkMask >> i) & 1) w = bl;
        pin(WPORT[i], WBIT[i], w);
    }
    pin(&PORTC, 0, exitRun != 0);                  /* key 7 (EXIT): red PC0 while it runs, white PA1 otherwise */
    pin(&PORTA, 1, exitRun == 0 && !motionOn && !standby);
}

/* ---------------- touch ---------------- */
static const uint8_t KEY[8] PROGMEM = { 4, 7, 2, 0, 1, 3, 8, 5 };   /* code -> 0..5 pole, 7 EXIT, 8 MASTER (6 unused) */
#define K_EXIT 7
#define K_MASTER 8
static uint8_t read_key(void)
{
    uint8_t p = PINC;
    if (p & _BV(4)) return 0xFF;
    uint8_t c = (uint8_t)(((p >> 5) & 1) << 2 | ((p >> 6) & 1) << 1 | ((p >> 7) & 1));
    return pgm_read_byte(&KEY[c]);
}

/* ---------------- poles ---------------- */
static uint32_t offAt[NP];                         /* timer / push / delayed off: when it goes off (0 = never) */
static void set_pole(uint8_t i, uint8_t v)
{
    if (C.type[i] == T_OFF) return;
    if (v) { on |= (uint8_t)(1 << i); wh &= (uint8_t)~(1 << i); }
    else { on &= (uint8_t)~(1 << i); wh |= (uint8_t)(1 << i); }
    blinkMask &= (uint8_t)~(1 << i);
    offAt[i] = 0;
    if (v && C.type[i] == T_TIMER) offAt[i] = now() + (uint32_t)C.min[i] * 60000UL;
    if (v && C.type[i] == T_PUSH) offAt[i] = now() + (uint32_t)(C.sec[i] ? C.sec[i] : 1) * 1000UL;
    show();
}
static void touch_pole(uint8_t i)
{
    uint8_t t = C.type[i], isOn = (on >> i) & 1;
    if (t == T_OFF) return;
    if (t == T_DELOFF && isOn) {                   /* on: blink, then off; a touch while it blinks keeps it on */
        if ((blinkMask >> i) & 1) { blinkMask &= (uint8_t)~(1 << i); offAt[i] = 0; }
        else { blinkMask |= (uint8_t)(1 << i); offAt[i] = now() + (uint32_t)(C.sec[i] ? C.sec[i] : 1) * 1000UL; }
        return;
    }
    if (t == T_PUSH && isOn) return;               /* push button: its time runs */
    set_pole(i, !isOn);
}
/* several poles one by one (step ms apart) */
static uint8_t stepOn, stepOff; static uint32_t stepAt;
static void steps(uint8_t onM, uint8_t offM) { stepOn = onM; stepOff = offM; stepAt = now(); }
static uint8_t stepping(void) { return stepOn | stepOff; }

/* ---------------- power-up motion (as the earlier program): the whites run 3 rounds, then all white ---------------- */
static void motion(void)
{
    static const uint8_t ORD[NP] = { 0, 1, 3, 5, 4, 2 };
    wh = 0; show(); _delay_ms(300);
    for (uint8_t r = 0; r < 3; r++)
        for (uint8_t k = 0; k < NP; k++) { wh = (uint8_t)(1 << ORD[k]); show(); _delay_ms(90); }
    wh = 0x3F; motionOn = 0; show();
}

int main(void)
{
    MCUCSR = _BV(JTD); MCUCSR = _BV(JTD);          /* JTAG off: PC2 (white of pole 6) free */
    DDRA = 0xFF; PORTA = 0; DDRB = 0xFF; PORTB = 0; DDRD = 0xFF; PORTD = 0;
    DDRC = 0x0F; PORTC = 0xF0;                      /* PC4..7 touch inputs (pull-ups) */
    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS01) | _BV(CS00);   /* 1 ms at 8 MHz */
    TIMSK = _BV(OCIE0);
    cfg_load();
    sei();
    motion();
    uint8_t last = 0xFF, held = 0xFF, done = 0;
    uint32_t keyAt = 0, exitAt = 0;
    uint32_t idleAt = now();
    for (;;) {
        uint32_t t = now();
        /* standby: 1 minute without a touch, every pole off, nothing running */
        if (!standby && !on && !exitRun && !stepping() && t - idleAt >= 60000) standby = 1;
        if (on || exitRun) idleAt = t;
        /* touch: the same code 30 ms in a row counts once; the next one after a release */
        uint8_t k = read_key();
        if (k != last) { last = k; keyAt = t; }
        else if (t - keyAt >= 30) {
            if (k == 0xFF) { held = 0xFF; done = 0; }
            else if (!done) {
                held = k; done = 1; idleAt = t;
                if (standby) { standby = 0; motion(); continue; }   /* the first touch wakes with startup motion */
                uint16_t xs = (uint16_t)(C.exitLo | C.exitHi << 8);
                if (exitRun) { }                               /* EXIT runs: no key works until it is done */
                else if (k == K_EXIT) { if (!stepping()) { exitRun = 1; exitAt = t + (uint32_t)xs * 1000UL; } }
                else {
                    if (stepping()) { }                        /* a master runs: wait */
                    else if (k == K_MASTER) {
                        uint8_t m = 0;
                        for (uint8_t i = 0; i < NP; i++) if (((C.mMask >> i) & 1) && C.type[i] != T_OFF) m |= (uint8_t)(1 << i);
                        if ((on & m) == m) steps(0, m); else steps((uint8_t)(m & ~on), 0);
                    }
                    else if (k < NP) touch_pole(k);
                }
            }
        }
        (void)held;
        /* EXIT time over: its poles off, one by one */
        if (exitRun == 1 && (int32_t)(t - exitAt) >= 0) { exitRun = 2; steps(0, (uint8_t)(C.xMask & on)); }
        if (exitRun == 2 && !stepping()) exitRun = 0;  /* the last pole is off: the panel works again */
        /* one step */
        if (stepping() && (int32_t)(t - stepAt) >= 0) {
            for (uint8_t i = 0; i < NP; i++) {
                if ((stepOn >> i) & 1) { stepOn &= (uint8_t)~(1 << i); set_pole(i, 1); break; }
                if ((stepOff >> i) & 1) { stepOff &= (uint8_t)~(1 << i); if ((on >> i) & 1) set_pole(i, 0); break; }
            }
            stepAt = t + C.stepMs;
        }
        /* timers */
        for (uint8_t i = 0; i < NP; i++) if (offAt[i] && (int32_t)(t - offAt[i]) >= 0) set_pole(i, 0);
        show();
    }
}
