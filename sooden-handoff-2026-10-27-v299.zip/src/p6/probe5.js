const H = require('./h'); const c = H(process.argv[2] || 'orig.hex');
const all = () => ['A','B','C','D'].map(p => (c.cpu.data[{A:0x3B,B:0x38,C:0x35,D:0x32}[p]]).toString(2).padStart(8,'0')).join(' ');
const st = [];let last=''; c.hook=()=>{const s=all(); if(s!==last){st.push((c.cpu.cycles/8000|0)+' '+s); last=s;}};
c.run(3000); console.log('boot', st.slice(-1)); st.length=0;
c.tap(6,400); c.run(1500); console.log('master', st.slice(-1)); st.length=0;
c.tap(1,400); c.run(25000); console.log(st.join('\n'));
