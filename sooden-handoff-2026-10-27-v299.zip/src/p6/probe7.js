const H = require('./h'); const c = H(process.argv[2] || 'orig.hex');
const all = () => ['A','B','C','D'].map(p => (c.cpu.data[{A:0x3B,B:0x38,C:0x35,D:0x32}[p]]).toString(2).padStart(8,'0')).join(' ');
c.run(3000); c.tap(3,300); c.run(500); console.log('pole1 on', all());
let last=all(), t0=c.cpu.cycles; c.hook=()=>{const s=all(); if(s!==last){console.log(((c.cpu.cycles-t0)/8000|0)+' '+s); last=s;}};
c.run(70000); c.hook=null; console.log('70s', all());
c.tap(4,300); c.run(500); console.log('touch pole2 in standby', all()); c.tap(4,300); c.run(500); console.log('again', all());
