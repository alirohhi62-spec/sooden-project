// 6-pole crystal network: settings from flash 0x7F00, RS485 frames on the UART
const fs = require('fs'), core = require('/home/claude/avrsim/cfgcore');
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const file = process.argv[2], room = +process.argv[3];
const m = core.parseHex(fs.readFileSync(file, 'utf8'));
const cfg = [0xA7, 1, 3, 5, 6, 1, 0, 1, 0, 3, 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 70, 0, 0x1F, 0x3F, 100, 0, room, /*pxLink*/ 0xFF, 0xFF, 0xFF, 2, 0xFF, 3];
cfg.forEach((v, i) => m.set(0x7F00 + i, v));
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/t6n.hex';
fs.writeFileSync(S, core.writeHex(m));
const c = require('./h')(S);
const u = new AVRUSART(c.cpu, { rxCompleteInterrupt: 26, dataRegisterEmptyInterrupt: 28, txCompleteInterrupt: 30,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x40, UBRRL: 0x29, UBRRH: 0x22, UDR: 0x2C }, 8000000);
// avr8js wipes the read-only UDRE bit when UCSRA is written; a real ATmega32 keeps it
{ const h = c.cpu.writeHooks[0x2B]; c.cpu.writeHooks[0x2B] = (v, o) => { const udre = c.cpu.data[0x2B] & 0x20; const r = h(v, o); c.cpu.data[0x2B] |= udre; return r; }; }
const tx = []; u.onByteTransmit = b => tx.push(b);
let n = 0, f = 0; const check = (ok, t) => { n++; if (!ok) f++; console.log((ok ? '  ok   ' : '  FAIL ') + t); };
c.run(3000);
tx.length = 0; c.tap(7, 200); c.run(200);
check(tx.length === 5 && tx[0] === 0xAA && tx[1] === room && tx[2] === 5 && tx[3] === 1 && tx[4] === (room ^ 5 ^ 1), 'pole 6 on -> frame ' + tx.map(x => x.toString(16)).join(' '));
check(c.o('B', 4) === 0, 'DE/RE back to receive');
const send = (r, p, s) => { for (const b of [0xAA, r, p, s, r ^ p ^ s]) { u.writeByte(b); c.run(3); } c.run(100); };
tx.length = 0; send(1 - room, 2, 1); check(c.red(3) === 1 && c.red(5) === 1, 'remote pole 3 on -> local poles 4 and 6 ' + c.state());
check(tx.length === 0, 'no echo of a change from the network (' + tx.length + ')');
send(1 - room, 2, 0); check(!c.red(3), 'remote pole 3 off -> local pole 4 off');
send(room, 2, 1); check(!c.red(3), 'frame from own room ignored');
for (const b of [0xAA, 1 - room, 2, 1, 0x55]) { u.writeByte(b); c.run(3); } c.run(100); check(!c.red(3), 'bad checksum ignored');
tx.length = 0; c.tap(6, 200); c.run(1000); check([0, 1, 2, 3].every(i => c.red(i)), 'master still works ' + c.state() + ' tx ' + tx.length);
console.log(`${n - f}/${n} passed`);
