const c = require('./h')('fw_6p.hex');
let n = 0, f = 0; const check = (ok, t) => { n++; if (!ok) f++; console.log((ok ? '  ok   ' : '  FAIL ') + t); };
const leds = () => [0, 1, 2, 3, 4, 5].map(i => '' + c.red(i) + c.white(i)).join(' ') + ' x' + c.o('C', 0) + c.o('A', 1);
c.run(3000); check(leds() === '01 01 01 01 01 01 x01', 'awake: whites on ' + leds());
c.run(58000); check(leds().endsWith('x01') && c.white(0) === 1, 'after 58 s still awake');
c.run(3000); check(leds() === '00 00 00 00 00 00 x00', 'after 1 minute: standby ' + leds());
// wake with motion: tap then run enough for motion to finish (~2s)
c.tap(6, 200); c.run(3000);
check(leds() === '01 01 01 01 01 01 x01', 'master touched: wakes with motion, all white ' + leds());
// next master touch: all on
c.tap(6, 200); c.run(1000);
check(c.red(0) && c.red(5), 'next master touch: all on');
// poles on: no standby
c.run(70000); check(c.red(0) === 1, 'poles on: no standby');
// turn off, wait for standby
c.tap(6, 200); c.run(1000); c.run(62000);
check(leds() === '00 00 00 00 00 00 x00', 'all off: standby after 1 min');
// wake with a pole touch
c.tap(3, 200); c.run(3000);
check(c.white(0) === 1 && !c.red(0), 'pole touched in standby: wakes with motion, no pole on');
c.tap(3, 200);
check(c.red(0) === 1, 'next touch works');
console.log(`${n - f}/${n} passed`);
