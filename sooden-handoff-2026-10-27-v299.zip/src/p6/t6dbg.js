// 6-pole Wi-Fi test build: the black box (@M_DBG live, @M_DBS saved 75 s after a join, kept over a power cut)
const fs = require('fs'), core = require('/home/claude/avrsim/cfgcore');
const { attachEsp } = require('/home/claude/avrsim/esp');
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/t6d.hex';
const m = core.parseHex(fs.readFileSync('fw_6p_wifi.hex', 'utf8'));
const cfg = [0xA7, 1, 1, 1, 5, 6, 0, 1, 3, 3, 4, 2, 3, 3, 5, 5, 5, 5, 5, 5, 3, 0, 0x3F, 0x3F, 100, 0, 0, 255, 255, 255, 255, 255, 255, 0];
while (cfg.length < 184) cfg.push(255);
cfg.forEach((v, i) => m.set(0x7F00 + i, v)); fs.writeFileSync(S, core.writeHex(m));
let n = 0, f = 0; const check = (ok, t) => { n++; if (!ok) f++; console.log((ok ? '  ok   ' : '  FAIL ') + t); };
function make(ee, opt) {
  const c = require('./h2')(S);
  if (ee) c.ee.memory.set(ee);
  c.u.onByteTransmit = null;
  const E = attachEsp({ b: { cpu: c.cpu, usart: c.u }, a: { D: { addListener: g => c.B.addListener(v => g(((v >> 4) & 1) << 5)) }, cpu: { data: { 0x31: 0x20 } } } }, opt);
  const steps = (ms, fn) => { for (let t = 0; t < ms; t += 20) { c.run(20); if (fn && fn()) return t + 20; } return -1; };
  return { c, E, steps };
}
let { c, E, steps } = make(null, { joinFail: true });
c.run(3000); c.touch(1); c.run(5600); c.release(); c.run(500); steps(12000, () => E.server);
let p = E.connect(0); steps(300);
const ask = (s, ms) => { p.rx.length = 0; E.send(0, s); steps(ms || 1500); return p.rx.join(''); };
let r = ask('@M_DBG');
check(/^\$DBG#R1B0E0J0W3P\dF\dQ\dC1S0A0I0\$\$DBL#.*\$/.test(r), 'live report before a join: ' + r);
ask('#AT+CWJAP="aramdaftar","2181517533a"#', 9000);
r = ask('@M_DBG');
check(/J1/.test(r) && /E1/.test(r) && /\+CWJAP:3/.test(r), 'after a failed join: 1 join, 1 FAIL, the module line +CWJAP:3 kept: ' + r);
r = ask('@M_DBS');
check(r.startsWith('$DBS#-$'), 'nothing saved yet: ' + r);
steps(80000);
r = ask('@M_DBS');
check(/^\$DBS#R1B0E1J1/.test(r) && /S1/.test(r) && /\$DBT#.*(CWJAP|FAIL|CWMODE)/.test(r), 'saved 75 s after the join: ' + r);
let tl = 0; for (let i = 0; i < 20; i++) { c.touch(4); c.run(150); c.release(); c.run(150); }
check(true, 'touches meanwhile fine');
const ee = Uint8Array.from(c.ee.memory);
({ c, E, steps } = make(ee, {}));
c.run(3000); steps(12000, () => E.server);
p = E.connect(0); steps(300);
r = ask('@M_DBS');
check(/^\$DBS#R1B0E1J1/.test(r), 'after a power cut the saved report is still there: ' + r);
console.log(`${n - f}/${n} passed`);
