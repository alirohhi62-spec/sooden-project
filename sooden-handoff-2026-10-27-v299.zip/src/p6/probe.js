const H = require('./h'); const c = H(process.argv[2] || 'orig.hex');
c.run(3000); console.log('after power-up', c.state());
for (const code of [0,1,2,3,4,5]) { c.tap(code, 400); c.run(1500); console.log('code', code, c.state()); }
c.tap(6, 400); c.run(3000); console.log('code6 (key?)', c.state());
c.tap(7, 400); c.run(3000); console.log('code7', c.state());
c.tap(7, 400); c.run(3000); console.log('code7 again', c.state());
