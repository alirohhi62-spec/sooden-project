// 6-pole: the router-join answer reaches the phone that connected again (the module changed channel)
const fs = require('fs'), core = require('/home/claude/avrsim/cfgcore');
const { attachEsp } = require('/home/claude/avrsim/esp');
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/t6j.hex';
const m = core.parseHex(fs.readFileSync('fw_6p_wifi.hex', 'utf8'));
const cfg = [0xA7, 1, 1, 1, 5, 6, 0, 1, 3, 3, 4, 2, 3, 3, 5, 5, 5, 5, 5, 5, 3, 0, 0x3F, 0x3F, 100, 0, 0, 255, 255, 255, 255, 255, 255, 0];
while (cfg.length < 184) cfg.push(255);
cfg.forEach((v, i) => m.set(0x7F00 + i, v)); fs.writeFileSync(S, core.writeHex(m));
let n = 0, f = 0; const check = (ok, t) => { n++; if (!ok) f++; console.log((ok ? '  ok   ' : '  FAIL ') + t); };
function make(opt) {
  const c = require('./h2')(S);
  c.u.onByteTransmit = null;
  const E = attachEsp({ b: { cpu: c.cpu, usart: c.u }, a: { D: { addListener: g => c.B.addListener(v => g(((v >> 4) & 1) << 5)) }, cpu: { data: { 0x31: 0x20 } } } }, opt);
  const steps = (ms, fn) => { for (let t = 0; t < ms; t += 20) { c.run(20); if (fn && fn()) return t + 20; } return -1; };
  c.run(3000); c.touch(1); c.run(5600); c.release(); c.run(500); steps(12000, () => E.server);
  return { c, E, steps };
}
let { E, steps } = make({ joinDrop: true });
let p0 = E.connect(0); steps(300); E.send(0, '@K'); steps(600);
E.send(0, '#AT+CWJAP="aramdaftar","2181517533a"#'); steps(6000);
const p1 = E.connect(1); steps(300); E.send(1, '@K');
let t = steps(3000, () => p1.rx.join('').includes('@M_S='));
check(t > 0 && p1.rx.join('').includes('@M_S=192.168.1.50'), 'phone connected again gets @M_S=192.168.1.50 ' + JSON.stringify(p1.rx.join('').slice(0, 60)));
({ E, steps } = make({ joinLate: 35000 }));
p0 = E.connect(0); steps(300); E.send(0, '@K'); steps(600);
E.send(0, '#AT+CWJAP="aramdaftar","2181517533a"#');
t = steps(45000, () => p0.rx.join('').includes('@M_S=192.168.1.50'));
check(p0.rx.join('').includes('@M_S=Error') && t > 0, 'Error first, then the late address');
({ E, steps } = make({ ipLag: 1500 }));
p0 = E.connect(0); steps(300); E.send(0, '@K'); steps(600);
E.send(0, '#AT+CWJAP="aramdaftar","2181517533a"#');
t = steps(15000, () => p0.rx.join('').includes('@M_S='));
check(t > 0 && p0.rx.join('').includes('@M_S=192.168.1.50'), 'address read 2 s after GOT IP: ' + JSON.stringify(p0.rx.join('').slice(-30)));
console.log(`${n - f}/${n} passed`);
