const H = require('./h'); const c = H(process.argv[2]||'orig.hex'); c.run(3000);
c.tap(3, 400); c.run(1000); console.log('pole1 on', c.state());
let t0 = c.cpu.cycles, last = c.state(), log = [];
c.hook = () => { const s = c.state(); if (s !== last) { log.push(((c.cpu.cycles - t0) / 8000 | 0) + 'ms ' + s); last = s; } };
c.tap(6, 400); c.run(2000); console.log(log.join('\n'));
c.tap(1,400); c.run(3000); c.tap(3,400); c.run(1000); console.log('touch during exit', c.state());
// power-up motion
const d = H(process.argv[2]||'orig.hex'); let l2 = d.state(), lg = []; d.hook = () => { const s = d.state(); if (s !== l2) { lg.push((d.cpu.cycles / 8000 | 0) + ' ' + s); l2 = s; } }; d.run(3000); console.log(lg.slice(0,8).join('\n'), '...', lg.length);
