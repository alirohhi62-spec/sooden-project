/* Sooden 6-pole crystal: ATmega32 @ 8 MHz external (fuses Low=DE, High=D1: EEPROM kept)
 *
 * Build:  -DVAR_REMOTE | -DVAR_WIFI | -DVAR_NET   (exactly one)
 *
 * Touch IC (coded): PC4 low = touched, code = PC5·4+PC6·2+PC7
 *   KEY[code]: 4,7,2,0,1,3,8,5  →  pole 0-5, EXIT(7), MASTER(8)
 *
 * Pole pins (same as 6-pole simple):
 *   pole 1 PB0/PA0, 2 PD6/PD7, 3 PB2/PB1, 4 PD4/PD5, 5 PA2/PA3, 6 PC1/PC2
 *   EXIT: red PC0, white PA1     MASTER: hardwired LED
 *
 * Remote RF:  PD3 (INT1), EV1527 24-bit, max 6 remotes
 * Buzzer:     PA6 (beep during exit countdown only)
 * Wi-Fi EN:   PB4                UART: PD0/PD1 (ESP or MAX485, never both)
 * Wi-Fi LED:  on the ESP module (no MCU pin)
 *
 * Settings in flash at 0x7F00 (written by the programmer, magic 0xA7); learned remotes in EEPROM.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <string.h>

#define NP 6
#define NREMOTE 6
enum { T_OFF=0, T_NORMAL=1, T_TIMER=3, T_DELOFF=5, T_PUSH=6 };

/* ---- settings the programmer writes in flash at 0x7F00 (erased = defaults) ----
 *   0 magic 0xA7, 1 ver, 2..7 type[6], 8..13 sec[6], 14..19 min[6], 20 exitLo, 21 exitHi,
 *   22 mMask, 23 xMask, 24 stepMs, 25 flags, 26 role A 0 / B 1 (network), 27..32 the other panel's key each pole follows (network, 0xFF none),
 *   33 remote places defined in the programmer (0 = no remote module),
 *   48..143 button table (place x code 0..15: bits 0..5 poles, bits 6..7 0 toggle / 1 only on / 2 only off; 0 = nothing),
 *   144..167 default timer choice (2 bits per place/button), 168..171 the 4 timer lengths (minutes),
 *   172..183 hold-timer flag per place/button (1 bit each), 184..186 / 187..189 (network) the other panel's keys of the master / EXIT
 * Remote = the 4-pole panel's way, for 6 places (one per pole):
 *   hold pole 1 5 s = learn: the white of pole 1 blinks 5 s; touching any pole N moves the blinking to pole N = place N;
 *   the remote button stores the remote there (white steady 2 s); without a touch: the first free place.
 *   hold pole 2 5 s + one more touch of pole 2 while it blinks = erase every remote.
 *   a place not defined in the programmer: A B C D (codes 1 2 4 8) = poles 1..4.
 *   hold timer (ticked in the programmer): hold the button 5 s (2 blinks) and release = its poles on, off after the chosen
 *   time; hold 15 s (2 more blinks), release, then press it 1..4 times = which of the 4 times (blinks back the number).
 *   recording for the programmer: 15 min after power-up every new code goes to EEPROM 0xB0 (100 codes, a ring).
 * EEPROM (the programmer never writes it): places 3 copies at 0x10/0x50/0x90 [0x60, 6 x id, crc8],
 *   timer choice 3 copies at 0x30/0x70/0x1E0 [0x61, 24 bytes, crc8], recording 0xB0 [0xB5, next, count, 100 x code] */
#define CF_MAGIC_VAL 0xA7
#define CF_ROOM   26
#define CF_PXLINK 27
#define CF_NSLOT  33
#define CF_RMAP   48
#define CF_TDEF   144
#define CF_TMIN   168
#define CF_RTF    172
#define CF_SIZE   256            /* 192..207: Wi-Fi network name (empty = sooden- + 4 hex of the module's MAC) */
const uint8_t cfg_flash[CF_SIZE] __attribute__((section(".p6cfg"), used)) = { [0 ... CF_SIZE - 1] = 0xFF };
static uint8_t cf_byte(uint8_t a){ return pgm_read_byte(&cfg_flash[a]); }
static uint8_t has_cf(void){ return cf_byte(0) == CF_MAGIC_VAL; }

/* ---- config RAM ---- */
static uint8_t ptype[NP], psec[NP], pmin[NP];
static uint8_t exitLo, exitHi, mMask, xMask, stepMs;
static uint32_t rmId[NREMOTE];     /* 0 = empty place */
static uint8_t nslot, rmOn;        /* places with a table from the programmer; remote module fitted */
static uint8_t tsel[NREMOTE*4];    /* timer length chosen per place/button, 2 bits each */
static uint8_t tmin[4];
enum { M_NORMAL=0, M_LEARN, M_ERASE, M_OK, M_TSET };
static uint8_t mode, modePole, lslot;
static uint32_t modeAt;
/* button table entry of place k, code c */
static uint8_t rm_entry(uint8_t k, uint8_t c)
{
    if (!has_cf() || k >= nslot) return c==1?0x01:c==2?0x02:c==4?0x04:c==8?0x08:0;
    uint8_t e = cf_byte((uint8_t)(CF_RMAP + k*16 + c));
    return e == 0xFF ? 0 : e;
}
static uint8_t rm_timer(uint8_t k, uint8_t c)
{
    if (!has_cf() || k >= nslot) return 0;
    uint8_t n=(uint8_t)(k*16+c), b=cf_byte((uint8_t)(CF_RTF + (n>>3)));
    return b != 0xFF && ((b >> (n & 7)) & 1);
}

/* ---- EEPROM blocks, 3 copies: [magic, data..., crc8]; a damaged copy is repaired (as the 4-pole panel) ---- */
static uint8_t crc8(const uint8_t *p, uint8_t n)
{
    uint8_t c=0;
    while(n--){ c^=*p++; for(uint8_t i=0;i<8;i++) c=(c&0x80)?(uint8_t)((c<<1)^0x07):(uint8_t)(c<<1); }
    return c;
}
static void blk_save(uint8_t *b, uint8_t len, const uint16_t *base)
{
    b[len-1]=crc8(b,(uint8_t)(len-1));
    for(uint8_t c=0;c<3;c++) eeprom_update_block(b,(void*)base[c],len);
}
static uint8_t blk_load(uint8_t *b, uint8_t len, const uint16_t *base, uint8_t magic)
{
    for(uint8_t c=0;c<3;c++){
        eeprom_read_block(b,(const void*)base[c],len);
        if(b[0]==magic && crc8(b,(uint8_t)(len-1))==b[len-1]){ blk_save(b,len,base); return 1; }
    }
    return 0;
}
#define EE_LEN   (2 + NREMOTE*3)
#define EE_TSLEN (2 + NREMOTE*4)
static const uint16_t ee_base[3]={0x10,0x50,0x90}, ts_base[3]={0x30,0x70,0x1E0};
#define EE_REC 0xB0
#define EE_RECMAGIC 0xB5
#define EE_RECN 100

static void cfg_load(void)
{
    if (has_cf()) {
        for (uint8_t i=0;i<NP;i++){ ptype[i]=cf_byte(2+i); psec[i]=cf_byte(8+i); pmin[i]=cf_byte(14+i); }
        exitLo=cf_byte(20); exitHi=cf_byte(21); mMask=cf_byte(22); xMask=cf_byte(23); stepMs=cf_byte(24);
        if(!stepMs || stepMs==0xFF) stepMs=100;
        nslot=cf_byte(CF_NSLOT); if(nslot>NREMOTE) nslot=NREMOTE;
        rmOn=nslot!=0;
        for(uint8_t i=0;i<4;i++){ tmin[i]=cf_byte(CF_TMIN+i); if(tmin[i]==0xFF) tmin[i]=0; }
        for(uint8_t i=0;i<sizeof tsel;i++){ uint8_t v=cf_byte(CF_TDEF+i); tsel[i]=v==0xFF?0:v; }
    } else {
        for (uint8_t i=0;i<NP;i++){ptype[i]=T_NORMAL;psec[i]=3;pmin[i]=5;}
        exitLo=20; exitHi=0; mMask=0x3F; xMask=0x3F; stepMs=100; nslot=0; rmOn=1;
        tmin[0]=10; tmin[1]=30; tmin[2]=90; tmin[3]=180; memset(tsel,0,sizeof tsel);
    }
    memset(rmId,0,sizeof rmId);
    uint8_t b[EE_TSLEN > EE_LEN ? EE_TSLEN : EE_LEN];
    if (blk_load(b,EE_LEN,ee_base,0x60))
        for(uint8_t i=0;i<NREMOTE;i++){
            uint32_t v=((uint32_t)b[1+i*3]<<16)|((uint32_t)b[2+i*3]<<8)|b[3+i*3];
            rmId[i]=v==0xFFFFFFUL?0:v;
        }
    if (blk_load(b,EE_TSLEN,ts_base,0x61)) memcpy(tsel,b+1,sizeof tsel);
}

/* the learned remotes (one per place) */
static void cfg_save(void)
{
    uint8_t b[EE_LEN];
    b[0]=0x60;
    for(uint8_t i=0;i<NREMOTE;i++){
        uint32_t v=rmId[i]?rmId[i]:0xFFFFFFUL;
        b[1+i*3]=(uint8_t)(v>>16); b[2+i*3]=(uint8_t)(v>>8); b[3+i*3]=(uint8_t)v;
    }
    blk_save(b,EE_LEN,ee_base);
}
static void tsel_save(void)
{
    uint8_t b[EE_TSLEN];
    b[0]=0x61; memcpy(b+1,tsel,sizeof tsel);
    blk_save(b,EE_TSLEN,ts_base);
}
static uint8_t tsel_get(uint8_t k, uint8_t c){ uint8_t n=(uint8_t)(k*16+c); return (uint8_t)((tsel[n>>2]>>((n&3)*2))&3); }

/* recording for the programmer: after power-up, 15 min, every new code in the order received */
static uint8_t logOn;
static uint32_t logged;
static void log_code(uint32_t code, uint32_t t)
{
    if(!logOn || code==logged || t>=900000UL) return;
    logged=code;
    uint8_t next=0, count=0;
    if(eeprom_read_byte((const uint8_t*)EE_REC)==EE_RECMAGIC){
        next=eeprom_read_byte((const uint8_t*)EE_REC+1); count=eeprom_read_byte((const uint8_t*)EE_REC+2);
        if(next>=EE_RECN || count>EE_RECN) next=count=0;
    }
    uint16_t a=EE_REC+3+next*3;
    eeprom_update_byte((uint8_t*)a,(uint8_t)(code>>16)); eeprom_update_byte((uint8_t*)a+1,(uint8_t)(code>>8)); eeprom_update_byte((uint8_t*)a+2,(uint8_t)code);
    if(++next>=EE_RECN) next=0;
    if(count<EE_RECN) count++;
    eeprom_update_byte((uint8_t*)EE_REC+1,next); eeprom_update_byte((uint8_t*)EE_REC+2,count); eeprom_update_byte((uint8_t*)EE_REC,EE_RECMAGIC);
}

/* ---- pin map ---- */
static volatile uint8_t *const RPORT[NP]={&PORTB,&PORTD,&PORTB,&PORTD,&PORTA,&PORTC};
static const uint8_t RBIT[NP]={0,6,2,4,2,1};
static volatile uint8_t *const WPORT[NP]={&PORTA,&PORTD,&PORTB,&PORTD,&PORTA,&PORTC};
static const uint8_t WBIT[NP]={0,7,1,5,3,2};
static void pin(volatile uint8_t *p,uint8_t b,uint8_t v){if(v)*p|=(uint8_t)(1<<b);else *p&=(uint8_t)~(1<<b);}

#ifdef VAR_NET
static uint8_t txMask;                             /* our keys not yet reported to the other panel (network) */
#endif

/* ---- state ---- */
static uint8_t on, wh=0x3F, blinkMask, exitRun;
static uint8_t blkN; static uint32_t blkAt;
static volatile uint32_t ms;
static uint8_t motionOn=1, standby;
static uint16_t buzCnt;  /* buzzer ms remaining */

ISR(TIMER0_COMP_vect){ ms++; if(buzCnt) buzCnt--; }
static uint32_t now(void){uint32_t v;cli();v=ms;sei();return v;}

static void show(void)
{
    uint8_t bl=(now()/250)&1;
    for(uint8_t i=0;i<NP;i++){
        pin(RPORT[i],RBIT[i],(on>>i)&1);
        uint8_t w=standby?0:(wh>>i)&1;
        if((blinkMask>>i)&1) w=bl;
        if(i==modePole){                         /* remote learn / erase: this white blinks; stored: steady 2 s */
            if(mode==M_LEARN||mode==M_ERASE) w=(uint8_t)(((now()-modeAt)/250)&1)?0:1;
            else if(mode==M_OK) w=1;
        }
        pin(WPORT[i],WBIT[i],w);
    }
    uint8_t dark=0;
    if(blkN){                                    /* confirmation: every white goes dark N times (buzzer too) */
        uint32_t ph=(now()-blkAt)/200;
        if(ph>=2u*blkN) blkN=0; else if(!(ph&1)) dark=1;
    }
    if(dark) for(uint8_t i=0;i<NP;i++) pin(WPORT[i],WBIT[i],0);
    pin(&PORTC,0,exitRun!=0);
    pin(&PORTA,1,exitRun==0&&!motionOn&&!standby&&!dark);
    pin(&PORTA,6,buzCnt>0||dark);
}

/* ---- touch ---- */
static const uint8_t KEY[8] PROGMEM={4,7,2,0,1,3,8,5};
#define K_EXIT 7
#define K_MASTER 8
static uint8_t read_key(void)
{
    uint8_t p=PINC;
    if(p&_BV(4)) return 0xFF;
    uint8_t c=(uint8_t)(((p>>5)&1)<<2|((p>>6)&1)<<1|((p>>7)&1));
    return pgm_read_byte(&KEY[c]);
}

/* ---- poles ---- */
static uint32_t offAt[NP];
static void set_pole(uint8_t i,uint8_t v)
{
    if(ptype[i]==T_OFF) return;
    if(v){on|=(uint8_t)(1<<i);wh&=(uint8_t)~(1<<i);}
    else {on&=(uint8_t)~(1<<i);wh|=(uint8_t)(1<<i);}
    blinkMask&=(uint8_t)~(1<<i); offAt[i]=0;
    if(v&&ptype[i]==T_TIMER) offAt[i]=now()+(uint32_t)pmin[i]*60000UL;
    if(v&&ptype[i]==T_PUSH)  offAt[i]=now()+(uint32_t)(psec[i]?psec[i]:1)*1000UL;
#ifdef VAR_NET
    txMask|=(uint8_t)(1<<i);                       /* every change goes to the other panel */
#endif
    show();
}
static void touch_pole(uint8_t i)
{
    uint8_t t=ptype[i],isOn=(on>>i)&1;
    if(t==T_OFF) return;
    if(t==T_DELOFF&&isOn){
        if((blinkMask>>i)&1){blinkMask&=(uint8_t)~(1<<i);offAt[i]=0;}
        else{blinkMask|=(uint8_t)(1<<i);offAt[i]=now()+(uint32_t)(psec[i]?psec[i]:1)*1000UL;}
        return;
    }
    if(t==T_PUSH&&isOn) return;
    set_pole(i,!isOn);
}

/* ---- stepping ---- */
static uint8_t stepOn,stepOff; static uint32_t stepAt;
static void steps(uint8_t onM,uint8_t offM){stepOn=onM;stepOff=offM;stepAt=now();}
static uint8_t stepping(void){return stepOn|stepOff;}

/* ---- motion (3 rounds white LED chase) ---- */
static void motion(void)
{
    static const uint8_t ORD[NP]={0,1,3,5,4,2};
    wh=0; show(); _delay_ms(300);
    for(uint8_t r=0;r<3;r++)
        for(uint8_t k=0;k<NP;k++){wh=(uint8_t)(1<<ORD[k]);show();_delay_ms(90);}
    wh=0x3F; motionOn=0; show();
}

/* ---- RF 433 EV1527 decoder (INT1 on PD3, Timer1 @ 1 µs/tick) ---- */
static volatile uint32_t rfCode;
static volatile uint8_t  rfNew;
static uint16_t rfHi, rfT;
static uint32_t rfAcc, rfPrev;
static uint8_t  rfBits, rfOn;

ISR(INT1_vect)
{
    uint16_t tc=TCNT1; static uint16_t last;
    uint16_t dt=tc-last; last=tc;
    uint8_t level=(PIND>>3)&1;  /* state AFTER edge */

    if(!level){ rfHi=dt; return; }  /* falling: high segment ended, store its width */

    /* rising: low segment ended */
    uint16_t hi=rfHi, lo=dt;

    /* sync detection */
    if(hi>=100 && hi<=1200 && lo>=hi*18u && lo<=hi*45u && lo>=3000){
        rfT=lo/31; rfBits=0; rfAcc=0; rfOn=1; return;
    }
    if(!rfOn) return;

    /* data bit */
    uint16_t T=rfT, sh, lg; uint8_t bit;
    if(hi>lo){bit=1;sh=lo;lg=hi;} else{bit=0;sh=hi;lg=lo;}
    if(sh<T/2||sh>T*2||lg<T*2||lg>T*5){rfOn=0;return;}
    rfAcc=(rfAcc<<1)|bit;
    if(++rfBits==24){
        rfOn=0;
        if(rfAcc==rfPrev){rfCode=rfAcc;rfNew=1;}
        rfPrev=rfAcc;
    }
}

/* ---- remote handling ---- */
static uint8_t remote_find(uint32_t id)
{
    for(uint8_t i=0;i<NREMOTE;i++) if(rmId[i]==id) return i;
    return 0xFF;
}

static uint8_t first_free(void)
{
    for(uint8_t i=0;i<NREMOTE;i++) if(!rmId[i]) return i;
    return 0xFF;
}
static void rm_mode(uint8_t m, uint8_t pole){ mode=m; modePole=pole; modeAt=now(); }
static void blink(uint8_t n){ blkN=n; blkAt=now(); }
/* put a remote into a place; the same remote is never kept in two places */
static void rm_store(uint8_t slot, uint32_t id)
{
    for(uint8_t i=0;i<NREMOTE;i++) if(rmId[i]==id) rmId[i]=0;
    rmId[slot]=id;
    cfg_save();
}

/* remote hold timer (as the 4-pole panel) */
static uint8_t hOn, hK, hC, hStage, tsK, tsC, tsN, rtMask;
static uint32_t hAt, tsAt, rtSecAt;
static uint16_t rtSec[NP];
static void rt_start(uint8_t k, uint8_t c)
{
    uint8_t mn=tmin[tsel_get(k,c)], m=(uint8_t)(rm_entry(k,c)&0x3F), n=0;
    if(!mn) return;
    for(uint8_t i=0;i<NP;i++){
        if(!((m>>i)&1) || ptype[i]!=T_NORMAL) continue;
        n|=(uint8_t)(1<<i); rtMask|=(uint8_t)(1<<i); rtSec[i]=(uint16_t)mn*60;
    }
    steps((uint8_t)(n&~on),0);
}

static uint32_t lastRf, lastRfAt;
static void rt_tick(void)
{
    uint32_t t=now();                            /* own time: rf_process may have stamped later than the loop's t */
    if(hOn){
        if((int32_t)(t-lastRfAt)>=400){                                     /* button released */
            hOn=0;
            if(hStage==1) rt_start(hK,hC);
            else if(hStage==2){ mode=M_TSET; tsK=hK; tsC=hC; tsN=0; tsAt=t; }
        } else if(hStage<2 && (int32_t)(t-hAt)>=(hStage?15000L:5000L)){ hStage++; blink(2); }
    }
    if(mode==M_TSET && (int32_t)(t-tsAt)>=10000){                /* 10 s after the last press */
        if(tsN){
            uint8_t n=(uint8_t)(tsK*16+tsC), sh=(uint8_t)((n&3)*2);
            tsel[n>>2]=(uint8_t)((tsel[n>>2]&~(3<<sh))|((tsN-1)<<sh));
            tsel_save();
            blink(tsN);
        }
        mode=M_NORMAL;
    }
    uint8_t sec=0;
    if((int32_t)(t-rtSecAt)>=1000){ rtSecAt+=1000; if((int32_t)(t-rtSecAt)>=1000) rtSecAt=t; sec=1; }
    for(uint8_t i=0;i<NP;i++){
        if(!((rtMask>>i)&1)) continue;
        if(!((on>>i)&1) && !((stepOn>>i)&1)) rtMask&=(uint8_t)~(1<<i);   /* switched off by hand: timer cancelled */
        else if(sec && !--rtSec[i]){ rtMask&=(uint8_t)~(1<<i); if((on>>i)&1) set_pole(i,0); }
    }
}

static void rf_process(void)
{
    if(!rfNew) return;
    uint32_t code; cli(); code=rfCode; rfNew=0; sei();
    uint32_t t=now();
    if(code==lastRf && t-lastRfAt<400){ lastRfAt=t; return; }   /* the same press repeats: once */
    lastRf=code; lastRfAt=t;
    if(!rmOn) return;
    log_code(code,t);
    uint32_t id=code&0xFFFFF0UL;
    uint8_t btn=(uint8_t)(code&0x0F);
    if(mode==M_LEARN){
        if(lslot==0xFF) return;                  /* every place is used and none was chosen */
        rm_store(lslot,id);
        rm_mode(M_OK,lslot);
        return;
    }
    uint8_t k=remote_find(id);
    if(mode==M_ERASE || k==0xFF) return;
    if(exitRun) return;
    if(mode==M_TSET){                            /* choosing the timer length: count presses of that button */
        if(k==tsK && btn==tsC){ if(tsN<4) tsN++; tsAt=t; blink(1); }
        return;
    }
    uint8_t e=rm_entry(k,btn), m=(uint8_t)(e&0x3F), act=(uint8_t)(e>>6);
    if(!m) return;
    if(mode==M_OK) mode=M_NORMAL;
    standby=0;
    if(rm_timer(k,btn)){ hOn=1; hK=k; hC=btn; hAt=t; hStage=0; }   /* watch for a long hold */
    if(stepping()) return;
    if(!(m&(m-1))){                              /* one pole */
        uint8_t i=0; while(!((m>>i)&1)) i++;
        if(ptype[i]!=T_NORMAL){ touch_pole(i); return; }   /* service / delayed off / push: like a touch */
        set_pole(i, act==1?1:act==2?0:(uint8_t)!((on>>i)&1));
        return;
    }
    /* several poles (normal poles only): toggle = like a master, or only on / only off */
    uint8_t n=0;
    for(uint8_t i=0;i<NP;i++) if(((m>>i)&1)&&ptype[i]==T_NORMAL) n|=(uint8_t)(1<<i);
    uint8_t v=act==1?1:act==2?0:(uint8_t)!(on&n);
    if(v) steps((uint8_t)(n&~on),0); else steps(0,(uint8_t)(n&on));
}

/* ---- buzzer helper ---- */
static void buz(uint16_t ms_dur){ buzCnt=ms_dur; }

#ifdef VAR_NET
/* ---- two-panel network v2: the same RS485 protocol as every other Sooden panel (sw.c HAS_PX) ----
 * USART PD0/PD1, 9600 8N1, auto-direction RS485 module (a 0xFF lead-in byte before every frame).
 * frame [A5][role 0/1][type][seq][d][crc8]: F_ST my key changed (acked), F_SET switch your key (acked),
 * F_PRESS touch your key (phone app through the other panel), F_ACK, F_HELLO (start), F_FULL (8 keys a chunk).
 * Our keys on the line: 0..5 poles, 6 EXIT (on = running), 7 master. Settings (programmer, flash):
 * 26 role (A 0 / B 1; 0xFF = alone: the line stays silent), 27..32 the other panel's key each pole follows (0xFF none),
 * 184..186 its keys the master also switches, 187..189 its keys EXIT also switches off (bit p of byte p >> 3). */
#define F_SOF   0xA5
#define F_ACK   2
#define F_HELLO 4
#define F_FULL  5
#define F_ST    6
#define F_SET   7
#define F_PRESS 8
#define FULL_APPLY 0x80
#define T_ACK     150
#define T_TURN    15
#define N_RETRY   4
#define T_PING    1000
#define T_OFFLINE 3500
#define CF_MPEER  184
#define CF_XPEER  187
static uint8_t nRole, netOn, nLink[NP], mPeer[3], xPeer[3];   /* netOn: programmed as panel A or B of a pair */
static uint8_t pst[3], sMask[3], sVal[3];            /* the other panel's keys; our commands to it not yet sent */
static uint8_t seq, outActive, outKind, outPole, outVal, outSeq, outTries, ackDue, ackSeq, online, helloDone, fullN, fullC, synced, pressSeq=0xFF;
static uint16_t nextWait, ackWait, outMs, txMs, peerMs, jit;
static uint8_t rxMs, rxn, rxf[6], lastExit;
static uint32_t linkNow;
static uint16_t rndS=0x1D2B;
static uint16_t rnd(void){ rndS^=(uint16_t)(rndS<<7); rndS^=(uint16_t)(rndS>>9); rndS^=(uint16_t)(rndS<<8); return rndS; }

#define RXBUFSZ 32
static volatile uint8_t rxBuf[RXBUFSZ];
static volatile uint8_t rxWr, rxRd;
ISR(USART_RXC_vect){ rxBuf[rxWr&(RXBUFSZ-1)]=(uint8_t)UDR; rxWr++; }
static void tx_byte(uint8_t c){ while(!(UCSRA&_BV(UDRE))); UDR=c; }

static void bset(uint8_t *a, uint8_t p, uint8_t v){ uint8_t b=(uint8_t)(1<<(p&7)); if(v) a[p>>3]|=b; else a[p>>3]&=(uint8_t)~b; }
static uint8_t bget(const uint8_t *a, uint8_t p){ return (uint8_t)((a[p>>3]>>(p&7))&1); }
/* the other panel's keys as they are, or are about to be (our commands not yet sent) */
static uint8_t px_tb(uint8_t j){ return (uint8_t)((pst[j]&(uint8_t)~sMask[j])|(sVal[j]&sMask[j])); }
static void px_q(const uint8_t *m, uint8_t v){ for(uint8_t j=0;j<3;j++){ sMask[j]|=m[j]; if(v) sVal[j]|=m[j]; else sVal[j]&=(uint8_t)~m[j]; } }
static uint8_t px_all_on(const uint8_t *m){ for(uint8_t j=0;j<3;j++) if((px_tb(j)&m[j])!=m[j]) return 0; return 1; }

static void net_init(void)
{
    UCSRA=0; UBRRH=0; UBRRL=51;                     /* 9600 at 8 MHz */
    UCSRB=_BV(RXEN)|_BV(TXEN)|_BV(RXCIE);
    UCSRC=_BV(URSEL)|_BV(UCSZ1)|_BV(UCSZ0);
    nRole=cf_byte(CF_ROOM); netOn=has_cf() && nRole<=1; if(nRole>1) nRole=0;
    for(uint8_t i=0;i<NP;i++){ nLink[i]=cf_byte(CF_PXLINK+i); if(nLink[i]>22) nLink[i]=0xFF; }
    for(uint8_t j=0;j<3;j++){ mPeer[j]=cf_byte(CF_MPEER+j); xPeer[j]=cf_byte(CF_XPEER+j); }
    if(!has_cf()){ memset(nLink,0xFF,NP); memset(mPeer,0,3); memset(xPeer,0,3); }
    if(mPeer[0]==0xFF && mPeer[1]==0xFF && mPeer[2]==0xFF) memset(mPeer,0,3);
    if(xPeer[0]==0xFF && xPeer[1]==0xFF && xPeer[2]==0xFF) memset(xPeer,0,3);
    rndS^=(uint16_t)(nRole?0x5A3C:0x1357);
    linkNow=now();
}
static void send(uint8_t type, uint8_t sq, uint8_t d)
{
    uint8_t f[6]={F_SOF,nRole,type,sq,d,0};
    f[5]=crc8(f+1,4);
    tx_byte(0xFF);                                  /* lead-in: lets the auto-direction module and the far receiver settle */
    for(uint8_t i=0;i<6;i++) tx_byte(f[i]);
    txMs=0;
}
static uint8_t net_any(void){ return netOn; }    /* alone (single panel): the line stays silent */
static uint8_t my_chunk(void){ return (uint8_t)((on&0x3F)|(exitRun?0x40:0)); }
static uint8_t my_key(uint8_t k){ return k<NP?(uint8_t)((on>>k)&1):k==6?(uint8_t)(exitRun!=0):0; }
/* the other panel's key p is v: our poles linked to it follow (follow 1: it changed - A keeps its own change still on the way;
   follow 2: a chunk of A's keys - our change still on the way is not undone) */
static void px_peer(uint8_t p, uint8_t v, uint8_t follow)
{
    bset(pst,p,v);
    if(!follow) return;
    for(uint8_t k=0;k<NP;k++){
        if(nLink[k]!=p) continue;
        if(((txMask>>k)&1) && (nRole==0 || follow==2)) continue;
        if(((on>>k)&1)!=v) set_pole(k,v);
    }
}
static uint8_t start_exit(void);
static void master_key(void);
static void net_rx(uint8_t b)
{
    if(rxn && rxMs>10) rxn=0;                       /* gap > 10 ms: resync */
    rxMs=0;
    if(rxn==0 && b!=F_SOF) return;
    rxf[rxn++]=b;
    if(rxn<6) return;
    rxn=0;
    if(crc8(rxf+1,4)!=rxf[5]) return;
    if(rxf[1]>1 || rxf[1]==nRole) return;           /* own echo, a room frame or garbage */
    peerMs=0; online=1;
    if(nextWait<T_TURN) nextWait=T_TURN;
    uint8_t sq=rxf[3], d=rxf[4], k=(uint8_t)(d&0x7F), v=(uint8_t)(d>>7);
    switch(rxf[2]){
    case F_ST: case F_SET: case F_PRESS:
        ackSeq=sq; ackDue=1; ackWait=T_TURN;
        if(rxf[2]==F_ST){ if(k<23) px_peer(k,v,1); }
        else if(rxf[2]==F_SET){ if(k<NP && !exitRun) set_pole(k,v); }
        else if(sq!=pressSeq){                       /* a touch only once (a repeat: our ACK was lost) */
            pressSeq=sq; standby=0;
            if(!exitRun && mode!=M_LEARN && mode!=M_ERASE){
                if(k<NP){ if(!stepping()) touch_pole(k); }
                else if(k==6) start_exit();
                else if(k==7) master_key();
            }
        }
        break;
    case F_ACK:
        if(outActive && sq==outSeq){
            outActive=0; outTries=0;
            if(outKind==0){ if(my_key(outPole)==outVal) txMask&=(uint8_t)~(1<<outPole); }
            else { if(bget(sVal,outPole)==outVal) bset(sMask,outPole,0); bset(pst,outPole,outVal); }
            nextWait=5;
        }
        break;
    case F_HELLO: fullN=1; pressSeq=0xFF; if(nextWait<T_TURN) nextWait=T_TURN; break;
    case F_FULL: {
        uint8_t c=(uint8_t)(sq&0x7F), apply=(sq&FULL_APPLY)!=0;
        if(c>2) break;
        if(apply) synced=1;
        for(uint8_t j=0;j<8;j++){
            uint8_t p=(uint8_t)(c*8+j);
            if(p>=23) break;
            uint8_t pv=(d>>j)&1;
            if(bget(sMask,p)){ bset(pst,p,pv); continue; }
            px_peer(p,pv,apply?2:0);
        }
        break;
    }
    default: break;
    }
}
static void net_tick(void)
{
    while(rxRd!=rxWr){ uint8_t c=rxBuf[rxRd&(RXBUFSZ-1)]; rxRd++; net_rx(c); }
    { uint8_t e=exitRun!=0; if(e!=lastExit){ lastExit=e; txMask|=0x40; } }
    if(!net_any()) return;                          /* no key linked and no scenario reaching the other panel: silent */
    {
        uint32_t t=now(), d=t-linkNow; uint16_t dt=d>60000UL?60000:(uint16_t)d;
        linkNow=t;
        nextWait=nextWait>dt?(uint16_t)(nextWait-dt):0;
        ackWait=ackWait>dt?(uint16_t)(ackWait-dt):0;
        outMs=outMs+dt<60000U?(uint16_t)(outMs+dt):60000U;
        txMs=txMs+dt<60000U?(uint16_t)(txMs+dt):60000U;
        peerMs=peerMs+dt<60000U?(uint16_t)(peerMs+dt):60000U;
        rxMs=rxMs+dt<250?(uint8_t)(rxMs+dt):250;
    }
    if(!helloDone && !nextWait){ helloDone=1; send(F_HELLO,0,0); nextWait=20; return; }
    if(online && peerMs>=T_OFFLINE) online=0;
    if(ackDue && !ackWait){ ackDue=0; send(F_ACK,ackSeq,0); if(nextWait<T_TURN) nextWait=T_TURN; return; }
    if(outActive){
        if(outMs<T_ACK) return;
        outActive=0;
        if(++outTries>=N_RETRY){ online=0; outTries=0; nextWait=500; }
        else nextWait=(uint16_t)(15+(rnd()&63)+(nRole?25:0));
        return;
    }
    if(nextWait) return;
    if(fullN){ fullN=0; send(F_FULL,(uint8_t)(0|FULL_APPLY),my_chunk()); nextWait=10; return; }   /* answer to HELLO */
    uint8_t anyS=(uint8_t)(sMask[0]|sMask[1]|sMask[2]);
    if(online && (anyS || txMask)){
        uint8_t kind, p=0;
        if(anyS){ kind=1; while(!bget(sMask,p)) p++; }
        else { kind=0; while(!((txMask>>p)&1)) p++; }
        uint8_t v=kind?bget(sVal,p):my_key(p);
        if(kind!=outKind || p!=outPole || v!=outVal) outTries=0;
        outKind=kind; outPole=p; outVal=v; outSeq=++seq;
        send(kind?F_SET:F_ST,outSeq,(uint8_t)(p|(v<<7)));
        outActive=1; outMs=0;
        return;
    }
    if(txMs>=T_PING+jit){
        jit=rnd()&255;
        if(nRole==0 && !synced) send(F_HELLO,0,0);
        else { fullC=0; send(F_FULL,(uint8_t)(0|(nRole==0?FULL_APPLY:0)),my_chunk()); }
        nextWait=10;
    }
}
#endif

/* ---- EXIT (key 7) ---- */
static uint32_t exitAt;
static uint8_t start_exit(void)
{
    uint16_t xs=(uint16_t)(exitLo|exitHi<<8);
    if(exitRun || stepping() || !xs) return 0;
    exitRun=1; exitAt=now()+(uint32_t)xs*1000UL; buz(100);
    return 1;
}
static void master_key(void)
{
    if(stepping()) return;
    uint8_t m=0;
    for(uint8_t i=0;i<NP;i++) if(((mMask>>i)&1)&&ptype[i]!=T_OFF) m|=(uint8_t)(1<<i);
#ifdef VAR_NET
    uint8_t allOn=(on&m)==m && px_all_on(mPeer);   /* the other panel's keys in the master count too */
    if(allOn){ steps(0,m); px_q(mPeer,0); } else { steps((uint8_t)(m&~on),0); px_q(mPeer,1); }
#else
    if((on&m)==m) steps(0,m); else steps((uint8_t)(m&~on),0);
#endif
}

#ifdef VAR_WIFI
/* ---- Wi-Fi: the 23-key board's way (wifi64.c), for the 6 poles + EXIT + master ----
 * ESP8266 AT firmware on the USART (PD0 RXD / PD1 TXD), 9600 8N1, powered while PB4 is high.
 * Wi-Fi off at the first power-up; holding key 7 (EXIT) 5 s turns it on / off (2 blinks on, 1 blink off), the last
 * state is kept over a power cut (EEPROM 0x370). Key 7 runs EXIT when the finger is lifted.
 * ESP start-up: AT+CWMODE=3, AT+CWSAP="sooden","sooden123",1,3 (first time only), AT+CIPMUX=1, AT+CIPSERVER=1,6269,
 * AT+CIFSR; "ready" from the ESP starts it all again.
 * Phone app (TCP 6269, up to 5 phones), the same messages as the 23-key board:
 *   @M_IP -> %mac(17)+ip(16)+router name(20)%     @M_F_C -> #T     @M_F_T -> #T*A1/Uaaaaaaaaaa/Vp1*L+#X1*Z1++
 *   @M_MDL -> $MDL=SD23-p6-1.0$   @M_LAY -> $LAY#<23 letters>$ (keys 1..6 poles, 7 EXIT, 8 master)
 *   @M_CAP -> $CAP#A0R<0/1>W1S0C1V0$ (no alarm, no phone scenarios, no vacation; key settings yes)
 *   @K -> $K#xxxxxx$ (pushed by itself on every change)   &K#nn -> $A#nn#1|0$
 *   Lbl#nn#ii~text# -> ok   @M_LBL#nn -> $Lnn#ii~text$   @M_CF#nn -> $CF#nn#type#sec1#sec2#min#on#off#left$
 *   Set#nn#f#hex# -> $CF#...$ or $SET#nn#no$ (1 delayed-off s, 2 push s, M service min, T EXIT s, O master poles)
 *   Set#RS# -> back to the programmed settings   #AT+CWJAP="router","password"#   *AT+CWSAP="name","password",1,4* */
#define NCONN 5
#define EE_WIFI   0x370      /* 0x5A: Wi-Fi on */
#define EE_APINIT 0x371      /* 0x5A: the default network name was given to the ESP once */
#define EE_USER   0x372      /* router name, 20 bytes */
#define EE_LBL    0x200      /* 8 keys x 41 bytes: icon + text */
#define LBL_TXT   40
#define LBL_SZ    (1+LBL_TXT)
#define EE_OV     0x390      /* times changed from the phone: 0x5B, crc of the programmed settings, sec[6], min[6], exitLo, exitHi, mMask, crc */
#define OV_LEN    18
#define NKEY      8
#define AFTER(a,b) ((int32_t)((a)-(b))>=0)

static uint8_t wifiOn;
/* ---- times changed from the phone (forgotten when the panel is programmed again) ---- */
static uint8_t cf_crc(void){ uint8_t b[26]; for(uint8_t i=0;i<26;i++) b[i]=cf_byte(i); return has_cf()?crc8(b,26):0; }
static void ov_save(void)
{
    uint8_t b[OV_LEN]; b[0]=0x5B; b[1]=cf_crc();
    memcpy(b+2,psec,6); memcpy(b+8,pmin,6); b[14]=exitLo; b[15]=exitHi; b[16]=mMask; b[17]=crc8(b,17);
    eeprom_update_block(b,(void*)EE_OV,OV_LEN);
}
static void ov_load(void)
{
    uint8_t b[OV_LEN]; eeprom_read_block(b,(const void*)EE_OV,OV_LEN);
    if(b[0]!=0x5B || b[17]!=crc8(b,17) || b[1]!=cf_crc()) return;
    memcpy(psec,b+2,6); memcpy(pmin,b+8,6); exitLo=b[14]; exitHi=b[15]; mMask=b[16];
}
static uint8_t rebootDue; static uint32_t rebootAt;

/* ---- UART on interrupts ---- */
static volatile uint8_t rxb[128], rxh, rxt;
#define TXN 64
static volatile uint8_t txb[TXN], txh, txt;
ISR(USART_RXC_vect){ uint8_t c=UDR, n=(uint8_t)((rxh+1)&127); if(n!=rxt){ rxb[rxh]=c; rxh=n; } }
ISR(USART_UDRE_vect){ if(txt!=txh){ UDR=txb[txt]; txt=(uint8_t)((txt+1)&(TXN-1)); } else UCSRB&=(uint8_t)~_BV(UDRIE); }
static void tx(uint8_t c){ uint8_t n=(uint8_t)((txh+1)&(TXN-1)); while(n==txt) ; txb[txh]=c; txh=n; UCSRB|=_BV(UDRIE); }
static void tx_P(const char *p){ char c; while((c=(char)pgm_read_byte(p++))) tx((uint8_t)c); }
static void tx_s(const char *s){ while(*s) tx((uint8_t)*s++); }
static void tx_nl(void){ tx('\r'); tx('\n'); }
static void uart_on(void)
{
    rxh=rxt=0; txh=txt=0;
    UBRRH=0; UBRRL=51; UCSRA=0;                    /* 9600 at 8 MHz */
    UCSRC=_BV(URSEL)|_BV(UCSZ1)|_BV(UCSZ0);
    UCSRB=_BV(RXCIE)|_BV(RXEN)|_BV(TXEN);
    PORTB|=_BV(4);                                 /* ESP on */
}
static void uart_off(void)
{
    UCSRB=0; PORTB&=(uint8_t)~_BV(4);              /* ESP off: drive nothing into it */
    DDRD&=(uint8_t)~0x03; PORTD&=(uint8_t)~0x03;
}

/* ---- ESP state ---- */
enum { W_OFF, W_BOOT, W_INIT, W_IDLE, W_AP, W_JOIN, W_JOINIP, W_IP, W_SEND1, W_SEND2, W_STA, W_JOINW };
static uint8_t wst, step, conn, wasOn, live, kForce;
static uint32_t until;
static uint8_t evOk, evErr, evSendOk, evGotIp, evPrompt, needIp;
/* as the old program: the address 2 s after "WIFI GOT IP"; 0.0.0.0 asked again up to 3 times before "Repeat" */
static uint32_t tNow, gotIpAt; static uint8_t ipTry;
static char mac[18], ip[16];
static char atCmd[104];                         /* *AT+CWSAP* / #AT+CWJAP# of the app (any letters, " , \ escaped) */
static uint8_t apReq, joinReq, joinId;
/* home router off: 20 s without it the station part stops (this panel's own network stays usable); every 2 min
   with no phone connected the module restarts and joins the router again by itself */
#define T_STA_LOST  20000UL
#define T_STA_RETRY 120000UL
static uint8_t staOff; static uint32_t staAt;
static uint8_t wakeReq;
/* the #AT+CWJAP# answer (as the old program): the panel network changes channel while joining and the phone
   connects again; the answer goes to its link and every phone past its first steps, up to 60 s; a late
   "WIFI GOT IP" (after the 30 s) still answers */
#define T_JOIN    30000UL
#define T_JOINANS 60000UL
static uint8_t joinRes, joinFail, joinSent; static uint32_t joinAt, joinEnd;                         /* a phone connected: out of standby (confirmation) */

/* ---- outgoing messages ---- */
#define QN 3
typedef struct { uint8_t id, len; char d[64]; } Msg;
static Msg q[QN], cur;
static uint8_t qh, qn, curFromQ;
static uint8_t kLast[NCONN]; static uint32_t kAt[NCONN];
static Msg *q_new(uint8_t id){ if(qn>=QN) return 0; Msg *m=&q[(qh+qn)%QN]; qn++; m->id=id; m->len=0; return m; }
static void m_c(Msg *m, char c){ if(m->len<sizeof m->d) m->d[m->len++]=c; }
static void m_P(Msg *m, const char *p){ char c; while((c=(char)pgm_read_byte(p++))) m_c(m,c); }
static void m_hex1(Msg *m, uint8_t v){ v&=15; m_c(m,(char)(v<10?'0'+v:'A'+v-10)); }
static void m_hx(Msg *m, uint32_t v, uint8_t n){ while(n--) m_hex1(m,(uint8_t)(v>>(4*n))); }
static void m_2(Msg *m, uint8_t v){ m_c(m,(char)('0'+v/10)); m_c(m,(char)('0'+v%10)); }
static void cmd_P(const char *p, uint32_t t, uint16_t ms){ evOk=evErr=0; tx_P(p); tx_nl(); until=t+ms; }

/* ---- phone payloads, received whole ---- */
#define PN 2
typedef struct { uint8_t id, len, pos; char d[112]; } Pay;
static Pay pay[PN];
static uint8_t payFull; static int8_t payIn=-1; static uint16_t payLeft;

static char lb[72]; static uint8_t ln;
static uint8_t num(const char *p, uint8_t *used){ uint8_t v=0,k=0; while(p[k]>='0'&&p[k]<='9'&&k<5){ v=(uint8_t)(v*10+(p[k]-'0')); k++; } *used=k; return v; }
static void copy_quoted(char *dst, uint8_t n, const char *src)
{
    const char *p=strchr(src,'"'); uint8_t k=0;
    if(p) for(p++; *p && *p!='"' && k<n-1; p++){ if(*p=='\\' && p[1]) p++; dst[k++]=*p; }
    dst[k]=0;
}
static int8_t take_at(const char *p, uint8_t rem, char end)   /* up to the end mark outside "..." */
{
    uint8_t k=1, j=0, q=0;
    for(; k<rem; k++){
        char c=p[k];
        if(!q && c==end){ k++; break; }
        if(q && c=='\\' && k+1<rem){ if(j<sizeof atCmd-2){ atCmd[j++]=c; atCmd[j++]=p[k+1]; } k++; continue; }
        if(c=='"') q^=1;
        if(j<sizeof atCmd-1) atCmd[j++]=c;
    }
    atCmd[j]=0;
    return (int8_t)(k>127?127:k);
}
/* ---- diagnostics (test build): what the module said around the router join ----
   live: @M_DBG -> $DBG#...$ + $DBL#last lines$ ; saved 75 s after each join (also over a power cut): @M_DBS -> $DBS#...$ + $DBT#...$
   R module restarts ("ready")  B "busy" answers  E ERROR/FAIL  J joins sent  W state  P payload slot (+2)  F slots full
   Q messages queued  C links  S station stopped  A join answer  I has an address */
#define EE_DBG 0x3B0                             /* 0xD6, 12 numbers, 3 lines x 20 (0x3B0..0x3F8) */
#define DBG_L 3
#define DBG_W 20
static uint8_t dbR, dbB, dbE, dbJ, dbN, dbDue; static uint32_t dbAt;
static char dbL[DBG_L][DBG_W];
static void db_line(const char *s)
{
    if(!strcmp_P(s,PSTR("OK")) || !strcmp_P(s,PSTR("SEND OK")) || !strncmp_P(s,PSTR("Recv "),5) || !strncmp_P(s,PSTR("+CIFSR:AP"),9)
       || strstr_P(s,PSTR("CIPSEND")) || !strncmp_P(s,PSTR("+CIFSR:STAMAC"),13)) return;
    if(s[0]>='0' && s[0]<='4' && s[1]==',') return;              /* phone links */
    if(!strncmp_P(s,PSTR("busy"),4)) dbB++;
    char *d=dbL[dbN%DBG_L]; uint8_t k=0;
    for(; s[k] && k<DBG_W-1; k++) d[k]=(s[k]=='|'||s[k]=='$'||(uint8_t)s[k]<32||(uint8_t)s[k]>126)?'.':s[k];
    d[k]=0; dbN++;
}
static void db_nums(uint8_t *b)                  /* the 12 numbers */
{
    b[0]=dbR; b[1]=dbB; b[2]=dbE; b[3]=dbJ; b[4]=wst; b[5]=(uint8_t)(payIn+2); b[6]=payFull; b[7]=qn; b[8]=conn; b[9]=staOff;
    b[10]=joinRes; b[11]=(uint8_t)(ip[0] && strcmp_P(ip,PSTR("0.0.0.0")));
}
#define DBG_SZ (1+12+DBG_L*DBG_W)
static uint8_t dbS[DBG_SZ], dbW=0xFF;           /* snapshot being written, one byte when the EEPROM is free (nothing waits) */
static void db_save(void)
{
    dbS[0]=0xD6; db_nums(dbS+1);
    for(uint8_t i=0;i<DBG_L;i++) memcpy(dbS+13+i*DBG_W, dbL[(uint8_t)(dbN+i)%DBG_L], DBG_W);   /* oldest first */
    dbW=0;
}
static void db_step(void){ if(dbW<DBG_SZ && eeprom_is_ready()){ eeprom_update_byte((uint8_t*)(EE_DBG+dbW),dbS[dbW]); dbW++; } }
static void line(void)
{
    const char *s=lb;
    db_line(s);
    if(!strcmp_P(s,PSTR("ready"))){ dbR++; conn=0; wst=W_BOOT; until=0; evOk=0; ip[0]=0; return; }
    if(!strcmp_P(s,PSTR("OK"))){ evOk=1; return; }
    if(!strcmp_P(s,PSTR("SEND OK"))){ evSendOk=1; return; }
    if(!strcmp_P(s,PSTR("ERROR")) || !strcmp_P(s,PSTR("FAIL")) || !strcmp_P(s,PSTR("SEND FAIL"))){ dbE++; evErr=1; return; }
    if(!strcmp_P(s,PSTR("WIFI GOT IP"))){ evGotIp=1; needIp=1; gotIpAt=tNow; return; }
    if(!strncmp_P(s,PSTR("WIFI DISCONNECT"),15)){ ip[0]=0; return; }
    if(s[0]>='0' && s[0]<='4' && s[1]==','){
        uint8_t b=(uint8_t)(1<<(s[0]-'0'));
        if(!strcmp_P(s+2,PSTR("CONNECT"))){ wakeReq=1; joinSent&=(uint8_t)~b; conn|=b; live&=(uint8_t)~b; kForce|=b; }
        else if(!strncmp_P(s+2,PSTR("CLOSED"),6) || !strncmp_P(s+2,PSTR("CONNECT FAIL"),12)) conn&=(uint8_t)~b;
        return;
    }
    if(!strncmp_P(s,PSTR("+CIFSR:STAMAC,"),14)){ copy_quoted(mac,sizeof mac,s); return; }
    if(!strncmp_P(s,PSTR("+CIFSR:STAIP,"),13)){ copy_quoted(ip,sizeof ip,s); return; }
}
static void rx_byte(uint8_t c)
{
    if(payIn!=-1){
        if(payIn>=0){ Pay *p=&pay[payIn]; if(p->len<sizeof p->d) p->d[p->len++]=(char)c; }
        if(--payLeft==0){ if(payIn>=0) payFull|=(uint8_t)(1<<payIn); payIn=-1; }
        return;
    }
    if(c=='\n'){ lb[ln]=0; if(ln) line(); ln=0; return; }
    if(c=='\r' || (ln==0 && c==' ')) return;
    if(ln==0 && c=='>'){ evPrompt=1; return; }
    if(ln<sizeof lb-1) lb[ln++]=(char)c;
    if(c==':' && ln>7 && !strncmp_P(lb,PSTR("+IPD,"),5)){
        uint8_t u, id=num(lb+5,&u), k=(uint8_t)(5+u+1);
        uint16_t len=0;
        while(lb[k]>='0' && lb[k]<='9') len=(uint16_t)(len*10+(lb[k++]-'0'));
        ln=0;
        if(!len) return;
        if(id<NCONN && !(conn&(1<<id))){ conn|=(uint8_t)(1<<id); kForce|=(uint8_t)(1<<id); }
        payLeft=len; payIn=-2;
        for(uint8_t j=0;j<PN;j++) if(!(payFull&(1<<j))){ payIn=(int8_t)j; pay[j].id=id; pay[j].len=0; pay[j].pos=0; break; }
    }
}

/* ---- the keys as the app sees them ---- */
static char lay_of(uint8_t k)
{
    if(k==6) return 'X';
    if(k==7) return 'M';
    uint8_t t=ptype[k];
    return t==T_NORMAL||t==T_TIMER?'L':t==T_DELOFF?'D':t==T_PUSH?'P':'-';
}
static uint8_t app_state(void){ return (uint8_t)((on&0x3F) | (exitRun?0x40:0)); }
static uint8_t lbl_byte(uint8_t n, uint8_t k){ return eeprom_read_byte((const uint8_t*)(EE_LBL+(uint16_t)n*LBL_SZ+k)); }
static void m_k(Msg *m, uint8_t v){ m_P(m,PSTR("$K#0000")); m_hx(m,v,2); m_c(m,'$'); }
/* $CF#nn#type#sec1#sec2#minutes#on#off#seconds left$ (hex), types as the 23-key board */
static void cf_msg(Msg *m, uint8_t k)
{
    uint8_t ty=1, s1=0, s2=0, mn=0; uint32_t onm=0; uint16_t left=0;
    if(k<NP){
        uint8_t t=ptype[k];
        if(t==T_DELOFF){ ty=5; s1=psec[k]; }
        else if(t==T_PUSH){ ty=6; s2=psec[k]; }
        else if(t==T_TIMER){ ty=1; mn=pmin[k]; }
        else if(t==T_OFF) ty=0;
        if(offAt[k] && (int32_t)(offAt[k]-now())>0) left=(uint16_t)((offAt[k]-now()+999)/1000);
    } else if(k==6){ ty=11; s1=exitLo; s2=exitHi; if(exitRun==1 && (int32_t)(exitAt-now())>0) left=(uint16_t)((exitAt-now()+999)/1000); }
    else { ty=2; for(uint8_t i=0;i<NP;i++) if(((mMask>>i)&1)&&ptype[i]!=T_OFF) onm|=1UL<<i; }
    m_P(m,PSTR("$CF#")); m_2(m,(uint8_t)(k+1)); m_c(m,'#');
    m_hx(m,ty,2); m_c(m,'#'); m_hx(m,s1,2); m_c(m,'#'); m_hx(m,s2,2); m_c(m,'#'); m_hx(m,mn,2); m_c(m,'#');
    m_hx(m,onm,6); m_c(m,'#'); m_hx(m,0,6); m_c(m,'#'); m_hx(m,left,4); m_c(m,'$');
}
static uint8_t hexv(char c){ return (uint8_t)(c>='0'&&c<='9'?c-'0':c>='A'&&c<='F'?c-'A'+10:c>='a'&&c<='f'?c-'a'+10:0xFF); }
static uint8_t hexn(const char *p, uint8_t rem, uint32_t *v)
{
    uint32_t x=0; uint8_t k=0;
    while(k<rem && k<8 && hexv(p[k])!=0xFF){ x=(x<<4)|hexv(p[k]); k++; }
    if(!k || (k<rem && p[k]!='#')) return 0;
    *v=x; return k;
}
/* one setting from the phone */
static uint8_t key_set(uint8_t k, char f, uint32_t v)
{
    if(k<NP){
        uint8_t t=ptype[k];
        if(f=='1' && t==T_DELOFF && v>=1 && v<=255) psec[k]=(uint8_t)v;
        else if(f=='2' && t==T_PUSH && v>=1 && v<=255) psec[k]=(uint8_t)v;
        else if(f=='M' && t==T_TIMER && v>=1 && v<=255) pmin[k]=(uint8_t)v;
        else return 0;
    } else if(k==6 && f=='T' && v>=1 && v<=0xFFFF){ exitLo=(uint8_t)v; exitHi=(uint8_t)(v>>8); }
    else if(k==7 && f=='O'){ uint8_t m=0; for(uint8_t i=0;i<NP;i++) if(((v>>i)&1)&&ptype[i]!=T_OFF) m|=(uint8_t)(1<<i); if(!m) return 0; mMask=m; }
    else return 0;
    ov_save();
    return 1;
}

#define IS(lit) (rem>=(uint8_t)(sizeof(lit)-1) && !strncmp_P(p,PSTR(lit),sizeof(lit)-1))
#define D2(x) ((x)[0]>='0'&&(x)[0]<='9'&&(x)[1]>='0'&&(x)[1]<='9')
static int8_t command(uint8_t id, const char *p, uint8_t rem)
{
    Msg *m;
    if(id<NCONN && !(live&(1<<id)) && !IS("@M_IP") && !IS("@M_F_") && !IS("@TA1") && (p[0]=='@'||p[0]=='&'||p[0]=='#'||p[0]=='*'||p[0]=='L')){
        live|=(uint8_t)(1<<id); kForce|=(uint8_t)(1<<id);
    }
    if(IS("@M_DBG") || IS("@M_DBS")){             /* diagnostics: live / saved at the last join */
        uint8_t sv=p[5]=='S', b[DBG_SZ];
        if(sv) eeprom_read_block(b,(const void*)EE_DBG,sizeof b);
        else { b[0]=0xD6; db_nums(b+1); for(uint8_t i=0;i<DBG_L;i++) memcpy(b+13+i*DBG_W, dbL[(uint8_t)(dbN+i)%DBG_L], DBG_W); }
        if(qn>QN-2) return -1;
        m=q_new(id); m_P(m,sv?PSTR("$DBS#"):PSTR("$DBG#"));
        if(b[0]!=0xD6) m_c(m,'-');
        else for(uint8_t i=0;i<12;i++){ static const char L[] PROGMEM="RBEJWPFQCSAI"; m_c(m,(char)pgm_read_byte(&L[i])); uint8_t v=b[1+i];
            if(v>=100){ m_c(m,(char)('0'+v/100)); } if(v>=10){ m_c(m,(char)('0'+v/10%10)); } m_c(m,(char)('0'+v%10)); }
        m_c(m,'$');
        m=q_new(id); m_P(m,sv?PSTR("$DBT#"):PSTR("$DBL#"));
        if(b[0]==0xD6) for(uint8_t i=0;i<DBG_L;i++){ if(i) m_c(m,'|'); const char *l=(const char*)b+13+i*DBG_W; for(uint8_t k=0;k<18 && l[k] && (uint8_t)l[k]!=0xFF;k++) m_c(m,l[k]); }
        m_c(m,'$');
        return 6;
    }
    if(IS("@M_IP")){
        if(!(m=q_new(id))) return -1;
        m_c(m,'%');
        uint8_t nm=(uint8_t)strlen(mac), ni=strcmp_P(ip,PSTR("0.0.0.0"))?(uint8_t)strlen(ip):0;
        for(uint8_t k=0;k<17;k++) m_c(m,k<nm?mac[k]:' ');
        m_c(m,'+');
        for(uint8_t k=0;k<16;k++) m_c(m,k<ni?ip[k]:' ');
        m_c(m,'+');
        for(uint8_t k=0;k<20;k++){ uint8_t c=eeprom_read_byte((const uint8_t*)(EE_USER+k)); m_c(m,c==0xFF?0:(char)c); }
        m_c(m,'%');
        return 5;
    }
    if(IS("@M_F_C")){ if(!(m=q_new(id))) return -1; m_P(m,PSTR("#T")); return 6; }
    if(IS("@M_F_T")){ if(!(m=q_new(id))) return -1; m_P(m,PSTR("#T*A1/Uaaaaaaaaaa/Vp1*L+#X1*Z1++")); return 6; }
    if(IS("@M_MDL")){ if(!(m=q_new(id))) return -1; m_P(m,PSTR("$MDL=SD23-p6-1.0$")); return 6; }
    if(IS("@M_VER")){ if(!(m=q_new(id))) return -1; m_P(m,PSTR("$VER=SD23-1.0$")); return 6; }
    if(IS("@M_LAY")){
        if(!(m=q_new(id))) return -1;
        m_P(m,PSTR("$LAY#"));
        for(uint8_t k=0;k<23;k++) m_c(m,k<NKEY?lay_of(k):'-');
        m_c(m,'$');
        return 6;
    }
    if(IS("@M_CAP")){
        if(!(m=q_new(id))) return -1;
        m_P(m,PSTR("$CAP#A0R")); m_c(m,rmOn?'1':'0'); m_P(m,PSTR("W1S0C1V0$"));
        return 6;
    }
    if(IS("@M_LBL#") && rem>=9 && D2(p+7)){
        uint8_t n=(uint8_t)((p[7]-'0')*10+(p[8]-'0'));
        if(n<1 || n>23) return 9;
        if(!(m=q_new(id))) return -1;
        m_P(m,PSTR("$L")); m_2(m,n); m_c(m,'#');
        if(n<=NKEY){
            uint8_t ic=lbl_byte((uint8_t)(n-1),0);
            if(ic<100){ m_2(m,ic); m_c(m,'~'); }
            for(uint8_t k=1;k<LBL_SZ;k++){ uint8_t c=lbl_byte((uint8_t)(n-1),k); if(!c||c==0xFF) break; m_c(m,(char)c); }
        }
        m_c(m,'$');
        return 9;
    }
    if(IS("@K")){ if(!(m=q_new(id))) return -1; uint8_t r=app_state(); m_k(m,r); if(id<NCONN){ kLast[id]=r; kAt[id]=now(); } return 2; }
    if(IS("&K#") && rem>=5 && D2(p+3)){
        uint8_t n=(uint8_t)((p[3]-'0')*10+(p[4]-'0')), ok=0;
        if(!(m=q_new(id))) return -1;
        standby=0;
        if(!exitRun && mode!=M_LEARN && mode!=M_ERASE){
            if(n>=1 && n<=NP){ if(!stepping() && ptype[n-1]!=T_OFF){ touch_pole((uint8_t)(n-1)); ok=1; } }
            else if(n==7) ok=start_exit();
            else if(n==8){ if(!stepping()){ master_key(); ok=1; } }
        }
        m_P(m,PSTR("$A#")); m_2(m,n); m_c(m,'#'); m_c(m,ok?'1':'0'); m_c(m,'$');
        return 5;
    }
    if(IS("Lbl#") && rem>=7 && D2(p+4) && p[6]=='#'){
        uint8_t n=(uint8_t)((p[4]-'0')*10+(p[5]-'0')), k=7, ic=0xFF;
        if(rem>=10 && D2(p+7) && p[9]=='~'){ ic=(uint8_t)((p[7]-'0')*10+(p[8]-'0')); k=10; }
        uint8_t t0=k;
        while(k<rem && p[k]!='#') k++;
        int8_t used=(int8_t)(k<rem?k+1:k);
        if(n<1 || n>NKEY) return used;
        if(!(m=q_new(id))) return -1;
        uint8_t len=(uint8_t)(k-t0);
        if(len>LBL_TXT){ len=LBL_TXT; while(len && ((uint8_t)p[t0+len]&0xC0)==0x80) len--; }   /* cut at a whole letter */
        uint16_t a=(uint16_t)(EE_LBL+(uint16_t)(n-1)*LBL_SZ);
        eeprom_update_byte((uint8_t*)a,ic);
        for(uint8_t j=0;j<len;j++) eeprom_update_byte((uint8_t*)(a+1+j),(uint8_t)p[t0+j]);
        if(len<LBL_TXT) eeprom_update_byte((uint8_t*)(a+1+len),0);
        m_P(m,PSTR("ok\n"));
        return used;
    }
    if(IS("@M_CF#") && rem>=8 && D2(p+6)){
        uint8_t n=(uint8_t)((p[6]-'0')*10+(p[7]-'0'));
        if(n<1 || n>NKEY) return 8;
        if(!(m=q_new(id))) return -1;
        cf_msg(m,(uint8_t)(n-1));
        return 8;
    }
    if(IS("Set#RS#")){
        if(!(m=q_new(id))) return -1;
        eeprom_update_byte((uint8_t*)EE_OV,0xFF);
        m_P(m,PSTR("$SET#RS#ok$"));
        rebootDue=1; rebootAt=now()+1500;
        return 7;
    }
    if(IS("Set#") && rem>=10 && D2(p+4) && p[6]=='#' && p[8]=='#'){
        uint8_t n=(uint8_t)((p[4]-'0')*10+(p[5]-'0')), u;
        uint32_t v;
        if(!(u=hexn(p+9,(uint8_t)(rem-9),&v))) return 9;
        if(!(m=q_new(id))) return -1;
        if(n>=1 && n<=NKEY && key_set((uint8_t)(n-1),p[7],v)) cf_msg(m,(uint8_t)(n-1));
        else { m_P(m,PSTR("$SET#")); m_2(m,n); m_P(m,PSTR("#no$")); }
        return (int8_t)(9+u+1);
    }
    if(IS("#AT+CWJAP=")){
        int8_t u=take_at(p,rem,'#');
        joinReq=1; apReq=0; joinId=id;
        char user[20]; copy_quoted(user,sizeof user,atCmd);
        uint8_t nu=(uint8_t)strlen(user);
        for(uint8_t i=0;i<20;i++) eeprom_update_byte((uint8_t*)(EE_USER+i),i<nu?(uint8_t)user[i]:0);
        return u;
    }
    if(IS("*AT+CWSAP=")){
        int8_t u=take_at(p,rem,'*');
        apReq=1; joinReq=0;
        return u;
    }
    return 0;
}
static void dispatch(void)
{
    for(uint8_t j=0;j<PN;j++){
        if(!(payFull&(1<<j))) continue;
        Pay *pl=&pay[j];
        while(pl->pos<pl->len){
            int8_t u=command(pl->id,pl->d+pl->pos,(uint8_t)(pl->len-pl->pos));
            if(u<0) return;
            pl->pos=(uint8_t)(pl->pos+(u?u:1));
        }
        payFull&=(uint8_t)~(1<<j);
    }
}
/* the next thing to send: a queued reply first, else the key state a phone has not seen yet (at most every 250 ms) */
static uint8_t next_msg(uint32_t t)
{
    if(qn){ cur=q[qh]; curFromQ=1; return 1; }
    curFromQ=0;
    uint8_t r=app_state();
    for(uint8_t c=0;c<NCONN;c++){
        uint8_t b=(uint8_t)(1<<c);
        if(!(conn&live&b)) continue;
        if((kForce&b) || (kLast[c]!=r && AFTER(t,kAt[c]+250))){
            cur.id=c; cur.len=0; m_k(&cur,r);
            kLast[c]=r; kAt[c]=t; kForce&=(uint8_t)~b;
            return 1;
        }
    }
    return 0;
}

static const char c0[] PROGMEM = "AT+CWMODE=3";
/* this panel's own network name (as wifi64.c): from the programmer, else "sooden-" + the last 4 hex of the MAC */
static uint8_t ap_name(char *b)
{
    uint8_t n=0, c=has_cf()?cf_byte(192):0xFF;
    if(c>32 && c<127){
        for(uint8_t k=0;k<16;k++){ c=cf_byte((uint8_t)(192+k)); if(c<=32||c>=127) break; b[n++]=(char)c; }
    } else {
        if(strlen(mac)<17) return 0;
        const char *p=PSTR("sooden-"); while((c=pgm_read_byte(p++))) b[n++]=(char)c;
        static const uint8_t at[4]={12,13,15,16};
        for(uint8_t k=0;k<4;k++){ c=(uint8_t)mac[at[k]]; b[n++]=(char)(c>='a'&&c<='f'?c-32:c); }
    }
    b[n]=0; return n;
}
static uint8_t ap_crc(const char *b)
{
    uint8_t c=0;
    while(*b){ c^=(uint8_t)*b++; for(uint8_t j=0;j<8;j++) c=(c&0x80)?(uint8_t)((c<<1)^0x07):(uint8_t)(c<<1); }
    return c==0xFF?0xFE:c;
}
static uint8_t apSent;
static const char c2[] PROGMEM = "AT+CIPMUX=1";
static const char c3[] PROGMEM = "AT+CIPSERVER=1,6269";
static const char c4[] PROGMEM = "AT+CIFSR";
static const char c8[] PROGMEM = "AT+CWQAP";
static const char c9[] PROGMEM = "AT+RST";
static uint8_t has_ip(void){ return ip[0] && strcmp_P(ip,PSTR("0.0.0.0")); }
static uint8_t router_set(void){ uint8_t c=eeprom_read_byte((const uint8_t*)EE_USER); return c && c!=0xFF; }

static void wifi_init(void)
{
    ov_load();
    wifiOn=eeprom_read_byte((const uint8_t*)EE_WIFI)==0x5A;      /* off at the first power-up */
    uart_off(); wst=W_OFF;
}
static void wifi_toggle(void)
{
    wifiOn=!wifiOn;
    eeprom_update_byte((uint8_t*)EE_WIFI,wifiOn?0x5A:0x00);
    blink(wifiOn?2:1);
}
static void wifi_tick(void)
{
    uint32_t t=now();
    if(rebootDue && AFTER(t,rebootAt) && !qn && (wst==W_IDLE||wst==W_OFF)){ wdt_enable(WDTO_15MS); for(;;); }
    if(!wifiOn){
        if(wasOn){ uart_off(); wasOn=0; wst=W_OFF; conn=0; live=0; qn=0; payFull=0; payIn=-1; joinReq=apReq=0; staOff=0; joinRes=joinFail=0; }
        return;
    }
    if(!wasOn){ uart_on(); wasOn=1; wst=W_BOOT; until=t+4000; ln=0; }
    tNow=t;
    if(dbDue && AFTER(t,dbAt)){ dbDue=0; db_save(); }
    db_step();
    while(rxt!=rxh){ uint8_t c=rxb[rxt]; rxt=(uint8_t)((rxt+1)&127); rx_byte(c); }
    dispatch();
    switch(wst){
    case W_BOOT:
        if(until==0) until=t+500;
        if(AFTER(t,until)){ wst=W_INIT; step=0; until=t; evOk=evErr=1; }
        break;
    case W_INIT:
        if(!(evOk || evErr || AFTER(t,until))) break;
        if(step==3 && apSent && evOk) eeprom_update_byte((uint8_t*)EE_APINIT,apSent);
        if(step==2){
            char nm[24]; apSent=0;
            if(ap_name(nm) && eeprom_read_byte((const uint8_t*)EE_APINIT)!=ap_crc(nm)){
                apSent=ap_crc(nm); evOk=evErr=0;
                tx_P(PSTR("AT+CWSAP=\"")); for(const char *a=nm;*a;a++){ if(*a=='"'||*a=='\\'||*a==',') tx('\\'); tx((uint8_t)*a); } tx_P(PSTR("\",\"sooden123\",1,3")); tx_nl();
                until=t+6000; step=3; break;
            }
            step=3;
        }
        switch(step++){
        case 0: cmd_P(c0,t,2000); break;
        case 1: cmd_P(c4,t,3000); break;
        case 3: cmd_P(c2,t,2000); break;
        case 4: cmd_P(c3,t,2000); break;
        case 5: cmd_P(c4,t,3000); break;
        default: wst=W_IDLE; needIp=0; staOff=0; staAt=t; break;
        }
        break;
    case W_STA:
        if(evOk || evErr || AFTER(t,until)) wst=W_IDLE;
        break;
    case W_AP: case W_IP:
        if(evOk || evErr || AFTER(t,until)){
            if(wst==W_IP && joinFail && has_ip() && !AFTER(t,joinEnd)){ joinRes=3; joinFail=0; joinSent=0; joinAt=t; }   /* joined late */
            wst=W_IDLE;
        }
        break;
    case W_JOIN:
        if(evOk || (evGotIp && AFTER(t,until))){ evGotIp=0; ipTry=0; until=t+2000; wst=W_JOINW; break; }
        if(evErr || AFTER(t,until)){ joinRes=1; joinFail=1; joinSent=0; joinAt=t; wst=W_IDLE; }
        break;
    case W_JOINW:
        if(AFTER(t,until)){ ip[0]=0; cmd_P(c4,t,3000); wst=W_JOINIP; }
        break;
    case W_JOINIP:
        if(evOk || evErr || AFTER(t,until)){
            if(!has_ip() && ++ipTry<3){ until=t+2000; wst=W_JOINW; break; }
            joinRes=has_ip()?3:2; joinFail=0; joinSent=0; joinAt=t;
            needIp=0; wst=W_IDLE;
        }
        break;
    case W_SEND1:
        if(evPrompt){
            for(uint8_t k=0;k<cur.len;k++) tx((uint8_t)cur.d[k]);
            evSendOk=evErr=0; until=t+2000; wst=W_SEND2;
        } else if(evErr || AFTER(t,until)){
            if(evErr) conn&=(uint8_t)~(1<<cur.id);
            if(curFromQ){ qh=(uint8_t)((qh+1)%QN); qn--; }
            wst=W_IDLE;
        }
        break;
    case W_SEND2:
        if(evSendOk || evErr || AFTER(t,until)){ if(curFromQ){ qh=(uint8_t)((qh+1)%QN); qn--; } wst=W_IDLE; }
        break;
    default: break;
    }
    if(wst!=W_IDLE) return;
    if(apReq){ apReq=0; evOk=evErr=0; tx_s(atCmd); tx_nl(); until=t+6000; wst=W_AP; return; }
    if(joinReq){
        joinReq=0; staOff=0; staAt=t+T_JOIN; evOk=evErr=evGotIp=0; joinRes=joinFail=joinSent=0; joinEnd=t+T_JOIN+T_JOINANS;
        dbJ++; dbDue=1; dbAt=t+75000;
        tx_s(atCmd); tx_nl(); until=t+T_JOIN; wst=W_JOIN; return;
    }
    if(has_ip()) staAt=t;
    else if(!staOff && AFTER(t,staAt+T_STA_LOST) && eeprom_is_ready() && router_set()){ staOff=1; cmd_P(c8,t,3000); wst=W_STA; return; }
    else if(staOff && AFTER(t,staAt+T_STA_LOST+T_STA_RETRY) && !conn && !qn){ staOff=0; cmd_P(c9,t,3000); wst=W_BOOT; until=t+6000; return; }
    if(needIp && AFTER(t,gotIpAt+2000)){ needIp=0; cmd_P(c4,t,3000); wst=W_IP; return; }
    if(joinRes){
        if(AFTER(t,joinAt+T_JOINANS)) joinRes=0;
        else {
            uint8_t want=(uint8_t)(conn&(live|(uint8_t)(1<<joinId))&(uint8_t)~joinSent); Msg *m;
            for(uint8_t to=0; to<NCONN && want; to++){
                if(!(want&(1<<to))) continue;
                if(!(m=q_new(to))) break;
                if(joinRes==1) m_P(m,PSTR("@M_S=Error\n"));
                else if(joinRes==2) m_P(m,PSTR("@M_S=Repeat\n"));
                else { m_P(m,PSTR("@M_S=")); for(uint8_t k=0;ip[k];k++) m_c(m,ip[k]); }
                joinSent|=(uint8_t)(1<<to); want&=(uint8_t)~(1<<to);
            }
        }
    }
    while(qn && !(conn&(1<<q[qh].id))){ qh=(uint8_t)((qh+1)%QN); qn--; }
    if(next_msg(t)){
        char b[20]; uint8_t k=0; const char *h=PSTR("AT+CIPSEND="); char c;
        while((c=(char)pgm_read_byte(h++))) b[k++]=c;
        b[k++]=(char)('0'+cur.id); b[k++]=',';
        if(cur.len>=10) b[k++]=(char)('0'+cur.len/10%10);
        b[k++]=(char)('0'+cur.len%10); b[k]=0;
        evPrompt=evErr=0;
        tx_s(b); tx_nl();
        until=t+1000; wst=W_SEND1;
    }
}
#endif /* VAR_WIFI */


/* ================ MAIN ================ */
int main(void)
{
    logOn=(MCUCSR&_BV(PORF))!=0;                 /* recording only after a power-up */
    MCUCSR=_BV(JTD); MCUCSR=_BV(JTD);
    DDRA=0xFF; PORTA=0; DDRB=0xFF; PORTB=0; DDRD=0xFF; PORTD=0;
    DDRC=0x0F; PORTC=0xF0;   /* PC4..7 touch inputs (pull-ups) */

    /* Timer0: 1 ms CTC @ 8 MHz (prescaler 64, OCR0=124) */
    OCR0=124; TCCR0=_BV(WGM01)|_BV(CS01)|_BV(CS00);
    TIMSK=_BV(OCIE0);

    /* Timer1: free-running, prescaler 8 → 1 µs/tick (for RF timing) */
    TCCR1B=_BV(CS11);

    /* INT1 on any edge for RF receiver (PD3 is input despite DDR default) */
    DDRD&=(uint8_t)~_BV(3);  /* PD3 input */
    PORTD&=(uint8_t)~_BV(3); /* no pull-up */
    MCUCR|=_BV(ISC10);       /* any edge */
    MCUCR&=(uint8_t)~_BV(ISC11);
    GICR|=_BV(INT1);

    /* PA6 buzzer output (already set by DDRA=0xFF) */
    /* PB4 Wi-Fi enable (already output) */

    cfg_load();
    sei();

#ifdef VAR_WIFI
    wifi_init();
#endif
#ifdef VAR_NET
    net_init();
#endif

    motion();

    uint8_t last=0xFF, held=0xFF, done=0, canHold=0, sOn=0, sBl=0;
    uint32_t sOff=0;
    modePole=0xFF;
    uint32_t keyAt=0, idleAt=now();
#ifdef VAR_WIFI
    uint8_t exitPend=0;                          /* key 7 touched: EXIT when lifted, Wi-Fi when held 5 s */
#endif

    for(;;){
        uint32_t t=now();

        /* standby: 60s idle, all off, nothing running */
        if(!standby && !on && !exitRun && !stepping() && t-idleAt>=60000) standby=1;
        if(on||exitRun) idleAt=t;
#ifdef VAR_WIFI
        if(wakeReq){ wakeReq=0; standby=0; idleAt=t; }
#endif

        /* touch debounce */
        uint8_t k=read_key();
        if(k!=last){last=k;keyAt=t;}
        else if(t-keyAt>=30){
            if(k==0xFF){
#ifdef VAR_WIFI
                if(exitPend){ exitPend=0; start_exit(); }
#endif
                held=0xFF;done=0;
            }
            else if(!done){
                held=k; done=1; idleAt=t;
                if(standby){standby=0;motion();continue;}

                canHold=0;
                if(mode==M_ERASE){                   /* one more touch of pole 2: every remote is erased */
                    if(k==modePole){ memset(rmId,0,sizeof rmId); cfg_save(); rm_mode(M_OK,k); }
                    continue;
                }
                if(mode==M_LEARN){                   /* touch any pole N: the blinking moves there, the remote goes to place N */
                    if(k<NP){ lslot=k; rm_mode(M_LEARN,k); }
                    continue;
                }
                if(mode==M_OK || mode==M_TSET) mode=M_NORMAL;   /* a touch ends choosing the timer length */
                if(k<2 && rmOn && !exitRun && !stepping()){       /* pole 1 / 2 may be held for the remote */
                    canHold=1; sOn=(uint8_t)((on>>k)&1); sBl=(uint8_t)((blinkMask>>k)&1); sOff=offAt[k];
                }

                if(exitRun){}
#ifdef VAR_WIFI
                else if(k==K_EXIT) exitPend=1;
#else
                else if(k==K_EXIT) start_exit();
#endif
                else{
                    if(stepping()){}
                    else if(k==K_MASTER) master_key();
                    else if(k<NP) touch_pole(k);
                }
            }
        }

        /* hold pole 1 5 s = learn a remote, pole 2 = erase every remote (as the 4-pole panel) */
        if(canHold && held<2 && done && t-keyAt>=5000 && mode==M_NORMAL){
            uint8_t i=held; canHold=0;
            if(((on>>i)&1)!=sOn) set_pole(i,sOn);          /* undo the short-touch toggle */
            if(sBl) blinkMask|=(uint8_t)(1<<i); else blinkMask&=(uint8_t)~(1<<i);
            offAt[i]=sOff;
            rm_mode(i?M_ERASE:M_LEARN,i);
            lslot=first_free();
        }
#ifdef VAR_WIFI
        if(exitPend && held==K_EXIT && done && t-keyAt>=5000){ exitPend=0; wifi_toggle(); }   /* hold key 7 5 s: Wi-Fi on / off */
#endif
        if((mode==M_LEARN||mode==M_ERASE) && (int32_t)(t-modeAt)>=5000) mode=M_NORMAL;
        if(mode==M_OK && (int32_t)(t-modeAt)>=2000) mode=M_NORMAL;

        /* EXIT countdown */
        if(exitRun==1){
            /* buzzer beep during countdown */
            if(!buzCnt) buz(50);
            if((int32_t)(t-exitAt)>=0){
                exitRun=2; steps(0,(uint8_t)(xMask&on));
#ifdef VAR_NET
                px_q(xPeer,0);                     /* the other panel's keys of the EXIT go off too */
#endif
            }
        }
        if(exitRun==2 && !stepping()) exitRun=0;

        /* one step */
        if(stepping() && (int32_t)(t-stepAt)>=0){
            for(uint8_t i=0;i<NP;i++){
                if((stepOn>>i)&1){stepOn&=(uint8_t)~(1<<i);set_pole(i,1);break;}
                if((stepOff>>i)&1){stepOff&=(uint8_t)~(1<<i);if((on>>i)&1)set_pole(i,0);break;}
            }
            stepAt=t+stepMs;
        }

        /* timers */
        for(uint8_t i=0;i<NP;i++) if(offAt[i]&&(int32_t)(t-offAt[i])>=0) set_pole(i,0);

        /* RF */
        rf_process();
        rt_tick();

#ifdef VAR_WIFI
        wifi_tick();
#endif
#ifdef VAR_NET
        net_tick();
#endif

        show();
    }
}
