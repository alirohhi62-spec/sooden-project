#!/bin/sh
# 6-pole crystal (ATmega32, 8 MHz crystal): settings block in flash at 0x7F00, learned remotes in EEPROM
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
F="-mmcu=atmega32 -DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 -ffunction-sections -fdata-sections -Wl,--gc-sections -Wl,--section-start=.p6cfg=0x7F00"
for v in REMOTE WIFI NET; do
  n=$(echo $v | tr A-Z a-z)
  avr-gcc $F -DVAR_$v p6x.c -o p6x_$n.elf
  avr-objcopy -O ihex -R .eeprom p6x_$n.elf fw_6p_$n.hex
  printf "%-14s " fw_6p_$n; avr-size p6x_$n.elf | tail -1
done
