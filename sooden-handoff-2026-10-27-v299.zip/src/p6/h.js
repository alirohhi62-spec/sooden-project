// ATmega32 6-pole harness: touch code on PC4..7 (PC4 low = touched, PC5..7 = code)
const fs = require('fs');
const { CPU, AVRIOPort, AVREEPROM, EEPROMMemoryBackend } = require('/home/claude/avrsim/node_modules/avr8js');
const { step } = require('/home/claude/avrsim/step');
const core = require('/home/claude/avrsim/cfgcore');
function load(f) { const m = core.parseHex(fs.readFileSync(f, 'utf8')), p = new Uint16Array(16384); for (const [a, v] of m) { if (a & 1) p[a >> 1] |= v << 8; else p[a >> 1] |= v; } return p; }
module.exports = function (file) {
  const cpu = new CPU(load(file), 2048);
  const P = (PIN, DDR, PORT) => new AVRIOPort(cpu, { PIN, DDR, PORT, externalInterrupts: [] });
  const c = { cpu, A: P(0x39, 0x3A, 0x3B), B: P(0x36, 0x37, 0x38), C: P(0x33, 0x34, 0x35), D: P(0x30, 0x31, 0x32) };
  c.ee = new EEPROMMemoryBackend(1024);
  new AVREEPROM(cpu, c.ee, { eepromReadyInterrupt: 34, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 34000, writeCycles: 34000 });
  const T0 = { address: 20, flagRegister: 0x58, flagMask: 0x02, enableRegister: 0x59, enableMask: 0x02 };
  const t = () => { if (cpu.data[0x53] & 7) cpu.setInterruptFlag(T0); cpu.addClockEvent(t, 8000); }; cpu.addClockEvent(t, 8000);
  for (const k of ['A', 'B', 'C', 'D']) for (let i = 0; i < 8; i++) c[k].setPin(i, true);
  const o = (p, n) => (cpu.data[{ A: 0x3B, B: 0x38, C: 0x35, D: 0x32 }[p]] >> n) & 1;
  c.o = o;
  c.run = (ms) => { const end = cpu.cycles + ms * 8000; while (cpu.cycles < end) { step(cpu); if (c.hook) c.hook(); } };
  c.touch = (code) => { c.C.setPin(5, !!(code & 4)); c.C.setPin(6, !!(code & 2)); c.C.setPin(7, !!(code & 1)); c.C.setPin(4, false); };
  c.release = () => { for (let i = 4; i < 8; i++) c.C.setPin(i, true); };
  c.tap = (code, ms) => { c.touch(code); c.run(ms || 120); c.release(); c.run(300); };
  const RED = [['B', 0], ['D', 6], ['B', 2], ['D', 4], ['A', 2], ['C', 1]], WH = [['A', 0], ['D', 7], ['B', 1], ['D', 5], ['A', 3], ['C', 2]];
  c.red = (i) => o(...RED[i]); c.white = (i) => o(...WH[i]);
  c.state = () => RED.map((x, i) => '' + o(...x) + o(...WH[i])).join(' ');
  return c;
};
