const H = require('./h'); const c = H(process.argv[2]||'orig.hex'); c.run(3000);
c.tap(6, 400); c.run(2000); console.log('master on', c.state());
let t0 = c.cpu.cycles, last = c.state(), log = [];
c.hook = () => { const s = c.state(); if (s !== last) { log.push(((c.cpu.cycles - t0) / 8000 | 0) + 'ms ' + s); last = s; } };
c.tap(1, 400); c.run(40000); console.log(log.slice(0, 30).join('\n'));
