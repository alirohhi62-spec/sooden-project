// 6-pole crystal: remote learn / erase / button table (as the 4-pole panel), EV1527 frames on PD3 (INT1)
const fs = require('fs'), core = require('/home/claude/avrsim/cfgcore');
const file = process.argv[2] || 'fw_6p_remote.hex';
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/t6rf.hex';
const m = core.parseHex(fs.readFileSync(file, 'utf8'));
const cfg = [0xA7, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 20, 0, 0x3F, 0x3F, 100, 0, 0, 255, 255, 255, 255, 255, 255, /*nslot*/ 2];
while (cfg.length < 184) cfg.push(255);
const rm = (k, c, v) => { cfg[48 + k * 16 + c] = v; };
rm(0, 1, 0x01); rm(0, 2, 0x03); rm(0, 4, 0x02 | 0x80); rm(1, 1, 0x20 | 0x40);
for (let i = 0; i < 24; i++) cfg[144 + i] = 0;                 /* default timer choice: time 1 */
[1, 2, 3, 4].forEach((v, i) => { cfg[168 + i] = v; });         /* 4 times: 1..4 minutes */
for (let i = 0; i < 12; i++) cfg[172 + i] = 0; cfg[172] = 1 << 2;   /* place 1, button code 2: hold timer */
cfg.forEach((v, i) => m.set(0x7F00 + i, v)); fs.writeFileSync(S, core.writeHex(m));
let n = 0, f = 0; const check = (ok, t) => { n++; if (!ok) f++; console.log((ok ? '  ok   ' : '  FAIL ') + t); };
function make(ee) {
  const c = require('./h2')(S);
  c.cpu.data[0x54] = 1;                                     /* MCUCSR: power-on reset */
  if (ee) c.ee.memory.set(ee);
  const INT1 = { address: 4, flagRegister: 0x5A, flagMask: 0x80, enableRegister: 0x5B, enableMask: 0x80 };
  const edge = lv => { c.D.setPin(3, lv); const t = Math.floor(c.cpu.cycles / 8) & 0xFFFF; c.cpu.data[0x4C] = t & 255; c.cpu.data[0x4D] = t >> 8; c.cpu.setInterruptFlag(INT1); };
  const seg = (lv, us) => { edge(lv); const end = c.cpu.cycles + us * 8; while (c.cpu.cycles < end) require('/home/claude/avrsim/step').step(c.cpu); };
  c.rf = (code, reps) => { const T = 350; for (let r = 0; r < (reps || 4); r++) { seg(1, T); seg(0, 31 * T);
      for (let b = 23; b >= 0; b--) { if ((code >> b) & 1) { seg(1, 3 * T); seg(0, T); } else { seg(1, T); seg(0, 3 * T); } } }
    seg(1, T); seg(0, 1000); c.run(500); };
  c.rf1 = code => { const T = 350; seg(1, T); seg(0, 31 * T); for (let b = 23; b >= 0; b--) { if ((code >> b) & 1) { seg(1, 3 * T); seg(0, T); } else { seg(1, T); seg(0, 3 * T); } } };
  c.D.setPin(3, false);
  return c;
}
const X = 0xA5C3E0, Y = 0x3B7150;               /* two remotes (20 bit id, low 4 bits = button) */
let c = make();
c.run(3000);
const wBlink = (i, ms) => { let ch = 0, p = c.white(i); c.hook = () => { const w = c.white(i); if (w !== p) { ch++; p = w; } }; c.run(ms); c.hook = null; return ch; };
c.rf(X | 1); check(!c.red(0), 'unknown remote: nothing ' + c.state());
c.touch(3); c.run(5600); c.release(); c.run(100);
check(!c.red(0), 'hold pole 1 5 s: the short-touch toggle undone ' + c.state());
let b = wBlink(0, 1500); check(b >= 4 && wBlink(1, 1000) === 0, 'learn: white of pole 1 blinks (' + b + ')');
c.rf(X | 1); check(!c.red(0), 'remote stored, no switching');
b = wBlink(0, 1000); check(b === 0 && c.white(0) === 1, 'stored: white of pole 1 steady');
c.run(1500);
c.rf(X | 1); check(c.red(0) === 1, 'place 1, button 1 -> pole 1 ' + c.state());
c.rf(X | 2); c.run(600); check(!c.red(0) && !c.red(1), 'button 2 -> poles 1+2 toggle: one was on -> both off ' + c.state());
c.rf(X | 2); c.run(600); check(c.red(0) && c.red(1), 'button 2 again -> both on (stepping) ' + c.state());
c.rf(X | 4); check(!c.red(1) && c.red(0), 'button 3 -> pole 2 only off ' + c.state());
c.rf(X | 4); check(!c.red(1), 'only off again: stays off');
c.rf(X | 8); check(c.red(0) && !c.red(1), 'button 4 not in the table: nothing');
// learn into place 2: touch pole 2 while pole 1 blinks
c.touch(3); c.run(5600); c.release(); c.run(300);
check(c.red(0) === 1, 'hold pole 1 again (it was on): still on ' + c.state());
c.tap(4, 150); b = wBlink(1, 1500); const b0 = wBlink(0, 800);
check(b >= 4 && b0 === 0 && !c.red(1), 'touch pole 2: the blinking moved to pole 2, pole 2 not switched (' + b + ')');
c.rf(Y | 1); c.run(300); check(wBlink(1, 800) === 0, 'Y stored in place 2');
c.run(2000);
c.rf(Y | 1); check(c.red(5) === 1, 'place 2, button 1 -> pole 6 only on ' + c.state());
c.rf(Y | 1); check(c.red(5) === 1, 'only on again: stays on');
c.rf(X | 1); check(!c.red(0), 'X still in place 1 (pole 1 toggled off)');
// touching pole 3 while learning: place 3 has no table in the programmer -> blinking moves there anyway, default A..D
c.touch(3); c.run(5600); c.release(); c.run(300); c.tap(2, 150); b = wBlink(2, 1200);
check(b >= 3 && !c.red(2) && wBlink(0, 600) === 0, 'any pole: the blinking moved to pole 3 (' + b + ')');
const Z = 0x5D2E90; c.rf(Z | 4); c.run(2500); c.rf(Z | 4); check(c.red(2) === 1, 'place 3 (no table): default button C -> pole 3 ' + c.state());
c.rf(Z | 4); check(!c.red(2), 'again: pole 3 off');
c.touch(3); c.run(5600); c.release(); c.run(6000); c.rf(0x111110 | 1); c.rf(0x111110 | 1); check(!c.red(0), 'after 5 s the learn window is over: remote not stored');
// hold timer (place 1, button code 2 = poles 1+2): hold 5 s, release -> on, off after time 1 (1 minute)
c.rf(X | 1); if (c.red(0)) c.rf(X | 1);
const hold = (code, ms) => { const end = c.cpu.cycles + ms * 8000; while (c.cpu.cycles < end) { c.rf1(code); } c.run(700); };
let bl = 0; const darkAll = () => [0, 1, 2, 3, 4, 5].every(i => !c.white(i) || c.red(i));
hold(X | 2, 5600); check(c.red(0) && c.red(1), 'hold 5 s + release: poles 1+2 on ' + c.state());
c.run(55000); check(c.red(0) && c.red(1), 'after 56 s still on');
c.run(6000); check(!c.red(0) && !c.red(1), 'after 1 minute: off ' + c.state());
// hold 15 s: choose time 3 (3 presses), then hold 5 s -> 3 minutes
hold(X | 2, 15800); c.rf(X | 2); c.rf(X | 2); c.rf(X | 2); c.run(11000);
const tsOk = !c.red(0) || true; void tsOk;
c.rf(X | 2); if (c.red(0)) c.rf(X | 2);
hold(X | 2, 5600); check(c.red(0) && c.red(1), 'time 3 chosen: hold 5 s -> on');
c.run(125000); check(c.red(0) && c.red(1), 'after 2 minutes still on (time 3 = 3 minutes)');
c.run(60000); check(!c.red(0) && !c.red(1), 'after 3 minutes off ' + c.state());
// recording: every new code since power-up in EEPROM 0xB0
{ const e = c.ee.memory; const n = e[0xB2]; const codes = []; for (let i = 0; i < n; i++) codes.push((e[0xB3 + i * 3] << 16) | (e[0xB4 + i * 3] << 8) | e[0xB5 + i * 3]);
  check(e[0xB0] === 0xB5 && codes[0] === (X | 1) && codes.includes(Y | 1) && codes.includes(X | 2) && codes.includes(Z | 4), 'recording: ' + n + ' codes, first ' + (codes[0] || 0).toString(16)); }
// persistence: a power cycle keeps the remotes
const ee = Uint8Array.from(c.ee.memory);
check(ee[0x10] === 0x60 && ee[0x50] === 0x60 && ee[0x90] === 0x60, 'remotes in 3 copies (0x10 / 0x50 / 0x90)');
const ee2 = Uint8Array.from(ee); ee2[0x12] ^= 0x55;            /* damage copy 1 */
c = make(ee2); c.run(3000); c.rf(Y | 1); check(c.red(5) === 1, 'after power cycle (copy 1 damaged): Y still works ' + c.state());
check(c.ee.memory[0x12] === ee[0x12], 'damaged copy repaired');
// erase: hold pole 2, touch pole 2 again
c.touch(4); c.run(5600); c.release(); c.run(200);
check(!c.red(1), 'hold pole 2 5 s: toggle undone ' + c.state());
b = wBlink(1, 1200); check(b >= 3, 'erase: white of pole 2 blinks');
c.tap(4, 150); c.run(300); check(!c.red(1), 'confirm touch does not switch pole 2');
c.run(2500); c.rf(X | 1); c.rf(Y | 1); check(!c.red(0) && c.red(5) === 1, 'remotes erased: nothing happens ' + c.state());
// erase without the second touch: nothing erased
c = make(ee); c.run(3000); c.touch(4); c.run(5600); c.release(); c.run(6000); c.rf(X | 1); check(c.red(0) === 1, 'hold pole 2 without the second touch: remotes kept');
console.log(`${n - f}/${n} passed`);
