// the hex the programmer made (20 pole model, scenario 1 = master) runs on the simulated board
const B = require('./big'), fs = require('fs');
const { run, tap, red, reds, check } = B;
const bd = B.makeBoard(fs.readFileSync('/home/claude/out/it10_main.hex', 'utf8'));
bd.b.cpu.data[0x54] = 1;
run(bd, 1800);
check(reds(bd) === '0'.repeat(23), 'boots, all off');
tap(bd, 0); check(red(bd, 0) === 1, 'pole 1 on');
tap(bd, 20); run(bd, 300); check(reds(bd) === '0'.repeat(23), 'master with a pole on: all off');
tap(bd, 20); run(bd, 2500); check(reds(bd).slice(0, 20) === '1'.repeat(20), 'scenario 1 (master): all 20 on, step by step');
tap(bd, 20); run(bd, 2500); check(reds(bd).slice(0, 20) === '0'.repeat(20), 'master again: all off');
tap(bd, 21); tap(bd, 22); run(bd, 300); check(reds(bd) === '0'.repeat(23), 'scenario 2 / 3 without work: nothing');
console.log(B.stats());
