// 23-key board: panel clock (phone / internet SNTP) and the vacation program, real hex + fake ESP with SNTP
const B = require('./big'); const { run, touch, red, check } = B; const C = B.core;
const { attachEsp } = require('./esp');
const { execSync } = require('child_process');
const { avrInstruction } = require('avr8js');
const FW = 'fw_big_six';
const nm = execSync(`$HOME/tc/avr-gcc-14.1.0-x64-linux/bin/avr-nm /home/claude/fw/out/${FW}.elf`).toString();
const MSADDR = parseInt(nm.match(/^([0-9a-f]+) b ms$/m)[1], 16) & 0xFFFF;
const BSSEND = parseInt(nm.match(/^([0-9a-f]+) . __bss_end$/m)[1], 16) & 0xFFFF;

/* layout: 10 lights, delayed-off light, pump, curtain pair, EXIT (locks 20 s), SLEEP on the Wi-Fi key */
const type = Array(23).fill(0), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
for (let k = 0; k < 10; k++) type[k] = C.T_NORMAL;
type[10] = C.T_DELOFF; sec1[10] = 3;
type[11] = C.T_NORMAL;
type[12] = type[13] = C.T_ILOCK; off[12] = 1 << 13; off[13] = 1 << 12; sec1[12] = sec1[13] = 6; sec2[12] = sec2[13] = 5;
const lights = (1 << 11) - 1;
type[20] = C.T_EXIT; sec1[20] = 20; off[20] = lights;
type[22] = C.T_SLEEP; sec1[22] = 30; off[22] = lights;
const LAY = 'LLLLLLLLLLDKUW------X-Z';
const cfg = { type, sec1, sec2, offmask: off, onmask: on, remote: false, nslot: 0, alarm: 0, dimsec: 0, stagMs: 50, lay: LAY, mdl: 'pc' };
const ee = new (require('avr8js').EEPROMMemoryBackend)(2048);

let bd, E;
const paint = () => { const d = bd.b.cpu.data, sp = d[0x5D] | d[0x5E] << 8; for (let a = BSSEND + 0x20; a < sp - 4; a++) d[a] = 0xA5; };   /* below the live stack */
const stackLow = () => { const d = bd.b.cpu.data; let a = BSSEND + 0x20; while (a < 0x1100 && d[a] === 0xA5) a++; return a; };
function boot(opt) {
  bd = B.boardWith(cfg, FW, ee);
  run(bd, 1);
  paint();
  E = attachEsp(bd, opt);
}
const steps = (ms, f) => { for (let t = 0; t < ms; t += 10) { run(bd, 10); if (f && f()) return t + 10; } return -1; };
/* move the panel ms counter (and the world clock of the fake ESP) forward: 60 s at a time (so a time an event is due
   is seen up to 60 s late: the timing checks allow that) */
function jump(ms) {
  const d = bd.b.cpu.data;
  run(bd, 200); while (E.txFree > bd.b.cpu.cycles) run(bd, 10);   /* a command just sent: its answer first */
  while (ms > 0) {
    const j = Math.min(ms, 60000), cpu = bd.b.cpu;
    while (!(d[0x5F] & 0x80)) { avrInstruction(cpu); cpu.tick(); }   /* not in the middle of reading ms (cli) */
    let v = d[MSADDR] | d[MSADDR + 1] << 8 | d[MSADDR + 2] << 16 | d[MSADDR + 3] << 24;
    v = (v + j) >>> 0;
    d[MSADDR] = v & 255; d[MSADDR + 1] = (v >>> 8) & 255; d[MSADDR + 2] = (v >>> 16) & 255; d[MSADDR + 3] = v >>> 24;
    E.skew += j; ms -= j;
    run(bd, 30);
    while (E.txFree > cpu.cycles) run(bd, 10);          /* a module answer on the way: let it arrive before the next jump */
    run(bd, 10);
  }
}
const iranMin = () => { const d = new Date(E.utcNow() + 12600000); return d.getUTCHours() * 60 + d.getUTCMinutes(); };
const iranDay = () => Math.floor((E.utcNow() + 12600000 - Date.UTC(2000, 0, 1)) / 864e5);
/* jump to Iran time hh:mm (+ s seconds) of day `day` */
function goTo(day, hh, mm, s = 0) {
  const target = Date.UTC(2000, 0, 1) + day * 864e5 + (hh * 3600 + mm * 60 + s) * 1000 - 12600000;
  const ms = target - E.utcNow();
  if (ms < 0) throw new Error('goTo backwards');
  jump(Math.round(ms));
}
const ask = (p, id, str, re, ms = 1500) => { const n = p.rx.length; E.send(id, str); steps(ms, () => p.rx.slice(n).some(m => re.test(m))); return p.rx.slice(n).find(m => re.test(m)) || p.rx.slice(n).join(' | '); };
const reds = () => [...Array(14).keys()].filter(k => red(bd, k)).join(',');
const D0 = 9783;   /* 2026-10-14 (Wednesday, 22 Mehr 1405) */
const pad = (n, w) => String(n).padStart(w, '0');

/* ---------------- 1. power-up, Wi-Fi on, the router, the time from the internet ---------------- */
boot({ router: true });
run(bd, 2500);
touch(bd, 22, true); run(bd, 7200); touch(bd, 22, false);
let t = steps(8000, () => E.server); steps(300);
check(E.on && t > 0, 'Wi-Fi on, server up');
t = steps(30000, () => E.sntpAsks.length);
check(E.sntpCfg === 'AT+CIPSNTPCFG=1,0,"pool.ntp.org","time.google.com"', 'SNTP set up: ' + E.sntpCfg);
check(t > 0, `time asked ${(t / 1000).toFixed(1)} s after the server (15 s after joining the router)`);
steps(500);
let p = E.connect(0); steps(800);
let r = ask(p, 0, '@M_CLK', /CLK/);
check(r === `$CLK#1#${pad(iranDay(), 5)}#${pad(iranMin(), 4)}#N$`, `clock from the internet, Iran time: ${r} (day ${iranDay()} ${Math.floor(iranMin() / 60)}:${iranMin() % 60})`);
check(iranDay() === D0 && iranMin() === 19 * 60 + 30, 'that is 2026-10-14 19:30 (UTC 16:00 + 3:30)');
const firstAsk = E.sntpAsks[0];

/* ---------------- 2. vacation saved ---------------- */
r = ask(p, 0, '&K#06', /^\$A#06/); ask(p, 0, '&K#12', /^\$A#12/); steps(400);
check(red(bd, 5) && red(bd, 11), 'before: pole 6 and the pump on');
const VAC = `Vac#1#${pad(D0, 5)}#${pad(D0 + 1, 5)}#3#118501003126000404153002008#159000000#`;
E.send(0, VAC); steps(800);
r = ask(p, 0, '@M_VAC', /^\$V#/);
check(r === `$V#1#${pad(D0, 5)}#${pad(D0 + 1, 5)}#3#118501003126000404153002008#159000000#1#-$`, '@M_VAC reads it back: ' + r);
steps(1500);
check(reds() === '5,11', 'saved at 19:30 before the first step: nothing changes (' + reds() + ')');
/* refused programs */
E.send(0, `Vac#1#${pad(D0, 5)}#${pad(D0 + 1, 5)}#2#120000001110000002#130000000#`); steps(600);   /* times going back */
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.startsWith(`$V#1#${pad(D0, 5)}#${pad(D0 + 1, 5)}#3#`), 'times going back: refused, old one kept');
E.send(0, `Vac#1#${pad(D0, 5)}#${pad(D0 + 1, 5)}#1#288000001#290000000#`); steps(600);           /* past 2879 */
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.includes('#3#1185'), 'time over 47:59: refused');
E.send(0, `Vac#1#${pad(D0, 5)}#${pad(D0 + 1, 5)}#1#1200000GG#130000000#`); steps(600);           /* bad hex */
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.includes('#3#1185'), 'bad mask: refused');

/* ---------------- 3. step 1 at 19:45 ---------------- */
goTo(D0, 19, 44, 50); steps(500);
check(reds() === '5,11', '19:44:50 still nothing');
steps(11000);
check(red(bd, 0) && red(bd, 1) && !red(bd, 5) && red(bd, 11) && red(bd, 12), `19:45 step 1: lights 1,2 on, 6 off, pump untouched, curtain opens (${reds()})`);
steps(7000);
check(!red(bd, 12) && !red(bd, 13), 'curtain stops after its 6 s');
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.endsWith('#1#1$'), 'last done: step 1 ' + r.slice(-6));

/* ---------------- 4. step 2 at 21:00 while EXIT locks the panel ---------------- */
goTo(D0, 20, 59, 50); steps(200);
r = ask(p, 0, '&K#21', /^\$A#21/); check(r === '$A#21#1$', 'EXIT pressed at 20:59:50 (panel locked 20 s)');
steps(13000);
check(!red(bd, 2), '21:00 while locked: step 2 waits');
steps(12000);
check(red(bd, 2) && red(bd, 10) && !red(bd, 0) && !red(bd, 1), `EXIT over: step 2 done (lights 3 and delayed-off 11 on, 1,2 off) (${reds()})`);

/* ---------------- 5. the clock every 2 hours ---------------- */
goTo(D0, 21, 30, 0); steps(2000);
check(E.sntpAsks.length === 1, 'no second ask before 2 hours: ' + E.sntpAsks.length);
E.net = false;
goTo(D0, 21, 31, 0); steps(2000);
const a2 = E.sntpAsks[1];
check(E.sntpAsks.length === 2 && Math.abs(a2 - firstAsk - 7200000) < 61000, `2 hours later asked again (+${((a2 - firstAsk) / 60000).toFixed(2)} min)`);
jump(240000); steps(1000);
check(E.sntpAsks.length === 2, 'no internet: no ask in the next 4 minutes');
jump(60000); steps(3000);
const a3 = E.sntpAsks[2];
check(E.sntpAsks.length === 3 && Math.abs(a3 - a2 - 300000) < 61000, `failed: again after 5 minutes (+${((a3 - a2) / 60000).toFixed(2)} min)`);
E.net = true; E.utc0 += 120000;                            /* the panel was 2 minutes slow */
jump(300000); steps(3000);
const a4 = E.sntpAsks[3];
check(E.sntpAsks.length === 4 && Math.abs(a4 - a3 - 300000) < 61000, 'internet back: next try 5 minutes later');
r = ask(p, 0, '@M_CLK', /CLK/);
check(r === `$CLK#1#${pad(iranDay(), 5)}#${pad(iranMin(), 4)}#N$`, `clock corrected by 2 minutes: ${r}`);
jump(3600000); steps(1000);
check(E.sntpAsks.length === 4, 'after success: nothing for an hour');
/* router lost and back: asked at once */
E.dropRouter(); steps(2000); E.backRouter();
t = steps(15000, () => E.sntpAsks.length === 5);
check(t > 0 && t < 12000, `router back: time asked ${(t / 1000).toFixed(1)} s later`);
const a5 = E.sntpAsks[4];

/* ---------------- 6. midnight: step 3 at 01:30 (next day) ---------------- */
goTo(D0 + 1, 1, 30, 5); steps(3000);
check(red(bd, 3) && !red(bd, 2) && red(bd, 13), `01:30 next day, step 3: light 4 on, light 3 off, curtain closes (${reds()})`);
const sinceA5 = E.sntpAsks.filter(x => x > a5);
check(sinceA5.length >= 1 && Math.abs(sinceA5[0] - a5 - 7200000) < 61000, 'the 2-hour asks go on: ' + sinceA5.map(x => ((x - a5) / 3600000).toFixed(2)).join(','));
steps(7000);

/* ---------------- 7. power cut at 01:40 for 10 minutes: clock lost, back from the internet ---------------- */
goTo(D0 + 1, 1, 40, 0);
const utcAt = E.utcNow();
boot({ router: true, utc0: utcAt + 600000 });
run(bd, 2000);
check(reds() === '', 'after the power cut everything is off');
t = steps(8000, () => E.server); steps(300);
check(t > 0, 'Wi-Fi comes back on by itself');
p = E.connect(0); steps(600);
r = ask(p, 0, '@M_CLK', /CLK/); check(r === '$CLK#0$', 'clock not known yet: ' + r);
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.endsWith('#0#-$') && r.startsWith('$V#1#'), 'program kept over the power cut; clock unknown: ' + r);
steps(4000);
check(reds() === '', 'no clock: nothing done');
t = steps(30000, () => E.sntpAsks.length && red(bd, 3));
steps(1500);
check(t > 0 && red(bd, 13), `time from the internet at ${Math.floor(iranMin() / 60)}:${iranMin() % 60}: step 3 caught up (light 4 on, curtain closing) (${reds()})`);
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.endsWith('#1#3$'), 'last done: step 3 ' + r.slice(-6));
steps(7000);

/* ---------------- 8. the end at 02:30, then the last night, then nothing ---------------- */
goTo(D0 + 1, 2, 30, 5); steps(3000);
check(reds() === '', `02:30 end: everything off (${reds()})`);
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.endsWith('#1#E$'), 'last done: end ' + r.slice(-6));
goTo(D0 + 1, 19, 45, 5); steps(3000);
check(red(bd, 0) && red(bd, 1) && red(bd, 12), `last night ${D0 + 1}: step 1 again (${reds()})`);
steps(7000);
goTo(D0 + 2, 2, 30, 5); steps(3000);
check(reds() === '', 'last night ends at 02:30');
goTo(D0 + 2, 19, 45, 5); steps(3000);
check(reds() === '', 'the night after the last: nothing');

/* ---------------- 9. switched off from the phone ---------------- */
E.send(0, `Vac#0#${pad(D0 + 3, 5)}#${pad(D0 + 3, 5)}#1#200000001#210000000#`); steps(800);
r = ask(p, 0, '@M_VAC', /^\$V#/); check(r.startsWith(`$V#0#${pad(D0 + 3, 5)}#`), 'saved switched off: ' + r);
goTo(D0 + 3, 20, 0, 5); steps(3000);
check(reds() === '', 'switched off: does nothing');
/* saved while a step is due: done at once (one night only, today) */
E.send(0, `Vac#1#${pad(D0 + 3, 5)}#${pad(D0 + 3, 5)}#1#119000003#143000000#`); steps(3000);
check(red(bd, 0) && red(bd, 1), 'saved at 20:00 with a step at 19:50 tonight: done at once ' + reds());

/* ---------------- 10. phone sets the clock ---------------- */
r = ask(p, 0, `&CLK#${pad(D0 + 3, 5)}#1300#30`, /CLK/);
check(r === `$CLK#1#${pad(iranDay(), 5)}#${pad(iranMin(), 4)}#N$`, 'clock from the internet: a phone does not change it: ' + r);
check(bd.b.overrun === 0, 'no UART byte lost');
console.log(`  stack: lowest ${stackLow().toString(16)} , free above bss ${stackLow() - BSSEND} bytes (bss end ${BSSEND.toString(16)})`);

/* ---------------- 11. old AT firmware without SNTP: only the phone sets the clock ---------------- */
const ee2 = ee;   /* same panel */
boot({ router: true, sntp: 'none', utc0: E.utcNow() });
t = steps(10000, () => E.server); steps(5000);
const cmds = E.cmds.filter(c => c.startsWith('AT+CIPSNTP'));
jump(1800000); steps(2000);
check(cmds.length === 1 && E.cmds.filter(c => c.startsWith('AT+CIPSNTP')).length === 1, 'no SNTP in the module: set up tried once, never asked: ' + E.cmds.filter(c => c.startsWith('AT+CIPSNTP')).join(','));
p = E.connect(0); steps(600);
r = ask(p, 0, '@M_CLK', /CLK/); check(r === '$CLK#0$', 'clock unknown: ' + r);
r = ask(p, 0, `&CLK#${pad(D0 + 3, 5)}#1300#30`, /CLK/); check(r === `$CLK#1#${pad(D0 + 3, 5)}#1300#P$`, 'set by the phone: ' + r);
r = ask(p, 0, '&CLK#99999#2000#00', /CLK/); check(r === `$CLK#1#${pad(D0 + 3, 5)}#1300#P$`, 'bad clock from the phone: ignored');
r = ask(p, 0, `&CLK#${pad(D0 + 3, 5)}#1310#00`, /CLK/); check(r === `$CLK#1#${pad(D0 + 3, 5)}#1310#P$`, 'set again by the phone: ' + r);
void ee2;

const st = B.stats(); console.log(`\n${st.checks - st.fails}/${st.checks} passed`); process.exit(st.fails ? 1 : 0);
