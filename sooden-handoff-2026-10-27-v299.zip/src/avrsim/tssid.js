// every panel its own Wi-Fi network name: from the programmer, else sooden- + 4 hex of the MAC; sent again only when it changes
const B = require('./big'); const { run, touch, check } = B; const C = B.core;
const { attachEsp } = require('./esp');
const { EEPROMMemoryBackend } = require('avr8js');
const ee = new EEPROMMemoryBackend(2048);
ee.memory[0x7C0] = 0x5A;                                     /* a panel that got "sooden" from the earlier firmware */
const cfg = ssid => ({ type: Array(23).fill(1), remote: false, nslot: 0, stagMs: 100, ssid });
function boot(ssid, wifiOn) {
  const bd = B.boardWith(cfg(ssid), 'fw_big', ee); const E = attachEsp(bd);
  run(bd, 2500);
  if (!wifiOn) { touch(bd, 22, true); run(bd, 7300); touch(bd, 22, false); }
  for (let t = 0; t < 12000 && !E.server; t += 50) run(bd, 50);
  run(bd, 500);
  return E.cmds.filter(c => c.startsWith('AT+CWSAP')).join(' ');
}
check(boot('sooden-1', false) === 'AT+CWSAP="sooden-1","sooden123",1,3', 'earlier panel (had "sooden"), programmed sooden-1: the new name once');
check(boot('sooden-1', true) === '', 'power again: not sent again');
check(boot('sooden-paziraei', true) === 'AT+CWSAP="sooden-paziraei","sooden123",1,3', 'programmed again with another name: sent');
check(boot('', true) === 'AT+CWSAP="sooden-BBCC","sooden123",1,3', 'no name in the programmer: sooden- + MAC');
check(boot('bad name"', true) === '', 'a bad name (space, quote) is not used: stays sooden-BBCC, nothing sent');
console.log(`${B.stats().checks - B.stats().fails}/${B.stats().checks} passed`);
