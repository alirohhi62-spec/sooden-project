// Drives the configurator page in jsdom, then runs the hex files it produces in the AVR simulator
var fs = require("fs");
const { JSDOM } = require('jsdom');
let src = fs.readFileSync(__dirname + '/test.js', 'utf8');
src = src.slice(0, src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm, "var ").replace(/^let /gm, "var "));

const html = fs.readFileSync('/home/claude/out/sooden-tabdil-config.html', 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true });
const w = dom.window, d = w.document;
const got = {};
w.URL.createObjectURL = () => 'blob:x';
w.URL.revokeObjectURL = () => {};
const realPatch = w.patchHex;
w.eval('window.__last=null; const __p = patchHex; patchHex = function(a,b){ const r = __p(a,b); window.__last = r; return r; };');
function dl(side) { w.__last = null; d.getElementById('dl' + side).click(); return w.__last; }
const q = s => d.querySelector(s);
const qa = s => [...d.querySelectorAll(s)];
function clickCount(side, n) { qa(`#types button[data-side="${side}"]`).find(b => +b.dataset.n === n).click(); }
function setType(side, i, t) { const s = q(`#roles select[data-side="${side}"][data-i="${i}"]`); s.value = t; s.dispatchEvent(new w.Event('change')); }
function cell(i, j) { q(`#mx .cell[data-i="${i}"][data-j="${j}"]`).click(); }
function msgs() { return qa('#msgs .msg').map(m => m.className.split(' ')[1] + ': ' + m.textContent); }

function pair(hA, hB, nA, nB) {
  const A = makeNode(hA), B = makeNode(hB);
  A.board = nA <= 2 ? 0 : 1; B.board = nB <= 2 ? 0 : 1;
  nodes = [A, B]; connect(true); run(700);
  return [A, B];
}

console.log('UI 1) default page: 4 pole <-> 4 pole, A1-B1 A2-B2 A3-B3');
{
  check(msgs().some(m => m.startsWith('ok')), 'default config valid');
  const hA = dl('A'), hB = dl('B');
  check(!!hA && !!hB, 'both hex files produced');
  const mA = core.parseHex(hA), cfgA = []; for (let i = 0; i < 32; i++) cfgA.push(mA.get(0x1FC0 + i));
  check(cfgA[0] === 0x53 && cfgA[3] === 0 && cfgA[5] === 4 && cfgA[12] === 0 && cfgA[13] === 1 && cfgA[14] === 2 && cfgA[15] === 0xFF, 'A config block bytes as expected');
  const [A, B] = pair(hA, hB, 4, 4);
  tap(A, 2); run(200);
  check(r4(A)[2] === 1 && r4(B)[2] === 1, 'A3 -> B3 works with UI-built files');
  tap(B, 3); run(200);
  check(r4(B)[3] === 1 && r4(A)[3] === 0, 'pole 4 independent');
}

console.log('UI 2) B = 2 pole, A4 master without linked poles, A3 timer');
{
  clickCount('B', 2);
  check(qa('#mx .cell.on').length === 2, 'link A3-B3 dropped automatically');
  setType('A', 3, 'm');
  q('#roles .ml[data-side="A"][data-i="3"]').click();      /* uncheck: do not include linked poles */
  check(msgs().some(m => m.startsWith('ok')), 'config valid');
  const hA = dl('A'), hB = dl('B');
  const mA = core.parseHex(hA);
  check(mA.get(0x1FC0 + 8 + 3) === 2 && mA.get(0x1FC0 + 20 + 3) === 0x04, 'master targets only A3 (unlinked)');
  const [A, B] = pair(hA, hB, 4, 2);
  tap(A, 0); run(200);
  tap(A, 3); run(400);
  check(r4(A)[2] === 1 && r4(A)[0] === 1 && eq(o2(B), [1, 0]), 'master switched only A3, A1/B1 untouched');
}

console.log('UI 3) timer scenario from the page');
{
  setType('A', 3, 't');
  q('#roles input[data-key="off"][data-side="A"][data-i="3"][data-k="0"]').click();
  q('#roles input[data-key="on"][data-side="A"][data-i="3"][data-k="2"]').click();
  const tm = q('#roles .tmin[data-side="A"][data-i="3"]'); tm.value = '1'; tm.dispatchEvent(new w.Event('input'));
  check(msgs().some(m => m.startsWith('ok')), 'timer config valid');
  const hA = dl('A'), hB = dl('B');
  const [A, B] = pair(hA, hB, 4, 2);
  tap(A, 0); run(200);
  check(eq(o2(B), [1, 0]), 'A1 on (B1 follows)');
  tap(A, 3); run(400);
  check(r4(A)[0] === 0 && r4(A)[2] === 1 && r4(A)[3] === 1 && eq(o2(B), [0, 0]), 'service: A1 off (+B1), A3 on, A4 relay on');
  run(61000);
  check(r4(A)[2] === 0 && r4(A)[3] === 0, 'A3 and A4 off after 1 minute');
}

console.log('UI 4) validation');
{
  clickCount('A', 4);
  setType('A', 0, 'm'); setType('A', 1, 'm'); setType('A', 2, 'm'); setType('A', 3, 'm');
  check(msgs().some(m => m.startsWith('err')) && d.getElementById('dlA').disabled, 'no normal pole -> error, download disabled');
  setType('A', 0, 'n'); setType('A', 1, 'n'); setType('A', 2, 'n');
  setType('A', 3, 't');
  check(msgs().some(m => m.includes('سناریو سرویس')), 'empty timer -> error');
  setType('A', 3, 'n');
  for (const k of Object.keys(w.eval('S.links'))) w.eval(`delete S.links[${k}]`);
  w.eval('render()');
  check(msgs().some(m => m.startsWith('warn')), 'no links -> warning');
  clickCount('A', 2); clickCount('A', 3);
  check(q('#roles select[data-side="A"][data-i="3"]') === null && w.eval('S.A.poles[3].type') === 'm', '3 pole: pole 4 locked as master');
  check(qa('#extras .rem').length === 2 || qa('#extras .rem').length === 1, 'remote option shown only for 3/4 pole');
  clickCount('B', 1);
  check(!q('#mx .cell[data-j="1"]'), '1 pole B: only one column');
}

console.log('\n' + checks + ' checks, ' + fails + ' failed');
process.exit(fails ? 1 : 0);
