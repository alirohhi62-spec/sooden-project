// 12 economic panel (E12): the real hex (fw_e12_*) in the simulator
const E = require('./e12.js');
const { run, touch, tap, red, white, reds, check, core: C } = E;
const z = () => Array(23).fill(0);
const lights = () => { const t = z(); for (let i = 0; i < 12; i++) t[i] = 1; return t; };
const ALL12 = (1 << 12) - 1;

console.log('1) 12 lights; s1 EXIT 5 s, s2 master (all 12), s3 SLEEP 6 s with pole 8 as night light');
{
  const type = lights(), onmask = z(), offmask = z(), sec1 = z(), sec2 = z();
  type[20] = C.T_EXIT; sec1[20] = 5; offmask[20] = ALL12;
  type[21] = C.T_MASTER; onmask[21] = ALL12;
  type[22] = C.T_SLEEP; sec1[22] = 6; offmask[22] = ALL12 & ~(1 << 7); onmask[22] = 1 << 7;
  const cfg = { type, onmask, offmask, sec1, sec2, remote: true, nslot: 1, stagMs: 100, dimsec: 60 };
  const b = E.boardWith(cfg, 'fw_e12_x');
  /* power-up motion: one white at a time, round 1 in the order 1 9 10 2 4 6 8 s3 s2 s1 7 5 3 */
  const ORDER = [0, 8, 9, 1, 3, 5, 7, 22, 21, 20, 6, 4, 2], seen = [];
  let many = 0;
  for (let t = 0; t < 1170; t += 10) {
    run(b, 10);
    const lit = [...Array(23).keys()].filter(k => white(b, k));
    if (lit.length > 1) many++;
    if (lit.length === 1 && seen[seen.length - 1] !== lit[0]) seen.push(lit[0]);
  }
  check(many === 0, 'power-up: never more than one white at a time');
  check(seen.join() === ORDER.filter(k => k !== 21).join(), 'round 1 order 1 9 10 2 4 6 8 s3 (s2 lit by supply) s1 7 5 3: ' + seen.map(k => k < 12 ? k + 1 : 's' + (k - 19)).join(' '));
  run(b, 1800);
  check([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 20, 22].every(k => white(b, k)) && reds(b) === '000000000000' && !red(b, 20) && !red(b, 22),
    'after the motion: every white on, every relay and scenario red off');
  let bad = [];
  for (let k = 0; k < 12; k++) {
    tap(b, k);
    if (!red(b, k) || white(b, k) || reds(b).split('1').length !== 2) bad.push(k + 1);
    tap(b, k);
    if (red(b, k) || !white(b, k)) bad.push(k + 1);
  }
  check(!bad.length, 'each pole (both touch chips) switches only its own relay, red on / white off' + (bad.length ? ' bad ' + bad : ''));
  tap(b, 2); run(b, 200);
  tap(b, 21); run(b, 1500);
  check(reds(b) === '111111111111', 'master (pole 3 on): all 12 on (all on first) ' + reds(b));
  tap(b, 21); run(b, 1500);
  check(reds(b) === '000000000000', 'master again: all off');
  tap(b, 0); tap(b, 11); run(b, 200);
  tap(b, 20); run(b, 300);
  check(red(b, 20) && !white(b, 20), 'EXIT running: s1 red on, white off');
  run(b, 3500);
  check(red(b, 0) && red(b, 11) && red(b, 20), 'still running at 4 s: poles on, s1 red');
  run(b, 2500);
  check(reds(b) === '000000000000' && !red(b, 20) && white(b, 20), 'EXIT over (5 s): poles off one by one, s1 white again');
  tap(b, 1); run(b, 200);
  tap(b, 22); run(b, 300);
  check(red(b, 22) && !white(b, 22), 'SLEEP running: s3 red on, white off');
  run(b, 7000);
  check(reds(b) === '000000010000' && !red(b, 22) && white(b, 22), 'SLEEP over: pole 2 off, night light pole 8 on ' + reds(b));
  /* Wi-Fi: s3 held 7 s */
  check(!E.wifiPower(b), 'Wi-Fi off at first power-up');
  touch(b, 22, true); run(b, 7400); touch(b, 22, false); run(b, 300);
  check(E.wifiPower(b) && !red(b, 22), 's3 held 7 s: Wi-Fi power PE6 on, SLEEP did not run');
  touch(b, 22, true); run(b, 7400); touch(b, 22, false); run(b, 300);
  check(!E.wifiPower(b), 'again: Wi-Fi off');
  /* dark after 60 s, the first touch only wakes */
  tap(b, 7); run(b, 200);
  run(b, 62000);
  check([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 20, 22].every(k => !white(b, k)), 'nothing on for 60 s: every white dark');
  tap(b, 3); run(b, 3000);
  check(!red(b, 3) && white(b, 3), 'first touch in the dark only wakes');
}

console.log('2) 8 lights (5..8 empty), curtains 9/10 and 11/12, s2 elevator, s1 EXIT closes the curtains');
{
  const type = lights(), onmask = z(), offmask = z(), sec1 = z(), sec2 = z();
  [4, 5, 6, 7].forEach(k => { type[k] = 0; });
  [[8, 9], [10, 11]].forEach(([o, c]) => { type[o] = type[c] = C.T_ILOCK; sec1[o] = sec1[c] = 6; sec2[o] = sec2[c] = 5; offmask[o] = 1 << c; offmask[c] = 1 << o; });
  type[20] = C.T_EXIT; sec1[20] = 3; offmask[20] = 0b1111 | (1 << 8) | (1 << 10); onmask[20] = (1 << 9) | (1 << 11);
  type[21] = C.T_ELEV; onmask[21] = 1 << 21;
  type[22] = C.T_MASTER; onmask[22] = 0b1111;
  const b = E.boardWith({ type, onmask, offmask, sec1, sec2, remote: false, nslot: 0, stagMs: 100 }, 'fw_e12_ix');
  run(b, 3500);
  check([4, 5, 6, 7].every(k => !white(b, k) && !red(b, k)), 'empty poles 5..8: no white, no relay');
  [4, 5, 6, 7].forEach(k => tap(b, k)); run(b, 200);
  check(reds(b) === '000000000000', 'touching an empty pole does nothing');
  tap(b, 8); run(b, 500);
  check(red(b, 8) && !red(b, 9), 'curtain 1 open (pole 9)');
  tap(b, 9); run(b, 100);
  check(!red(b, 8) && !red(b, 9), 'touch close while it opens: stops');
  tap(b, 9); run(b, 300);
  let both = 0; for (let i = 0; i < 80; i++) { run(b, 100); if (red(b, 8) && red(b, 9)) both++; }
  check(both === 0 && !red(b, 9), 'close runs its 6 s and stops; never both relays');
  tap(b, 10); run(b, 300); tap(b, 11); run(b, 100); tap(b, 11);
  for (let i = 0; i < 20; i++) { run(b, 50); if (red(b, 10) && red(b, 11)) both++; }
  check(both === 0, 'curtain 2: change of direction, never both relays (interlock)');
  run(b, 8000);
  /* elevator */
  tap(b, 21, 500); run(b, 200);
  check(!E.elevRelay(b), 'elevator: a 0.5 s touch does nothing');
  touch(b, 21, true); run(b, 1100);
  const on1 = E.elevRelay(b), s1 = red(b, 20);
  touch(b, 21, false); run(b, 1200);
  check(on1 && s1, 'elevator: held 1 s -> relay PB1 on and s1 red (confirmation)');
  check(!E.elevRelay(b) && !red(b, 20), 'after 1 s: relay and s1 red off');
  touch(b, 21, true); run(b, 400); touch(b, 21, false); run(b, 30); touch(b, 21, true); run(b, 700); touch(b, 21, false); run(b, 100);
  check(!E.elevRelay(b), 'elevator: two short touches (a break) do not add up');
  /* EXIT closes the curtains */
  tap(b, 0); tap(b, 8); run(b, 7000);
  tap(b, 20); run(b, 3600);
  let closing = red(b, 9) || red(b, 11);
  run(b, 7000);
  check(closing && !red(b, 0) && !red(b, 8), 'EXIT: lights off, curtains closing');
  tap(b, 22); run(b, 800);
  check(reds(b) === '111100000000', 'master: only the 4 lights ' + reds(b));
}

console.log('3) remote: 12 places, learn on pole 1 (the blink moves to the touched pole), erase on pole 2');
{
  const rmap = Array.from({ length: 12 }, () => Array(16).fill(0));
  rmap[0][1] = 12;                          /* place 1, A -> pole 12 (key + 1) */
  const b = E.boardWith({ type: lights(), remote: true, nslot: 12, rmap, stagMs: 100 }, 'fw_e12');
  run(b, 3500);
  const R = 0x5A3C10, R2 = 0x6B4D20, R3 = 0x7C5E30;
  touch(b, 0, true); run(b, 5200); touch(b, 0, false); run(b, 100);
  let bl = 0, was = white(b, 0); for (let i = 0; i < 20; i++) { run(b, 50); if (white(b, 0) !== was) bl++; was = white(b, 0); }
  check(bl >= 3 && !red(b, 0), 'pole 1 held 5 s: its white blinks');
  E.rfSend(b, R | 1, 4, 350); run(b, 2500);
  E.rfSend(b, R | 1, 4, 350); run(b, 400);
  check(red(b, 11) && reds(b).split('1').length === 2, 'remote learned in place 1: A -> pole 12 (programmed table)');
  E.rfSend(b, R | 2, 4, 350); run(b, 400);
  check(red(b, 0), 'button B (no job in the table) -> pole 1, the pole of its place');
  for (const [pole, id] of [[10, R2], [6, R3]]) {           /* pole 11 and pole 7: touch it while pole 1 blinks */
    touch(b, 0, true); run(b, 5200); touch(b, 0, false); run(b, 300);
    tap(b, pole); run(b, 300);
    bl = 0; was = white(b, pole); for (let i = 0; i < 20; i++) { run(b, 50); if (white(b, pole) !== was) bl++; was = white(b, pole); }
    check(bl >= 3, `learning: touching pole ${pole + 1} moves the blink there`);
    E.rfSend(b, id | 4, 4, 350); run(b, 2500);
    const before = red(b, pole);
    E.rfSend(b, id | 8, 4, 350); run(b, 400);
    check(red(b, pole) !== before, `remote in place ${pole + 1}: any button switches pole ${pole + 1}`);
  }
  const ee = b.ee.memory; check(ee[0x5F0] === 0x60 && ((ee[0x5F1 + 30] << 16) | (ee[0x5F2 + 30] << 8) | ee[0x5F3 + 30]) === R2, 'EEPROM: 12-place block at 0x5F0 (place 11 = remote 2)');
  touch(b, 1, true); run(b, 5200); touch(b, 1, false); run(b, 300);
  tap(b, 1); run(b, 2500);
  const st = reds(b);
  E.rfSend(b, R | 1, 4, 350); run(b, 400); E.rfSend(b, R2 | 1, 4, 350); run(b, 400);
  check(reds(b) === st, 'pole 2 held 5 s + touch: every remote erased');
}

console.log('6) poles 11, 12 as custom scenarios (stored with a 4 s hold)');
{
  const type = lights(); type[10] = C.T_CUSTOM; type[11] = C.T_CUSTOM;
  const b = E.boardWith({ type, remote: false, nslot: 0, stagMs: 100 }, 'fw_e12_x');
  E.run(b, 3500);
  check(white(b, 10) && white(b, 11) && !red(b, 10), 'custom scenario keys: white on, no relay');
  tap(b, 0); tap(b, 4); E.run(b, 200);
  touch(b, 10, true); E.run(b, 4400); touch(b, 10, false); E.run(b, 400);
  tap(b, 0); tap(b, 4); tap(b, 6); E.run(b, 300);
  check(reds(b) === '000000100000', 'stored (poles 1, 5), then changed by hand ' + reds(b));
  tap(b, 10); E.run(b, 1000);
  check(reds(b) === '100010000000', 'pole 11 (custom): poles 1 and 5 on, 7 off ' + reds(b));
}
const s = E.stats(); console.log(`${s.checks - s.fails}/${s.checks} passed`);
