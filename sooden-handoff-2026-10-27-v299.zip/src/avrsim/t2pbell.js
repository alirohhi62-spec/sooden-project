// 1/2-pole board: 1-pole panel on PD5 -> PB4, bell push (PD5, bell PB3, do-not-disturb PB4), two-panel network v2
const M = require('./mix'); const { C, run, until } = M;
const { EEPROMMemoryBackend } = require('avr8js');
let fails = 0, n = 0; const check = (c, m) => { n++; if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
const ob = (nd, port, bit) => ((nd.cpu.data[port] >> bit) & 1) && ((nd.cpu.data[port - 1] >> bit) & 1);
const PB3 = nd => ob(nd, 0x38, 3), PB4 = nd => ob(nd, 0x38, 4);
const pd5 = (nd, low) => nd.pd.setPin(5, !low);
const tapPD5 = (nd, ms) => { pd5(nd, 1); run(ms || 120); pd5(nd, 0); run(200); };
const c2 = o => Object.assign({ role: 0, npoles: 2, peerpoles: 2, remote: false, type: [1, 1, 0, 0], link: [-1, -1, -1, -1],
  offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 0, sec1: [0, 0, 0, 0], sec2: [0, 0, 0, 0] }, o);
const px0 = () => C.buildPx({ on: [], off: [] }, false);
console.log('1) 1-pole panel A (PD5 -> PB4) with a 2-pole panel B, A1 <-> B1');
{
  const A = M.m8Node(c2({ npoles: 1, type: [1, 0, 0, 0], link: [0, -1, -1, -1] }), 'fw_2p_px', px0(), new EEPROMMemoryBackend(512));
  const B = M.m8Node(c2({ role: 1, npoles: 2, peerpoles: 1, link: [0, -1, -1, -1] }), 'fw_2p_px', px0(), new EEPROMMemoryBackend(512));
  A.pd.setPin(5, false); B.pb.setPin(5, false); B.pd.setPin(4, false);   /* touch ICs "touched" from power-up */
  M.bus([A, B], true); let any = 0; for (let i = 0; i < 25; i++) { run(100); if (PB4(A) || PB3(B) || PB4(B)) any = 1; }
  check(!any, 'power-up with the touch inputs low: no relay moves (1-pole and 2-pole, 2.5 s)');
  A.pd.setPin(5, true); B.pb.setPin(5, true); B.pd.setPin(4, true); run(500);
  check(!PB4(A) && !PB3(A), 'A off at start');
  tapPD5(A); const t = until(1500, () => PB3(B));
  check(PB4(A) && !PB3(A) && t > 0, '1-pole: touch PD5 -> PB4 on, B pole 1 follows (' + t + ' ms)');
  A.pb.setPin(5, false); run(150); A.pb.setPin(5, true); run(400);
  check(PB4(A), '1-pole: PB5 (the 2-pole pad) does nothing');
  M.tap(B, 0); until(1500, () => !PB4(A)); check(!PB4(A), 'B pole 1 off -> A follows');
  M.tap(B, 1); run(500); check(!PB4(A) && PB4(B), 'B pole 2 (not linked): A unchanged');
}
console.log('2) bell push A (PD5, bell PB3, DND PB4, 3 s) with a 2-pole panel B, B1 <-> the bell');
{
  const eeA = new EEPROMMemoryBackend(512);
  const mk = () => M.m8Node(c2({ npoles: 1, type: [1, 0, 0, 0], link: [0, -1, -1, -1], sec1: [30, 0, 0, 0] }), 'fw_2p_bell', px0(), eeA);
  let A = mk();
  const B = M.m8Node(c2({ role: 1, npoles: 2, peerpoles: 1, link: [0, -1, -1, -1] }), 'fw_2p_px', px0(), new EEPROMMemoryBackend(512));
  pd5(A, 1);                                               /* touch IC "touched" from power-up */
  M.bus([A, B], true); let any = 0; for (let i = 0; i < 25; i++) { run(100); if (PB3(A)) any = 1; }
  check(!any, 'bell: input touched from power-up: no ring (2.5 s)');
  pd5(A, 0); run(500);
  tapPD5(A); let on = 0; for (let i = 0; i < 40; i++) { run(100); if (PB3(A)) on++; }
  check(on >= 28 && on <= 32 && !PB3(A), 'bell: short touch -> PB3 about 3 s (' + on * 100 + ' ms)');
  check(!PB4(A), 'bell: do-not-disturb red off');
  M.tap(B, 0); on = 0; let bOn = 0; for (let i = 0; i < 45; i++) { run(100); if (PB3(A)) on++; if (PB3(B)) bOn++; }
  check(on >= 27 && on <= 33 && !PB3(A) && !PB3(B), 'bell: the linked key of B rings it 3 s, then both off (' + on * 100 + ' ms, B ' + bOn * 100 + ')');
  pd5(A, 1); run(5300); pd5(A, 0); run(400);
  check(PB4(A) && !PB3(A), 'bell: held 5 s -> do-not-disturb (PB4), no ring');
  tapPD5(A); run(800); check(!PB3(A), 'bell: do-not-disturb: a touch does not ring');
  M.tap(B, 0); on = 0; for (let i = 0; i < 20; i++) { run(100); if (PB3(A)) on++; }
  check(on <= 4 && !PB3(A) && !PB3(B), 'bell: do-not-disturb: B cannot ring it (' + on * 100 + ' ms)');
  run(100); A = mk(); M.bus([A, B], true); run(2500);
  check(PB4(A), 'bell: do-not-disturb kept over a power cut');
  pd5(A, 1); run(5300); pd5(A, 0); run(400); check(!PB4(A), 'bell: held 5 s again -> off');
  tapPD5(A); run(300); check(PB3(A), 'bell: rings again');
}
console.log(`${n - fails}/${n} passed`);
