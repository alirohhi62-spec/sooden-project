// Home router off: the panel's own Wi-Fi network must stay usable (the module stops looking for the router),
// and the panel goes back to the router by itself when it is on again. Names / passwords with any letters.
const B = require('./big'); const { run, tap, red, check } = B;
const { attachEsp } = require('./esp');
const type = Array(23).fill(1);
const cfg = { type, remote: false, nslot: 0, alarm: 0, dimsec: 0, stagMs: 100, lay: 'LLLLLLLLLLLLLLLLLLLLMMM', mdl: 'p20' };
const OLD = process.env.OLDAT === '1';
function setup(opt) {
  const ee = new (require('avr8js').EEPROMMemoryBackend)(2048);
  const bd = B.boardWith(cfg, 'fw_big_six', ee);
  const E = attachEsp(bd, opt);
  const steps = (ms, f) => { for (let t = 0; t < ms; t += 10) { run(bd, 10); if (f && f()) return t + 10; } return -1; };
  const ask = (p, id, str, re, ms = 1500) => { const n = p.rx.length; E.send(id, str); steps(ms, () => p.rx.slice(n).some(m => re.test(m))); return p.rx.slice(n).find(m => re.test(m)) || p.rx.slice(n).join(' | '); };
  run(bd, 2500);
  B.touch(bd, 22, true); run(bd, 7200); B.touch(bd, 22, false);
  steps(8000, () => E.server); steps(500);
  return { bd, E, steps, ask };
}
const n = (E, c) => E.cmds.filter(x => x === c).length;

console.log('1) router name / password and panel network name with any letters (escaped by the app)');
let { bd, E, steps, ask } = setup(OLD ? { errOn: { 'AT+CWMODE_CUR': 99 } } : {});
let p = E.connect(0); steps(300);
let r = ask(p, 0, '#AT+CWJAP="Home \\"A\\",1#","p#ss*w,1\\\\"#', /@M_S=/, 8000);
check(E.join && E.join[0] === 'Home "A",1#' && E.join[1] === 'p#ss*w,1\\', 'router name / password reach the module whole: ' + JSON.stringify(E.join));
check(r === '@M_S=192.168.1.50', 'joined: ' + JSON.stringify(r));
r = ask(p, 0, '@M_IP', /^%/);
check(r.includes('+Home "A",1#'), '@M_IP: router name without the escapes ' + JSON.stringify(r));
ask(p, 0, '*AT+CWSAP="@Soo_den\\"*","",1,0*', /x/, 1500); steps(500);
check(E.apArgs && E.apArgs.join('|') === '@Soo_den"*||1|0', 'panel network: any name, no password (open): ' + JSON.stringify(E.apArgs));
ask(p, 0, '*AT+CWSAP="سودن منزل","12345678",1,4*', /x/, 1500); steps(500);
check(E.apArgs && E.apArgs[0] === 'سودن منزل' && E.apArgs[1] === '12345678', 'Persian name: ' + JSON.stringify(E.apArgs));
E.close(0); steps(300);

console.log('2) router switched off');
const c0 = E.cmds.length;
E.modemOff(); let t0 = bd.b.cpu.cycles;
let t = steps(40000, () => !E.scanning());
const stopCmd = 'AT+CWQAP';
check(t > 15000 && t < 26000 && E.cmds.slice(c0).includes(stopCmd), `about 20 s later the module stops looking (${stopCmd}) at ${t} ms`);
p = E.connect(1); steps(200);
r = ask(p, 1, '@M_IP', /^%/);
check(r.startsWith('%5c:cf:7f'), 'a phone on the panel network is served: ' + JSON.stringify(r.slice(0, 20)));
const rs0 = E.resets;
steps(200000);
check(E.resets === rs0, 'while a phone is connected: no restart for 200 s');
r = ask(p, 1, '@M_IP', /^%/); check(r.startsWith('%'), 'still served');
tap(bd, 3); steps(300); check(red(bd, 3), 'touch keeps working'); tap(bd, 3);
E.close(1);
t = steps(130000, () => E.resets > rs0);
check(t > 0, `phone gone: the module restarts to try the router (${t} ms)`);
t = steps(40000, () => E.server && !E.scanning());
check(t > 0 && E.staIp === '0.0.0.0', `router still off: back on its own network (${t} ms)`);

console.log('3) router on again');
E.modemOn();
const rs1 = E.resets;
t = steps(170000, () => E.staIp !== '0.0.0.0' && E.server);
check(t > 0 && E.resets === rs1 + 1, `on the router again by itself (${t} ms)`);
steps(3000);
p = E.connect(2); steps(200);
r = ask(p, 2, '@M_IP', /^%/);
check(r.includes('192.168.1.50'), 'its address on the router: ' + JSON.stringify(r.slice(0, 40)));
const c1 = E.cmds.length; steps(60000);
check(!E.cmds.slice(c1).some(c => c === stopCmd || c === 'AT+RST'), 'on the router: nothing stopped, no restart for 60 s');
E.close(2); steps(300);

console.log('4) router off, then the app sends new router settings');
E.modemOff(); steps(26000);
E.routerOn = true;
p = E.connect(3); steps(200);
const c2 = E.cmds.length;
r = ask(p, 3, '#AT+CWJAP="NewHome","newpass12"#', /@M_S=/, 12000);
check(r === '@M_S=192.168.1.50' && !E.cmds.some(c => c.startsWith('AT+CWMODE_CUR')), 'joined the new router, no mode change: ' + JSON.stringify(r) + ' ' + E.cmds.slice(c2).join(' | '));
E.close(3);

console.log('5) a panel never set on a router: nothing changes');
({ bd, E, steps, ask } = setup({}));
const c3 = E.cmds.length;
steps(200000);
check(E.cmds.length === c3, 'no command to the module for 200 s: ' + E.cmds.slice(c3).join(' | '));
check(!E.hung, 'the module never hung (no mode change: AT+CWMODE=3 after AP-only hangs the real module)');
const s = B.stats ? B.stats() : null; if (s) console.log(`${s.checks - s.fails}/${s.checks} passed`);
