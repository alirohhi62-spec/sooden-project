var fs=require('fs');const {JSDOM}=require('jsdom');
const h=require('/home/claude/tiny/harness');
const dom=new JSDOM(fs.readFileSync('/home/claude/out/sooden-programmer.html','utf8'),{runScripts:'dangerously'});
const w=dom.window,d=w.document; w.URL.createObjectURL=()=>'x'; w.scrollTo=()=>{};
let fails=0,checks=0; const check=(c,m)=>{checks++; if(!c)fails++; console.log((c?'  ok   ':'  FAIL ')+m);};
let lastBlob=null; w.Blob=class{constructor(p){lastBlob=p.join('');}};
const click=s=>{const e=d.querySelector(s); if(!e) throw new Error('missing '+s); e.click();};
for (const [id,file,bit,out] of [['T1','new_1pol.hex',3,1],['T2','new_2pol.hex',2,1],['TB','new_bell.hex',null,null]]) {
  click('.pc[data-i="0"]'); click('.choice[data-k="single"]'); click('.choice[data-v="false"]');
  check(!!d.querySelector(`.mdl[data-id="${id}"][data-ok="1"]`), id+' selectable under no-crystal');
  click(`.mdl[data-id="${id}"]`);
  check(d.querySelector('#stage').textContent.includes('برنامه ثابت'), id+' prog step shows fixed program');
  click('#next');
  check(d.querySelector('#stage').textContent.includes('62') && d.querySelector('#stage').textContent.includes('FB'), id+' finish shows tiny13 fuses 62/FB');
  lastBlob=null; click('[data-dl="0"]');
  const want=fs.readFileSync('/home/claude/tiny/'+file,'utf8').trim();
  check(lastBlob && lastBlob.replace(/\r/g,'').trim()===want.replace(/\r/g,''), id+' downloaded hex = compiled firmware');
  if (bit!==null){ fs.writeFileSync('/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/dl.hex',lastBlob);
    const n=h.load('/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/dl.hex'); h.run(n,2600); h.press(n,bit,1); h.run(n,100); h.press(n,bit,0); h.run(n,300);
    check(h.out(n)===out, id+' downloaded file toggles in tiny13 simulation'); }
}
// tiny models must not appear in crystal / pair paths
click('.pc[data-i="0"]'); click('.choice[data-k="single"]'); click('.choice[data-v="true"]'); click('.choice[data-k="remote"]');
check(!d.querySelector('.mdl[data-id="T1"][data-ok="1"]'), 'T1 not selectable with crystal');
click('.pc[data-i="0"]'); click('.choice[data-k="pair"]');
check(!d.querySelector('.mdl[data-id="T2"][data-ok="1"]'), 'T2 not selectable in pair mode');
console.log(checks+' checks, '+fails+' failed');
