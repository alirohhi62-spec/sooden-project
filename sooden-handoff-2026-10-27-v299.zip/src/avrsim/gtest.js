var fs=require('fs');const {JSDOM}=require('jsdom');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
const dom=new JSDOM(fs.readFileSync('/home/claude/out/sooden-tabdil-general.html','utf8'),{runScripts:'dangerously'});
const w=dom.window,d=w.document; w.URL.createObjectURL=()=>'x'; w.URL.revokeObjectURL=()=>{};
w.eval('const __p=patchHex; patchHex=function(a,b){const r=__p(a,b); window.__last=r; return r;}');
const dl=s=>{w.__last=null;d.querySelector(`[data-dl="${s}"]`).click();return w.__last};
// default P4 <-> P2 A1-B1 A2-B2
const hA=dl('A'),hB=dl('B');
check(!!hA&&!!hB,'hex files for P4 and P2');
const [A,B]=(()=>{const A=makeNode(hA),B=makeNode(hB);A.board=1;B.board=0;nodes=[A,B];connect(true);run(700);return [A,B]})();
tap(A,1);run(300);check(r4(A)[1]===1&&eq(o2(B),[0,1]),'general page files: A2 -> B2');
// 3-pole master model on A, link A3-B1
d.querySelector('#slot button[data-s="A"]').click(); d.querySelector('.mdl[data-id="P3M"]').click();
d.querySelector('button.kk[data-side="A"][data-i="2"]').click(); d.querySelector('button.kk[data-side="B"][data-i="0"]').click();
const h3=dl('A'),h3b=dl('B'); const m3=core.parseHex(h3);
check(m3.get(0x1FC0+5)===3&&m3.get(0x1FC0+11)===2&&m3.get(0x1FC0+14)===0,'3-pole: npoles 3, pole4 master, A3->B1');
// link to pole >4 not allowed for firmware
d.querySelector('#slot button[data-s="B"]').click(); d.querySelector('.mdl[data-id="P8"]').click();
d.querySelector('button.kk[data-side="A"][data-i="0"]').click(); d.querySelector('button.kk[data-side="B"][data-i="6"]').click();
check(d.querySelector('[data-dl="A"]').disabled,'A1<->B7 on 4P firmware -> download blocked with message');
// wifi installer code decodes
d.querySelector('#slot button[data-s="B"]').click(); d.querySelector('.mdl[data-id="W4"]').click();
d.querySelector('button.kk[data-side="A"][data-i="1"]').click(); d.querySelector('button.kk[data-side="B"][data-i="3"]').click();
const code=d.getElementById('codeB').textContent; const j=JSON.parse(Buffer.from(code.slice(5),'base64').toString('utf8'));
check(j.model==='W4'&&j.poles[3].link===1&&j.role==='B','wifi installer code: B4 linked to A2');
console.log(checks+' checks, '+fails+' failed');
