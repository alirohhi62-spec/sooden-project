// One AVR instruction, as the real chip does it around interrupts:
// after the I flag is set (SEI, or OUT SREG with I) one more instruction runs before an interrupt is taken.
// gcc's stack-pointer update (cli; out SPH; out SREG; out SPL) relies on it; avr8js alone would take an
// interrupt between the two halves of SP and push into the wrong place.
const { avrInstruction } = require('avr8js');
function step(c, wrap) {
  const was = c.data[0x5F] & 0x80;
  avrInstruction(c);
  if (wrap && (c.pc & ~wrap)) c.pc &= wrap;
  if (!was && (c.data[0x5F] & 0x80)) { avrInstruction(c); if (wrap && (c.pc & ~wrap)) c.pc &= wrap; }
  c.tick();
}
module.exports = { step };
