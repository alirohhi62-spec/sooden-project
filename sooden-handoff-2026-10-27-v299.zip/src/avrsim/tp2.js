// Phone app through the Wi-Fi panel: the other panel of a two-panel network (4-pole A + alarm a14 B with Wi-Fi)
const M = require('./mix'); const { C, run, tap, red, until } = M;
const { attachEsp } = require('./esp');
let fails = 0, checks = 0;
const check = (c, m) => { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); };
function a14(o) {
  const type = Array(23).fill(1), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
  type[12] = C.T_ALON; type[13] = C.T_ALPW;
  [14, 15, 16, 17].forEach((k, d) => { type[k] = C.T_KEY; sec1[k] = d + 1; });
  type[18] = type[19] = 7; off[18] = 1 << 19; off[19] = 1 << 18; sec1[18] = sec1[19] = 6; sec2[18] = sec2[19] = 5;
  type[20] = C.T_EXIT; sec1[20] = 20; off[20] = 0xFFF; type[21] = 0; type[22] = C.T_SLEEP; sec1[22] = 30; off[22] = 0xFFF & ~32; on[22] = 32;
  return Object.assign({ type, sec1, sec2, offmask: off, onmask: on, remote: false, nslot: 0, alarm: 1, alArm: 3, alEntry: 5, alSiren: 4,
    dimsec: 0, stagMs: 100, lay: 'LLLLLLLLLLLLnc1234UWX-Z', mdl: 'a14', link: Array(23).fill(-1) }, o);
}
const cA = { role: 0, npoles: 4, peerpoles: 23, remote: false, type: [1, 1, 2, 1], link: [2, -1, -1, -1], offmask: [0, 0, 0, 0], onmask: [0, 0, 3, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 100 };
const A = M.m8Node(cA, 'fw_4p_px', C.buildPx({ on: [[], [], [4, 5]] }, false));
const lB = Array(23).fill(-1); lB[2] = 0;
const B = M.bigNode(a14({ role: 1, link: lB }), 'fw_big_a_ix_p', C.buildPx({ pmdl: 'p4', play: 'LLML', pnp: 4, wifi: 1 }, true));
M.bus([A, B], true);
const E = attachEsp(B.bd);
const steps = (ms, f) => { for (let t = 0; t < ms; t += 10) { run(10); if (f && f()) return t + 10; } return -1; };
const ask = (p, id, str, re, ms = 1500) => { const n = p.rx.length; E.send(id, str); steps(ms, () => p.rx.slice(n).some(m => re.test(m))); return p.rx.slice(n).find(m => re.test(m)) || p.rx.slice(n).join(' | '); };
run(2500);
M.B.touch(B.bd, 22, true); run(7200); M.B.touch(B.bd, 22, false);
let t = steps(8000, () => E.server); steps(500);
check(E.on && t > 0, 'Wi-Fi on, server up');
const p = E.connect(0);
steps(1500);
check(p.rx.some(m => /^\$P2K#000000#1\$$/.test(m)), 'on connecting: the other panel pushed ($P2K#000000#1$): ' + p.rx.filter(m => m.startsWith('$P2K')).join(' '));
let r = ask(p, 0, '@M_CAP', /CAP/); check(r === '$CAP#A1R0W1S1P1$', '@M_CAP shows the other panel: ' + r);
r = ask(p, 0, '@M_P2', /^\$P2#/); check(r === '$P2#p4#LLML-------------------#1$', '@M_P2: ' + r);
/* touch on the 4-pole panel: the phone sees it */
tap(A, 1);
t = steps(1500, () => p.rx.some(m => m === '$P2K#000002#1$'));
check(t > 0, `4-pole pole 2 touched: $P2K#000002#1$ after ${t} ms`);
/* from the phone */
r = ask(p, 0, '&P2K#01', /^\$P2A#01/);
check(r === '$P2A#01#1$', '&P2K#01 accepted: ' + r);
t = steps(1500, () => red(A, 0) && red(B, 2));
check(t > 0, `pole 1 of the 4-pole panel on from the phone, B place 3 follows (${t} ms)`);
t = steps(1500, () => p.rx.some(m => m === '$P2K#000003#1$'));
check(t > 0, 'phone sees poles 1, 2 on');
/* the master of the 4-pole panel from the phone: its poles and B places 5, 6 */
ask(p, 0, '&P2K#03', /^\$P2A#03/);
t = steps(3000, () => !red(A, 0) && !red(A, 1));
check(t > 0, `master from the phone: some on -> all off (${t} ms)`);
ask(p, 0, '&P2K#03', /^\$P2A#03/);
t = steps(3000, () => red(A, 0) && red(A, 1) && red(B, 4) && red(B, 5));
check(t > 0, `master again: 4-pole poles 1, 2 and B places 5, 6 on (${t} ms)`);
steps(800);
const ks = p.rx.filter(m => m.startsWith('$K#')).pop();
check(ks === '$K#000034$', 'the phone sees B places 3, 5, 6 on: ' + ks);
/* cable cut: offline */
M.cut(true);
t = steps(8000, () => p.rx.some(m => /^\$P2K#[0-9A-F]{6}#0\$$/.test(m)));
check(t > 0, `cable cut: phone told the other panel is offline (${t} ms)`);
r = ask(p, 0, '&P2K#01', /^\$P2A#01/); check(r === '$P2A#01#0$', 'press while offline refused: ' + r);
M.cut(false);
t = steps(8000, () => p.rx.slice(-3).some(m => /^\$P2K#[0-9A-F]{6}#1\$$/.test(m)));
check(t > 0, `cable back: online again (${t} ms)`);
check(B.bd.b.overrun === 0, 'no UART byte lost');
console.log('  stack gap', M.stackGap(B), 'bytes');
check(M.stackGap(B) > 150, 'RAM: stack never closer than 150 bytes');
console.log(`\n${checks - fails}/${checks} passed`); process.exit(fails ? 1 : 0);
