// Real hex: touch -> relay latency, quick second touch, chatter
var fs=require('fs');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
for (const fw of ['fw_4p','fw_4p_r','fw_4p_pair_r']) {
  console.log('== '+fw);
  const c={role:0,npoles:4,peerpoles:4,remote:fw.includes('_r'),type:[1,1,1,1],link:[-1,-1,-1,-1],offmask:[0,0,0,0],onmask:[0,0,0,0],minutes:[0,0,0,0],dimsec:0,beep:0,stagMs:250,nslot:fw.includes('_r')?1:0};
  const A=makeNode(core.patchHex(FWS[fw],core.buildCfg(c))); A.board=1; nodes=[A]; connect(false); run(1600);
  touch(A,0,true); let lat=-1; for(let k=0;k<40;k++){ run(1); if(r4(A)[0]===1){lat=k+1;break;} } touch(A,0,false); run(40);
  check(lat>0&&lat<=5,'touch -> relay '+lat+' ms');
  touch(A,1,true); run(6); touch(A,1,false); run(35); touch(A,2,true); run(6); touch(A,2,false); run(5);
  check(r4(A)[1]===1&&r4(A)[2]===1,'two quick touches (35 ms apart): both on, no 250 ms wait');
  run(100); touch(A,3,true); run(15); touch(A,3,false); run(10); touch(A,3,true); run(15); touch(A,3,false); run(50);
  check(r4(A)[3]===1,'chatter inside one touch: toggled once');
  run(100); let n=0,l=r4(A)[0]; for(let k=0;k<6;k++){ touch(A,0,true); run(35); touch(A,0,false); run(25); if(r4(A)[0]!==l){n++;l=r4(A)[0];} }
  check(n===6,'6 fast taps (60 ms apart): all 6 counted ('+n+')');
}
console.log(`\n${checks} checks, ${fails} failed`);
