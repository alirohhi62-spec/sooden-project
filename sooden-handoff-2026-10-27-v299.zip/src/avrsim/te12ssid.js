// 12 economic: the Wi-Fi network name from the programmer reaches the module
const E = require('./e12.js'); const { touch, check, core: C } = E; const { attachEsp } = require('./esp');
const type = Array(23).fill(0); for (let i = 0; i < 12; i++) type[i] = 1; type[22] = C.T_SLEEP;
const b = E.boardWith({ type, remote: false, nslot: 0, stagMs: 100, ssid: 'sooden-e12' }, 'fw_e12_x');
const W = attachEsp({ b: { cpu: b.cpu, usart: b.usart }, a: { D: { addListener: f => b.E.addListener(v => f(((v >> 6) & 1) << 5)) }, cpu: { data: new Proxy({}, { get: (t, k) => k === '49' ? ((b.cpu.data[0x22] >> 6) & 1) << 5 : 0 }) } } });
E.run(b, 3500); touch(b, 22, true); E.run(b, 7400); touch(b, 22, false); E.run(b, 8000);
check(W.ap && W.ap[0] === 'sooden-e12' && W.server, 'module got the name sooden-e12, server up: ' + W.cmds.join(' | '));
const s = E.stats(); console.log(`${s.checks - s.fails}/${s.checks} passed`);
