// Real fw_4p_r.hex in avr8js: remote places learned in order on pole 1, place chosen by touch,
// erase on pole 2, per-place tables, actions, 250 ms steps, EEPROM layout and code log
var fs=require('fs');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
const { EEPROMMemoryBackend: EB } = require('avr8js');
const rmap=[Array(16).fill(0),Array(16).fill(0),Array(16).fill(0),Array(16).fill(0)];
rmap[0][1]=0x04; rmap[0][2]=0x0F; rmap[0][3]=0x03|0x10; rmap[0][5]=0x0F|0x20;   // place 1 (4-ch)
rmap[1][12]=0x08; rmap[1][4]=0x01;                                             // place 2 (12-ch)
rmap[2][1]=0x02;                                                               // place 3
const CF={role:0,npoles:4,peerpoles:4,remote:true,type:[1,1,1,1],link:[-1,-1,-1,-1],offmask:[0,0,0,0],onmask:[0,0,0,0],minutes:[0,0,0,0],dimsec:0,beep:0,stagMs:250,nslot:3,rmap};
const ee=new EB(512);
let A=makeNode(core.patchHex(FWS.fw_4p_r,core.buildCfg(CF)),ee); A.board=1; A.cpu.data[0x54]=1; /* power-on reset */ nodes=[A]; connect(false);
run(1600);
const st=()=>r4(A).map(v=>v===1?1:0).join('');
const learn=(code,place)=>{ touch(A,0,true); run(5100); touch(A,0,false); run(50); if(place){ tap(A,place-1); } rfSend(A,code,4,350); run(2300); };
const R4=0x111110, R12=0x2222A0, R3=0x333330, RX=0x777770;
const m=ee.memory, idAt=p=>(m[0x11+p*3]<<16)|(m[0x12+p*3]<<8)|m[0x13+p*3];
console.log('learn in order');
touch(A,0,true); run(5100); touch(A,0,false); run(50);
let blink=0; for(let i=0;i<20;i++){ run(50); if(w4(A)[0]!==1) blink++; }
check(blink>5,'pole1 hold -> pole1 white blinks');
check(st()==='0000','short-press toggle undone');
rfSend(A,R4|1,4,350); run(100);
check(w4(A)[0]===1,'learned -> blinking stops');
run(2300);
learn(R12|12); learn(R3|1);
check(m[0x10]===0x60 && idAt(0)===R4 && idAt(1)===R12 && idAt(2)===R3 && idAt(3)===0xFFFFFF,'places 1,2,3 in EEPROM in order');
check([0x10,0x50,0x90].every(b=>m[b]===0x60),'3 EEPROM copies');
console.log('per-place tables');
rfSend(A,R4|1,4,350); run(500); check(st()==='0010','R4 (place 1) code1 -> pole3');
rfSend(A,R4|1,4,350); run(500); check(st()==='0000','again -> off');
rfSend(A,R4|2,4,350);
let t=[]; for(let i=0;i<120;i++){ run(10); const s=st(); if(t.length===0||t[t.length-1].s!==s) t.push({ms:i*10,s}); }
console.log('     '+t.map(x=>x.s+'@'+x.ms).join(' '));
const gaps=t.slice(1).map((x,i)=>x.ms-t[i].ms);
check(st()==='1111' && t.map(x=>x.s).join()==='1000,1100,1110,1111' && gaps.slice(1).every(g=>g>=240&&g<=260),'code2 -> all on, order 1,2,3,4 in 250 ms steps');
rfSend(A,R4|2,4,350); run(1200); check(st()==='0000','again -> all off');
rfSend(A,R4|3,4,350); run(600); rfSend(A,R4|3,4,350); run(600); check(st()==='1100','only-on (twice) -> 1+2 on');
rfSend(A,R4|5,4,350); run(1000); check(st()==='0000','only-off -> all off');
rfSend(A,R12|12,4,350); run(500); check(st()==='0001','R12 (place 2) code12 -> pole4');
rfSend(A,R12|4,4,350); run(500); check(st()==='1001','R12 code4 -> pole1');
rfSend(A,R12|1,4,350); run(500); check(st()==='1001','R12 code1 not in place-2 table -> nothing');
rfSend(A,R3|1,4,350); run(500); check(st()==='1101','R3 (place 3) code1 -> pole2');
console.log('replace place 2 by touching pole 2 in learn mode');
learn(RX|1, 2);
check(idAt(1)===RX && idAt(0)===R4 && idAt(2)===R3,'RX in place 2, others kept');
const b4=st(); rfSend(A,R12|12,4,350); run(500); check(st()===b4,'old R12 no longer works');
rfSend(A,RX|4,4,350); run(500); check(st()!==b4,'RX uses the place-2 table (code4 -> pole1)');
console.log('erase all on pole 2');
touch(A,1,true); run(5100); touch(A,1,false); run(300); tap(A,1); run(2300);
check([0,1,2,3].every(p=>idAt(p)===0xFFFFFF),'all places empty');
const b5=st(); rfSend(A,R4|1,4,350); run(500); check(st()===b5,'R4 no longer works');
console.log('recording (after power-up)');
const rec=()=>{ const n=m[0xB2], out=[]; for(let i=0;i<n;i++) out.push(((m[0xB3+i*3]<<16)|(m[0xB4+i*3]<<8)|m[0xB5+i*3]).toString(16)); return out; };
check(m[0xB0]===0xB5 && rec().slice(0,3).join()==='111111,2222ac,333331','buttons recorded in first-press order: '+rec().slice(0,6).join(' '));
check(rec().every((c,i)=>i===0||c!==rec()[i-1]),'no consecutive repeats (the programmer removes the other repeats)');
console.log('reset keeps remotes');
learn(R4|1);
A=makeNode(core.patchHex(FWS.fw_4p_r,core.buildCfg(CF)),ee); A.board=1; A.cpu.data[0x54]=2; /* external reset = programmer */ nodes=[A]; connect(false); run(1600);
const nrec=m[0xB2]; rfSend(A,0x99999A,4,350); run(500);
check(m[0xB2]===nrec,'after a programmer (external) reset nothing is recorded');
const b6=st(); rfSend(A,R4|1,4,350); run(500); check(st()!==b6,'after reset R4 still works');
console.log('wrong hex for the settings: panel stays inactive');
const pairCfg=Object.assign({},CF,{link:[0,-1,-1,-1]});
const W=makeNode(core.patchHex(FWS.fw_4p_r,core.buildCfg(pairCfg))); nodes=[W]; connect(false); run(200);
check(W.cpu.data[0x37]===0 && W.cpu.data[0x34]===0,'single-panel hex refuses network settings (pins stay inputs)');
const W2=makeNode(core.patchHex(FWS.fw_4p,core.buildCfg(CF))); nodes=[W2]; connect(false); run(200);
check(W2.cpu.data[0x37]===0,'no-crystal hex refuses remote settings');
console.log(`\n${checks} checks, ${fails} failed`);
