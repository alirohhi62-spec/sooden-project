// Two-panel network v2 with the 6-pole crystal panel (fw_6p_net) on one RS485 line:
//  1) 6-pole A <-> 4-pole B (ATmega8, fw_4p_px)   2) 6-pole B <-> alarm panel a14 A (23 keys)   3) two 6-pole panels
const M = require('./mix'); const { C, run, tap, red, reds, until } = M;
const fs = require('fs'), core = require('./cfgcore');
const { EEPROMMemoryBackend } = require('avr8js');
let fails = 0, checks = 0;
const check = (c, m) => { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); };
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/';
const bits = ks => { const b = [0, 0, 0]; ks.forEach(k => { b[k >> 3] |= 1 << (k & 7); }); return b; };
/* a 6-pole crystal panel: role, links (6 x other panel's key or -1), the other panel's keys of the master / EXIT */
function p6Node(o, ee) {
  const m = core.parseHex(fs.readFileSync('/home/claude/p6/fw_6p_net.hex', 'utf8'));
  const cfg = [0xA7, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, o.exit || 5, 0, o.mMask === undefined ? 0x3F : o.mMask, 0x3F, 100, 0,
    o.role, ...o.link.map(v => v < 0 ? 255 : v), 0];
  while (cfg.length < 184) cfg.push(255);
  cfg.push(...bits(o.mPeer || []), ...bits(o.xPeer || []));
  while (cfg.length < 192) cfg.push(255);
  cfg.forEach((v, i) => m.set(0x7F00 + i, v));
  const f = S + 'p6net_' + o.role + '.hex'; fs.writeFileSync(f, core.writeHex(m));
  const c = require('/home/claude/p6/h2')(f);
  if (ee) c.ee.memory.set(ee);
  c.u.onByteTransmit = null;
  return { kind: 'p6', c, cpu: c.cpu, usart: c.u, cpus: [[c.cpu, 16, 0]] };
}
const tap6 = (n, code, ms) => { n.c.touch(code); run(ms || 120); n.c.release(); run(150); };
const P6 = [3, 4, 2, 5, 0, 7], K7 = 1, K8 = 6;               /* touch codes: poles 1..6, EXIT, master */
const red6 = (n, i) => n.c.red(i) === 1;
const reds6 = n => [0, 1, 2, 3, 4, 5].filter(i => red6(n, i)).join(',');
const c4 = o => Object.assign({ role: 1, npoles: 4, peerpoles: 8, remote: false, type: [1, 1, 1, 1], link: [-1, -1, -1, -1],
  offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 100 }, o);

console.log('1) 6-pole A <-> 4-pole B');
{
  const oA = { role: 0, link: [0, -1, -1, -1, -1, -1], mPeer: [1], xPeer: [2], exit: 5 };
  const cB = c4({ type: [1, 1, 1, 2], link: [0, -1, -1, -1], onmask: [0, 0, 0, 1 << 0] });
  const pB = C.buildPx({ on: [[], [], [], [4, 5]], off: [] }, false);
  const eeA = new EEPROMMemoryBackend(1024).memory, eeB = new EEPROMMemoryBackend(512);
  let A = p6Node(oA), Bn = M.m8Node(cB, 'fw_4p_px', pB, eeB);
  M.bus([A, Bn], true); run(4000);
  check(reds6(A) === '' && reds(Bn) === '', 'both start off');
  tap6(A, P6[0]); let t = until(1500, () => red(Bn, 0));
  check(red6(A, 0) && t > 0, `touch 6-pole pole 1: 4-pole pole 1 follows (${t} ms)`);
  tap(Bn, 0); t = until(1500, () => !red6(A, 0));
  check(!red(Bn, 0) && t > 0, `touch 4-pole pole 1: 6-pole pole 1 follows (${t} ms)`);
  tap6(A, K8); t = until(3000, () => reds6(A) === '0,1,2,3,4,5' && red(Bn, 1));
  check(t > 0 && red(Bn, 0), `6-pole master: its 6 poles + 4-pole pole 2 on (pole 1 linked) (${t} ms) B ${reds(Bn)}`); run(1000);
  tap(Bn, 1); run(800);
  tap6(A, K8); t = until(3000, () => red(Bn, 1));
  check(t > 0 && reds6(A) === '0,1,2,3,4,5', `4-pole pole 2 off by hand: 6-pole master turns everything on again (${t} ms)`); run(1000);
  tap6(A, K8); t = until(3000, () => reds6(A) === '' && !red(Bn, 1) && !red(Bn, 0));
  check(t > 0, `master again (all on): all off on both (${t} ms)`); run(2000);
  tap(Bn, 3); t = until(2000, () => red6(A, 4) && red6(A, 5));
  check(t > 0, `4-pole master (pole 4): 6-pole poles 5, 6 on (${t} ms) ${reds6(A)}`); run(800);
  tap(Bn, 3); t = until(2000, () => !red6(A, 4) && !red6(A, 5));
  check(t > 0, `4-pole master again: 6-pole poles 5, 6 off (${t} ms)`); run(800);
  tap(Bn, 2); until(1000, () => red(Bn, 2));
  tap6(A, P6[1]); tap6(A, K7);
  run(3000); check(red(Bn, 2) && red6(A, 1), 'EXIT running (5 s): 4-pole pole 3 still on');
  t = until(5000, () => !red(Bn, 2) && !red6(A, 1));
  check(t > 0, `EXIT over: 6-pole pole 2 and 4-pole pole 3 off (${(3 + t / 1000).toFixed(1)} s)`);
  run(1500);
  M.cut(true); tap6(A, P6[0]); run(5000);
  check(red6(A, 0) && !red(Bn, 0), 'cable cut: 6-pole pole 1 on, the 4-pole cannot know');
  M.cut(false); t = until(6000, () => red(Bn, 0));
  check(t > 0, `cable back: 4-pole pole 1 follows (${t} ms)`);
  /* power cut of the 6-pole (A): its linked pole comes back from B */
  A = p6Node(oA); M.bus([A, Bn], true);
  t = until(6000, () => red6(A, 0), 5);
  check(t > 0 && red(Bn, 0), `6-pole after a power cut takes pole 1 back (${t} ms)`);
  /* power cut of the 4-pole (B): its pole 1 comes back from A */
  Bn = M.m8Node(cB, 'fw_4p_px', pB, eeB); M.bus([A, Bn], true);
  t = until(6000, () => red(Bn, 0), 5);
  check(t > 0, `4-pole after a power cut takes pole 1 back from the 6-pole (${t} ms)`);
}

console.log('2) alarm panel a14 A (23 keys) <-> 6-pole B');
{
  const type = Array(23).fill(1), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
  type[12] = C.T_ALON; type[13] = C.T_ALPW; [14, 15, 16, 17].forEach((k, d) => { type[k] = C.T_KEY; sec1[k] = d + 1; });
  type[18] = type[19] = 1; type[20] = C.T_EXIT; sec1[20] = 4; off[20] = (1 << 12) - 1; type[21] = 0; type[22] = 0;
  const lA = Array(23).fill(-1); lA[4] = 1;                   /* place 5 <-> 6-pole pole 2 */
  const cA = { type, sec1, sec2, offmask: off, onmask: on, remote: true, nslot: 4, alarm: 1, alArm: 3, alEntry: 5, alSiren: 4,
    dimsec: 0, stagMs: 100, lay: 'LLLLLLLLLLLLnc1234LLX--', mdl: 'a14', link: lA, role: 0 };
  const pA = C.buildPx({ on: [], off: Object.assign(Array(23).fill(0), { 20: [0, 1, 2] }), pmdl: 'p6', play: 'LLLLLLXM', pnp: 8 }, true);
  const Bn = p6Node({ role: 1, link: [-1, 4, -1, -1, -1, -1], mPeer: [0, 1], xPeer: [] });
  const A = M.bigNode(cA, 'fw_big_a_six_p', pA, new EEPROMMemoryBackend(2048));
  M.bus([A, Bn], true); run(5000);
  tap(A, 4); let t = until(1500, () => red6(Bn, 1));
  check(red(A, 4) && t > 0, `alarm panel place 5: 6-pole pole 2 follows (${t} ms)`);
  tap6(Bn, P6[1]); t = until(1500, () => !red(A, 4));
  check(t > 0, `6-pole pole 2 off: alarm panel place 5 follows (${t} ms)`);
  tap6(Bn, K8); t = until(3000, () => red(A, 0) && red(A, 1) && reds6(Bn) === '0,1,2,3,4,5' && red(A, 4));
  check(t > 0, `6-pole master: alarm panel places 1, 2 on too (place 5 linked) (${t} ms)`);
  run(2000); tap(A, 20); run(3000); t = until(6000, () => reds6(Bn) === '3,4,5' && !red(A, 0));
  check(t > 0, `alarm panel EXIT (its places 1..12 and 6-pole poles 1..3): 6-pole poles 1..3 off, 4..6 (not in the EXIT) stay ${reds6(Bn)}`);
}

console.log('3) two 6-pole panels');
{
  const A = p6Node({ role: 0, link: [0, 1, -1, -1, -1, -1], mPeer: [2, 3], xPeer: [4] });
  const Bn = p6Node({ role: 1, link: [0, 1, -1, -1, -1, -1], mPeer: [], xPeer: [] });
  M.bus([A, Bn], true); run(4000);
  tap6(A, P6[0]); let t = until(1500, () => red6(Bn, 0));
  check(t > 0, `A pole 1 -> B pole 1 (${t} ms)`);
  tap6(Bn, P6[1]); t = until(1500, () => red6(A, 1));
  check(t > 0, `B pole 2 -> A pole 2 (${t} ms)`);
  tap6(Bn, P6[4]); run(300);
  tap6(A, K8); t = until(3000, () => red6(Bn, 2) && red6(Bn, 3) && reds6(A) === '0,1,2,3,4,5');
  check(t > 0, `A master: B poles 3, 4 on (${t} ms) B ${reds6(Bn)}`);
  run(2000); tap6(A, K7); t = until(9000, () => !red6(Bn, 4) && reds6(A) === '' && reds6(Bn) === '2,3');
  check(t > 0, `A EXIT: A all off, B pole 5 off (EXIT), B 1, 2 follow (linked), B 3, 4 stay (${t} ms) B ${reds6(Bn)}`);
}
console.log(`${checks - fails}/${checks} passed`);
