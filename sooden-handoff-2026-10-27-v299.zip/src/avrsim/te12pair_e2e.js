// 12 economic (A) + 4-pole (B): the hexes the programmer made (itest_e12pair.js) on one RS485 line
const E = require('./e12.js'); const M = require('./mix');
const fs = require('fs'); const { EEPROMMemoryBackend } = require('avr8js');
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/';
let f = 0, n = 0; const check = (c, m) => { n++; if (!c) f++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
const b = E.boardHex(fs.readFileSync(S + 'pr_e12A.hex', 'utf8'));
const A = { kind: 'e12', cpu: b.cpu, usart: b.usart1, cpus: [[b.cpu, 16, 0]] };
const Bn = M.m8(fs.readFileSync(S + 'pr_e12B4.hex', 'utf8'), new EEPROMMemoryBackend(512));
M.bus([A, Bn], true); M.run(4000);
const tapA = k => { E.touch(b, k, true); M.run(80); E.touch(b, k, false); M.run(100); };
tapA(0); let t = M.until(1500, () => M.red(Bn, 0)); check(E.red(b, 0) && t > 0, `E12 pole 1 -> 4-pole pole 1 (${t} ms)`);
M.tap(Bn, 0); t = M.until(1500, () => !E.red(b, 0)); check(t > 0, `4-pole pole 1 -> E12 pole 1 off (${t} ms)`);
tapA(21); t = M.until(3000, () => E.reds(b) === '111111111111' && M.red(Bn, 1));
check(t > 0 && M.red(Bn, 0), `E12 master (s2): its 12 + 4-pole pole 2 (pole 1 linked) (${t} ms)`); M.run(1000);
tapA(21); t = M.until(3000, () => E.reds(b) === '000000000000' && !M.red(Bn, 1)); check(t > 0, `again (all on): all off on both (${t} ms)`); M.run(1000);
M.tap(Bn, 3); t = M.until(2000, () => E.red(b, 4) && E.red(b, 5)); check(t > 0, `4-pole master: E12 poles 5, 6 on (${t} ms)`);
console.log(`${n - f}/${n} passed`);
