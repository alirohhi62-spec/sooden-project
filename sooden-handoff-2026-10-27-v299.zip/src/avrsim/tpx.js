// Two-panel network v2 (px): real hex of every chip, one RS485 line
//  1) 4-pole panel (ATmega8, A) with an alarm panel a14 (23 keys, B)
//  2) two 23-key panels (alarm a14 = A, 20-pole custom = B)
//  3) 1/2-pole panel with a 23-key panel
const M = require('./mix'); const { C, run, tap, red, reds, until, r4 } = M;
const { EEPROMMemoryBackend } = require('avr8js');
let fails = 0, checks = 0;
const check = (c, m) => { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); };
const range = (a, b) => Array.from({ length: b - a + 1 }, (_, i) => a + i);

/* a14 alarm layout (as tesp.js) */
function a14(o) {
  const type = Array(23).fill(1), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
  type[12] = C.T_ALON; type[13] = C.T_ALPW;
  [14, 15, 16, 17].forEach((k, d) => { type[k] = C.T_KEY; sec1[k] = d + 1; });
  type[18] = type[19] = 7; off[18] = 1 << 19; off[19] = 1 << 18; sec1[18] = sec1[19] = 6; sec2[18] = sec2[19] = 5;
  const relays = (1 << 12) - 1 | 1 << 18 | 1 << 19;
  type[20] = C.T_EXIT; sec1[20] = 20; off[20] = relays & ~(1 << 19); on[20] = 1 << 19;
  type[21] = C.T_ELEV; on[21] = 1 << 20;
  type[22] = C.T_SLEEP; sec1[22] = 30; off[22] = relays & ~(1 << 5); on[22] = 1 << 5;
  return Object.assign({ type, sec1, sec2, offmask: off, onmask: on, remote: true, nslot: 4, alarm: 1, alArm: 3, alEntry: 5, alSiren: 4,
    dimsec: 0, stagMs: 100, lay: 'LLLLLLLLLLLLnc1234UWXEZ', mdl: 'a14', link: Array(23).fill(-1) }, o);
}
function c4(o) {
  return Object.assign({ role: 0, npoles: 4, peerpoles: 23, remote: false, type: [1, 1, 1, 1], link: [-1, -1, -1, -1],
    offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 100 }, o);
}
/* times (ms from now) at which keys of node n turn on */
function onTimes(n, keys, ms) {
  const t = {}, t0 = Date.now();
  for (let x = 0; x < ms; x += 5) { run(5); keys.forEach(k => { if (t[k] === undefined && red(n, k)) t[k] = x + 5; }); if (keys.every(k => t[k] !== undefined)) break; }
  void t0; return keys.map(k => t[k]);
}

console.log('1) 4-pole A (ATmega8) <-> alarm panel a14 B (23 keys)');
{
  const cA = c4({ type: [1, 1, 2, 3], link: [2, -1, -1, -1], onmask: [0, 0, 1 << 1, 0], minutes: [0, 0, 0, 1] });
  const pA = C.buildPx({ on: [[], [], range(4, 11), [3]], off: [] }, false);
  const lB = Array(23).fill(-1); lB[2] = 0;
  const cB = a14({ role: 1, link: lB });
  const pB = C.buildPx({ on: [], off: Object.assign(Array(23).fill(0), { 20: [0, 1] }), pmdl: 'p4', play: 'LLMT', pnp: 4 }, true);
  const eeA = new EEPROMMemoryBackend(512), eeB = new EEPROMMemoryBackend(2048);
  let A = M.m8Node(cA, 'fw_4p_px', pA, eeA), Bn = M.bigNode(cB, 'fw_big_a_six_p', pB, eeB);
  M.bus([A, Bn], true);
  run(4000);
  check(reds(A) === '' && reds(Bn) === '', 'both start with everything off');

  /* link A1 <-> B3 */
  tap(A, 0);
  let t = until(1000, () => red(Bn, 2));
  check(red(A, 0) && t > 0, `touch A pole 1: B place 3 follows (${t} ms)`);
  tap(Bn, 2);
  t = until(1000, () => !red(A, 0));
  check(!red(Bn, 2) && t > 0, `touch B place 3: A pole 1 follows (${t} ms)`);

  /* A pole 3 = master over A pole 2 and B places 5..12 */
  tap(A, 2);
  const tm = onTimes(Bn, range(4, 11), 3000);
  const gaps = tm.slice(1).map((x, i) => x - tm[i]);
  check(red(A, 1) && tm.every(x => x !== undefined), 'A master: A pole 2 and B places 5..12 on: ' + reds(Bn));
  check(gaps.every(g => g >= 60), `B places come on one after the other (gaps ${gaps.join(',')} ms)`);
  tap(Bn, 7);                                                  /* one of them off on B */
  run(500);
  tap(A, 2);                                                   /* some still on: master turns all off */
  t = until(3000, () => reds(Bn) === '' && !red(A, 1));
  check(t > 0, `A master again: everything off on both panels (${t} ms)`);
  tap(Bn, 9); run(600);                                        /* only one of B on */
  tap(A, 2); run(2500);
  check(reds(Bn) === '' && !red(A, 1), 'one B place on: A master counts it, all off');

  /* A pole 4 = service: B place 4 (hood) on, 1 minute */
  tap(A, 3);
  t = until(1500, () => red(Bn, 3));
  check(red(A, 3) && t > 0, `A service: its red on, B place 4 on (${t} ms)`);
  run(30000);
  check(red(A, 3) && red(Bn, 3), 'after 30 s still running');
  t = until(35000, () => !red(Bn, 3));
  check(t > 0 && !red(A, 3), `after 1 minute: B place 4 off and A service red off (${(30 + t / 1000).toFixed(1)} s)`);
  tap(A, 3); until(1500, () => red(Bn, 3));
  tap(Bn, 3);                                                  /* hood off by hand on B */
  t = until(3000, () => !red(A, 3));
  check(t > 0, `hood switched off on B: A service stops (${t} ms)`);

  /* B EXIT: its poles and A poles 1, 2 off */
  tap(A, 0); tap(A, 1); until(1500, () => red(Bn, 2));
  check(red(A, 0) && red(A, 1) && red(Bn, 2), 'A poles 1, 2 on (B place 3 with A 1)');
  tap(Bn, 20);
  run(15000);
  check(red(A, 1), 'EXIT running: A pole 2 still on');
  t = until(12000, () => !red(A, 1) && !red(A, 0));
  check(t > 0 && !red(Bn, 2), `EXIT over: A poles 1, 2 off (${(15 + t / 1000).toFixed(1)} s)`);
  run(8000);                                                   /* curtain close of EXIT runs 6 s */

  /* cable cut */
  M.cut(true);
  tap(A, 0);
  run(5000);
  check(red(A, 0) && !red(Bn, 2), 'cable cut: A pole 1 on, B cannot know');
  M.cut(false);
  t = until(6000, () => red(Bn, 2));
  check(t > 0, `cable back: B place 3 follows (${t} ms)`);

  /* power cut of A (role A): its linked pole comes back from B */
  A = M.m8Node(cA, 'fw_4p_px', pA, eeA); M.bus([A, Bn], true);
  t = until(5000, () => red(A, 0), 5);
  check(t > 0 && red(Bn, 2), `A after a power cut takes pole 1 back from B (${t} ms after power-up)`);

  /* power cut of B: B place 3 comes back from A */
  Bn = M.bigNode(cB, 'fw_big_a_six_p', pB, eeB); M.bus([A, Bn], true);
  run(2500);
  t = until(6000, () => red(Bn, 2));
  check(t > 0 && red(A, 0), `B after a power cut takes place 3 back from A (${t} ms)`);
  check(Bn.bd.b.overrun === 0, 'no byte lost on the ATmega64 UART');
  console.log('  stack: free RAM never used by the stack, alarm panel:', M.stackGap(Bn), 'bytes');
}

console.log('2) two 23-key panels: alarm a14 (A) <-> 20-pole custom (B)');
{
  /* B: places 1..12 normal, 13/14 curtain open/close, 15 custom scenario, 16..20 normal, EXIT, -, SLEEP */
  const type = Array(23).fill(1), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
  type[12] = type[13] = 7; off[12] = 1 << 13; off[13] = 1 << 12; sec1[12] = sec1[13] = 6; sec2[12] = sec2[13] = 5;
  type[14] = C.T_CUSTOM; on[14] = 1 << 4 | 1 << 5; off[14] = 1 << 6;
  type[20] = C.T_EXIT; sec1[20] = 3; off[20] = 0xFFF; type[21] = 0; type[22] = C.T_SLEEP; sec1[22] = 60; off[22] = 0xFFF & ~1; on[22] = 1;
  const lB = Array(23).fill(-1); lB[0] = 0; lB[19] = 10;     /* B1 <-> A1, B20 <-> A11 (key 19: third chunk) */
  const cB = { type, sec1, sec2, offmask: off, onmask: on, remote: false, nslot: 0, alarm: 0, dimsec: 0, stagMs: 100, role: 1,
    lay: 'LLLLLLLLLLLLUWSLLLLLX-Z', mdl: 'pc', link: lB };
  const pB = C.buildPx({ on: Object.assign(Array(23).fill(0), { 14: [6, 7] }), off: Object.assign(Array(23).fill(0), { 14: [8] }) }, true);
  const lA = Array(23).fill(-1); lA[0] = 0; lA[10] = 19;
  const cA = a14({ role: 0, link: lA, remote: false, nslot: 0 });
  /* A EXIT also: B places 2..4 off, B curtain close (key 13) */
  const pA = C.buildPx({ on: Object.assign(Array(23).fill(0), { 20: [13] }), off: Object.assign(Array(23).fill(0), { 20: [1, 2, 3] }), pmdl: 'pc', play: cB.lay, pnp: 23, wifi: 1 }, true);
  const eeB = new EEPROMMemoryBackend(2048);
  const A = M.bigNode(cA, 'fw_big_a_six_p', pA), Bn = M.bigNode(cB, 'fw_big_six_p', pB, eeB);
  M.bus([A, Bn], true);
  run(4000);
  tap(A, 0);
  let t = until(1000, () => red(Bn, 0));
  check(t > 0, `A place 1 -> B place 1 (${t} ms)`);
  tap(Bn, 19);
  t = until(1000, () => red(A, 10));
  check(t > 0, `B place 20 (third block of keys) -> A place 11 (${t} ms)`);
  /* B custom scenario: B 5, 6 on, B 7 off; A 7, 8 on, A 9 off */
  tap(A, 8); tap(Bn, 6); run(800);
  check(red(A, 8) && red(Bn, 6), 'before: A place 9 and B place 7 on');
  tap(Bn, 14);
  t = until(3000, () => red(Bn, 4) && red(Bn, 5) && !red(Bn, 6) && red(A, 6) && red(A, 7) && !red(A, 8));
  check(t > 0, `B custom scenario: B 5,6 on, 7 off; A 7,8 on, 9 off (${t} ms): A ${reds(A)} B ${reds(Bn)}`);
  /* A EXIT (20 s): B places 2..4 off and B curtain close */
  tap(Bn, 1); tap(Bn, 2); tap(Bn, 3); run(600);
  tap(A, 20);
  run(18000);
  check(red(Bn, 1) && red(Bn, 2), 'A EXIT running: B places 2, 3 still on');
  t = until(8000, () => !red(Bn, 1) && !red(Bn, 2) && !red(Bn, 3) && red(Bn, 13));
  check(t > 0, `A EXIT over: B places 2..4 off, B curtain closing (${(18 + t / 1000).toFixed(1)} s)`);
  t = until(9000, () => !red(Bn, 13));
  check(t > 0, `B curtain stops after its 6 s (${t} ms)`);
  /* power cut of B: place 20 back from A (third block of keys) */
  tap(A, 10); run(800);
  const on20 = red(A, 10);
  const B2 = M.bigNode(cB, 'fw_big_six_p', pB, eeB); M.bus([A, B2], true);
  t = until(8000, () => red(B2, 19) === on20 && red(B2, 0) === red(A, 0));
  check(t > 0, `B after a power cut: places 1 and 20 back from A (${t} ms)`);
  check(A.bd.b.overrun === 0 && B2.bd.b.overrun === 0, 'no byte lost on either ATmega64');
  console.log('  stack: free RAM never used by the stack:', M.stackGap(A), 'and', M.stackGap(B2), 'bytes');
  check(M.stackGap(A) > 150, 'ATmega64 RAM: more than 150 bytes never reached by the stack');
}

console.log('3) 2-pole panel (ATmega8) <-> 23-key panel');
{
  const c2 = { role: 1, npoles: 2, peerpoles: 23, remote: false, type: [1, 1, 0, 0], link: [5, 6, -1, -1], offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0 };
  const P = M.m8Node(c2, 'fw_2p_px', C.buildPx({}, false));
  const lA = Array(23).fill(-1); lA[5] = 0; lA[6] = 1;
  const A = M.bigNode(a14({ role: 0, link: lA }), 'fw_big_a_six_p', C.buildPx({ pnp: 2, play: 'LL', pmdl: 'p2' }, true));
  M.bus([A, P], true);
  run(4000);
  tap(P, 0);
  let t = until(1000, () => red(A, 5));
  check(t > 0 && r4(P)[0] === 1, `2-pole pole 1 -> place 6 (${t} ms)`);
  tap(A, 6);
  t = until(1000, () => r4(P)[1] === 1);
  check(t > 0, `place 7 -> 2-pole pole 2 (${t} ms)`);
}

console.log(`\n${checks - fails}/${checks} passed`); process.exit(fails ? 1 : 0);
