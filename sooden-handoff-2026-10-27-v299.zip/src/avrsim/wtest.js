var fs=require('fs');const {JSDOM}=require('jsdom');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
const dom=new JSDOM(fs.readFileSync('/home/claude/out/sooden-programmer.html','utf8'),{runScripts:'dangerously'});
const w=dom.window,d=w.document; w.URL.createObjectURL=()=>'x';
w.eval('const __p=patchHex; patchHex=function(a,b){const r=__p(a,b); window.__last=r; return r;}');
const click=s=>{const e=d.querySelector(s); if(!e) throw new Error('missing '+s); e.click();};
// pair: A=P4 service on pole4 (off 1, on 3), B=P2, link A1-B2, A3-B1
click('.choice[data-k="pair"]');
click('.lib[data-side="A"] .mdl[data-id="P4"]'); click('.lib[data-side="B"] .mdl[data-id="P2"]'); click('#next');
const sel=d.querySelector('select.ptype[data-p="A"][data-i="3"]'); sel.value='t'; sel.dispatchEvent(new w.Event('change'));
click('input[data-pk="off"][data-p="A"][data-i="3"][data-k="0"]'); click('input[data-pk="on"][data-p="A"][data-i="3"][data-k="2"]');
const tm=d.querySelector('.tmin[data-p="A"][data-i="3"]'); tm.value='1'; tm.dispatchEvent(new w.Event('input'));
click('button.kk[data-s="A"][data-i="0"]'); click('button.kk[data-s="B"][data-i="1"]');
click('button.kk[data-s="A"][data-i="2"]'); click('button.kk[data-s="B"][data-i="0"]');
click('#next');
const dl=i=>{w.__last=null; click(`[data-dl="${i}"]`); return w.__last;};
const hA=dl(0),hB=dl(1);
check(!!hA&&!!hB,'wizard pair produced two hex files');
const A=makeNode(hA),B=makeNode(hB);A.board=1;B.board=0;nodes=[A,B];connect(true);run(800 + 1440);
tap(A,0);run(300);check(r4(A)[0]===1&&eq(o2(B),[0,1]),'A1 -> B2');
tap(A,3);run(1000);check(r4(A)[0]===0&&r4(A)[2]===1&&r4(A)[3]===1&&eq(o2(B),[1,0]),'service: A1 off(B2 off), A3 on(B1 on), A4 relay');
run(61000);check(r4(A)[2]===0&&r4(A)[3]===0&&eq(o2(B),[0,0]),'timer end');
// single remote P4
click('.pc[data-i="0"]'); click('.choice[data-k="single"]'); click('.choice[data-v="true"]');
click('.choice[data-k="remote"]'); click('.mdl[data-id="P4"]'); click('#next');
const hS=dl(0); const mS=core.parseHex(hS);
check(mS.get(0x1F80+7)===1&&[12,13,14,15].every(k=>mS.get(0x1F80+k)===0xFF),'single remote: remote on, no links');
const S1=makeNode(hS);S1.board=1;nodes=[S1];connect(false);run(500 + 1440);tap(S1,1);run(200);check(r4(S1)[1]===1,'single panel works alone');
// no crystal -> no models
click('.pc[data-i="0"]'); click('.choice[data-k="single"]'); click('.choice[data-v="false"]');
check([...d.querySelectorAll('.mdl[data-ok="1"]')].map(e=>e.dataset.id).join()==='P4','no-crystal: 4 pole only (tiny13 archived)');
console.log(checks+' checks, '+fails+' failed');
