// End to end: the hex files the programmer made (itest14) on simulated boards: 4-pole A + alarm panel a14 B
const fs = require('fs');
const M = require('./mix'); const { run, tap, red, until } = M;
const DIR = process.argv[2];
let fails = 0, checks = 0;
const check = (c, m) => { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); };
const A = M.m8(fs.readFileSync(DIR + '/A.hex', 'utf8'), null, 1);
const bd = M.B.makeBoard(fs.readFileSync(DIR + '/B.hex', 'utf8')); bd.b.cpu.data[0x54] = 1; bd.b.C.setPin(4, true);
const B = { kind: 'big', bd, cpu: bd.b.cpu, usart: bd.b.usart1, cpus: [[bd.a.cpu, 16, 0], [bd.b.cpu, 16, 0]] };
M.bus([A, B], true);
run(4000);
tap(A, 0);
let t = until(1500, () => red(B, 2));
check(t > 0, `A pole 1 -> B place 3 (${t} ms)`);
tap(A, 0); until(1500, () => !red(B, 2));              /* everything off again */
tap(A, 2);
t = until(3000, () => [4, 5, 6, 7, 8, 9, 10, 11].every(k => red(B, k)) && red(A, 0) && red(A, 1) && red(B, 2));
check(t > 0, `A master (pole 3): its own poles 1, 2 (pole 1 with B place 3) and B places 5..12 on (${t} ms)`);
tap(A, 2);
t = until(3000, () => [4, 5, 6, 7, 8, 9, 10, 11].every(k => !red(B, k)));
check(t > 0, `A master again -> all off (${t} ms)`);
tap(A, 3);
t = until(1500, () => red(B, 3));
check(t > 0 && red(A, 3), `A service (pole 4) -> B place 4 (hood) on (${t} ms)`);
run(300); if (!red(A, 1)) tap(A, 1); run(300);
check(red(A, 1), 'A pole 2 on before the EXIT');
tap(B, 20);                                   /* EXIT 20 s (programmer default) */
t = until(26000, () => !red(A, 1));
check(t > 15000, `B EXIT -> A pole 2 off after the EXIT time (${(t / 1000).toFixed(1)} s)`);
console.log(`\n${checks - fails}/${checks} passed`); process.exit(fails ? 1 : 0);
