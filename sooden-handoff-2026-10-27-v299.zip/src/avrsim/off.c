#include <stddef.h>
#include <stdint.h>
#include "cfg.h"
const uint16_t off[] = { offsetof(Cfg, type), offsetof(Cfg, link), offsetof(Cfg, offmask), offsetof(Cfg, onmask), offsetof(Cfg, minutes),
  offsetof(Cfg, sec1), offsetof(Cfg, sec2), offsetof(Cfg, beep), offsetof(Cfg, dimsec), offsetof(Cfg, rmap), offsetof(Cfg, tmin), offsetof(Cfg, tdef),
  offsetof(Cfg, alArm), offsetof(Cfg, lay), offsetof(Cfg, mdl), offsetof(Cfg, room), offsetof(Cfg, rooms), sizeof(Cfg), SW_NP, N_SLOTS, sizeof(rm_t) };
