// Mixed two-panel network: 23-key boards (ATmega32 + ATmega64, USART1 = RS485) and ATmega8 panels on one RS485 line
const { step } = require('./step');
const fs = require('fs');
const B = require('./big'); const C = B.core;
const { CPU, avrInstruction, AVRIOPort, AVRUSART, AVREEPROM, EEPROMMemoryBackend } = require('avr8js');
const MS = 8000, CHAR = 8 * 1042;
const FWD = '/home/claude/fw/out/';
const hex = n => fs.readFileSync(FWD + n + '.hex', 'utf8');
const T2 = { address: 3, flagRegister: 0x58, flagMask: 0x80, enableRegister: 0x59, enableMask: 0x80 };

/* ATmega8 panel (as test.js) */
function m8(hexText, ee, board) {
  const mem = C.parseHex(hexText), prog = new Uint16Array(4096);
  for (const [a, v] of mem) { if (a & 1) prog[a >> 1] |= v << 8; else prog[a >> 1] |= v; }
  const cpu = new CPU(prog, 1024);
  const pb = new AVRIOPort(cpu, { PIN: 0x36, DDR: 0x37, PORT: 0x38, externalInterrupts: [] });
  const pc = new AVRIOPort(cpu, { PIN: 0x33, DDR: 0x34, PORT: 0x35, externalInterrupts: [] });
  const pd = new AVRIOPort(cpu, { PIN: 0x30, DDR: 0x31, PORT: 0x32, externalInterrupts: [] });
  const usart = new AVRUSART(cpu, { rxCompleteInterrupt: 11, dataRegisterEmptyInterrupt: 12, txCompleteInterrupt: 13,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x40, UBRRL: 0x29, UBRRH: 0x5C, UDR: 0x2C }, 8e6);
  new AVREEPROM(cpu, ee || new EEPROMMemoryBackend(512), { eepromReadyInterrupt: 15, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 34000, writeCycles: 34000 });
  const t2 = () => { if (cpu.data[0x45] & 7) cpu.setInterruptFlag(T2); cpu.addClockEvent(t2, MS); };
  cpu.addClockEvent(t2, MS);
  let t1hi = 0;
  cpu.readHooks[0x4C] = () => { const v = Math.floor(cpu.cycles / 8) & 0xFFFF; t1hi = v >> 8; return v & 0xFF; };
  cpu.readHooks[0x4D] = () => t1hi;
  for (let i = 0; i < 8; i++) { pb.setPin(i, true); pc.setPin(i, true); pd.setPin(i, true); }
  pd.setPin(3, false);
  return { kind: 'm8', cpu, pb, pc, pd, usart, board: board === undefined ? 1 : board, cpus: [[cpu, 400, 0xFFF]] };
}
function bigNode(cfg, fw, pxb, ee) {
  let text = C.patchHexAt(hex(fw), C.buildCfgBig(cfg), C.BIG_ADDR);
  if (pxb) text = C.patchHexAt(text, pxb, C.PX_ADDRB);
  const bd = B.makeBoard(text, ee);
  bd.b.cpu.data[0x54] = 1;
  /* free RAM painted: the deepest stack use can be read at the end (stackGap) */
  const nm = require('child_process').execSync(`$HOME/tc/avr-gcc-14.1.0-x64-linux/bin/avr-nm ${FWD}${fw}.elf`).toString();
  const bss = parseInt(nm.match(/^([0-9a-f]+) . __bss_end$/m)[1], 16) & 0xFFFF;
  for (let a = bss; a < 0x1100; a++) bd.b.cpu.data[a] = 0xA5;
  bd.bssEnd = bss;
  bd.b.C.setPin(4, true);                                   /* PIR idle */
  return { kind: 'big', bd, cpu: bd.b.cpu, usart: bd.b.usart1, cpus: [[bd.a.cpu, 16, 0], [bd.b.cpu, 16, 0]] };
}
function m8Node(cfg, fw, pxb, ee) {
  let text = C.patchHex(hex(fw), C.buildCfg(cfg));
  if (pxb) text = C.patchHexAt(text, pxb, C.PX_ADDR4);
  return m8(text, ee, cfg.npoles <= 2 ? 0 : 1);
}

let NODES = [], CUT = false;
function bus(nodes, echo) {
  NODES = nodes;
  nodes.forEach((n, i) => {
    n.txFree = 0;
    n.usart.onByteTransmit = b => {
      if (CUT) return;
      /* one character time per byte, as on the wire (the simulated UART hands bytes over at once) */
      n.txFree = Math.max(n.txFree, n.cpu.cycles) + CHAR;
      const delay = n.txFree - n.cpu.cycles;
      for (let j = 0; j < nodes.length; j++) if (j !== i || echo) {
        const r = nodes[j];
        r.cpu.addClockEvent(() => r.usart.writeByte(b, true), Math.max(1, delay));   /* (each chip counts its own cycles) */
      }
    };
  });
}
function cut(v) { CUT = v; }
/* every chip advances in the same small steps of time (the clocked link of the 23-key board needs 16 cycles) */
function run(ms) {
  const all = []; NODES.forEach(n => n.cpus.forEach(c => all.push(c)));
  const st = all.map(([c]) => c.cycles), total = ms * MS;   /* each chip from its own count (a restarted one starts at 0) */
  for (let el = 0; el < total;) {
    el = Math.min(el + 16, total);
    all.forEach(([c, , wrap], k) => { const t = st[k] + el; while (c.cycles < t) step(c, wrap); });
  }
}
/* ATmega8 4P inputs / outputs */
const CODE4 = [7, 0, 3, 4];
function touch8(n, pole, on) {
  if (n.board === 1) {
    const c = CODE4[pole];
    if (on) { n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); }
    else { n.pc.setPin(2, true); n.pc.setPin(3, true); n.pc.setPin(4, true); n.pc.setPin(5, true); }
  } else { if (pole === 0) n.pb.setPin(5, !on); else n.pd.setPin(4, !on); }
}
const outBit = (port, cpu, bit) => { const ddr = cpu.data[port.portConfig.DDR], prt = cpu.data[port.portConfig.PORT]; return (ddr >> bit) & 1 ? (prt >> bit) & 1 : -1; };
const r4 = n => { const c = n.cpu; return n.board === 1 ? [outBit(n.pb, c, 2), outBit(n.pd, c, 7), outBit(n.pc, c, 1), outBit(n.pd, c, 6)] : [outBit(n.pb, c, 3), outBit(n.pb, c, 4)]; };
const w4 = n => { const c = n.cpu; return [outBit(n.pb, c, 1), outBit(n.pb, c, 0), outBit(n.pc, c, 0), outBit(n.pd, c, 5)]; };
function tap(n, k, holdMs) {
  if (n.kind === 'm8') { touch8(n, k, true); run(holdMs || 60); touch8(n, k, false); run(60); }
  else { B.touch(n.bd, k, true); run(holdMs || 60); B.touch(n.bd, k, false); run(60); }
}
const red = (n, k) => n.kind === 'm8' ? r4(n)[k] === 1 : !!B.red(n.bd, k);
/* keys whose red (relay) is on; key 16 of an alarm panel is the sensor input (pull-up), not a relay */
const reds = n => n.kind === 'm8' ? r4(n).map((v, k) => v === 1 ? k : -1).filter(k => k >= 0).join(',') : [...Array(23).keys()].filter(k => B.red(n.bd, k) && !(k === 16 && n.bd.b.cpu.data[0x34] !== undefined && !((n.bd.b.cpu.data[0x34] >> 4) & 1))).join(',');
/* watch until f() or ms; returns ms taken or -1 */
function until(ms, f, step = 10) { for (let t = 0; t < ms; t += step) { run(step); if (f()) return t + step; } return -1; }
function stackGap(n) { const d = n.cpu.data; let a = n.bd.bssEnd; while (a < 0x1100 && d[a] === 0xA5) a++; return a - n.bd.bssEnd; }
module.exports = { stackGap, B, C, m8, bigNode, m8Node, bus, cut, run, touch8, tap, red, reds, r4, w4, until, hex };
