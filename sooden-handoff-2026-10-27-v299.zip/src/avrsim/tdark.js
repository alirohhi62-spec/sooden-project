// 23-key board: the whites go dark, and come back, one key at a time (50 ms, place 1 first)
const B = require('./big'); const { run, check } = B;
const t = Array(23).fill(1);
const bd = B.boardWith({ type: t, onmask: Array(23).fill(0), remote: true, nslot: 4, dimsec: 3, stagMs: 100 }, 'fw_big');
run(bd, 1800);
const lit = () => [...Array(23).keys()].filter(k => B.white(bd, k));
const trace = ms => { const ev = []; let last = lit().join(); for (let i = 0; i < ms; i++) { run(bd, 1); const l = lit(); if (l.join() !== last) { ev.push([i, l]); last = l.join(); } } return ev; };
let ev = trace(5000);
const goneOrder = ev.map((e, j) => (j ? ev[j - 1][1] : [...Array(23).keys()].filter(k => k !== 21)).filter(k => !e[1].includes(k))).flat();
const gaps = ev.slice(1).map((e, j) => e[0] - ev[j][0]);
check(goneOrder.join() === [...Array(23).keys()].filter(k => k !== 21).join(), 'dark: place 1, 2, 3 … 20, scenario 1, scenario 3 (' + goneOrder.join(' ') + ')');
check(gaps.every(g => g >= 45 && g <= 105), 'about 50 ms apart (100 across the centre key, which has no LED): ' + gaps.join(' '));
B.touch(bd, 5, true); run(bd, 5); B.touch(bd, 5, false);
ev = trace(1500);
const backOrder = ev.map((e, j) => e[1].filter(k => !(j ? ev[j - 1][1] : []).includes(k))).flat();
check(backOrder.join() === [...Array(23).keys()].filter(k => k !== 21).join(), 'light again: same order (' + backOrder.join(' ') + ')');
check(B.red(bd, 5) === 0 && ev[0][0] <= 60, 'the touch only lit the panel; first white back within 60 ms (' + ev[0][0] + ' ms)');
console.log(`\n${B.stats().checks} checks, ${B.stats().fails} failed`);
