// 23-key alarm panel on the real ATmega32 + ATmega64 hex: keypad alarm, EXIT / SLEEP / ELEVATOR, lock, dark panel
const B = require('./big');
const { run, touch, tap, red, white, check, rfSend } = B;
const C = B.core;
/* layout a14: places 1..12 poles, 13 ON/OFF, 14 change pass, 15..18 digits 1..4, 19/20 curtain, S1 EXIT, S2 ELEVATOR, S3 SLEEP */
const type = Array(23).fill(1), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
type[12] = C.T_ALON; type[13] = C.T_ALPW;
[14, 15, 16, 17].forEach((k, d) => { type[k] = C.T_KEY; sec1[k] = d + 1; });
type[18] = type[19] = 7; off[18] = 1 << 19; off[19] = 1 << 18; sec1[18] = sec1[19] = 6; sec2[18] = sec2[19] = 5;
const relays = (1 << 12) - 1 | 1 << 18 | 1 << 19;
type[20] = C.T_EXIT; sec1[20] = 20; off[20] = relays & ~(1 << 19); on[20] = 1 << 19;          /* EXIT 20 s, closes the curtain */
type[21] = C.T_ELEV; on[21] = 1 << 20;                                                       /* elevator relay on S1's red pin */
type[22] = C.T_SLEEP; sec1[22] = 30; off[22] = relays & ~(1 << 5); on[22] = 1 << 5;           /* SLEEP 30 s, night light = pole 6 */
const A = 0x5A3C10;
const rmap = [Array(16).fill(0), Array(16).fill(0), Array(16).fill(0), Array(16).fill(0)];
rmap[0][1] = 1 << 2;                                                                         /* remote button 1 -> pole 3 */
const cfg = { type, sec1, sec2, offmask: off, onmask: on, remote: true, nslot: 4, alarm: 1, alArm: 3, alEntry: 5, alSiren: 4, dimsec: 12, stagMs: 100, rmap };
const ee = new (require('avr8js').EEPROMMemoryBackend)(2048);
let bd = B.boardWith(cfg, 'fw_big_a_six', ee);
const siren = () => (bd.b.cpu.data[B.PORTADDR.D] >> 4) & 1;
const sirenDDR = () => (bd.b.cpu.data[B.DDRADDR.D] >> 4) & 1;
const pir = act => bd.b.C.setPin(4, !!act);   /* normally closed sensor: high = someone (or wire cut) */
const digits = () => [14, 15, 16, 17].map(k => white(bd, k)).join('');
const code = (...d) => { d.forEach(x => tap(bd, 13 + x)); run(bd, 450); };   /* the reds follow 0.5 s after the last digit */
const wake = () => { if (!white(bd, 12)) { tap(bd, 12); run(bd, 50); tap(bd, 12); run(bd, 50); } };   /* dark: a touch only lights; close the keypad again */
/* siren pulses within ms: [[start, length], ...] */
const pulses = ms => { const a = []; let on = 0; for (let i = 0; i < ms; i++) { run(bd, 1); const v = siren(); if (v && !on) a.push([i, 0]); if (v) a[a.length - 1][1]++; on = v; } return a; };
const measure = (ms, f) => { let first = -1, n = 0; for (let i = 0; i < ms; i++) { run(bd, 1); if (f()) { if (first < 0) first = i; n++; } } return [first, n]; };
pir(false);

console.log('1) power-up, keypad lights');
run(bd, 1800);
check(digits() === '1111' && white(bd, 12) && white(bd, 13), 'after power-up: digits lit, ON/OFF and change pass lit');
check(sirenDDR() === 1 && siren() === 0, 'siren pin: output, off');
run(bd, 10000);
check(digits() === '0000' && white(bd, 12) && white(bd, 13), '10 s later: digits dark, 13/14 still lit');
let bz = 0; touch(bd, 14, true); for (let i = 0; i < 80; i++) { run(bd, 1); bz |= B.buzzer(bd); } touch(bd, 14, false); run(bd, 80);
check(!bz && digits() === '0000', 'digit while dark: ignored, no beep');

touch(bd, 0, true); run(bd, 5300); touch(bd, 0, false); run(bd, 200);
rfSend(bd, A | 1, 3, 350); run(bd, 2500);
rfSend(bd, A | 1, 3, 350); run(bd, 300); check(red(bd, 2) === 1, 'remote learned on place 1: button 1 -> pole 3');
rfSend(bd, A | 1, 3, 350); run(bd, 300);
console.log('2) arming');
tap(bd, 12); check(digits() === '1111', 'touch 13: digits lit');
bz = 0; touch(bd, 14, true); for (let i = 0; i < 80; i++) { run(bd, 1); bz |= B.buzzer(bd); } touch(bd, 14, false); run(bd, 80);
check(bz === 1, 'digit touch beeps');
tap(bd, 15); tap(bd, 16); touch(bd, 17, true);
let tr = -1, bzOn = -1, bzOff = -1; for (let i = 0; i < 900; i++) { run(bd, 1); if (i === 60) touch(bd, 17, false); if (tr < 0 && red(bd, 12)) tr = i; if (bzOn < 0 && B.buzzer(bd)) bzOn = i; if (bzOn >= 0 && bzOff < 0 && !B.buzzer(bd)) bzOff = i; }
check(tr > 470 && tr < 560 && bzOn >= 0 && bzOff > bzOn && bzOff < tr, `last digit: 13 red 0.5 s later (${tr} ms), after its beep (${bzOn}-${bzOff} ms)`);
const tArm = bd.a.cpu.cycles / 8000 - 900;   /* the last digit was touched here */
check(digits() === '0000' && red(bd, 12) === 1, 'right password: digits dark, 13 red (arming)');
let [t0, len] = measure(4000, siren);
const dArm = Math.round(bd.a.cpu.cycles / 8000 - 4000 + t0 - tArm);
check(dArm > 2900 && dArm < 3150 && len > 450 && len < 560, `armed 3 s after the password: one siren beep (${dArm} ms, ${len} ms)`);
{ const tq = bd.b.cpu.cycles / 8000; pir(true); run(bd, 300); pir(false); run(bd, 300); check(tq > 60000 || digits() === '0000', 'first minute after power-up: the sensor is ignored');
  if (tq < 60000) run(bd, 60000 - tq + 200); }
pir(true); run(bd, 50); pir(false); run(bd, 500);
check(digits() === '0000', 'sensor shorter than 100 ms: ignored');

console.log('3) someone comes in: entry time, wrong password, siren, re-arm');
pir(true); run(bd, 300); pir(false); run(bd, 1000);   /* (the panel went dark in the first minute: the whites come back one at a time) */
check(digits() === '1111', 'sensor: digits light by themselves');
let blink = 0, last = red(bd, 12); for (let i = 0; i < 1200; i++) { run(bd, 1); if (red(bd, 12) !== last) { blink++; last = red(bd, 12); } }
check(blink >= 3, '13 red blinks during the entry time');
code(1, 1, 1, 1); run(bd, 50);
check(digits() === '0000' && siren() === 0, 'wrong password: digits go dark, no siren');
code(1, 2, 3, 4); check(siren() === 0 && digits() === '0000', 'digits while dark: nothing');
let p = pulses(12000);
check(p.length === 2 && p[0][0] > 0 && p[0][0] < 4000, `entry time over: siren (${JSON.stringify(p)})`);
check(p.length === 2 && Math.abs(p[0][1] - 4000) < 60, 'siren sounds 4 s');
check(p.length === 2 && Math.abs(p[1][0] - p[0][0] - p[0][1] - 2000) < 60 && Math.abs(p[1][1] - 500) < 40, '2 s quiet, then a 0.5 s beep');
check(siren() === 0 && red(bd, 12) === 1, 'after the siren (2 s quiet + 0.5 s beep): armed again');

console.log('4) right password in the entry time');
pir(true); run(bd, 300); pir(false); run(bd, 500);
code(1, 2, 3, 4); run(bd, 100);
check(red(bd, 12) === 0 && digits() === '0000', 'disarmed: 13 red and digits off');
[t0, len] = measure(8000, siren); check(len === 0, 'no siren later');
pir(true); run(bd, 300); pir(false); run(bd, 300); check(digits() === '0000', 'disarmed: sensor ignored');

console.log('5) siren stopped with the password');
wake(); tap(bd, 12); code(1, 2, 3, 4); run(bd, 4000);
pir(true); run(bd, 300); pir(false); run(bd, 5500);
check(siren() === 1, 'siren on');
tap(bd, 12); code(1, 2, 3, 4); run(bd, 50);
check(siren() === 0 && red(bd, 12) === 0, '13 + password: siren off, disarmed');

console.log('6) change password, kept over a power cut');
tap(bd, 12); code(1, 2, 3, 4); run(bd, 200);
touch(bd, 13, true); run(bd, 2300); touch(bd, 13, false); run(bd, 100);
check(red(bd, 13) === 0, 'armed: holding 14 does nothing');
tap(bd, 12); code(1, 2, 3, 4); run(bd, 100);
touch(bd, 13, true); run(bd, 1500); check(red(bd, 13) === 0, 'held 1.5 s: not yet');
run(bd, 700); touch(bd, 13, false); run(bd, 100);
check(red(bd, 13) === 1 && digits() === '1111', 'held 2 s while disarmed: 14 red, digits lit (no old password asked)');
code(4, 3, 2, 1); run(bd, 300);
check(red(bd, 13) === 0 && digits() === '0000', 'new password saved');
tap(bd, 12); code(1, 2, 3, 4); run(bd, 100); check(red(bd, 12) === 0, 'old password no longer arms');
tap(bd, 12); code(4, 3, 2, 1); run(bd, 100); check(red(bd, 12) === 1, 'new password arms');
bd = B.boardWith(cfg, 'fw_big_a_six', ee); pir(false); run(bd, 1800);
check(red(bd, 12) === 1, 'power cut while armed: arms again');
run(bd, 4000);
tap(bd, 12); code(4, 3, 2, 1); run(bd, 100); check(red(bd, 12) === 0, 'new password kept over the power cut');
tap(bd, 12); run(bd, 10500); check(digits() === '0000' && white(bd, 12) === 1, 'keypad closes 10 s after the last touch');

console.log('7) EXIT under 1 min: panel locked, the alarm still works');
wake();
tap(bd, 0); tap(bd, 1); tap(bd, 18); run(bd, 400);
check(red(bd, 0) && red(bd, 1) && red(bd, 18), 'poles 1, 2 and curtain open on');
const ms = () => bd.b.cpu.cycles / 8000;
const tExit = ms(); tap(bd, 20); run(bd, 200);
check(white(bd, 20) === 1, 'EXIT running: scenario 1 white stays (its red pin is the elevator relay)');
tap(bd, 2); run(bd, 200); check(red(bd, 2) === 0, 'locked: touch ignored');
rfSend(bd, A | 1, 3, 350); run(bd, 300); check(red(bd, 2) === 0, 'locked: remote ignored too');
tap(bd, 12); code(4, 3, 2, 1); run(bd, 100); check(red(bd, 12) === 1, 'locked panel: the alarm arms');
tap(bd, 12); code(4, 3, 2, 1); run(bd, 100); check(red(bd, 12) === 0, 'and disarms');
let k = 0; while (red(bd, 0) && k < 25000) { run(bd, 10); k += 10; }
const dExit = Math.round(ms() - tExit);
check(dExit > 19000 && dExit < 21200, `EXIT ends after about 20 s (${dExit} ms)`);
run(bd, 1500);
check(!red(bd, 0) && !red(bd, 1) && !red(bd, 18) && red(bd, 19), 'all off, the curtain closes');
tap(bd, 2); run(bd, 200); check(red(bd, 2) === 1, 'unlocked after');

console.log('8) elevator on scenario 2 (relay on scenario 1 red pin)');
wake();
tap(bd, 21); run(bd, 300); check(red(bd, 20) === 0, 'short touch: nothing');
touch(bd, 21, true); let eb = -1; t0 = -1; len = 0;
for (let i = 0; i < 2500; i++) { run(bd, 1); if (eb < 0 && B.buzzer(bd)) eb = i; if (red(bd, 20)) { if (t0 < 0) t0 = i; len++; } }
touch(bd, 21, false); run(bd, 100);
check(eb >= t0 && eb < t0 + 30, `elevator beep with the relay, not at the touch (beep ${eb} ms, relay ${t0} ms)`);
check(t0 > 950 && t0 < 1100 && len > 950 && len < 1060, `held: relay on after 1 s, for 1 s (${t0} / ${len} ms)`);

console.log('9) SLEEP 30 s, night light, dark panel');
wake();
tap(bd, 2); run(bd, 300);
tap(bd, 22); run(bd, 200);
check(red(bd, 22) === 1 && white(bd, 22) === 0, 'SLEEP running: scenario 3 red on, its white off');
check(white(bd, 20) === 1, 'scenario 1 white on');
k = 0; while (red(bd, 22) && k < 35000) { run(bd, 10); k += 10; }
run(bd, 1000);
check(red(bd, 5) === 1 && red(bd, 2) === 0 && white(bd, 22) === 1, `SLEEP over after ${k} ms: pole 3 off, night light (pole 6) on`);
run(bd, 13000);
const lit = [...Array(23).keys()].filter(i => white(bd, i));
check(lit.length === 0 && red(bd, 5) === 1, 'night light on: the panel still goes dark (' + lit + ')');
tap(bd, 0); run(bd, 200);
check(red(bd, 0) === 0 && white(bd, 0) === 1, 'touch on the dark panel: only lights it');
tap(bd, 0); run(bd, 200); check(red(bd, 0) === 1, 'second touch acts');
tap(bd, 0); run(bd, 13500); check(white(bd, 0) === 0, 'dark again');
rfSend(bd, A | 1, 3, 350); run(bd, 300);
check(red(bd, 2) === 1, 'remote on the dark panel: lights it and acts at once');
tap(bd, 2); tap(bd, 5); tap(bd, 12); code(4, 3, 2, 1); run(bd, 16000);
check(white(bd, 0) === 0 && red(bd, 12) === 1, 'alarm armed: the panel still goes dark (13 red stays)');
pir(true); run(bd, 300); pir(false); run(bd, 1000);
check(digits() === '1111' && white(bd, 0) === 1, 'sensor on the dark panel: lights it (one key at a time), digits ready');
run(bd, 14500); check(white(bd, 0) === 1, 'entry time / siren: the panel stays lit');
console.log(`\n${B.stats().checks} checks, ${B.stats().fails} failed`);
