// Fake ESP8266 (AT firmware 1.x, ATE1) on the ATmega64 USART0 of the simulated 23-key board, plus fake phones.
// Powered while the ATmega32 PD5 (MP2315 EN) is high.
const CHAR = 8 * 1042;                                   /* one character at 9600 baud, in CPU cycles */
function attachEsp(bd, opt = {}) {
  const cpu = bd.b.cpu, u = bd.b.usart;
  const E = { on: false, cmds: [], raw: [], phones: {}, staIp: '0.0.0.0', mac: '5c:cf:7f:aa:bb:cc', ap: null, mode: 0, server: 0,
    log: opt.log || false, txFree: 0, lineBuf: '', sendTo: -1, sendLeft: 0, sendBuf: [], errOn: opt.errOn || {},
    /* SNTP: sntp 'ok' (AT firmware with SNTP) / 'none' (old firmware: ERROR); net = internet reachable;
       utc0 + simulated ms + skew = UTC now; router = joins its saved router by itself after a start */
    sntp: opt.sntp || 'ok', net: opt.net !== undefined ? opt.net : true, utc0: opt.utc0 || Date.UTC(2026, 9, 14, 16, 0, 0), skew: 0,
    router: opt.router || false, sntpCfgAt: -1, sntpAsks: [],
    /* the home router: saved = the station settings kept in the module (AT+CWJAP), routerOn = the router is powered;
       curMode = the mode now (AT+CWMODE_CUR), qap = station stopped by AT+CWQAP; resets = AT+RST count */
    saved: opt.router ? ['HomeNet', 'pass1234'] : null, routerOn: opt.routerOn !== undefined ? opt.routerOn : true,
    curMode: 3, qap: false, resets: 0 };
  /* the module keeps looking for a saved router that is off: its own network then hardly works */
  E.scanning = () => E.on && !!E.saved && !E.routerOn && (E.curMode & 1) && !E.qap && E.staIp === '0.0.0.0';
  /* "a","b\"c",1,4 -> ['a','b"c','1','4'] (AT escapes) */
  E.args = str => { const a = []; let i = 0;
    while (i < str.length) {
      if (str[i] === '"') { let v = ''; i++; while (i < str.length && str[i] !== '"') { if (str[i] === '\\') i++; v += str[i++]; } i++; a.push(v); }
      else { let v = ''; while (i < str.length && str[i] !== ',') v += str[i++]; a.push(v); }
      if (str[i] === ',') i++;
    }
    return a; };
  E.utcNow = () => E.utc0 + cpu.cycles / 8000 + E.skew;
  /* bytes to the panel, one character time apart */
  E.out = str => { if (E.hung) return; if (E.tap) E.tap(str);
    const bytes = typeof str === 'string' ? [...Buffer.from(str, 'utf8')] : str;
    for (const b of bytes) {
      E.txFree = Math.max(E.txFree, cpu.cycles) + CHAR;
      cpu.addClockEvent(() => { if (E.on) u.writeByte(b, true); }, E.txFree - cpu.cycles);
    }
  };
  const later = (ms, f) => cpu.addClockEvent(() => { if (E.on) f(); }, ms * 8000);
  E.boot = () => {
    E.out([0x55, 0xAA, 0x12, 0x00]); E.out('\r\nets Jan  8 2013\r\n'); E.out('\r\nready\r\n');
    E.sntpCfgAt = -1;
    E.curMode = 3; E.qap = false; E.staIp = '0.0.0.0';
    if (E.saved && E.routerOn) later(2500, () => { if (E.routerOn && E.staIp === '0.0.0.0') { E.staIp = '192.168.1.50'; E.out('WIFI CONNECTED\r\nWIFI GOT IP\r\n'); } });
  };
  E.dropRouter = () => { E.staIp = '0.0.0.0'; E.out('WIFI DISCONNECT\r\n'); };
  E.modemOff = () => { E.routerOn = false; if (E.staIp !== '0.0.0.0') E.dropRouter(); };
  E.modemOn = () => { E.routerOn = true; if (E.on && E.saved && (E.curMode & 1) && !E.qap) later(3000, () => { if (E.staIp === '0.0.0.0') E.backRouter(); }); };
  E.backRouter = () => { E.staIp = '192.168.1.50'; E.out('WIFI CONNECTED\r\nWIFI GOT IP\r\n'); };
  const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const p2 = n => String(n).padStart(2, '0');
  const ctime = ms => { const d = new Date(ms); return `${DOW[d.getUTCDay()]} ${MON[d.getUTCMonth()]} ${p2(d.getUTCDate())} ${p2(d.getUTCHours())}:${p2(d.getUTCMinutes())}:${p2(d.getUTCSeconds())} ${d.getUTCFullYear()}`; };
  u.onByteTransmit = b => {
    if (!E.on) return;
    E.raw.push(b);
    if (E.sendLeft > 0) {                                /* data for CIPSEND */
      E.sendBuf.push(b);
      if (--E.sendLeft === 0) {
        const data = Buffer.from(E.sendBuf).toString('utf8'), id = E.sendTo;
        E.out(`\r\nRecv ${E.sendBuf.length} bytes\r\n`);
        later(5, () => { E.out('\r\nSEND OK\r\n'); const p = E.phones[id]; if (p) p.rx.push(data); });
      }
      return;
    }
    if (b === 13) return;
    if (b !== 10) { (E.lineB = E.lineB || []).push(b); return; }   /* a command ends with CR LF (UTF-8 bytes) */
    const l = Buffer.from(E.lineB || []).toString('utf8'); E.lineB = []; E.lineBuf = '';
    E.cmds.push(l);
    if (E.log) console.log('    esp <', l);
    E.out(l + '\r\r\n');                                  /* echo */
    if (E.errOn[l.split('=')[0]]) { E.errOn[l.split('=')[0]]--; E.out('\r\nERROR\r\n'); return; }
    let m;
    /* as the 6-pole board's module (2026-10-27): back from AP-only to AP+station it hangs, nothing more on the UART */
    if (l === 'AT+CWMODE=3' && E.curMode === 2) { E.hung = true; return; }
    if (l === 'AT+CWMODE=3') { E.mode = 3; E.curMode = 3; E.out('\r\nOK\r\n'); if (E.saved && E.routerOn && E.staIp === '0.0.0.0') later(2500, () => { if (E.staIp === '0.0.0.0') E.backRouter(); }); }
    else if (l === 'AT+CWMODE_CUR=2') { E.curMode = 2; if (E.staIp !== '0.0.0.0') E.dropRouter(); E.out('\r\nOK\r\n'); }
    else if (l === 'AT+CWQAP') { E.qap = true; if (E.staIp !== '0.0.0.0') E.dropRouter(); E.out('\r\nOK\r\n'); }
    else if (l === 'AT+RST') { E.resets++; E.out('\r\nOK\r\n'); E.phones = {}; E.server = 0; later(300, E.boot); }
    else if (l.startsWith('AT+CWSAP=')) { const a = E.args(l.slice(9)); E.apArgs = a; later(300, () => { E.ap = [a[0], a[1]]; E.out('\r\nOK\r\n'); }); }
    else if (l === 'AT+CIPMUX=1') E.out('\r\nOK\r\n');
    else if (l === 'AT+CIPSERVER=1,6269') { E.server = 1; E.out('\r\nOK\r\n'); }
    else if (l === 'AT+CIFSR') later(20, () => E.out(`+CIFSR:APIP,"192.168.4.1"\r\n+CIFSR:APMAC,"5e:cf:7f:aa:bb:cc"\r\n+CIFSR:STAIP,"${E.staIp}"\r\n+CIFSR:STAMAC,"${E.mac}"\r\n\r\nOK\r\n`));
    else if (l.startsWith('AT+CWJAP=')) {
      const a = E.args(l.slice(9));
      E.join = [a[0], a[1]];
      if (!(E.curMode & 1)) { E.out('\r\nERROR\r\n'); return; }
      E.saved = E.join; E.qap = false;
      if (opt.joinFail || !E.routerOn) later(opt.joinFail ? 3000 : 15000, () => E.out('+CWJAP:3\r\n\r\nFAIL\r\n'));
      else if (opt.joinLate) later(3000, () => { E.out('+CWJAP:1\r\n\r\nFAIL\r\n'); later(opt.joinLate, () => { E.staIp = '192.168.1.50'; E.out('WIFI CONNECTED\r\nWIFI GOT IP\r\n'); }); });
      else later(3000, () => {
        /* the module's own network moves to the router's channel: every phone drops (the module does not know yet) */
        if (opt.joinDrop) E.phones = {};
        /* ipLag: the module says GOT IP / OK but CIFSR still shows 0.0.0.0 for a while */
        if (opt.ipLag) later(500 + opt.ipLag, () => { E.staIp = '192.168.1.50'; }); else E.staIp = '192.168.1.50';
        E.out('WIFI CONNECTED\r\n'); later(500, () => E.out('WIFI GOT IP\r\n\r\nOK\r\n'));
      });
    }
    else if (l.startsWith('AT+CIPSNTPCFG=')) {
      if (E.sntp === 'none') E.out('\r\nERROR\r\n');
      else { E.sntpCfg = l; E.sntpCfgAt = cpu.cycles / 8000 + E.skew; E.out('\r\nOK\r\n'); }
    }
    else if (l === 'AT+CIPSNTPTIME?') {
      E.sntpAsks.push(cpu.cycles / 8000 + E.skew);
      if (E.sntp === 'none') { E.out('\r\nERROR\r\n'); return; }
      const synced = E.sntpCfgAt >= 0 && E.net && E.staIp !== '0.0.0.0' && cpu.cycles / 8000 + E.skew - E.sntpCfgAt > 3000;
      E.sntpSynced = (E.sntpSynced || []).concat([synced]);
      later(10, () => E.out(`+CIPSNTPTIME:${synced ? ctime(E.utcNow()) : 'Thu Jan 01 00:00:00 1970'}\r\nOK\r\n`));
    }
    else if ((m = l.match(/^AT\+CIPSEND=(\d),(\d+)$/))) {
      const id = +m[1];
      if (!E.phones[id]) { E.out('link is not valid\r\n\r\nERROR\r\n'); return; }
      E.sendTo = id; E.sendLeft = +m[2]; E.sendBuf = [];
      E.out('\r\nOK\r\n> ');
    }
    else E.out('\r\nERROR\r\n');
  };
  /* power follows the ATmega32 PD5 */
  bd.a.D.addListener(v => {
    const p = !!((v >> 5) & 1) && !!((bd.a.cpu.data[0x31] >> 5) & 1);
    if (p && !E.on) { E.on = true; E.cmds = []; E.phones = {}; E.server = 0; E.txFree = 0; E.lineBuf = ''; E.lineB = []; E.sendLeft = 0; later(300, E.boot); }
    else if (!p && E.on) { E.on = false; E.phones = {}; }
  });
  E.connect = id => { E.phones[id] = { rx: [] }; E.out(`${id},CONNECT\r\n`); return E.phones[id]; };
  E.close = id => { delete E.phones[id]; E.out(`${id},CLOSED\r\n`); };
  E.send = (id, str) => { const b = Buffer.from(str, 'utf8'); E.out(`\r\n+IPD,${id},${b.length}:`); E.out([...b]); };
  E.restart = () => { E.phones = {}; E.server = 0; E.out('\r\nWIFI DISCONNECT\r\n'); later(200, E.boot); };
  return E;
}
module.exports = { attachEsp };
