// 23-key board Wi-Fi: real ATmega32 + ATmega64 hex, fake ESP8266 (AT) and fake phones running the app protocol
const B = require('./big'); const { run, touch, tap, red, white, check } = B; const C = B.core;
const { attachEsp } = require('./esp');
/* a14 alarm layout (as talarm.js) */
const type = Array(23).fill(1), sec1 = Array(23).fill(0), sec2 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
type[12] = C.T_ALON; type[13] = C.T_ALPW;
[14, 15, 16, 17].forEach((k, d) => { type[k] = C.T_KEY; sec1[k] = d + 1; });
type[18] = type[19] = 7; off[18] = 1 << 19; off[19] = 1 << 18; sec1[18] = sec1[19] = 6; sec2[18] = sec2[19] = 5;
const relays = (1 << 12) - 1 | 1 << 18 | 1 << 19;
type[20] = C.T_EXIT; sec1[20] = 20; off[20] = relays & ~(1 << 19); on[20] = 1 << 19;
type[21] = C.T_ELEV; on[21] = 1 << 20;
type[22] = C.T_SLEEP; sec1[22] = 30; off[22] = relays & ~(1 << 5); on[22] = 1 << 5;
const LAY = 'LLLLLLLLLLLLnc1234UWXEZ';
const cfg = { type, sec1, sec2, offmask: off, onmask: on, remote: true, nslot: 4, alarm: 1, alArm: 3, alEntry: 5, alSiren: 4, dimsec: 0, stagMs: 100,
  lay: LAY, mdl: 'a14' };
const ee = new (require('avr8js').EEPROMMemoryBackend)(2048);
let bd = B.boardWith(cfg, 'fw_big_a_six', ee);
bd.b.C.setPin(4, false);                                        /* PIR idle (normally closed: low) */
let E = attachEsp(bd);
const steps = (ms, f) => { for (let t = 0; t < ms; t += 10) { run(bd, 10); if (f && f()) return t + 10; } return -1; };
const cpuAt = (ms, f) => bd.b.cpu.addClockEvent(f, ms * 8000 + 1);
const lastOf = (p, pre) => p.rx.filter(m => m.startsWith(pre)).pop();
const last = p => p.rx[p.rx.length - 1];
const said = (p, re) => p.rx.some(m => re.test(m));
const ask = (p, id, str, re, ms = 1500) => { const n = p.rx.length; E.send(id, str); const t = steps(ms, () => p.rx.slice(n).some(m => re.test(m))); return [t, p.rx.slice(n).find(m => re.test(m)) || p.rx.slice(n).join(' | ')]; };

run(bd, 2500);
check(!E.on && bd.b.cpu.data[0x2A] === 0, 'power-up: module off, ATmega64 UART off');
touch(bd, 22, true); run(bd, 7200); touch(bd, 22, false);
let t = steps(8000, () => E.server); steps(300);
check(E.on && t > 0, `held 7 s: module powered, server up ${t} ms later`);
check(E.cmds.join('|') === 'AT+CWMODE=3|AT+CIFSR|AT+CWSAP="sooden-BBCC","sooden123",1,3|AT+CIPMUX=1|AT+CIPSERVER=1,6269|AT+CIFSR', 'first start: its own name sooden- + 4 hex of the MAC: ' + E.cmds.join(' | '));
steps(500);

/* ---- phone 0: the app's connection steps ---- */
const p0 = E.connect(0);
t = steps(1000, () => p0.rx.length);
check(t < 0, 'connect: nothing pushed before the app asks (its first steps stop on anything unexpected)');
let r = ask(p0, 0, '@M_IP', /^%/);
check(p0.rx.length === 1 && p0.rx[0][0] === '%', '@M_IP: the first thing the phone gets is its answer');
check(r[1] === '%5c:cf:7f:aa:bb:cc+                +' + '\0'.repeat(0) + r[1].slice(36), `@M_IP: ${JSON.stringify(r[1])} (${r[0]} ms)`);
check(r[1].length === 1 + 17 + 1 + 16 + 1 + 20 + 1, '@M_IP: 57 bytes like RF-12');
r = ask(p0, 0, '@M_F_C', /^#T$/); check(r[0] > 0, '@M_F_C -> #T');
r = ask(p0, 0, '@M_F_T', /^#T\*/); check(r[1] === '#T*A1/Uaaaaaaaaaa/Vp1*L+#X1*Z1++', '@M_F_T -> ' + r[1]);
r = ask(p0, 0, '@M_MDL', /MDL/); check(r[1] === '$MDL=SD23-a14-1.0$', '@M_MDL -> ' + r[1]);
r = ask(p0, 0, '@M_LAY', /LAY/); check(r[1] === '$LAY#' + LAY + '$', '@M_LAY -> ' + r[1]);
r = ask(p0, 0, '@M_CAP', /CAP/); check(r[1] === '$CAP#A1R1W1S1$', '@M_CAP -> ' + r[1]);
r = ask(p0, 0, '@M_VER', /VER/); check(r[1] === '$VER=SD23-1.0$', '@M_VER -> ' + r[1]);
/* several commands in one packet (the app may glue them) */
let n0 = p0.rx.length; E.send(0, '@M_MDL@M_CAP@X1Z'); steps(1500);
check(p0.rx.slice(n0).join('') === '$MDL=SD23-a14-1.0$$CAP#A1R1W1S1$$AL#0$', 'three commands in one packet: ' + p0.rx.slice(n0).join(''));

/* ---- press from the app, state to the phone ---- */
r = ask(p0, 0, '&K#01', /^\$A#01/);
check(r[1] === '$A#01#1$' && red(bd, 0) === 1, `&K#01: pole 1 on (${r[1]})`);
t = steps(1000, () => last(p0) === '$K#000001$'); check(t > 0, '$K#000001$ pushed');
tap(bd, 0); t = steps(1000, () => last(p0) === '$K#000000$');
check(red(bd, 0) === 0 && t > 0, `touch on the panel: phone sees it ${t} ms later`);
r = ask(p0, 0, '&K#15', /^\$A#15/); check(r[1] === '$A#15#0$', '&K on a keypad digit: refused ' + r[1]);
r = ask(p0, 0, '&K#13', /^\$A#13/); check(r[1] === '$A#13#0$', '&K on ON/OFF: refused ' + r[1]);
r = ask(p0, 0, '&K#24', /^\$A#24/); check(r[1] === '$A#24#0$', '&K#24: refused');
r = ask(p0, 0, '@K', /^\$K#/); check(r[1] === '$K#000000$', '@K -> ' + r[1]);

/* ---- curtain from the app (interlock): open, then close only stops ---- */
ask(p0, 0, '&K#19', /^\$A#19/); steps(300);
check(red(bd, 18) === 1, 'curtain open from the app');
ask(p0, 0, '&K#20', /^\$A#20/); steps(300);
check(red(bd, 18) === 0 && red(bd, 19) === 0, 'opposite key from the app while moving: only stops');

/* ---- stepped switching: several poles -> a few messages, the last one right ---- */
ask(p0, 0, '&K#02', /^\$A#02/); ask(p0, 0, '&K#03', /^\$A#03/); ask(p0, 0, '&K#04', /^\$A#04/); steps(800);
check(last(p0) === '$K#00000E$', 'three poles on: last state ' + last(p0));
r = ask(p0, 0, '&K#21', /^\$A#21/); steps(500);
check(r[1] === '$A#21#1$' && last(p0) === '$K#10000E$', 'EXIT from the app: runs, the phone sees it on (' + last(p0) + ')');
r = ask(p0, 0, '&K#01', /^\$A#01/);
check(r[1] === '$A#01#0$' && red(bd, 0) === 0, 'EXIT (short scenario) running: app press refused like a touch');
n0 = p0.rx.length; steps(19500 + 7500);
const ks = p0.rx.slice(n0).filter(m => m.startsWith('$K#'));
check(red(bd, 1) === 0 && red(bd, 2) === 0 && red(bd, 3) === 0 && ks.includes('$K#080000$') && ks[ks.length - 1] === '$K#000000$',
  `EXIT ends: poles off stepwise, curtain closes, phone follows (${ks.join(' ')})`);
check(ks.length <= 8, `stepped switching: ${ks.length} state messages (at most one per 250 ms)`);

/* ---- elevator from the app: fires at once (no 1 s hold) ---- */
let rise = -1; n0 = p0.rx.length; E.send(0, '&K#22');
for (let i = 0; i < 1500 && rise < 0; i++) { run(bd, 1); if (red(bd, 20)) rise = i; }
check(rise > 0 && rise < 400, `&K#22 elevator: relay ${rise} ms after the packet`);
steps(1500); check(red(bd, 20) === 0, 'elevator relay off after 1 s');

/* ---- labels ---- */
r = ask(p0, 0, 'Lbl#01#05~چراغ آشپزخانه#', /^ok/); check(r[1] === 'ok\n', 'Lbl#01 -> ok');
r = ask(p0, 0, '@M_LBL#01', /^\$L01/); check(r[1] === '$L01#05~چراغ آشپزخانه$', '@M_LBL#01 -> ' + r[1]);
const long = 'نورمخفیسقفپذیراییبزرگ';                         /* 21 letters = 42 bytes: cut at 40 on a letter */
r = ask(p0, 0, `Lbl#23#${long}#`, /^ok/); r = ask(p0, 0, '@M_LBL#23', /^\$L23/);
check(r[1] === '$L23#' + long.slice(0, 20) + '$', 'long label cut to 40 bytes on a whole letter: ' + r[1]);
r = ask(p0, 0, '@M_LBL#02', /^\$L02/); check(r[1] === '$L02#$', 'empty label: ' + r[1]);
steps(1000);

/* ---- second phone, both get every change ---- */
const p1 = E.connect(1); steps(300); E.send(1, '@M_MDL'); steps(800);
check(p1.rx.filter(m => !m.startsWith('$MDL')).join('') === '$K#000000$$AL#0$', 'phone 2: state and alarm state on connect: ' + p1.rx.join(''));
tap(bd, 4); steps(800);
check(last(p0) === '$K#000010$' && last(p1) === '$K#000010$', 'touch: both phones told');
tap(bd, 4); steps(600);

/* ---- alarm from the app ---- */
r = ask(p0, 0, '&X1Z1#1111', /ARM/); check(r[1] === '$ARM#no$', 'wrong code: ' + r[1]);
r = ask(p0, 0, '&X1Z1#1234', /ARM/); check(r[1] === '$ARM#ok$', 'right code: ' + r[1]);
t = steps(1000, () => said(p0, /^\$AL#1\$$/) && said(p1, /^\$AL#1\$$/)); check(t > 0, 'both phones: arming ($AL#1$)');
t = steps(5000, () => last(p0) === '$AL#2$'); check(t > 0 && red(bd, 12) === 1, `armed after the delay (${t} ms), ON/OFF red lit`);
r = ask(p0, 0, '&X1P#4321', /PASS/); check(r[1] === '$PASS=no$', 'new password while armed: refused');
while (bd.b.cpu.cycles / 8000 < 61000) run(bd, 100);   /* the sensor counts after the first minute */
bd.b.C.setPin(4, true); run(bd, 300); bd.b.C.setPin(4, false);
t = steps(1500, () => last(p1) === '$AL#3$'); check(t > 0, 'sensor: entry time on the phone ($AL#3$)');
t = steps(7000, () => last(p1) === '$AL#4$'); check(t > 0, 'no code: siren on the phone ($AL#4$)');
r = ask(p1, 1, '&X1Z1#1234', /ARM/); check(r[1] === '$ARM#ok$', 'disarm from phone 2');
t = steps(1500, () => lastOf(p0, '$AL') === '$AL#0$' && lastOf(p1, '$AL') === '$AL#0$'); check(t > 0 && !((bd.b.cpu.data[B.PORTADDR.D] >> 4) & 1), 'siren off, both phones $AL#0$');
r = ask(p0, 0, '&X1P#4321', /PASS/); check(r[1] === '$PASS=ok$', 'new password: ok');
r = ask(p0, 0, '&X1P#1259', /PASS/); check(r[1] === '$PASS=no$', 'password with a digit not on this keypad (5, 9): refused');
r = ask(p0, 0, '&X1Z1#1234', /ARM/); check(r[1] === '$ARM#no$', 'old password no longer works');
r = ask(p0, 0, '&X1Z1#4321', /ARM/); check(r[1] === '$ARM#ok$', 'new password arms');
steps(500); ask(p0, 0, '&X1Z1#4321', /ARM/); steps(1000);
check(last(p0) === '$AL#0$', 'and disarms');
/* the panel keypad still works with the new password */
const wake = () => { if (!white(bd, 12)) { tap(bd, 12); run(bd, 50); } };
wake(); tap(bd, 12); run(bd, 100); [4, 3, 2, 1].forEach(d => tap(bd, 13 + d)); t = steps(1500, () => last(p0) === '$AL#1$');
check(t > 0, 'arming on the panel keypad: phone sees $AL#1$');
[4, 3, 2, 1].forEach(d => tap(bd, 13 + d)); steps(1000);
wake(); tap(bd, 12); run(bd, 100); [4, 3, 2, 1].forEach(d => tap(bd, 13 + d)); t = steps(1500, () => last(p0) === '$AL#0$');
check(t > 0, 'disarmed on the panel: phone sees $AL#0$ (' + p0.rx.slice(-3).join(' ') + ')');

/* ---- home router ---- */
r = ask(p0, 0, '#AT+CWJAP="HomeNet","pass1234"#', /@M_S=/, 8000);
check(E.join && E.join[0] === 'HomeNet' && E.join[1] === 'pass1234', 'router command passed to the ESP');
check(r[1] === '@M_S=192.168.1.50', 'router joined: ' + JSON.stringify(r[1]));
r = ask(p0, 0, '@M_IP', /^%/);
check(r[1] === '%5c:cf:7f:aa:bb:cc+192.168.1.50    +HomeNet' + '\0'.repeat(13) + '%', '@M_IP now: ' + JSON.stringify(r[1]));
r = ask(p0, 0, '*AT+CWSAP="Sooden-Home","newpass99",1,4*', /x/, 1500); steps(500);
check(E.ap && E.ap[0] === 'Sooden-Home' && E.ap[1] === 'newpass99', 'panel network name / password passed to the ESP');

/* ---- busy: a command flood does not slow the touches ---- */
let reply = 0; const nf = p0.rx.length;                     /* the app leaves 200 ms between commands: here 120 ms */
for (let i = 0; i < 12; i++) cpuAt(i * 120, () => E.send(0, '@M_LAY'));
run(bd, 600); touch(bd, 6, true); let dt = -1; for (let i = 0; i < 400 && dt < 0; i++) { run(bd, 1); if (red(bd, 6)) dt = i; } touch(bd, 6, false);
steps(8000); reply = p0.rx.slice(nf).filter(m => m.startsWith('$LAY')).length;
check(dt > 0 && dt < 150, `12 commands in flight: a touch still switches in ${dt} ms`);
check(reply === 12, `and all 12 got their answer (${reply})`);
tap(bd, 6); steps(500);

/* ---- phone leaves; module restarts ---- */
E.close(1); steps(300); tap(bd, 7); steps(800);
check(last(p0) === '$K#000080$', 'phone 2 gone: phone 1 still served');
tap(bd, 7); steps(500);
E.cmds = []; E.restart(); t = steps(5000, () => E.server); steps(300);
check(t > 0 && E.cmds.join('|') === 'AT+CWMODE=3|AT+CIFSR|AT+CIPMUX=1|AT+CIPSERVER=1,6269|AT+CIFSR', 'module restarted: server again, the name not sent again: ' + E.cmds.join(' | '));
const p2 = E.connect(2); steps(300); E.send(2, '@M_MDL'); steps(800); check(p2.rx.some(m => m === '$K#000000$'), 'new phone after the restart served: ' + p2.rx.join(''));

/* ---- labels survive a power cut; Wi-Fi off ---- */
steps(1500);
bd = B.boardWith(cfg, 'fw_big_a_six', ee); bd.b.C.setPin(4, false); E = attachEsp(bd);
t = steps(9000, () => E.server);
check(t > 0 && E.cmds[2] === 'AT+CIPMUX=1', 'power cut: Wi-Fi comes back on by itself, server up (name not sent again)');
const p3 = E.connect(0); steps(300); E.send(0, '@M_MDL'); steps(500);
r = ask(p3, 0, '@M_LBL#01', /^\$L01/); check(r[1] === '$L01#05~چراغ آشپزخانه$', 'label kept over the power cut');
r = ask(p3, 0, '@M_IP', /^%/); check(r[1].includes('+HomeNet'), 'router name kept over the power cut');
touch(bd, 22, true); run(bd, 7200); touch(bd, 22, false); steps(500);
check(!E.on && bd.b.cpu.data[0x2A] === 0 && !(bd.b.cpu.data[0x22] & 3), 'held 7 s: module off, UART off, PE0/PE1 inputs');
check(!(bd.b.cpu.data[0x23] & 3), 'PE0/PE1 without pull-up (nothing pushed into the unpowered module)');
tap(bd, 0); run(bd, 300); check(red(bd, 0) === 1, 'panel works on without Wi-Fi');
check(bd.b.overrun === 0, 'no byte lost from the module: ' + bd.b.overrun);

/* ---- a 20 pole panel without alarm (plain hex fw_big) ---- */
{
  const ee2 = new (require('avr8js').EEPROMMemoryBackend)(2048);
  bd = B.boardWith({ type: Array(23).fill(1), remote: true, nslot: 4, dimsec: 0, stagMs: 100, lay: 'L'.repeat(20) + 'MMM', mdl: 'p20' }, 'fw_big', ee2);
  E = attachEsp(bd); run(bd, 2500);
  touch(bd, 22, true); run(bd, 7200); touch(bd, 22, false); steps(3000, () => E.server); steps(300);
  const q = E.connect(0); steps(300); E.send(0, '@M_MDL'); steps(500);
  check(q.rx.filter(m => !m.startsWith('$MDL')).join('') === '$K#000000$', 'p20: on connect only the state (no alarm messages): ' + q.rx.join(''));
  let r2 = ask(q, 0, '@M_MDL', /MDL/); check(r2[1] === '$MDL=SD23-p20-1.0$', 'p20: ' + r2[1]);
  r2 = ask(q, 0, '@M_CAP', /CAP/); check(r2[1] === '$CAP#A0R1W1S1$', 'p20: ' + r2[1]);
  r2 = ask(q, 0, '@M_LAY', /LAY/); check(r2[1] === '$LAY#' + 'L'.repeat(20) + 'MMM$', 'p20: ' + r2[1]);
  r2 = ask(q, 0, '&X1Z1#1234', /ARM/); check(r2[1] === '$ARM#no$', 'p20: no alarm to arm');
  r2 = ask(q, 0, '&K#20', /^\$A#20/); steps(300); check(r2[1] === '$A#20#1$' && red(bd, 19) === 1 && last(q) === '$K#080000$', 'p20: pole 20 from the app');
  check(bd.b.overrun === 0, 'p20: no byte lost');
}
console.log(`\n${B.stats().checks} checks, ${B.stats().fails} failed`);
