// Real fw.hex in avr8js: single 4-pole panel (no links) - power-up circle, buzzer PD2, silent RS485
const { step: avrStep } = require('./step');
const fs = require('fs');
const { CPU, avrInstruction, AVRIOPort, AVRUSART } = require('avr8js');
const core = require('./cfgcore');
const F = 8e6, MS = 8000;
const FW = fs.readFileSync(process.argv[2] || '/home/claude/fw/out/fw_4p.hex', 'utf8');
let fails = 0, checks = 0;
function check(c, m) { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); }
const T2 = { address: 3, flagRegister: 0x58, flagMask: 0x80, enableRegister: 0x59, enableMask: 0x80 };

function node(cfg) {
  const mem = core.parseHex(core.patchHex(FW, core.buildCfg(cfg)));
  const prog = new Uint16Array(4096);
  for (const [a, v] of mem) { if (a & 1) prog[a >> 1] |= v << 8; else prog[a >> 1] |= v; }
  const cpu = new CPU(prog, 1024);
  const pb = new AVRIOPort(cpu, { PIN: 0x36, DDR: 0x37, PORT: 0x38, externalInterrupts: [] });
  const pc = new AVRIOPort(cpu, { PIN: 0x33, DDR: 0x34, PORT: 0x35, externalInterrupts: [] });
  const pd = new AVRIOPort(cpu, { PIN: 0x30, DDR: 0x31, PORT: 0x32, externalInterrupts: [] });
  const usart = new AVRUSART(cpu, { rxCompleteInterrupt: 11, dataRegisterEmptyInterrupt: 12, txCompleteInterrupt: 13,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x40, UBRRL: 0x29, UBRRH: 0x5C, UDR: 0x2C }, F);
  const t2 = () => { if (cpu.data[0x45] & 7) cpu.setInterruptFlag(T2); cpu.addClockEvent(t2, MS); };
  cpu.addClockEvent(t2, MS);
  for (let i = 0; i < 8; i++) { pb.setPin(i, true); pc.setPin(i, true); pd.setPin(i, true); }
  pd.setPin(3, false);
  const n = { cpu, pb, pc, pd, tx: 0 };
  usart.onByteTransmit = () => n.tx++;
  return n;
}
const out = (n, port, bit) => { const c = port.portConfig, d = n.cpu.data; return (d[c.DDR] >> bit) & 1 ? (d[c.PORT] >> bit) & 1 : -1; };
const W = n => [out(n, n.pb, 1), out(n, n.pb, 0), out(n, n.pc, 0), out(n, n.pd, 5)];   // whites pole 1..4
const R = n => [out(n, n.pb, 2), out(n, n.pd, 7), out(n, n.pc, 1), out(n, n.pd, 6)];   // red+relay pole 1..4
const BZ = n => out(n, n.pd, 2);
function step(n, ms, each) { for (let k = 0; k < ms; k++) { const e = n.cpu.cycles + MS; while (n.cpu.cycles < e) avrStep(n.cpu, 0xFFF); if (each) each(k); } }
const CODE4 = [7, 0, 3, 4];
function touch(n, p, on) {
  if (on) { const c = CODE4[p]; n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); }
  else [2, 3, 4, 5].forEach(b => n.pc.setPin(b, true));
}

const single = { role: 0, npoles: 4, peerpoles: 4, remote: false, type: [1, 1, 1, 1], link: [-1, -1, -1, -1],
  offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, beep: 0x05 };

console.log('single 4 pole, no crystal (no remote), beep on poles 1 and 3');
const n = node(single);
// power-up: sample the white LED in the middle of every 120 ms step
const seen = [], bad = { red: 0, bz: 0, multi: 0 };
step(n, 1440, k => {
  if (R(n).some(v => v === 1)) bad.red++;
  if (BZ(n) === 1) bad.bz++;
  if (k % 120 === 60) { const w = W(n); if (w.filter(v => v === 1).length !== 1) bad.multi++; seen.push(w.indexOf(1) + 1); }
});
check(seen.join('') === '124312431243', 'power-up circle 1-2-4-3 x3 (got ' + seen.join('') + ')');
check(bad.multi === 0, 'one white at a time');
check(bad.red === 0 && bad.bz === 0, 'no red/relay, no buzzer during power-up');
step(n, 20);
check(W(n).join() === '1,1,1,1' && R(n).join() === '0,0,0,0' && BZ(n) === 0, 'after circle: 4 white, relays off, buzzer off (PD2 driven low)');

function press(p) { let bz = 0, first = -1; touch(n, p, true); step(n, 100, k => { if (BZ(n) === 1) { bz++; if (first < 0) first = k; } }); touch(n, p, false); step(n, 150, () => { if (BZ(n) === 1) bz++; }); return { bz, first }; }
let r = press(0);
check(R(n)[0] === 1 && W(n)[0] === 0, 'pole1 on: red/relay on, white off');
check(r.bz >= 38 && r.bz <= 42 && r.first <= 35, `pole1 beep ${r.bz} ms, starts ${r.first} ms after touch`);
r = press(1);
check(R(n)[1] === 1 && r.bz === 0, 'pole2 on, no beep');
r = press(2);
check(R(n)[2] === 1 && r.bz >= 38 && r.bz <= 42, 'pole3 on, beep');
r = press(3);
check(R(n)[3] === 1 && r.bz === 0, 'pole4 on, no beep');
for (let p = 0; p < 4; p++) press(p);
check(R(n).join() === '0,0,0,0' && W(n).join() === '1,1,1,1', 'all off again');
step(n, 3000);
check(n.tx === 0, 'nothing sent on RS485 (single panel)');

console.log('no beep selected');
const m = node(Object.assign({}, single, { beep: 0 }));
step(m, 1500);
let bz = 0; touch(m, 0, true); step(m, 100, () => { if (BZ(m) === 1) bz++; }); touch(m, 0, false); step(m, 100);
check(R(m)[0] === 1 && bz === 0, 'pole1 switches, buzzer silent');

console.log(`\n${checks} checks, ${fails} failed`);
process.exit(fails ? 1 : 0);
