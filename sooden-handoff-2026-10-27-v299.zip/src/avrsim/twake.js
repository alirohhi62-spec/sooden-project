// A phone connecting over Wi-Fi lights a dark panel up (confirmation), nothing switched: 12 economic + 23-key board
const E = require('./e12.js'); const { touch, tap, white, red, reds, check, core: C } = E; const { attachEsp } = require('./esp');
{
  const type = Array(23).fill(0); for (let i = 0; i < 12; i++) type[i] = 1; type[22] = C.T_SLEEP;
  const b = E.boardWith({ type, remote: false, nslot: 0, stagMs: 100, dimsec: 60 }, 'fw_e12_x');
  const W = attachEsp({ b: { cpu: b.cpu, usart: b.usart }, a: { D: { addListener: f => b.E.addListener(v => f(((v >> 6) & 1) << 5)) }, cpu: { data: new Proxy({}, { get: (t, k) => k === '49' ? ((b.cpu.data[0x22] >> 6) & 1) << 5 : 0 }) } } });
  E.run(b, 3500); touch(b, 22, true); E.run(b, 7400); touch(b, 22, false); E.run(b, 8000);
  E.run(b, 64000);
  check([0, 5, 11].every(k => !white(b, k)), '12 economic: dark after 60 s');
  W.connect(0); E.run(b, 3000);
  check([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].every(k => white(b, k)) && reds(b) === '000000000000', 'phone connected: every white back, no relay ' + reds(b));
  tap(b, 3); E.run(b, 300);
  check(red(b, 3), 'the next touch switches at once (the panel is awake)');
  tap(b, 3); W.close(0); E.run(b, 64000);
  check(!white(b, 0), 'dark again after 60 s');
}
{
  const B = require('./big');
  const type = Array(23).fill(1);
  const bd = B.boardWith({ type, remote: false, nslot: 0, alarm: 0, dimsec: 60, stagMs: 100, lay: 'LLLLLLLLLLLLLLLLLLLLMMM', mdl: 'p20' }, 'fw_big_six');
  const W = attachEsp(bd);
  B.run(bd, 2500); B.touch(bd, 22, true); B.run(bd, 7200); B.touch(bd, 22, false); B.run(bd, 8000);
  B.run(bd, 66000);
  const dark = [0, 5, 19].every(k => !B.white(bd, k));
  W.connect(0); B.run(bd, 4000);
  check(dark && [0, 5, 19].every(k => B.white(bd, k)), '23-key: dark, then lit when a phone connects');
}
const s = E.stats(); console.log(`${s.checks - s.fails}/${s.checks} passed`);
