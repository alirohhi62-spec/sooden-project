// latency with a noisy 433 receiver (random edges every 30..200 us)
var fs=require('fs');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
for (const fw of ['fw_4p_r','fw_4p_pair_r']) {
  const c={role:0,npoles:4,peerpoles:4,remote:true,type:[1,1,1,1],link:[-1,-1,-1,-1],offmask:[0,0,0,0],onmask:[0,0,0,0],minutes:[0,0,0,0],dimsec:0,beep:0,stagMs:100,nslot:1};
  const A=makeNode(core.patchHex(FWS[fw],core.buildCfg(c))); A.board=1; nodes=[A]; connect(false); run(1600);
  let lv=false; const noise=()=>{ lv=!lv; A.pd.setPin(3,lv); A.cpu.setInterruptFlag(I1); A.cpu.addClockEvent(noise, 8*(30+Math.floor(Math.random()*170))); };
  A.cpu.addClockEvent(noise,10);
  const res=[];
  for (let t=0;t<10;t++){ run(37); touch(A,t%4,true); let lat=-1; const was=r4(A)[t%4]; for(let k=0;k<60;k++){ run(1); if(r4(A)[t%4]!==was){lat=k+1;break;} } touch(A,t%4,false); run(60); res.push(lat); }
  console.log(fw,'latency ms with RF noise:',res.join(' '));
}
