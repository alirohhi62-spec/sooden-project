// Simulation of the 23-key board: real ATmega32 + ATmega64 hex files in avr8js, wired like the board
const { step } = require('./step');
const fs = require('fs');
const { CPU, avrInstruction, AVRIOPort, AVREEPROM, EEPROMMemoryBackend, AVRUSART } = require('avr8js');
const core = require('./cfgcore');
const MS = 8000;
const FWD = '/home/claude/fw/out/';
const hex = n => fs.readFileSync(FWD + n + '.hex', 'utf8');

function loadProg(text, words) {
  const mem = core.parseHex(text), prog = new Uint16Array(words);
  for (const [a, v] of mem) { if (a & 1) prog[a >> 1] |= v << 8; else prog[a >> 1] |= v; }
  return prog;
}
const port = (cpu, PIN, DDR, PORT) => new AVRIOPort(cpu, { PIN, DDR, PORT, externalInterrupts: [] });

function makeBoard(m64hex, eeBackend) {
  /* ---- ATmega32 ---- */
  const c32 = new CPU(loadProg(hex('fw_big_io32'), 16384), 2048);
  const a = { cpu: c32, A: port(c32, 0x39, 0x3A, 0x3B), B: port(c32, 0x36, 0x37, 0x38), C: port(c32, 0x33, 0x34, 0x35), D: port(c32, 0x30, 0x31, 0x32) };
  const I32 = {
    INT0: { address: 2, flagRegister: 0x5A, flagMask: 0x40, enableRegister: 0x5B, enableMask: 0x40 },
    INT1: { address: 4, flagRegister: 0x5A, flagMask: 0x80, enableRegister: 0x5B, enableMask: 0x80 },
    T2:   { address: 8, flagRegister: 0x58, flagMask: 0x80, enableRegister: 0x59, enableMask: 0x80 },
  };
  /* ---- ATmega64 ---- */
  const c64 = new CPU(loadProg(m64hex, 32768), 4096);
  const b = { cpu: c64, A: port(c64, 0x39, 0x3A, 0x3B), B: port(c64, 0x36, 0x37, 0x38), C: port(c64, 0x33, 0x34, 0x35),
    D: port(c64, 0x30, 0x31, 0x32), E: port(c64, 0x21, 0x22, 0x23), F: port(c64, 0x20, 0x61, 0x62), G: port(c64, 0x63, 0x64, 0x65) };
  const ee = eeBackend || new EEPROMMemoryBackend(2048);
  new AVREEPROM(c64, ee, { eepromReadyInterrupt: 44, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 34000, writeCycles: 34000 });
  /* USART0 (Wi-Fi module): word vectors RX 0x24, UDRE 0x26, TX 0x28 */
  b.usart = new AVRUSART(c64, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
  b.usart.UDRE.constant = true;        /* real chip: UDRE stays 1 while UDR is empty (avr8js clears it when the interrupt runs) */
  /* USART1 (two-panel network, RS485 on PD2/PD3): word vectors RX1 0x3C, UDRE1 0x3E, TX1 0x40 */
  b.usart1 = new AVRUSART(c64, { rxCompleteInterrupt: 0x3C, dataRegisterEmptyInterrupt: 0x3E, txCompleteInterrupt: 0x40,
    UCSRA: 0x9B, UCSRB: 0x9A, UCSRC: 0x9D, UBRRL: 0x99, UBRRH: 0x98, UDR: 0x9C }, 8000000);
  b.usart1.UDRE.constant = true;
  b.overrun = 0;
  const wb = b.usart.writeByte.bind(b.usart);
  b.usart.writeByte = (v, imm) => { if (c64.data[0x2B] & 0x80) b.overrun++; return wb(v, imm); };   /* byte lost: previous one not read */
  const I64 = {
    INT5: { address: 12, flagRegister: 0x58, flagMask: 0x20, enableRegister: 0x59, enableMask: 0x20 },
    T0:   { address: 30, flagRegister: 0x56, flagMask: 0x02, enableRegister: 0x57, enableMask: 0x02 },
  };
  /* timers: 1 ms compare interrupts while the timer runs; Timer1 at 1 MHz (TCNT1 read) */
  const t2 = () => { if (c32.data[0x45] & 7) c32.setInterruptFlag(I32.T2); c32.addClockEvent(t2, MS); }; c32.addClockEvent(t2, MS);
  a.restart = () => { c32.reset(); c32.addClockEvent(t2, MS); };   /* avr8js drops pending clock events on reset */
  const t0 = () => { if (c64.data[0x53] & 7) c64.setInterruptFlag(I64.T0); c64.addClockEvent(t0, MS); }; c64.addClockEvent(t0, MS);
  /* ATmega64 watchdog (WDTCR 0x41): wdt_enable / wdr; a timeout restarts the chip like the real one */
  const wd = { on: false, presc: 0, until: 0, cePending: 0 };
  const wdLen = () => Math.round(16.3 * (1 << wd.presc) * MS);
  c64.onWatchdogReset = () => { wd.until = c64.cycles + wdLen(); };
  c64.writeHooks[0x41] = v => {
    if ((v & 0x18) === 0x18) { wd.cePending = c64.cycles + 4; c64.data[0x41] = v; return true; }
    if (!(v & 8) && c64.cycles > wd.cePending) { v |= 8 * wd.on; }          /* WDE clears only right after WDCE */
    wd.on = !!(v & 8); wd.presc = v & 7; wd.until = c64.cycles + wdLen(); c64.data[0x41] = v & 0x0F;
    return true;
  };
  const wdCheck = () => {
    if (wd.on && c64.cycles >= wd.until) {
      bd64.wdtResets++;
      const keep = [0x39, 0x36, 0x33, 0x30, 0x21, 0x20, 0x63].map(a => [a, c64.data[a]]);   /* input pins stay as wired */
      c64.reset(); c64.data.fill(0, 0x20, 0x100); keep.forEach(([a, v]) => { c64.data[a] = v; }); c64.data[0x54] = 0x08;   /* MCUCSR: WDRF */
      wd.on = false; c64.data[0x41] = 0;
      b.usart.reset(); b.usart1.reset();
      c64.addClockEvent(t0, MS);
    }
    c64.addClockEvent(wdCheck, MS);
  };
  c64.addClockEvent(wdCheck, MS);
  const bd64 = { wdtResets: 0 };
  for (const cpu of [c32, c64]) {
    let hi = 0;
    cpu.readHooks[0x4C] = () => { const v = Math.floor(cpu.cycles / 8) & 0xFFFF; hi = v >> 8; return v & 0xFF; };
    cpu.readHooks[0x4D] = () => hi;
  }
  /* idle inputs: touch lines high (no touch), 433 low */
  for (let i = 0; i < 8; i++) { a.A.setPin(i, true); a.C.setPin(i, true); }
  a.D.setPin(3, false);
  /* the link wires */
  let p32 = 0, p64 = 0;
  a.D.addListener(v => {
    const clk = (v >> 1) & 1, dat = (v >> 4) & 1;
    b.E.setPin(2, !!dat);
    if (clk !== ((p32 >> 1) & 1)) { b.E.setPin(5, !!clk); if (clk) c64.setInterruptFlag(I64.INT5); }
    p32 = v;
  });
  b.E.addListener(v => {
    const clk = (v >> 3) & 1, dat = (v >> 4) & 1;
    a.D.setPin(0, !!dat);
    if (clk !== ((p64 >> 3) & 1)) { a.D.setPin(2, !!clk); if (clk) c32.setInterruptFlag(I32.INT0); }
    p64 = v;
  });
  const board = { a, b, ee, I32, linkCut: false };
  Object.defineProperty(board, 'wdtResets', { get: () => bd64.wdtResets });
  return board;
}

/* run both chips side by side in small slices (the link needs a few microseconds of accuracy) */
function run(bd, ms) {
  const ends = [bd.a.cpu.cycles + ms * MS, bd.b.cpu.cycles + ms * MS];
  const cpus = [bd.a.cpu, bd.b.cpu];
  const slice = 16;
  while (cpus[0].cycles < ends[0] || cpus[1].cycles < ends[1]) {
    for (let k = 0; k < 2; k++) {
      const c = cpus[k], stop = Math.min(c.cycles + slice, ends[k]);
      while (c.cycles < stop) step(c);
    }
  }
}

/* touch: chip / code of every key (as wired) */
const KEYS = {};
[[3, 0], [2, 2], [1, 4], [0, 6], [4, 12], [5, 14], [6, 16], [7, 18]].forEach(([c, k]) => KEYS[k] = [0, c]);
[[6, 8], [5, 10], [4, 20], [3, 21], [2, 22], [1, 11], [0, 9]].forEach(([c, k]) => KEYS[k] = [1, c]);
[[4, 1], [5, 3], [6, 5], [7, 7], [3, 13], [2, 15], [1, 17], [0, 19]].forEach(([c, k]) => KEYS[k] = [2, c]);
function touch(bd, key, on) {
  const [chip, code] = KEYS[key];
  const b2 = (code >> 2) & 1, b1 = (code >> 1) & 1, b0 = code & 1;
  if (chip === 0) { const C = bd.a.C; C.setPin(5, !!b2); C.setPin(6, !!b1); C.setPin(7, !!b0); C.setPin(4, !on); }
  if (chip === 1) { const A = bd.a.A; A.setPin(6, !!b2); A.setPin(5, !!b1); A.setPin(4, !!b0); A.setPin(7, !on); }
  if (chip === 2) { const A = bd.a.A; A.setPin(2, !!b2); A.setPin(1, !!b1); A.setPin(0, !!b0); A.setPin(3, !on); }
}
function tap(bd, key, ms) { touch(bd, key, true); run(bd, ms || 60); touch(bd, key, false); run(bd, 60); }

/* outputs of the ATmega64: white and red (relay) of every key */
const PINS = [['F', 4, 'F', 5], ['E', 7, 'B', 0], ['A', 5, 'A', 4], ['B', 2, 'B', 3], ['A', 3, 'A', 2], ['G', 4, 'G', 3], ['A', 1, 'A', 0], ['B', 6, 'B', 7],
  ['F', 7, 'F', 6], ['B', 5, 'B', 4], ['A', 7, 'G', 2], ['G', 1, 'C', 0], ['F', 3, 'F', 2], ['E', 6, 'D', 0], ['F', 1, 'F', 0], ['D', 1, 'D', 4],
  ['C', 3, 'C', 4], ['D', 5, 'D', 6], ['C', 5, 'A', 6], ['D', 7, 'G', 0], ['C', 7, 'C', 6], null, ['C', 1, 'C', 2]];
const PORTADDR = { A: 0x3B, B: 0x38, C: 0x35, D: 0x32, E: 0x23, F: 0x62, G: 0x65 };
const DDRADDR = { A: 0x3A, B: 0x37, C: 0x34, D: 0x31, E: 0x22, F: 0x61, G: 0x64 };
const bitOf = (bd, p, n) => (bd.b.cpu.data[PORTADDR[p]] >> n) & 1;
const red = (bd, k) => PINS[k] ? bitOf(bd, PINS[k][2], PINS[k][3]) : 0;
const white = (bd, k) => PINS[k] ? bitOf(bd, PINS[k][0], PINS[k][1]) : 0;
const reds = bd => PINS.map((p, k) => red(bd, k)).join('');
const buzzer = bd => (bd.a.cpu.data[0x38] >> 4) & 1;

/* EV1527 frames into the ATmega32 433 MHz input (PD3 / INT1) */
function rfSend(bd, code, frames, Tus) {
  const T = Tus * 8, seg = [], cpu = bd.a.cpu;
  for (let f = 0; f < frames; f++) {
    seg.push([1, T], [0, 31 * T]);
    for (let i = 23; i >= 0; i--) { const bit = (code >> i) & 1; seg.push([1, bit ? 3 * T : T], [0, bit ? T : 3 * T]); }
  }
  let at = 0;
  for (const [lvl, dur] of seg) { cpu.addClockEvent(() => { bd.a.D.setPin(3, !!lvl); cpu.setInterruptFlag(bd.I32.INT1); }, at + 1); at += dur; }
  run(bd, Math.ceil(at / MS) + 30);
}

function boardWith(cfg, fwName, ee) {
  const text = core.patchHexAt(hex(fwName || 'fw_big_six'), core.buildCfgBig(cfg), core.BIG_ADDR);
  const bd = makeBoard(text, ee);
  bd.b.cpu.data[0x54] = 1;            /* MCUCSR: power-on reset */
  return bd;
}

let fails = 0, checks = 0;
function check(c, m) { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); }
module.exports = { makeBoard, boardWith, run, touch, tap, red, white, reds, buzzer, rfSend, check, PINS, DDRADDR, PORTADDR, core,
  stats: () => ({ fails, checks }) };
