// UI: single 4-pole, no crystal and crystal+remote; checks config block in downloaded hex
var fs=require('fs');const {JSDOM}=require('jsdom');const core=require('./cfgcore');
const dom=new JSDOM(fs.readFileSync('/home/claude/out/sooden-programmer.html','utf8'),{runScripts:'dangerously'});
const w=dom.window,d=w.document; w.URL.createObjectURL=()=>'x'; w.scrollTo=()=>{};
let fails=0,checks=0; const check=(c,m)=>{checks++; if(!c)fails++; console.log((c?'  ok   ':'  FAIL ')+m);};
let lastBlob=null; w.Blob=class{constructor(p){lastBlob=p.join('');}};
const click=s=>{const e=d.querySelector(s); if(!e) throw new Error('missing '+s); e.click();};
const txt=()=>d.querySelector('#stage').textContent;
const cfgOf=hex=>{const m=core.parseHex(hex);return [...Array(128)].map((_,i)=>m.get(0x1F80+i));};
const base=core.parseHex(fs.readFileSync('/home/claude/fw/out/fw_4p.hex','utf8'));

click('.choice[data-k="single"]'); click('.choice[data-v="false"]');
const ok=[...d.querySelectorAll('.mdl[data-ok="1"]')].map(e=>e.dataset.id);
check(ok.join()==='P4', 'no crystal: only 4 pole offered (tiny models archived) -> '+ok.join());
click('.mdl[data-id="P4"]');
check(d.querySelectorAll('.pbeep').length===4, '4 beep checkboxes');
check(!txt().includes('ریموت‌های این پنل'), 'no remote places without crystal');
d.querySelector('.pbeep[data-i="0"]').click(); d.querySelector('.pbeep[data-i="2"]').click();
click('#next');
check(txt().includes('Low 24') && txt().includes('High D1'), 'finish shows fuses 24 / D1');
check(txt().includes('بدون کریستال'), 'finish says no crystal');
lastBlob=null; click('[data-dl="0"]');
let c=cfgOf(lastBlob);
check(c[0]===0x53&&c[1]===0xD2&&c[4]===1&&c[5]===4, 'cfg: 4P board, 4 poles');
check(c.slice(8,12).join()==='1,1,1,1', 'all normal poles');
check(c.slice(12,16).every(x=>x===0xFF), 'no links (single panel, line silent)');
check(c[7]===0, 'remote off');
check(c[29]===5, 'beep mask = poles 1 and 3');
check(c[127]===core.crc8(c,127) && c[2]===3, 'crc ok, config v3');
const mm=core.parseHex(lastBlob); let diff=0; for(const [a,v] of base) if(a<0x1F80&&mm.get(a)!==v) diff++;
check(diff===0, 'program code identical to tested fw.hex');

click('.pc[data-i="0"]'); click('.choice[data-k="single"]'); click('.choice[data-v="true"]'); click('.choice[data-k="remote"]');
check(!!d.querySelector('.mdl[data-id="P4"][data-ok="1"]'), 'crystal + remote: 4 pole offered');
click('.mdl[data-id="P4"]');
check(txt().includes('ریموت‌های این پنل') && d.querySelectorAll('.smodel').length===1, 'remote places shown');
click('#next');
check(txt().includes('Low 3F') && txt().includes('High D1'), 'crystal fuses 3F / D1');
lastBlob=null; click('[data-dl="0"]'); c=cfgOf(lastBlob);
check(c[7]===1 && c[29]===0 && c.slice(12,16).every(x=>x===0xFF), 'cfg: remote on, no beep, no links');

click('.pc[data-i="0"]'); click('.choice[data-k="single"]'); click('.choice[data-v="true"]'); click('.choice[data-k="wifi"]');
check(!d.querySelector('.mdl[data-ok="1"]'), 'wifi path: nothing yet');
console.log(checks+' checks, '+fails+' failed');
