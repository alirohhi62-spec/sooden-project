// Real hex in avr8js: remote hold timer (hold 5 s -> timer, hold 15 s -> choose length 1..4 presses)
var fs=require('fs');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
const { EEPROMMemoryBackend: EB } = require('avr8js');
const R=0x111110;
for (const fw of (process.argv[2]?[process.argv[2]]:['fw_4p_r','fw_4p_pair_r'])) {
  console.log('== '+fw);
  const rmap=[Array(16).fill(0),Array(16).fill(0),Array(16).fill(0),Array(16).fill(0)];
  rmap[0][1]=0x01|0x40;            // A: pole 1, hold timer
  rmap[0][2]=0x06|0x10|0x40;       // B: poles 2+3 only-on, hold timer
  rmap[0][4]=0x08;                 // C: pole 4, no timer
  const tdef=[Array(16).fill(0),Array(16).fill(0),Array(16).fill(0),Array(16).fill(0)];
  tdef[0][2]=1;                    // B defaults to length 2
  const CF={role:0,npoles:4,peerpoles:4,remote:true,type:[1,1,1,1],link:[-1,-1,-1,-1],offmask:[0,0,0,0],onmask:[0,0,0,0],
            minutes:[0,0,0,0],dimsec:0,beep:0,stagMs:250,nslot:1,rmap,tmin:[1,2,3,4],tdef};
  const ee=new EB(512);
  // place 1 = remote R (3 copies, magic 0x60, crc over 14 bytes)
  const blk=[0x60,0x11,0x11,0x10]; for(let i=0;i<9;i++) blk.push(0xFF);
  blk.push(core.crc8(blk,13)); for (const b of [0x10,0x50,0x90]) blk.forEach((v,i)=>ee.memory[b+i]=v);
  let A=makeNode(core.patchHex(FWS[fw],core.buildCfg(CF)),ee); A.board=1; nodes=[A]; connect(false);
  run(1600);
  const st=()=>r4(A).map(v=>v===1?1:0).join('');
  const m=ee.memory;
  // watch the whites of the off poles while the button is held
  const hold=(code,ms)=>{ const frames=Math.round(ms/44.8); let dark=0,was=1; const T=350*8, per=128*T;
    for(let k=0;k<frames;k+=4){ rfSend(A,code,4,350); const w=w4(A)[3]; if(w!==1&&was===1) dark++; was=w; } return dark; };
  rfSend(A,R|1,4,350); run(600); check(st()==='1000','short press A: pole 1 toggles on');
  rfSend(A,R|1,4,350); run(600); check(st()==='0000','short press A again: off');
  console.log('hold A 6 s -> 1 min timer');
  let d=hold(R|1,6000); run(600);
  check(st()==='1000','pole 1 on after release');
  check(d>=1,'whites of off poles blinked at 5 s (pole-4 white went dark '+d+'x)');
  run(55000); check(st()==='1000','still on after ~55 s');
  run(8000);  check(st()==='0000','off after 1 min');
  console.log('touch cancels the timer');
  hold(R|1,6000); run(600); check(st()==='1000','timer again');
  run(5000); tap(A,0); run(300); check(st()==='0000','touched off');
  tap(A,0); run(70000); check(st()==='1000','switched on again by touch: stays on past 1 min');
  tap(A,0); run(300);
  console.log('C has no timer: hold just toggles');
  hold(R|4,6000); run(600); check(st()==='0001','C held: pole 4 toggled, no timer');
  rfSend(A,R|4,4,350); run(600); check(st()==='0000','C off');
  console.log('hold A 16 s -> choose length; 3 presses -> length 3');
  hold(R|1,16500); run(600);
  check(st()==='1000' && w4(A)[1]===1,'released after 15 s: only the first-press toggle, no timer');
  for(let k=0;k<3;k++){ rfSend(A,R|1,4,350); run(800); }
  check(st()==='1000','presses while choosing do not switch');
  run(9000);
  check(m[0x20]!==0x61,'not saved yet 9 s after the last press');
  run(3000);
  check([0x20,0x60,0x1E0].every(b=>m[b]===0x61),'saved in 3 EEPROM copies');
  check(((m[0x21]>>2)&3)===2,'A choice = length 3 (bits)');
  check(((m[0x21]>>4)&3)===1,'B keeps its default (length 2)');
  rfSend(A,R|1,4,350); run(600); check(st()==='0000','back to normal: short press works');
  console.log('choice survives power cut; B: only-on group with 2 min');
  A=makeNode(core.patchHex(FWS[fw],core.buildCfg(CF)),ee); A.board=1; nodes=[A]; connect(false); run(1600);
  hold(R|2,6000); run(1200); check(st()==='0110','B held: poles 2+3 on');
  run(110000); check(st()==='0110','on after ~1 min 55 s');
  run(12000); check(st()==='0000','off after 2 min');
  check(((m[0x21]>>2)&3)===2,'A choice still length 3 after reset');
}
console.log(`\n${checks} checks, ${fails} failed`);
