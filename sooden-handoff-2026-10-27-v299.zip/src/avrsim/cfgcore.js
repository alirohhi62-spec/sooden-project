// Sooden two-way switch - config block builder and hex patcher (shared by configurator and tests)
const CFG_ADDR = 0x1F80, CFG_SIZE = 128;
const RT_TIMER = 0x40, T_OFF = 0, T_NORMAL = 1, T_MASTER = 2, T_TIMER = 3, T_OFFTMR = 4, T_DELOFF = 5, T_DELAY = 6, T_ILOCK = 7, NO_LINK = 0xFF;

function crc8(bytes, n) {
  let c = 0;
  for (let k = 0; k < n; k++) {
    c ^= bytes[k];
    for (let i = 0; i < 8; i++) c = (c & 0x80) ? ((c << 1) ^ 0x07) & 0xFF : (c << 1) & 0xFF;
  }
  return c;
}

// sw: {role:0|1, npoles:1..4, peerpoles, remote:bool, type[4], link[4], offmask[4], onmask[4], minutes[4], dimsec, beep,
//      stagMs (group step, default 80), nslot (remote places, default 4 with remote),
//      rmap: [place][16] entry = poles(bits0-3) | action<<4 (0 toggle, 1 only on, 2 only off) | 0x40 hold timer,
//      tmin: [4] minutes (default 10,30,90,180), tdef: [place][16] default length choice 0..3}
function buildCfg(sw) {
  const b = new Uint8Array(CFG_SIZE);
  b[0] = 0x53; b[1] = 0xD2; b[2] = 3;
  b[3] = sw.role; b[4] = sw.npoles <= 2 ? 0 : 1; b[5] = sw.npoles; b[6] = sw.peerpoles || 0;
  b[7] = sw.remote ? 1 : 0;
  for (let i = 0; i < 4; i++) {
    b[8 + i] = sw.type[i] || 0;
    b[12 + i] = sw.link[i] === undefined || sw.link[i] === null || sw.link[i] < 0 ? NO_LINK : sw.link[i];
    b[16 + i] = sw.offmask[i] || 0;
    b[20 + i] = sw.onmask[i] || 0;
    b[24 + i] = sw.minutes[i] || 0;
  }
  b[28] = sw.dimsec || 0;
  b[29] = sw.beep || 0;      // bit i = buzzer beep when pole i is touched
  b[30] = sw.stagMs ? Math.max(1, Math.min(255, Math.round(sw.stagMs / 10))) : 0;
  b[31] = sw.nslot !== undefined ? sw.nslot : (sw.remote ? 4 : 0);
  const def = [0, 1, 2, 0, 4, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0];   // A,B,C,D (codes 1,2,4,8) -> poles 1..4
  for (let t = 0; t < 4; t++) for (let k = 0; k < 16; k++) b[32 + t * 16 + k] = sw.rmap ? ((sw.rmap[t] && sw.rmap[t][k]) || 0) & 0x7F : def[k];
  // remote hold timer: 4 lengths (minutes) the customer chooses from, and the default choice per place/button
  const tm = sw.tmin || [10, 30, 90, 180];
  for (let i = 0; i < 4; i++) b[96 + i] = Math.max(0, Math.min(255, tm[i] | 0));
  for (let t = 0; t < 4; t++) for (let k = 0; k < 16; k++) {
    const d = sw.tdef && sw.tdef[t] ? (sw.tdef[t][k] | 0) & 3 : 0, n = t * 16 + k;
    b[100 + (n >> 2)] |= d << ((n & 3) * 2);
  }
  // seconds for push buttons / delayed off / curtain-cooler (see cfg.h)
  for (let i = 0; i < 4; i++) { b[116 + i] = (sw.sec1 && sw.sec1[i]) | 0; b[120 + i] = (sw.sec2 && sw.sec2[i]) | 0; }
  // touch timing: ms steady before a touch acts (1..50) and shortest time between two touches (2 ms units)
  b[124] = Math.max(1, Math.min(50, sw.tpress || 2));
  b[125] = Math.max(5, Math.min(250, Math.round((sw.tgap || 30) / 2)));
  b[126] = sw.room || 0;                                       /* room number on the 7-segment network (v2 builds) */
  b[CFG_SIZE - 1] = crc8(b, CFG_SIZE - 1);
  return b;
}

function parseHex(text) {
  const mem = new Map();
  let base = 0;
  for (const raw of text.split(/\r?\n/)) {
    const l = raw.trim();
    if (!l.startsWith(':')) continue;
    const bytes = l.slice(1).match(/../g).map(h => parseInt(h, 16));
    const n = bytes[0], addr = (bytes[1] << 8) | bytes[2], type = bytes[3];
    let sum = 0; for (const x of bytes) sum = (sum + x) & 0xFF;
    if (sum !== 0) throw new Error('bad checksum in hex line: ' + l);
    if (type === 0) for (let i = 0; i < n; i++) mem.set(base + addr + i, bytes[4 + i]);
    else if (type === 2) base = ((bytes[4] << 8) | bytes[5]) << 4;
    else if (type === 4) base = ((bytes[4] << 8) | bytes[5]) << 16;
    else if (type === 1) break;
  }
  return mem;
}

function hx(v, w) { return v.toString(16).toUpperCase().padStart(w, '0'); }

function writeHex(mem) {
  const addrs = [...mem.keys()].sort((a, b) => a - b);
  const out = [];
  let i = 0;
  while (i < addrs.length) {
    const start = addrs[i];
    const row = [mem.get(start)];
    let j = i + 1;
    while (j < addrs.length && addrs[j] === start + row.length && row.length < 16 && ((start + row.length) & 0xF) !== 0) {
      row.push(mem.get(addrs[j])); j++;
    }
    let sum = row.length + (start >> 8) + (start & 0xFF);
    for (const x of row) sum += x;
    out.push(':' + hx(row.length, 2) + hx(start, 4) + '00' + row.map(x => hx(x, 2)).join('') + hx((-sum) & 0xFF, 2));
    i = j;
  }
  out.push(':00000001FF');
  return out.join('\r\n') + '\r\n';
}

function patchHex(fwText, cfgBytes) {
  const mem = parseHex(fwText);
  for (let i = 0; i < CFG_SIZE; i++) {
    if (!mem.has(CFG_ADDR + i)) throw new Error('firmware has no config block');
    mem.set(CFG_ADDR + i, cfgBytes[i]);
  }
  return writeHex(mem);
}


// ===== 23-key board (ATmega64): 768-byte config at 0xF000 =====
// keys 0..19 = places 1..20, 20/21/22 = scenario 1/2/3; masks are 32-bit (bit k = key k)
const BIG_ADDR = 0xF000, BIG_SIZE = 768, T_KEY = 8, T_ALON = 9, T_ALPW = 10, T_EXIT = 11, T_SLEEP = 12, T_ELEV = 13, T_CUSTOM = 14, T_GROUP = 15, BIG_RT_TIMER = 0x04000000;
/* Wi-Fi network name of the panel (bytes 751..766 of the 768-byte blocks): letters, digits, - _ . (empty = automatic sooden-XXXX) */
const SSID_AT = 751, SSID_LEN = 16;
const ssidOk = t => /^[A-Za-z0-9_.\-]{1,16}$/.test(t || '');
function putSsid(b, t) { if (!ssidOk(t)) return; for (let i = 0; i < SSID_LEN; i++) b[SSID_AT + i] = i < t.length ? t.charCodeAt(i) : 0; }
function buildCfgBig(sw) {
  const b = new Uint8Array(BIG_SIZE), NP = 23;
  const u32 = (o, v) => { v >>>= 0; b[o] = v & 255; b[o + 1] = (v >>> 8) & 255; b[o + 2] = (v >>> 16) & 255; b[o + 3] = v >>> 24; };
  b[0] = 0x53; b[1] = 0xD2; b[2] = 0x40; b[3] = sw.role ? 1 : 0; b[4] = 2; b[5] = sw.npoles || 0; b[6] = sw.model || 0; b[7] = sw.remote ? 1 : 0;
  for (let i = 0; i < NP; i++) {
    b[8 + i] = (sw.type && sw.type[i]) || 0;
    const l = sw.link && sw.link[i];                          /* two-panel network: key of the other panel it follows */
    b[31 + i] = l === undefined || l === null || l < 0 ? NO_LINK : l;
    u32(54 + 4 * i, (sw.offmask && sw.offmask[i]) || 0);
    u32(146 + 4 * i, (sw.onmask && sw.onmask[i]) || 0);
    b[238 + i] = (sw.minutes && sw.minutes[i]) || 0;
    b[261 + i] = (sw.sec1 && sw.sec1[i]) || 0;
    b[284 + i] = (sw.sec2 && sw.sec2[i]) || 0;
  }
  u32(307, sw.beep || 0);
  b[311] = sw.dimsec || 0;
  b[312] = sw.stagMs ? Math.max(1, Math.min(255, Math.round(sw.stagMs / 10))) : 10;
  b[313] = sw.nslot !== undefined ? sw.nslot : (sw.remote ? 4 : 0);
  b[314] = Math.max(1, Math.min(50, sw.tpress || 2));
  b[315] = Math.max(5, Math.min(250, Math.round((sw.tgap || 30) / 2)));
  b[316] = sw.alarm ? 1 : 0;
  if (sw.e12) return e12Tail(b, sw);
  for (let t = 0; t < 4; t++) for (let k = 0; k < 16; k++) u32(317 + 4 * (t * 16 + k), (sw.rmap && sw.rmap[t] && sw.rmap[t][k]) || 0);
  const tm = sw.tmin || [10, 30, 90, 180];
  for (let i = 0; i < 4; i++) b[573 + i] = Math.max(0, Math.min(255, tm[i] | 0));
  for (let t = 0; t < 4; t++) for (let k = 0; k < 16; k++) {
    const d = sw.tdef && sw.tdef[t] ? (sw.tdef[t][k] | 0) & 3 : 0, n = t * 16 + k;
    b[577 + (n >> 2)] |= d << ((n & 3) * 2);
  }
  const by = (v, d) => Math.max(0, Math.min(255, v === undefined ? d : v | 0));
  b[593] = by(sw.alArm, 20); b[594] = by(sw.alEntry, 30); b[595] = by(sw.alSiren, 60);   /* alarm times, s */
  const lay = sw.lay || '';                                    /* phone app: role letter of each key, then the model id */
  for (let i = 0; i < NP; i++) { const c = lay.charCodeAt(i); b[596 + i] = c > 32 && c < 127 ? c : 45; }
  const mdl = sw.mdl || '';
  for (let i = 0; i < 7 && i < mdl.length; i++) b[619 + i] = mdl.charCodeAt(i) & 127;
  b[627] = sw.room || 0;
  putSsid(b, sw.ssid);
  b[BIG_SIZE - 1] = crc8(b, BIG_SIZE - 1);
  return b;
}
/* 12 economic panel (SW_E12): the same block up to byte 316, then 12 remote places of one byte a button
   (key + 1 | action << 5 | 0x80 hold timer, as the 12-pole SIM panel) and what follows moves up */
function e12Tail(b, sw) {
  b[313] = sw.nslot !== undefined ? sw.nslot : (sw.remote ? 12 : 0);
  for (let t = 0; t < 12; t++) for (let k = 0; k < 16; k++) b[317 + t * 16 + k] = (sw.rmap && sw.rmap[t] && sw.rmap[t][k]) || 0;
  const tm = sw.tmin || [10, 30, 90, 180];
  for (let i = 0; i < 4; i++) b[509 + i] = Math.max(0, Math.min(255, tm[i] | 0));
  for (let t = 0; t < 12; t++) for (let k = 0; k < 16; k++) {
    const d = sw.tdef && sw.tdef[t] ? (sw.tdef[t][k] | 0) & 3 : 0, n = t * 16 + k;
    b[513 + (n >> 2)] |= d << ((n & 3) * 2);
  }
  b[561] = 20; b[562] = 30; b[563] = 60;                       /* alarm times (no alarm on this panel) */
  const lay = sw.lay || '';
  for (let i = 0; i < 23; i++) { const c = lay.charCodeAt(i); b[564 + i] = c > 32 && c < 127 ? c : 45; }
  const mdl = sw.mdl || 'e12';
  for (let i = 0; i < 7 && i < mdl.length; i++) b[587 + i] = mdl.charCodeAt(i) & 127;
  b[595] = sw.room || 0;
  putSsid(b, sw.ssid);
  b[BIG_SIZE - 1] = crc8(b, BIG_SIZE - 1);
  return b;
}
// ===== two-panel network v2: keys of the OTHER panel in each key's scenario (see cfg.h) =====
// px: { on: [key] -> mask or list of the other panel's keys, off: same, pmdl, play, pnp, wifi (23-key board only) }
const PX_ADDR4 = 0x1F40, PX_SIZE4 = 64, PX_ADDRB = 0xF300, PX_SIZEB = 256;
function buildPx(px, big, nk) {
  const size = big ? PX_SIZEB : PX_SIZE4, n = nk || (big ? 23 : 4), b = new Uint8Array(size);
  const mask = x => Array.isArray(x) ? x.reduce((a, k) => (a | (1 << k)) >>> 0, 0) : (x || 0) >>> 0;
  const put = (o, m) => { b[o] = (m >>> 16) & 0x7F; b[o + 1] = (m >>> 8) & 255; b[o + 2] = m & 255; };
  b[0] = 0x50; b[1] = 0x58; b[2] = n;
  for (let k = 0; k < n; k++) { put(3 + 3 * k, mask(px.on && px.on[k])); put(3 + 3 * n + 3 * k, mask(px.off && px.off[k])); }
  if (big && n === 23) {
    const md = px.pmdl || '', ly = px.play || '';
    for (let i = 0; i < 8; i++) b[141 + i] = i < md.length ? md.charCodeAt(i) & 127 : 0;
    for (let i = 0; i < 23; i++) { const c = ly.charCodeAt(i); b[149 + i] = c > 32 && c < 127 ? c : 45; }
    b[172] = px.pnp || 0; b[173] = px.wifi ? 1 : 0;
  }
  b[size - 1] = crc8(b, size - 1);
  return b;
}
// ===== 12-pole SIM panel (M4 ATmega64): 27 keys, remote table u8 = key+1 | act<<5 | 0x80 hold timer =====
const P12_NP = 27, P12_NET = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 23, 24, 25, 26, 22];   /* network number -> key */
function buildCfgP12(sw) {
  const b = new Uint8Array(BIG_SIZE), NP = P12_NP;
  const u32 = (o, v) => { v >>>= 0; b[o] = v & 255; b[o + 1] = (v >>> 8) & 255; b[o + 2] = (v >>> 16) & 255; b[o + 3] = v >>> 24; };
  b[0] = 0x53; b[1] = 0xD2; b[2] = 0x40; b[3] = sw.role ? 1 : 0; b[4] = 3; b[5] = 15; b[6] = sw.model || 0; b[7] = sw.remote === false ? 0 : 1;
  for (let i = 0; i < NP; i++) {
    b[8 + i] = (sw.type && sw.type[i]) || 0;
    const l = sw.link && sw.link[i];
    b[35 + i] = l === undefined || l === null || l < 0 ? NO_LINK : l;
    u32(62 + 4 * i, (sw.offmask && sw.offmask[i]) || 0);
    u32(170 + 4 * i, (sw.onmask && sw.onmask[i]) || 0);
    b[278 + i] = (sw.minutes && sw.minutes[i]) || 0;
    b[305 + i] = (sw.sec1 && sw.sec1[i]) || 0;
    b[332 + i] = (sw.sec2 && sw.sec2[i]) || 0;
  }
  u32(359, sw.beep || 0);
  b[363] = sw.dimsec === undefined ? 60 : sw.dimsec;
  b[364] = sw.stagMs ? Math.max(1, Math.min(255, Math.round(sw.stagMs / 10))) : 10;
  b[365] = sw.nslot !== undefined ? sw.nslot : 12;
  b[366] = Math.max(1, Math.min(50, sw.tpress || 2));
  b[367] = Math.max(5, Math.min(250, Math.round((sw.tgap || 30) / 2)));
  b[368] = 0;
  for (let t = 0; t < 12; t++) for (let k = 0; k < 16; k++) b[369 + t * 16 + k] = (sw.rmap && sw.rmap[t] && sw.rmap[t][k]) || 0;
  const tm = sw.tmin || [5, 10, 30, 60];
  for (let i = 0; i < 4; i++) b[561 + i] = Math.max(0, Math.min(255, tm[i] | 0));
  for (let t = 0; t < 12; t++) for (let k = 0; k < 16; k++) {
    const d = sw.tdef && sw.tdef[t] ? (sw.tdef[t][k] | 0) & 3 : 0, n = t * 16 + k;
    b[565 + (n >> 2)] |= d << ((n & 3) * 2);
  }
  const lay = sw.lay || '';
  for (let i = 0; i < NP; i++) { const c = lay.charCodeAt(i); b[616 + i] = c > 32 && c < 127 ? c : 45; }
  const mdl = sw.mdl || 'p12';
  for (let i = 0; i < 7 && i < mdl.length; i++) b[643 + i] = mdl.charCodeAt(i) & 127;
  b[651] = sw.room || 0;
  b[654] = sw.clk === undefined ? 21 : sw.clk;                 /* child-lock key + 1 (S6 = key 20), 0 = none */
  b[652] = (sw.rooms === undefined ? 0x1FF : sw.rooms) & 255; b[653] = ((sw.rooms === undefined ? 0x1FF : sw.rooms) >> 8) & 255;
  putSsid(b, sw.ssid);
  b[BIG_SIZE - 1] = crc8(b, BIG_SIZE - 1);
  return b;
}
// alarm MCU of the 12-pole SIM panel: 15 bytes at 0xF000 (see alarm_p12.c)
const AL_ADDR = 0xF000, R_NONE = 0, R_OFF = 0x40, R_TOG = 0x80, R_ARM = 0x10;
function buildAlarmCfg(a) {
  const b = new Uint8Array(15), s = a.siren || [1, 2, 4];
  b[0] = 0xA5;
  b[1] = (a.zone2 ? 2 : 0) | (a.zone3 ? 4 : 0);
  b[2] = s[0] & 7; b[3] = s[1] & 7; b[4] = s[2] & 7;
  b[5] = (a.magOn ? 1 : 0) | (a.magMsg ? 2 : 0) | (a.curSms ? 4 : 0);
  b[6] = (a.magSiren || 0) & 7;
  const r = a.rem || [R_ARM | 1, R_OFF, 0, 0];
  for (let i = 0; i < 4; i++) b[7 + i] = r[i] & 255;
  const by = (v, d) => Math.max(0, Math.min(255, v === undefined ? d : v | 0));
  b[11] = by(a.exitS, 40); b[12] = by(a.entryS, 30);
  const sr = Math.max(0, Math.min(65535, a.sirenS === undefined ? 180 : a.sirenS | 0));
  b[13] = sr & 255; b[14] = sr >> 8;
  return b;
}
function patchHexAt(fwText, cfgBytes, addr) {
  const mem = parseHex(fwText);
  for (let i = 0; i < cfgBytes.length; i++) {
    if (!mem.has(addr + i)) throw new Error('firmware has no config block');
    mem.set(addr + i, cfgBytes[i]);
  }
  return writeHex(mem);
}

if (typeof module !== 'undefined') module.exports = { ssidOk, putSsid, SSID_AT, buildCfgP12, buildAlarmCfg, P12_NP, P12_NET, AL_ADDR, R_NONE, R_OFF, R_TOG, R_ARM, buildPx, PX_ADDR4, PX_SIZE4, PX_ADDRB, PX_SIZEB, T_CUSTOM, T_GROUP, T_ALON, T_ALPW, T_EXIT, T_SLEEP, T_ELEV, BIG_ADDR, BIG_SIZE, T_KEY, BIG_RT_TIMER, buildCfgBig, patchHexAt, RT_TIMER, T_OFFTMR, T_DELOFF, T_DELAY, T_ILOCK, CFG_ADDR, CFG_SIZE, T_OFF, T_NORMAL, T_MASTER, T_TIMER, NO_LINK, crc8, buildCfg, parseHex, writeHex, patchHex };
