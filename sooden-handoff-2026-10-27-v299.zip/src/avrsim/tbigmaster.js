// 23-key board master: "all on" first (one pole on -> all on; all on -> all off)
const B = require('./big.js'); const { run, tap, reds, check } = B;
const type = Array(23).fill(1); type[21] = 2; const onmask = Array(23).fill(0); onmask[21] = 0b1111;
for (const fw of ['fw_big', 'fw_big_a_six_p']) {
  const bd = B.boardWith({ type, onmask, remote: false, nslot: 0, stagMs: 100 }, fw); run(bd, 2500);
  tap(bd, 1); run(bd, 300);
  tap(bd, 21); run(bd, 800);
  check(reds(bd).slice(0, 4) === '1111', fw + ': pole 2 on, master -> places 1..4 all on ' + reds(bd).slice(0, 4));
  tap(bd, 21); run(bd, 800);
  check(reds(bd).slice(0, 4) === '0000', fw + ': master again -> all off');
}
console.log(`${B.stats().checks - B.stats().fails}/${B.stats().checks} passed`);
