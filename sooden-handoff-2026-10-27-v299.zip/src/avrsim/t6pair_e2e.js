// end to end: the hexes the programmer made (itest_6pair.js) on one RS485 line
const M = require('./mix'); const { B, run, tap, red, reds, until } = M;
const fs = require('fs'); const { EEPROMMemoryBackend } = require('avr8js');
const S = '/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/';
let fails = 0, checks = 0; const check = (c, m) => { checks++; if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
const p6 = f => { const c = require('/home/claude/p6/h2')(S + f); c.u.onByteTransmit = null; return { kind: 'p6', c, cpu: c.cpu, usart: c.u, cpus: [[c.cpu, 16, 0]] }; };
const big = f => { const bd = B.makeBoard(fs.readFileSync(S + f, 'utf8'), new EEPROMMemoryBackend(2048)); bd.b.cpu.data[0x54] = 1; bd.b.C.setPin(4, true);
  return { kind: 'big', bd, cpu: bd.b.cpu, usart: bd.b.usart1, cpus: [[bd.a.cpu, 16, 0], [bd.b.cpu, 16, 0]] }; };
const P6 = [3, 4, 2, 5, 0, 7], K7 = 1, K8 = 6;
const tap6 = (n, code) => { n.c.touch(code); run(120); n.c.release(); run(150); };
const red6 = (n, i) => n.c.red(i) === 1, reds6 = n => [0, 1, 2, 3, 4, 5].filter(i => red6(n, i)).join(',');
console.log('1) programmer: 6-pole A (link 1, master + B2, EXIT 5 s - B3) <-> 4-pole B (master on 4 -> A5, A6)');
{
  const A = p6('pr_A6.hex'), Bn = M.m8(fs.readFileSync(S + 'pr_B4.hex', 'utf8'), new EEPROMMemoryBackend(512));
  M.bus([A, Bn], true); run(4000);
  tap6(A, P6[0]); let t = until(1500, () => red(Bn, 0)); check(t > 0, `A pole 1 -> B pole 1 (${t} ms)`);
  tap(Bn, 0); t = until(1500, () => !red6(A, 0)); check(t > 0, `B pole 1 -> A pole 1 off (${t} ms)`);
  tap6(A, K8); t = until(3000, () => reds6(A) === '0,1,2,3,4,5' && red(Bn, 1) && red(Bn, 0));
  check(t > 0, `A master: its 6 + B pole 2 (+ pole 1 linked) (${t} ms) B ${reds(Bn)}`); run(1000);
  tap6(A, K8); t = until(3000, () => reds6(A) === '' && !red(Bn, 1)); check(t > 0, `A master again: all off (${t} ms)`); run(1500);
  tap(Bn, 3); t = until(2000, () => red6(A, 4) && red6(A, 5)); check(t > 0, `B master: A poles 5, 6 (${t} ms) ${reds6(A)}`); run(800);
  tap(Bn, 3); t = until(2000, () => !red6(A, 4) && !red6(A, 5)); check(t > 0, `B master again: off (${t} ms)`); run(800);
  tap(Bn, 2); until(1000, () => red(Bn, 2)); tap6(A, K7); run(3000);
  check(red(Bn, 2), 'A EXIT running: B pole 3 still on');
  t = until(5000, () => !red(Bn, 2)); check(t > 0, `A EXIT over: B pole 3 off (${t} ms)`);
}
console.log('2) programmer: alarm a14 A <-> 6-pole B (pole 2 <-> place 5, B master + places 1, 2)');
{
  const A = big('pr_A14.hex'), Bn = p6('pr_B6.hex');
  M.bus([A, Bn], true); run(5000);
  tap(A, 4); let t = until(1500, () => red6(Bn, 1)); check(red(A, 4) && t > 0, `place 5 -> B pole 2 (${t} ms)`);
  tap6(Bn, P6[1]); t = until(1500, () => !red(A, 4)); check(t > 0, `B pole 2 off -> place 5 off (${t} ms)`);
  tap6(Bn, K8); t = until(3000, () => red(A, 0) && red(A, 1) && reds6(Bn) === '0,1,2,3,4,5');
  check(t > 0, `B master: places 1, 2 on (${t} ms)`);
}
console.log(`${checks - fails}/${checks} passed`);
