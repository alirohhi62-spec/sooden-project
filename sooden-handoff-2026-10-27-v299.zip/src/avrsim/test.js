// Runs the real ATmega8 firmware (patched hex) in avr8js: two switches on one RS485 line
const { step } = require('./step');
const fs = require('fs');
const { CPU, avrInstruction, AVRIOPort, AVRUSART, AVREEPROM, EEPROMMemoryBackend } = require('avr8js');
const core = require('./cfgcore');

const F = 8e6, MS = 8000;
const FWD = '/home/claude/fw/out/';
const FWS = {}; for (const n of fs.readdirSync(FWD).filter(f => f.endsWith('.hex')).map(f => f.slice(0, -4))) FWS[n] = fs.readFileSync(FWD + n + '.hex', 'utf8');
const FW = FWS.fw_4p_pair_r;
/* the hex a panel gets: only what it has */
function fwName(c) {
  const pair = c.link && c.link.some(x => x !== undefined && x !== null && x >= 0);
  if (c.npoles <= 2) return 'fw_2p_pair';
  return 'fw_4p' + (pair ? '_pair' : '') + (c.remote ? '_r' : '');
}
function fwFor(c) { return FWS[fwName(c)]; }
let fails = 0, checks = 0;
function check(c, m) { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); }

const T2 = { address: 3, flagRegister: 0x58, flagMask: 0x80, enableRegister: 0x59, enableMask: 0x80 };
const I1 = { address: 2, flagRegister: 0x5A, flagMask: 0x80, enableRegister: 0x5B, enableMask: 0x80 };

function makeNode(hexText, eeBackend) {
  const mem = core.parseHex(hexText);
  const prog = new Uint16Array(4096);
  for (const [a, v] of mem) { if (a & 1) prog[a >> 1] |= v << 8; else prog[a >> 1] |= v; }
  const cpu = new CPU(prog, 1024);
  const pb = new AVRIOPort(cpu, { PIN: 0x36, DDR: 0x37, PORT: 0x38, externalInterrupts: [] });
  const pc = new AVRIOPort(cpu, { PIN: 0x33, DDR: 0x34, PORT: 0x35, externalInterrupts: [] });
  const pd = new AVRIOPort(cpu, { PIN: 0x30, DDR: 0x31, PORT: 0x32, externalInterrupts: [] });
  const usart = new AVRUSART(cpu, { rxCompleteInterrupt: 11, dataRegisterEmptyInterrupt: 12, txCompleteInterrupt: 13,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x40, UBRRL: 0x29, UBRRH: 0x5C, UDR: 0x2C }, F);
  const ee = eeBackend || new EEPROMMemoryBackend(512);
  new AVREEPROM(cpu, ee, { eepromReadyInterrupt: 15, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 34000, writeCycles: 34000 });
  // Timer2 CTC 1 ms (emulated): fires while TCCR2 has a clock source
  const t2 = () => { if (cpu.data[0x45] & 7) cpu.setInterruptFlag(T2); cpu.addClockEvent(t2, MS); };
  cpu.addClockEvent(t2, MS);
  // Timer1 at 1 MHz for the RF decoder
  let t1hi = 0;
  cpu.readHooks[0x4C] = () => { const v = Math.floor(cpu.cycles / 8) & 0xFFFF; t1hi = v >> 8; return v & 0xFF; };
  cpu.readHooks[0x4D] = () => t1hi;
  // idle inputs: touch lines high (pull-ups / BS818 idle), RF low
  for (let i = 0; i < 8; i++) { pb.setPin(i, true); pc.setPin(i, true); pd.setPin(i, true); }
  pd.setPin(3, false);
  return { cpu, pb, pc, pd, usart, ee, tx: [] };
}

function outBit(port, cpu, bit) { // driven output level
  const ddr = cpu.data[port.portConfig.DDR], prt = cpu.data[port.portConfig.PORT];
  return (ddr >> bit) & 1 ? (prt >> bit) & 1 : -1;
}

let nodes = [];
function connect(echo) {
  nodes.forEach((n, i) => {
    n.usart.onByteTransmit = b => {
      n.tx.push(b);
      for (let j = 0; j < nodes.length; j++) if (j !== i || echo) {
        const r = nodes[j];                                  /* one character at 9600 */
        r.cpu.addClockEvent(() => r.usart.writeByte(b, true), 8 * 1042);
      }
    };
  });
}
function run(ms) {           /* every node advances by the same amount of time */
  const slice = 400, ends = nodes.map(n => n.cpu.cycles + ms * MS);
  let busy = true;
  while (busy) {
    busy = false;
    nodes.forEach((n, k) => {
      const stop = Math.min(n.cpu.cycles + slice, ends[k]);
      while (n.cpu.cycles < stop) step(n.cpu, 0xFFF);  /* 8K flash: PC wraps like the real chip */
      if (n.cpu.cycles < ends[k]) busy = true;
    });
  }
}

// ---- inputs ----
const CODE4 = [7, 0, 3, 4];
function touch(n, pole, on) {
  if (n.board === 1) {
    const c = CODE4[pole];
    if (on) { n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); }
    else { n.pc.setPin(2, true); n.pc.setPin(3, true); n.pc.setPin(4, true); n.pc.setPin(5, true); }
  } else {
    if (pole === 0) n.pb.setPin(5, !on); else n.pd.setPin(4, !on);
  }
}
function tap(n, pole) { touch(n, pole, true); run(60); touch(n, pole, false); run(60); }

// ---- outputs (4P: white/red, 2P: single) ----
function w4(n) { const c = n.cpu; return [outBit(n.pb, c, 1), outBit(n.pb, c, 0), outBit(n.pc, c, 0), outBit(n.pd, c, 5)]; }
function r4(n) { const c = n.cpu; return [outBit(n.pb, c, 2), outBit(n.pd, c, 7), outBit(n.pc, c, 1), outBit(n.pd, c, 6)]; }
function o2(n) { const c = n.cpu; return [outBit(n.pb, c, 3), outBit(n.pb, c, 4)]; }

// ---- RF EV1527 waveform on PD3 ----
function rfSend(n, code, frames, Tus) {
  const T = Tus * 8;
  const seg = [];
  for (let f = 0; f < frames; f++) {
    seg.push([1, T], [0, 31 * T]);
    for (let i = 23; i >= 0; i--) { const b = (code >> i) & 1; seg.push([1, b ? 3 * T : T], [0, b ? T : 3 * T]); }
  }
  let at = 0;
  for (const [lvl, dur] of seg) {
    n.cpu.addClockEvent(() => { n.pd.setPin(3, !!lvl); n.cpu.setInterruptFlag(I1); }, at + 1);
    at += dur;
  }
  run(Math.ceil(at / MS) + 30);
}

function cfg(o) {
  const d = { role: 0, npoles: 4, peerpoles: 4, remote: false, type: [1, 1, 1, 1], link: [-1, -1, -1, -1],
    offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0 };
  return Object.assign(d, o);
}
function boot(cA, cB, eeA, eeB) {
  const A = makeNode(core.patchHex(fwFor(cA), core.buildCfg(cA)), eeA);
  const B = makeNode(core.patchHex(fwFor(cB), core.buildCfg(cB)), eeB);
  A.board = cA.npoles <= 2 ? 0 : 1; B.board = cB.npoles <= 2 ? 0 : 1;
  nodes = [A, B]; connect(true);
  run(700 + 1440);
  return [A, B];
}
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);

console.log('0) hex patcher round trip');
{
  const m1 = core.parseHex(FW), out = core.writeHex(m1), m2 = core.parseHex(out);
  check(m1.size === m2.size && [...m1].every(([a, v]) => m2.get(a) === v), 'parse/write keeps every byte');
  let unc = makeNode(FW); nodes = [unc]; connect(false); run(100);
  check(unc.cpu.data[0x37] === 0 && unc.cpu.data[0x34] === 0 && unc.cpu.data[0x31] === 0, 'unconfigured firmware: all pins stay inputs');
}

console.log('1) 4 pole A (pole 4 master, 3-pole model) <-> 2 pole B: A1-B1, A2-B2');
{
  const [A, B] = boot(
    cfg({ role: 0, npoles: 3, peerpoles: 2, type: [1, 1, 1, 2], link: [0, 1, -1, -1], onmask: [0, 0, 0, 7] }),
    cfg({ role: 1, npoles: 2, peerpoles: 3, type: [1, 1, 0, 0], link: [0, 1, -1, -1] }));
  check(eq(w4(A), [1, 1, 1, 1]) && eq(r4(A), [0, 0, 0, 0]), 'A boots: all white, relays off');
  check(eq(o2(B), [0, 0]), 'B boots: outputs off');
  check(A.cpu.data[0x2A] === 0x98 && A.cpu.data[0x29] === 51, 'UART 9600 8N1 set up');
  tap(A, 0); run(200);
  check(eq(r4(A), [1, 0, 0, 0]) && w4(A)[0] === 0 && eq(o2(B), [1, 0]), 'A pole1 -> A red + B pole1 on');
  tap(B, 1); run(200);
  check(eq(r4(A), [1, 1, 0, 0]) && eq(o2(B), [1, 1]), 'B pole2 -> A pole2 on');
  tap(B, 0); run(200);
  check(eq(r4(A), [0, 1, 0, 0]) && eq(o2(B), [0, 1]), 'B pole1 off -> A pole1 off');
  // master: any on -> all off, staggered
  touch(A, 3, true);
  const t0 = A.cpu.cycles; let seen = [];
  for (let i = 0; i < 40; i++) { run(10); const r = r4(A); if (r[1] === 0 && !seen[1]) seen[1] = (A.cpu.cycles - t0) / MS; if (i === 4) touch(A, 3, false); }
  check(eq(r4(A), [0, 0, 0, 0]) && eq(o2(B), [0, 0]), 'master: one was on -> all off (B too)');
  touch(A, 3, true);
  const times = [0, 0, 0]; const t1 = A.cpu.cycles;
  for (let i = 0; i < 300; i++) { run(1); if (i === 40) touch(A, 3, false); const r = r4(A); for (let p = 0; p < 3; p++) if (r[p] === 1 && !times[p]) times[p] = Math.round((A.cpu.cycles - t1) / MS); }
  console.log('     relays on at +' + times.join(' +') + ' ms');
  check(times[0] > 0 && times[1] - times[0] >= 75 && times[2] - times[1] >= 75, 'master on: pole1, 2, 3 in order, ~80 ms apart');
  run(300);
  check(eq(o2(B), [1, 1]) && w4(A)[3] === 1 && r4(A)[3] === 0, 'B follows; master LED white, relay off');
  // B reboots alone -> takes A's state
  const cB2 = cfg({ role: 1, npoles: 2, peerpoles: 3, type: [1, 1, 0, 0], link: [0, 1, -1, -1] }); const B2 = makeNode(core.patchHex(fwFor(cB2), core.buildCfg(cB2)));
  B2.board = 0; nodes = [A, B2]; connect(true); run(1500);
  check(eq(o2(B2), [1, 1]), 'B after power cycle restores linked poles from A');
}

console.log('2) remote on A (4 pole), learn / use / erase, EEPROM survives reset');
{
  const eeA = new EEPROMMemoryBackend(512);
  const cA = cfg({ role: 0, npoles: 4, remote: true, link: [0, -1, -1, -1] });
  const cB = cfg({ role: 1, npoles: 4, link: [0, -1, -1, -1] });
  let [A, B] = boot(cA, cB, eeA);
  const id = 0x5C3A10;
  rfSend(A, id | 1, 4, 350); run(200);
  check(r4(A)[0] === 0, 'unknown remote ignored');
  touch(A, 0, true); run(5100);
  let on = 0, off = 0;
  for (let i = 0; i < 40; i++) { run(25); if (w4(A)[0] === 1) on++; else off++; }
  touch(A, 0, false); run(50);
  check(on > 8 && off > 8, 'hold pole1 5 s -> white blinks (' + on + '/' + off + ')');
  check(r4(A)[0] === 0 && r4(B)[0] === 0, 'short-press toggle undone on both');
  rfSend(A, id | 2, 3, 350); run(100);
  check(w4(A)[0] === 1, 'remote learned -> white solid');
  run(2300);
  check(eeA.memory[0x10] === 0x60 && eeA.memory[0x50] === 0x60 && eeA.memory[0x90] === 0x60, 'stored in 3 EEPROM copies');
  rfSend(A, id | 1, 4, 350); run(300);
  check(r4(A)[0] === 1 && r4(B)[0] === 1, 'remote btn1 -> A pole1 + linked B pole1');
  rfSend(A, id | 8, 4, 450); run(300);
  check(r4(A)[3] === 1 && r4(B)[3] === 0, 'remote btn4 (T=450us) -> A pole4 only');
  // reset A: remote still known
  A = makeNode(core.patchHex(fwFor(cA), core.buildCfg(cA)), eeA); A.board = 1; nodes = [A, B]; connect(true); run(1500 + 1440);
  check(r4(A)[0] === 1, 'A after reset takes linked pole1 state from B');
  rfSend(A, id | 4, 4, 300); run(300);
  check(r4(A)[2] === 1, 'after reset remote still works (btn3, T=300us)');
  // erase: hold pole2 5 s, touch pole2 again
  touch(A, 1, true); run(5100); touch(A, 1, false); run(300);
  tap(A, 1); run(2300);
  rfSend(A, id | 4, 4, 300); run(300);
  check(r4(A)[2] === 1, 'after erase remote does nothing (pole3 unchanged)');
  check([0,1,2,3].every(i => eeA.memory[0x11 + i * 3] === 0xFF && eeA.memory[0x13 + i * 3] === 0xFF), 'EEPROM: every place empty');
}

console.log('3) dimming on 4 pole');
{
  const [A] = boot(cfg({ role: 0, npoles: 4, dimsec: 2 }), cfg({ role: 1, npoles: 4 }));
  run(2300);
  check(eq(w4(A), [0, 0, 0, 1]), 'after 2 s idle: only pole4 white');
  tap(A, 0); run(100);
  check(eq(w4(A).slice(1), [1, 1, 1]) && r4(A)[0] === 1, 'first touch wakes and switches at once');
}

console.log('4) 433 receiver noise flood while working (ISR load)');
{
  const cA = cfg({ role: 0, npoles: 4, remote: true, link: [0, 1, 2, -1] });
  const cB = cfg({ role: 1, npoles: 4, link: [0, 1, 2, -1] });
  const [A, B] = boot(cA, cB);
  let lvl = 0, seed = 12345;
  const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF) / 0x7FFFFFFF;
  const noise = () => { lvl ^= 1; A.pd.setPin(3, !!lvl); A.cpu.setInterruptFlag(I1); A.cpu.addClockEvent(noise, 8 * (20 + Math.floor(rnd() * 300))); };
  A.cpu.addClockEvent(noise, 10);
  for (let p = 0; p < 3; p++) { tap(A, p); run(150); }
  check(eq(r4(A).slice(0, 3), [1, 1, 1]) && eq(r4(B).slice(0, 3), [1, 1, 1]), 'touch + link work under heavy RF noise');
  tap(B, 1); run(300);
  check(r4(A)[1] === 0, 'B -> A still works under noise');
  check(r4(A)[3] === 0, 'noise never triggers anything');
}

console.log('5) service scenario on 4 pole (like original: pole4 -> 1 off, 3 on, 4 relay on, timer)');
{
  const [A, B] = boot(cfg({ role: 0, npoles: 4, type: [1, 1, 1, 3], link: [0, -1, 2, -1], offmask: [0, 0, 0, 1], onmask: [0, 0, 0, 4], minutes: [0, 0, 0, 1] }),
                      cfg({ role: 1, npoles: 4, link: [0, -1, 2, -1] }));
  tap(A, 0); tap(A, 1); run(300);
  tap(A, 3); run(400);
  check(eq(r4(A), [0, 1, 1, 1]) && w4(A)[3] === 0, 'service: 1 off, 2 stays, 3 on, pole4 relay+red on');
  check(r4(B)[0] === 0 && r4(B)[2] === 1, 'linked B1 off, B3 on');
  tap(A, 2); run(300);
  check(r4(A)[2] === 0 && r4(A)[3] === 0 && w4(A)[3] === 1, 'pole3 off by hand -> pole4 off, white');
  tap(A, 3); run(61500);
  check(r4(A)[2] === 0 && r4(A)[3] === 0 && r4(B)[2] === 0, 'timeout after 1 min: 3 and 4 off (B3 too)');
}

console.log('\n' + checks + ' checks, ' + fails + ' failed');
process.exit(fails ? 1 : 0);
