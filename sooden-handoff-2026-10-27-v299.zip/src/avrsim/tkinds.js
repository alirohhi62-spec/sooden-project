// Real hex in avr8js: curtain, cooler + off timer, push buttons, delayed off (groups _s / _i)
var fs=require('fs');
let src=fs.readFileSync(__dirname+'/test.js','utf8');src=src.slice(0,src.indexOf("console.log('0)"));
eval(src.replace(/^const /gm,"var ").replace(/^let /gm,"var "));
const base={role:0,npoles:4,peerpoles:4,remote:false,link:[-1,-1,-1,-1],offmask:[0,0,0,0],onmask:[0,0,0,0],minutes:[0,0,0,0],dimsec:0,beep:0,stagMs:250,nslot:0};
const mk=(fw,o)=>{ const A=makeNode(core.patchHex(FWS[fw],core.buildCfg(Object.assign({},base,o)))); A.board=1; nodes=[A]; connect(false); run(1600); return A; };
const st=A=>r4(A).map(v=>v===1?1:0).join('');
for (const fw of ['fw_4p_si','fw_4p_r_si','fw_4p_pair_si']) {
  console.log('== '+fw);
  const rem = fw.includes('_r_');
  // curtain 1/2 + cooler: 3 pump? -> use poles: 1 open, 2 close, 3 pulse 2 s, 4 delayed off 3 s
  let A=mk(fw,{remote:rem,type:[7,7,6,5],offmask:[2,1,0,0],sec1:[45,45,0,3],sec2:[5,5,2,0]});
  tap(A,0); run(1000); check(st(A)==='1000','curtain open running');
  tap(A,1); run(200); check(st(A)==='0000','close touched while opening: open stops');
  run(1500); check(st(A)==='0000','and close does not start (only stop)');
  tap(A,1); run(300); check(st(A)==='0100','close from rest runs');
  run(45200); check(st(A)==='0000','close stops by itself (45 s)');
  tap(A,2); run(300); check(st(A)==='0010','pulse on'); run(2000); check(st(A)==='0000','pulse off after 2 s');
  tap(A,3); run(300); tap(A,3); run(2000); check(st(A)==='0001','delayed off: still on'); run(1500); check(st(A)==='0000','off after 3 s');
  // cooler: 1 pump, 2 slow, 3 fast, 4 off timer 1 min
  A=mk(fw,{remote:rem,type:[1,7,7,4],offmask:[0,4,2,7],onmask:[0,1,1,0],sec2:[0,10,10,0],minutes:[0,0,0,1]});
  tap(A,1); run(1000); check(st(A)==='1100','slow + pump');
  tap(A,2); run(400); check(st(A)==='1000','fast touched: slow off, pause');
  run(1200); check(st(A)==='1010','fast on after 1 s');
  tap(A,3); run(500); check(st(A)==='1011','off timer running');
  run(61000); check(st(A)==='0000','1 min: everything off');
  // delayed push button 2 s, stays on
  A=mk(fw,{remote:rem,type:[6,1,1,1],sec1:[2,0,0,0],sec2:[0,0,0,0]});
  tap(A,0); let bl=0,was=w4(A)[0]; for(let i=0;i<30;i++){ run(50); const w=w4(A)[0]; if(w!==was) bl++; was=w; }
  check(st(A)==='0000' && bl>=3,'delayed: waiting with white blinking ('+bl+')');
  run(800); check(st(A)==='1000','on after 2 s'); run(10000); check(st(A)==='1000','stays on');
}
console.log('== kinds refused by a hex without them');
const W=makeNode(core.patchHex(FWS.fw_4p_r,core.buildCfg(Object.assign({},base,{remote:true,type:[7,7,1,1],offmask:[2,1,0,0]})))); nodes=[W]; connect(false); run(200);
check(W.cpu.data[0x37]===0,'fw_4p_r refuses curtain settings (pins stay inputs)');
const W2=makeNode(core.patchHex(FWS.fw_4p_i,core.buildCfg(Object.assign({},base,{type:[6,1,1,1]})))); nodes=[W2]; connect(false); run(200);
check(W2.cpu.data[0x37]===0,'_i hex refuses a push button');
for (const fw of ['fw_4p_x','fw_4p_r_six','fw_4p_pair_six']) {
  console.log('== '+fw+': EXIT / SLEEP / ELEVATOR');
  const rem = fw.includes('_r_');
  /* 1 normal, 2 normal, 3 EXIT 10 s (off 1+2), 4 SLEEP 12 s (off 1, night light 2) */
  let A=mk(fw,{remote:rem,type:[1,1,11,12],offmask:[0,0,3,1],onmask:[0,0,0,2],sec1:[0,0,10,12],sec2:[0,0,0,0]});
  tap(A,0); tap(A,1); run(300); check(st(A)==='1100','poles 1, 2 on');
  tap(A,2); run(300); check(st(A)==='1110','EXIT running (pole 3 relay = indicator)');
  tap(A,0); run(300); check(st(A)==='1110','locked: touch ignored');
  run(10500); check(st(A)==='0000','after 10 s: all off');
  tap(A,0); run(300); check(st(A)==='1000','unlocked');
  tap(A,3); run(12800); check(st(A)==='0100','SLEEP: pole 1 off, night light on');
  /* elevator on pole 1 */
  A=mk(fw,{remote:rem,type:[13,1,1,1],onmask:[1,0,0,0]});
  tap(A,0); run(300); check(st(A)==='0000','elevator: short touch nothing');
  touch(A,0,true); let on=-1,len=0; for(let i=0;i<2500;i++){ run(1); if(r4(A)[0]===1){ if(on<0) on=i; len++; } } touch(A,0,false); run(100);
  check(on>950&&on<1080&&len>950&&len<1060,`held 1 s: relay 1 s (${on} / ${len} ms)`);
}
console.log(`\n${checks} checks, ${fails} failed`);
