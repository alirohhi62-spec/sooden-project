const B = require('./big.js');
const { run, touch, tap, red, white, reds, check } = B;
const ALL = Array(23).fill(1); ALL[21] = 2;           /* scenario 2 (no LED): a master */
const base = { type: ALL, onmask: Array(23).fill(0), remote: true, nslot: 4, stagMs: 100 };
base.onmask[21] = 0b111;                               /* scenario 2 switches places 1..3 */
console.log('1) power-up and every key');
let bd = B.boardWith(base);
run(bd, 300);
const lit = []; for (let t = 0; t < 14; t++) { run(bd, 100); lit.push([...Array(23).keys()].filter(k => B.white(bd, k)).length); }
check(lit.slice(0, 9).every(n => n <= 1), 'power-up: one white at a time (' + lit.join(',') + ')');
run(bd, 400);
check(reds(bd) === '0'.repeat(23), 'all relays off after power-up');
check([...Array(23).keys()].filter(k => k !== 21).every(k => white(bd, k) === 1), 'every white on');
let ok = true, bad = [];
for (let k = 0; k < 23; k++) {
  if (k === 21) continue;
  tap(bd, k);
  if (red(bd, k) !== 1 || reds(bd).split('').filter(x => x === '1').length !== 1) { ok = false; bad.push(k); }
  tap(bd, k);
  if (red(bd, k) !== 0) { ok = false; bad.push(k); }
}
check(ok, 'each of the 22 keys switches only its own relay, on and off' + (bad.length ? ' bad: ' + bad : ''));
console.log('2) speed');
touch(bd, 4, true); let lat = -1; for (let i = 0; i < 40; i++) { run(bd, 1); if (red(bd, 4)) { lat = i + 1; break; } } touch(bd, 4, false); run(bd, 60);
check(lat > 0 && lat <= 7, 'touch -> relay ' + lat + ' ms (through both chips)');
let n = 0, l = red(bd, 4);
for (let i = 0; i < 6; i++) { touch(bd, 4, true); run(bd, 35); touch(bd, 4, false); run(bd, 25); if (red(bd, 4) !== l) { n++; l = red(bd, 4); } }
check(n === 6, '6 fast taps: all counted (' + n + ')');
console.log('3) scenario key 2 = master of places 1..3 (in 100 ms steps)');
tap(bd, 21); run(bd, 400);
check(red(bd, 0) && red(bd, 1) && red(bd, 2), 'scenario 2: places 1, 2, 3 on');
tap(bd, 21); run(bd, 400);
check(!red(bd, 0) && !red(bd, 1) && !red(bd, 2), 'again: off');

console.log('4) remote: learn on place 1, per-button table with any of the 23 keys, hold timer');
{
  const rmap = [Array(16).fill(0), Array(16).fill(0), Array(16).fill(0), Array(16).fill(0)];
  rmap[0][1] = 1 << 14;                                   /* A -> place 15 */
  rmap[0][2] = (1 << 19) | (1 << 22) | (1 << 24);         /* B -> place 20 + scenario 3, only on */
  rmap[0][4] = (1 << 9) | B.core.BIG_RT_TIMER;            /* C -> place 10, hold = timer */
  const cfg = Object.assign({}, base, { rmap, tmin: [1, 2, 3, 4] });
  bd = B.boardWith(cfg); run(bd, 1800);
  const R = 0x5A3C10;
  touch(bd, 0, true); run(bd, 5200); touch(bd, 0, false); run(bd, 100);
  let bl = 0, was = B.white(bd, 0); for (let i = 0; i < 20; i++) { run(bd, 50); const w = B.white(bd, 0); if (w !== was) bl++; was = w; }
  check(bl >= 3 && red(bd, 0) === 0, 'hold place 1 for 5 s: its white blinks, relay unchanged');
  B.rfSend(bd, R | 1, 4, 350); run(bd, 2500);
  const ee = bd.ee.memory; const id = (ee[0x11] << 16) | (ee[0x12] << 8) | ee[0x13];
  check(id === R, 'remote learned into place 1 (EEPROM ' + id.toString(16) + ')');
  B.rfSend(bd, R | 1, 4, 350); run(bd, 300);
  check(red(bd, 14) === 1 && reds(bd).split('1').length === 2, 'button A -> place 15 only');
  B.rfSend(bd, R | 2, 4, 350); run(bd, 500);
  check(red(bd, 19) === 1 && red(bd, 22) === 1, 'button B (only on) -> place 20 and scenario 3');
  B.rfSend(bd, R | 2, 4, 350); run(bd, 500);
  check(red(bd, 19) === 1 && red(bd, 22) === 1, 'B again: stays on');
  for (let f = 0; f < 30; f++) B.rfSend(bd, R | 4, 4, 350);
  run(bd, 800);
  check(red(bd, 9) === 1, 'C held 5 s: place 10 on with the timer');
  run(bd, 58000); check(red(bd, 9) === 1, 'still on at 58 s');
  run(bd, 4000); check(red(bd, 9) === 0, 'timer (1 min): off');
  console.log('5) the ATmega64 restarts: remotes kept, link back');
  const ee2 = bd.ee;
  const bd2 = B.boardWith(cfg, 'fw_big_si', ee2); run(bd2, 2000);
  B.rfSend(bd2, R | 1, 4, 350); run(bd2, 300);
  check(red(bd2, 14) === 1, 'after restart the learned remote still works');
  tap(bd2, 3); check(red(bd2, 3) === 1, 'touch works after restart');
}
console.log('6) the ATmega32 restarts / goes silent');
{
  bd = B.boardWith(base); run(bd, 1800);
  touch(bd, 5, true); run(bd, 100);
  check(red(bd, 5) === 1, 'key held: relay on');
  bd.a.restart(); run(bd, 20);                  /* ATmega32 restarts while the finger is on the key */
  run(bd, 1500);
  touch(bd, 5, false); run(bd, 100);
  tap(bd, 6); tap(bd, 5);
  check(red(bd, 6) === 1 && red(bd, 5) === 0, 'after the ATmega32 restart: keys work again, nothing stuck');
  /* noise on the link clock: random pulses, then normal use */
  let ok = true;
  for (let n = 0; n < 200; n++) { bd.b.E.setPin(5, true); bd.b.cpu.setInterruptFlag({ address: 12, flagRegister: 0x58, flagMask: 0x20, enableRegister: 0x59, enableMask: 0x20 }); run(bd, 0.05); bd.b.E.setPin(5, false); run(bd, 0.3); }
  run(bd, 200);
  const before = reds(bd);
  tap(bd, 7); if (red(bd, 7) !== 1) ok = false;
  check(ok && reds(bd).slice(0, 7) === before.slice(0, 7), 'noise on the link: ignored, next touch works');
}
console.log('7) beep, dimming, kinds on the big board');
{
  const t = Array(23).fill(1); t[10] = 7; t[11] = 7; t[21] = 2;
  const off = Array(23).fill(0); off[10] = 1 << 11; off[11] = 1 << 10;
  const sec1 = Array(23).fill(0); sec1[10] = 5; sec1[11] = 5; const sec2 = Array(23).fill(0); sec2[10] = 5; sec2[11] = 5;
  bd = B.boardWith({ type: t, offmask: off, onmask: Array(23).fill(0), sec1, sec2, beep: 1 << 2, dimsec: 3, remote: true, nslot: 4 }); run(bd, 1800);
  let bz = 0; touch(bd, 2, true); for (let i = 0; i < 60; i++) { run(bd, 1); bz |= B.buzzer(bd); } touch(bd, 2, false); run(bd, 100);
  check(bz === 1 && B.buzzer(bd) === 0, 'key 3 beeps (buzzer on the ATmega32) and stops');
  tap(bd, 2); run(bd, 4300);
  const lit = [...Array(23).keys()].filter(k => B.white(bd, k));
  check(lit.join() === '', 'dark after 3 s idle: every white off (' + lit + ')');
  tap(bd, 10); run(bd, 300);
  check(red(bd, 10) === 0 && B.white(bd, 0) === 1, 'dark: first touch only lights the panel');
  tap(bd, 10); run(bd, 300); check(red(bd, 10) === 1, 'second touch: curtain open runs');
  tap(bd, 11); run(bd, 1500); check(red(bd, 10) === 0 && red(bd, 11) === 0, 'close touched while opening: only stops');
  tap(bd, 11); run(bd, 200); check(red(bd, 11) === 1, 'close from rest runs');
  run(bd, 5000); check(red(bd, 11) === 0, 'stops after 5 s');
}
console.log('8) alarm layout: keys without relay leave their red pin free (PIR on 17, siren on 16)');
{
  const t = Array(23).fill(1); [12, 13, 14, 15, 16, 17].forEach(k => t[k] = 8); t[0] = 0; t[1] = 0;
  bd = B.boardWith({ type: t, onmask: Array(23).fill(0), remote: true, nslot: 4, alarm: 0 }, 'fw_big_a'); run(bd, 1800);
  const ddr = (p, n) => (bd.b.cpu.data[B.DDRADDR[p]] >> n) & 1;
  check(ddr('C', 4) === 0 && ddr('D', 4) === 0, 'key 17 red (PC4, PIR) and key 16 red (PD4, siren): inputs');
  check(ddr('F', 5) === 0 && ddr('B', 0) === 0, 'empty keys 1, 2: red pins inputs');
  const prt = (p, n) => (bd.b.cpu.data[B.PORTADDR[p]] >> n) & 1;
  check(prt('C', 4) === 0 && prt('D', 4) === 0 && prt('F', 5) === 0, 'and without pull-up (nothing pushed into the siren driver / against the sensor)');
  check(ddr('F', 4) === 1 && ddr('C', 3) === 1 && ddr('B', 3) === 1, 'white LEDs and real relays (key 4) still outputs');
  tap(bd, 16); run(bd, 100);
  check(ddr('C', 4) === 0 && red(bd, 16) === 0, 'touching a keypad key: no relay');
  tap(bd, 3); check(red(bd, 3) === 1, 'normal pole beside it works');
}
console.log(`\n${B.stats().checks} checks, ${B.stats().fails} failed`);
