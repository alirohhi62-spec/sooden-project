const M = require('/home/claude/avrsim/mix'); const { C, run } = M;
const { EEPROMMemoryBackend } = require('avr8js');
const ob = (nd, port, bit) => ((nd.cpu.data[port] >> bit) & 1) && ((nd.cpu.data[port - 1] >> bit) & 1);
const c2 = o => Object.assign({ role: 0, npoles: 2, peerpoles: 2, remote: false, type: [1, 1, 0, 0], link: [-1, -1, -1, -1],
  offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 0, sec1: [0, 0, 0, 0], sec2: [0, 0, 0, 0] }, o);
for (const [na, nb, la] of [[1, 1, [0, -1, -1, -1]], [2, 2, [0, 1, -1, -1]], [1, 2, [0, -1, -1, -1]]]) {
  const px0 = () => C.buildPx({ on: [], off: [] }, false);
  const A = M.m8Node(c2({ npoles: na, peerpoles: nb, type: na == 1 ? [1, 0, 0, 0] : [1, 1, 0, 0], link: la }), 'fw_2p_px', px0(), new EEPROMMemoryBackend(512));
  const B = M.m8Node(c2({ role: 1, npoles: nb, peerpoles: na, type: nb == 1 ? [1, 0, 0, 0] : [1, 1, 0, 0], link: la }), 'fw_2p_px', px0(), new EEPROMMemoryBackend(512));
  M.bus([A, B], true);
  const ev = [];
  for (let t = 0; t < 4000; t++) { run(1); const s = [A, B].map(n => '' + ob(n, 0x38, 3) + ob(n, 0x38, 4)).join('|'); if (ev.length === 0 || ev[ev.length - 1][1] !== s) ev.push([t, s]); }
  console.log(na + '-pole A, ' + nb + '-pole B:', JSON.stringify(ev));
}
