// Simulation of the 12 economic panel (E12): one ATmega64 hex in avr8js, wired like the board
const { step } = require('./step');
const fs = require('fs');
const { CPU, AVRIOPort, AVREEPROM, EEPROMMemoryBackend, AVRUSART } = require('avr8js');
const core = require('./cfgcore');
const MS = 8000;
const FWD = '/home/claude/fw/out/';
const hex = n => fs.readFileSync(FWD + n + '.hex', 'utf8');
function loadProg(text, words) {
  const mem = core.parseHex(text), prog = new Uint16Array(words);
  for (const [a, v] of mem) { if (a & 1) prog[a >> 1] |= v << 8; else prog[a >> 1] |= v; }
  return prog;
}
const port = (cpu, PIN, DDR, PORT) => new AVRIOPort(cpu, { PIN, DDR, PORT, externalInterrupts: [] });
const INT7 = { address: 16, flagRegister: 0x58, flagMask: 0x80, enableRegister: 0x59, enableMask: 0x80 };

function makeBoard(text, eeBackend) {
  const c = new CPU(loadProg(text, 32768), 4096);
  const b = { cpu: c, A: port(c, 0x39, 0x3A, 0x3B), B: port(c, 0x36, 0x37, 0x38), C: port(c, 0x33, 0x34, 0x35),
    D: port(c, 0x30, 0x31, 0x32), E: port(c, 0x21, 0x22, 0x23), F: port(c, 0x20, 0x61, 0x62), G: port(c, 0x63, 0x64, 0x65) };
  b.ee = eeBackend || new EEPROMMemoryBackend(2048);
  new AVREEPROM(c, b.ee, { eepromReadyInterrupt: 44, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 34000, writeCycles: 34000 });
  b.usart = new AVRUSART(c, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
  b.usart.UDRE.constant = true;
  b.usart1 = new AVRUSART(c, { rxCompleteInterrupt: 0x3C, dataRegisterEmptyInterrupt: 0x3E, txCompleteInterrupt: 0x40,
    UCSRA: 0x9B, UCSRB: 0x9A, UCSRC: 0x9D, UBRRL: 0x99, UBRRH: 0x98, UDR: 0x9C }, 8000000);
  b.usart1.UDRE.constant = true;
  const T0 = { address: 30, flagRegister: 0x56, flagMask: 0x02, enableRegister: 0x57, enableMask: 0x02 };
  const t0 = () => { if (c.data[0x53] & 7) c.setInterruptFlag(T0); c.addClockEvent(t0, MS); }; c.addClockEvent(t0, MS);
  let hi = 0;
  c.readHooks[0x4C] = () => { const v = Math.floor(c.cycles / 8) & 0xFFFF; hi = v >> 8; return v & 0xFF; };
  c.readHooks[0x4D] = () => hi;
  /* watchdog as the real chip */
  const wd = { on: false, presc: 0, until: 0, ce: 0 };
  const wdLen = () => Math.round(16.3 * (1 << wd.presc) * MS);
  c.onWatchdogReset = () => { wd.until = c.cycles + wdLen(); };
  c.writeHooks[0x41] = v => {
    if ((v & 0x18) === 0x18) { wd.ce = c.cycles + 4; c.data[0x41] = v; return true; }
    if (!(v & 8) && c.cycles > wd.ce) v |= 8 * wd.on;
    wd.on = !!(v & 8); wd.presc = v & 7; wd.until = c.cycles + wdLen(); c.data[0x41] = v & 0x0F; return true;
  };
  b.wdtResets = 0;
  const wdCheck = () => { if (wd.on && c.cycles >= wd.until) { b.wdtResets++; wd.until = c.cycles + wdLen(); } c.addClockEvent(wdCheck, MS); };
  c.addClockEvent(wdCheck, MS);
  /* idle: touch lines high (no touch), 433 low */
  for (let i = 0; i < 8; i++) { b.A.setPin(i, true); b.C.setPin(i, true); }
  b.E.setPin(7, false);
  return b;
}
function run(b, ms) { const end = b.cpu.cycles + ms * MS; while (b.cpu.cycles < end) step(b.cpu); }

/* touch: [chip, code] of every place (0..11 poles, 20..22 scenarios) */
const KEYS = {};
[6, 2, 21, 8, 20, 4, 0, 10].forEach((k, code) => { KEYS[k] = [0, code]; });
[11, 9, 1, 3, 5, 7, 22].forEach((k, code) => { KEYS[k] = [1, code]; });
function touch(b, key, on) {
  const [chip, code] = KEYS[key], b2 = (code >> 2) & 1, b1 = (code >> 1) & 1, b0 = code & 1;
  if (chip === 0) { b.A.setPin(3, !!b2); b.A.setPin(2, !!b1); b.A.setPin(0, !!b0); b.A.setPin(1, !on); }
  else { b.C.setPin(3, !!b2); b.C.setPin(1, !!b1); b.C.setPin(0, !!b0); b.C.setPin(4, !on); }
}
function tap(b, key, ms) { touch(b, key, true); run(b, ms || 60); touch(b, key, false); run(b, 80); }

const PINS = [['F', 2, 'F', 3], ['B', 2, 'B', 3], ['F', 4, 'F', 6], ['B', 4, 'B', 5], ['F', 5, 'A', 6], ['B', 6, 'D', 0], ['A', 7, 'C', 7], ['D', 4, 'D', 6],
  ['F', 1, 'F', 0], ['B', 7, 'G', 3], ['A', 4, 'A', 5], ['D', 5, 'G', 1], null, null, null, null, null, null, null, null,
  ['C', 6, 'C', 5], null, ['D', 7, 'G', 0]];
const PORTADDR = { A: 0x3B, B: 0x38, C: 0x35, D: 0x32, E: 0x23, F: 0x62, G: 0x65 };
const DDRADDR = { A: 0x3A, B: 0x37, C: 0x34, D: 0x31, E: 0x22, F: 0x61, G: 0x64 };
const bit = (b, p, n) => (b.cpu.data[PORTADDR[p]] >> n) & 1 & (b.cpu.data[DDRADDR[p]] >> n);
const red = (b, k) => PINS[k] ? bit(b, PINS[k][2], PINS[k][3]) : 0;
const white = (b, k) => PINS[k] ? bit(b, PINS[k][0], PINS[k][1]) : 0;
const reds = b => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(k => red(b, k)).join('');
const elevRelay = b => bit(b, 'B', 1);
const wifiPower = b => bit(b, 'E', 6);

function rfSend(b, code, frames, Tus) {
  const T = Tus * 8, seg = [], cpu = b.cpu;
  for (let f = 0; f < frames; f++) {
    seg.push([1, T], [0, 31 * T]);
    for (let i = 23; i >= 0; i--) { const v = (code >> i) & 1; seg.push([1, v ? 3 * T : T], [0, v ? T : 3 * T]); }
  }
  let at = 0;
  for (const [lvl, dur] of seg) { cpu.addClockEvent(() => { b.E.setPin(7, !!lvl); cpu.setInterruptFlag(INT7); }, at + 1); at += dur; }
  run(b, Math.ceil(at / MS) + 30);
}
function boardWith(cfg, fwName, ee) {
  const text = core.patchHexAt(hex(fwName || 'fw_e12_six'), core.buildCfgBig(Object.assign({ e12: true }, cfg)), core.BIG_ADDR);
  const b = makeBoard(text, ee);
  b.cpu.data[0x54] = 1;                                  /* MCUCSR: power-on reset */
  return b;
}
function boardHex(text, ee) { const b = makeBoard(text, ee); b.cpu.data[0x54] = 1; return b; }
let fails = 0, checks = 0;
function check(c, m) { checks++; if (!c) { fails++; console.log('  FAIL: ' + m); } else console.log('  ok   ' + m); }
module.exports = { makeBoard, boardWith, boardHex, run, touch, tap, red, white, reds, elevRelay, wifiPower, rfSend, check, core, MS,
  stats: () => ({ fails, checks }) };
