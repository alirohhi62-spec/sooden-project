// 23-key alarm board a10: curtain keys on places 11 / 12, their relays on places 19 / 20 (keypad digits 5 / 6)
const B = require('./big'); const { run, tap, red, white, check } = B;
const r = JSON.parse(require('fs').readFileSync('/tmp/a10cfg.json', 'utf8'));
const bd = B.boardWith(r.cfg, r.name);
run(bd, 2500);
tap(bd, 10); run(bd, 300);
check(red(bd, 10) === 1 && red(bd, 18) === 1 && red(bd, 19) === 0, 'curtain open (place 11): its relay and place 19 on');
tap(bd, 10); run(bd, 300);
check(red(bd, 10) === 0 && red(bd, 18) === 0, 'touch again: both off (stop)');
tap(bd, 11); run(bd, 300);
check(red(bd, 11) === 1 && red(bd, 19) === 1 && red(bd, 18) === 0, 'curtain close (place 12): place 20 on');
run(bd, 46000); check(red(bd, 11) === 0 && red(bd, 19) === 0, 'after the run time both off');
tap(bd, 18); run(bd, 300); check(red(bd, 18) === 0, 'a touch on place 19 (keypad digit) does not run the relay');
console.log('fails', B.check.fails !== undefined ? B.check.fails : '');
{ const pr = B.PINS[18]; const port = pr[2], bit = pr[3]; check(((bd.b.cpu.data[B.DDRADDR[port]] >> bit) & 1) === 1, 'place 19 red pin is an output (relay), not an input'); }
