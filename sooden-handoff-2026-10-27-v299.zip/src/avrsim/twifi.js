// 23-key board: scenario 3 key - lifted before 7 s runs its scenario, held 7 s switches the Wi-Fi power (ATmega32 PD5)
const B = require('./big'); const { run, touch, tap, red, check } = B; const C = B.core;
const type = Array(23).fill(1), sec1 = Array(23).fill(0), off = Array(23).fill(0), on = Array(23).fill(0);
type[22] = C.T_SLEEP; sec1[22] = 70; off[22] = 1; on[22] = 2;              /* SLEEP 70 s on scenario 3 (a touch cancels it) */
const cfg = { type, sec1, offmask: off, onmask: on, remote: true, nslot: 4, dimsec: 60, stagMs: 100 };
const ee = new (require('avr8js').EEPROMMemoryBackend)(2048);
let bd = B.boardWith(cfg, 'fw_big_x', ee);
const wifi = () => (bd.a.cpu.data[0x32] >> 5) & 1, wifiDDR = () => (bd.a.cpu.data[0x31] >> 5) & 1;
let first = -1; for (let i = 0; i < 1800; i++) { run(bd, 1); if (first < 0 && wifi()) first = i; }
check(wifiDDR() === 1 && wifi() === 0 && first < 0, 'power-up: Wi-Fi power pin (ATmega32 pin 14) output, low from the start');
tap(bd, 22); run(bd, 200);
check(red(bd, 22) === 1 && wifi() === 0, 'short touch: SLEEP runs (on lifting the finger), Wi-Fi stays off');
tap(bd, 22); run(bd, 300); check(red(bd, 22) === 0, 'short touch again: cancelled');
touch(bd, 22, true); run(bd, 3000);
check(red(bd, 22) === 0 && wifi() === 0, 'held 3 s: nothing yet (the scenario waits for the finger)');
let t7 = -1, bz = 0; for (let i = 0; i < 4500; i++) { run(bd, 1); if (t7 < 0 && wifi()) t7 = i + 3000; bz |= B.buzzer(bd); }
touch(bd, 22, false); run(bd, 500);
check(t7 > 6990 && t7 < 7100 && bz, `held 7 s: Wi-Fi on at ${t7} ms, with a beep`);
check(red(bd, 22) === 0, 'and the scenario did not run');
bd = B.boardWith(cfg, 'fw_big_x', ee);
first = -1; for (let i = 0; i < 1800; i++) { run(bd, 1); if (first < 0 && wifi()) first = i; }
check(wifi() === 1 && first > 0, `power cut: Wi-Fi back on (pin high ${first} ms after power-up, low before)`);
bd.b.cpu.data[0x23] |= 0; for (let i = 0; i < 3; i++) run(bd, 1);
touch(bd, 22, true); run(bd, 7200); touch(bd, 22, false); run(bd, 500);
check(wifi() === 0, 'held 7 s again: Wi-Fi off');
bd = B.boardWith(cfg, 'fw_big_x', ee); run(bd, 2500);
check(wifi() === 0, 'power cut: stays off');
touch(bd, 22, true); run(bd, 7200); touch(bd, 22, false); run(bd, 300);
bd.b.cpu.reset(); run(bd, 3000);
check(wifi() === 1, 'ATmega64 silent (reset, no settings): the ATmega32 keeps the Wi-Fi as it was');
console.log(`\n${B.stats().checks} checks, ${B.stats().fails} failed`);
