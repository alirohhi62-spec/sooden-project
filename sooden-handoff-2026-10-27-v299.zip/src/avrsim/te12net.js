// 12 economic panel (E12): the phone app over Wi-Fi, and the two-panel network with a 4-pole panel
const E = require('./e12.js');
const { touch, red, check, core: C } = E;
const { attachEsp } = require('./esp');
const M = require('./mix');
const { EEPROMMemoryBackend } = require('avr8js');
const z = () => Array(23).fill(0);
const lights = () => { const t = z(); for (let i = 0; i < 12; i++) t[i] = 1; return t; };

console.log('4) phone app: the panel tells its model and layout, the app switches a pole');
{
  const type = lights(); type[20] = C.T_EXIT; type[21] = C.T_MASTER; type[22] = C.T_SLEEP;
  const sec1 = z(); sec1[20] = 30; sec1[22] = 40; const onmask = z(); onmask[21] = 4095; const offmask = z(); offmask[20] = 4095; offmask[22] = 4095;
  const lay = 'LLLLLLLLLLLL--------XMZ';
  const b = E.boardWith({ type, sec1, onmask, offmask, remote: true, nslot: 1, stagMs: 100, lay, mdl: 'e12' }, 'fw_e12_x');
  const shim = { b: { cpu: b.cpu, usart: b.usart },
    a: { D: { addListener: f => b.E.addListener(v => f(((v >> 6) & 1) << 5)) }, cpu: { data: new Proxy({}, { get: (t, k) => k === '49' ? ((b.cpu.data[0x22] >> 6) & 1) << 5 : 0 }) } } };
  const W = attachEsp(shim);
  E.run(b, 3500);
  touch(b, 22, true); E.run(b, 7400); touch(b, 22, false); E.run(b, 6000);
  check(W.on, 's3 held 7 s: the Wi-Fi module gets power');
  const p = W.connect(0); E.run(b, 500);
  const ask = (s, ms) => { const n = p.rx.length; W.send(0, s); E.run(b, ms || 1500); return p.rx.slice(n).join(''); };
  let r = ask('@M_MDL');
  check(r.includes('$MDL=SD23-e12-1.0$'), 'model: ' + r);
  r = ask('@M_LAY');
  check(r.includes('$LAY#' + lay + '$'), 'layout: ' + r);
  r = ask('&K#05', 1500);
  check(red(b, 4), 'app: key 5 -> pole 5 on ' + r);
}

console.log('5) two-panel network: E12 (A) pole 1 <-> 4-pole (B) pole 1, E12 master also switches B pole 2');
{
  const type = lights(); type[21] = C.T_MASTER; const onmask = z(); onmask[21] = 4095;
  const link = Array(23).fill(-1); link[0] = 0;
  const text = C.patchHexAt(C.patchHexAt(require('fs').readFileSync('/home/claude/fw/out/fw_e12_p.hex', 'utf8'),
    C.buildCfgBig({ e12: true, type, onmask, link, role: 0, remote: false, nslot: 0, stagMs: 100 }), C.BIG_ADDR),
    C.buildPx({ on: Object.assign(Array(23).fill(0), { 21: [1] }), off: [], pmdl: 'p4', play: 'LLLL', pnp: 4 }, true), C.PX_ADDRB);
  const b = E.boardHex(text);
  const A = { kind: 'e12', cpu: b.cpu, usart: b.usart1, cpus: [[b.cpu, 16, 0]] };
  const cB = { role: 1, npoles: 4, peerpoles: 23, remote: false, type: [1, 1, 1, 1], link: [0, -1, -1, -1], offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 100 };
  const Bn = M.m8Node(cB, 'fw_4p_px', C.buildPx({ on: [], off: [] }, false), new EEPROMMemoryBackend(512));
  M.bus([A, Bn], true); M.run(4000);
  touch(b, 0, true); M.run(80); touch(b, 0, false); M.run(80);
  let t = M.until(1500, () => M.red(Bn, 0));
  check(red(b, 0) && t > 0, `E12 pole 1 -> 4-pole pole 1 (${t} ms)`);
  M.tap(Bn, 0); t = M.until(1500, () => !red(b, 0));
  check(t > 0, `4-pole pole 1 -> E12 pole 1 off (${t} ms)`);
  touch(b, 21, true); M.run(80); touch(b, 21, false);
  t = M.until(3000, () => M.red(Bn, 1) && red(b, 11));
  check(t > 0 && M.red(Bn, 0), `E12 master: its 12 poles + 4-pole pole 2 (pole 1 linked) (${t} ms)`);
}
const s = E.stats(); console.log(`${s.checks - s.fails}/${s.checks} passed`);
