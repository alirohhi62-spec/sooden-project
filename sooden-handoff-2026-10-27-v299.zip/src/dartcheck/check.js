const { Parser, Language } = require('web-tree-sitter'); const fs = require('fs');
(async () => {
  await Parser.init(); const p = new Parser();
  p.setLanguage(await Language.load(__dirname + '/node_modules/tree-sitter-wasms/out/tree-sitter-dart.wasm'));
  let bad = 0;
  for (const f of process.argv.slice(2)) {
    const t = p.parse(fs.readFileSync(f, 'utf8')); const errs = [];
    (function walk(n) { if (n.type === 'ERROR' || n.isMissing) errs.push(`${n.isMissing ? 'MISSING ' + n.type : 'ERROR'} at ${n.startPosition.row + 1}:${n.startPosition.column + 1} ${n.text.slice(0, 60).replace(/\n/g, ' ')}`); else for (const c of n.children) walk(c); })(t.rootNode);
    if (errs.length) { bad++; console.log(f + ':'); errs.slice(0, 8).forEach(e => console.log('  ' + e)); } else console.log('ok ' + f);
  }
  process.exit(bad ? 1 : 0);
})();
