/* Sooden crystal-less touch panels on ATtiny13 (internal 9.6 MHz, the CKDIV8 fuse is undone at start):
 *   MODE_1POL  touch PB3 (pin 2)            -> PB1 (pin 6) toggles
 *   MODE_2POL  touch PB2 (pin 7) -> PB0 (pin 5) toggles, touch PB4 (pin 3) -> PB1 (pin 6) toggles
 *   MODE_BELL  touch PB3 (pin 2): short touch -> PB0 (pin 5) on for the bell time; held 5 s -> do-not-disturb on/off,
 *              shown on PB1 (pin 6, pole 2: its red LED); the bell does not ring while it is on
 *   MODE_LOGO  touch PB4 (pin 3): relay PB1 (pin 6), white LED PB0 (pin 5), red LED PB3 (pin 2);
 *              idle white, ringing red + relay, do-not-disturb red (held 5 s, no relay)
 * Do-not-disturb is kept in EEPROM over a power cut. The bell time (0.1 s units) is in flash at 0x3F8 (the programmer writes it).
 * Touch IC outputs are active low. Noise: a touch counts after 40 ms without a break, the next one after 80 ms released;
 * 300 ms after a relay change the touch is not looked at; nothing in the first second and not before a released input is seen. */
#include <avr/io.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay.h>

#define T_ON     40
#define T_OFF    80
#define T_QUIET  300
#define T_START  1000
#define T_DND    5000
#define EE_DND   ((uint8_t *)0)
#define DND_ON   0xA5

/* bell settings: magic 0xB5, time in 0.1 s (low, high) */
const uint8_t bellcfg[4] __attribute__((section(".bellcfg"), used)) = { 0xB5, 30, 0, 0xFF };

typedef struct { uint8_t pin, down, held, ready; uint16_t cnt; uint16_t hold; } Key;
static uint16_t quiet;

/* one 1 ms step of a touch input: returns 1 on a new touch, 2 on its release; k->hold = ms held so far */
static uint8_t key_step(Key *k)
{
    uint8_t low = !(PINB & _BV(k->pin));
    if (!k->down) {
        if (low) { if (k->cnt < 0xFFFF) k->cnt++; } else { k->cnt = 0; k->ready = 1; }
        if (low && k->ready && !quiet && k->cnt >= T_ON) { k->down = 1; k->cnt = 0; k->hold = T_ON; return 1; }
    } else {
        if (k->hold < 0xFFFF) k->hold++;
        if (!low) { if (++k->cnt >= T_OFF) { k->down = 0; k->cnt = 0; return 2; } } else k->cnt = 0;
    }
    return 0;
}
static void key_init(Key *k, uint8_t pin) { k->pin = pin; k->down = 0; k->cnt = 0; k->ready = 0; k->hold = 0; }
static void __attribute__((unused)) set(uint8_t bit, uint8_t on) { if (on) PORTB |= _BV(bit); else PORTB &= (uint8_t)~_BV(bit); }

int main(void)
{
#if defined(MODE_1POL)
    PORTB = _BV(2) | _BV(3) | _BV(4); DDRB = _BV(0) | _BV(1);          /* PB1 out; PB0 low; inputs with pull-ups */
#elif defined(MODE_2POL)
    PORTB = _BV(2) | _BV(3) | _BV(4); DDRB = _BV(0) | _BV(1);
#elif defined(MODE_BELL)
    PORTB = _BV(2) | _BV(3) | _BV(4); DDRB = _BV(0) | _BV(1);
#elif defined(MODE_LOGO)
    PORTB = _BV(4); DDRB = _BV(0) | _BV(1) | _BV(2) | _BV(3);          /* all outputs off first, then white below */
#endif
    CLKPR = _BV(CLKPCE); CLKPR = 0;                                    /* 9.6 MHz even with the CKDIV8 fuse */
    wdt_enable(WDTO_250MS);
    Key a;
#if defined(MODE_2POL)
    Key b;
#endif
#if defined(MODE_2POL)
    key_init(&a, 2); key_init(&b, 4);
#elif defined(MODE_LOGO)
    key_init(&a, 4);
#else
    key_init(&a, 3);
#endif
    quiet = T_START;
#if defined(MODE_BELL) || defined(MODE_LOGO)
    uint16_t bell = 30;
    if (pgm_read_byte(&bellcfg[0]) == 0xB5) { bell = (uint16_t)(pgm_read_byte(&bellcfg[1]) | pgm_read_byte(&bellcfg[2]) << 8); if (!bell) bell = 1; }
    uint32_t ringMs = (uint32_t)bell * 100, left = 0;
    uint8_t dnd = eeprom_read_byte(EE_DND) == DND_ON, done = 0;
#endif
#if defined(MODE_BELL)
    set(1, dnd);
#elif defined(MODE_LOGO)
    set(0, !dnd); set(3, dnd);
#endif
    for (;;) {
        wdt_reset();
        _delay_us(995);                                                /* the rest of the pass makes 1 ms */
        if (quiet) quiet--;
#if defined(MODE_1POL)
        if (key_step(&a) == 1) { PORTB ^= _BV(1); quiet = T_QUIET; }
#elif defined(MODE_2POL)
        if (key_step(&a) == 1) { PORTB ^= _BV(0); quiet = T_QUIET; }
        if (key_step(&b) == 1) { PORTB ^= _BV(1); quiet = T_QUIET; }
#else
        uint8_t e = key_step(&a);
        if (e == 1) done = 0;
        if (a.down && !done && a.hold >= T_DND) {                      /* held 5 s: do-not-disturb on / off, kept */
            done = 1; dnd = !dnd; left = 0;
            eeprom_update_byte(EE_DND, dnd ? DND_ON : 0);
# if defined(MODE_BELL)
            set(0, 0); set(1, dnd);
# else
            set(1, 0); set(0, !dnd); set(3, dnd);
# endif
            quiet = T_QUIET;
        }
        if (e == 2 && !done && !dnd && !left) {                        /* a short touch, lifted: ring */
            left = ringMs;
# if defined(MODE_BELL)
            set(0, 1);
# else
            set(1, 1); set(0, 0); set(3, 1);
# endif
            quiet = T_QUIET;
        }
        if (left && !--left) {
# if defined(MODE_BELL)
            set(0, 0);
# else
            set(1, 0); set(0, !dnd); set(3, dnd);
# endif
            quiet = T_QUIET;
        }
#endif
    }
}
