set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
for m in 1POL 2POL BELL LOGO; do
  avr-gcc -mmcu=attiny13 -DF_CPU=9600000UL -Os -Wall -Wextra -std=gnu99 -DMODE_$m -Wl,--section-start=.bellcfg=0x3F8 t13.c -o t13_$m.elf
  avr-objcopy -O ihex -R .eeprom t13_$m.elf t13_$m.hex
  printf "%-5s " $m; avr-size t13_$m.elf | tail -1
done
