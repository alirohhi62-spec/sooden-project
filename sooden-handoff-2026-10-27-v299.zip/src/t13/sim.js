const fs = require('fs');
const { CPU, AVRIOPort, AVREEPROM, EEPROMMemoryBackend } = require('/home/claude/avrsim/node_modules/avr8js');
const { step } = require('/home/claude/avrsim/step');
const core = require('/home/claude/avrsim/cfgcore');
function load(file, patch) {
  const m = core.parseHex(fs.readFileSync(file, 'utf8'));
  if (patch) for (const [a, v] of Object.entries(patch)) m.set(+a, v);
  const p = new Uint16Array(512); for (const [a, v] of m) { if (a & 1) p[a >> 1] |= v << 8; else p[a >> 1] |= v; } return p;
}
function chip(file, ee, patch) {
  const cpu = new CPU(load(file, patch), 256);
  const B = new AVRIOPort(cpu, { PIN: 0x36, DDR: 0x37, PORT: 0x38, externalInterrupts: [] });
  const be = new EEPROMMemoryBackend(64); if (ee) be.memory.set(ee);
  new AVREEPROM(cpu, be, { eepromReadyInterrupt: 0x0e, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 32000, writeCycles: 32000 });
  for (let i = 0; i < 6; i++) B.setPin(i, true);
  let minSp = 0xFFFF; const ms = n => { for (let t = 0; t < n; t++) { const end = cpu.cycles + 9600; while (cpu.cycles < end) { step(cpu); const sp = cpu.dataView.getUint16(0x5D, true); if (sp < minSp && sp > 0x40) minSp = sp; } } };
  const out = b => (cpu.data[0x38] >> b) & 1 && (cpu.data[0x37] >> b) & 1;
  return { cpu, B, be, ms, out, minSp: () => minSp };
}
let n = 0, f = 0; const check = (c, m) => { n++; if (!c) f++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
const touch = (c, pin, len) => { c.B.setPin(pin, false); c.ms(len); c.B.setPin(pin, true); };
// measure how long an output stays on (ms) watching every ms
const onTime = (c, bit, max) => { let t = 0, seen = 0; for (let i = 0; i < max; i++) { c.ms(1); if (c.out(bit)) { seen = 1; t++; } else if (seen) break; } return t; };
// 1-pol
{ const c = chip('t13_1POL.hex'); c.B.setPin(3, false); let any = 0; for (let i = 0; i < 2500; i++) { c.ms(1); if (c.out(1)) any = 1; }
  check(!any, '1-pol: input stuck "touched" from power-up: relay never moves (2.5 s)');
  c.B.setPin(3, true); c.ms(300); touch(c, 3, 100); c.ms(50); check(c.out(1), '1-pol: after a release, a touch switches on');
  c.ms(400); for (let i = 0; i < 20; i++) { touch(c, 3, 30); c.ms(15); } c.ms(400); check(c.out(1), '1-pol: 20 noise pulses of 30 ms: no change');
  touch(c, 3, 60); c.ms(400); check(!c.out(1), '1-pol: a 60 ms touch switches off');
  touch(c, 3, 60); c.ms(100); touch(c, 3, 60); c.ms(400); check(c.out(1), '1-pol: a touch 100 ms after a relay change is ignored (only one toggle)');
  check(c.minSp() > 0x70, '1-pol: stack lowest 0x' + c.minSp().toString(16)); }
// power-up with free input: nothing in the first second
{ const c = chip('t13_1POL.hex'); c.ms(200); touch(c, 3, 100); c.ms(500); check(!c.out(1), '1-pol: a touch in the first second does nothing'); }
// 2-pol
{ const c = chip('t13_2POL.hex'); c.ms(1200); touch(c, 2, 60); c.ms(400); check(c.out(0) && !c.out(1), '2-pol: touch PB2 -> PB0 on, PB1 off');
  touch(c, 4, 60); c.ms(400); check(c.out(0) && c.out(1), '2-pol: touch PB4 -> PB1 on');
  touch(c, 2, 60); c.ms(400); check(!c.out(0) && c.out(1), '2-pol: PB2 again -> PB0 off'); }
// bell
{ const c = chip('t13_BELL.hex'); c.ms(1200); touch(c, 3, 100); const t = onTime(c, 0, 5000);
  check(t > 2950 && t < 3050, 'bell: short touch -> PB0 on ' + t + ' ms (3 s)');
  check(!c.out(1), 'bell: PB1 (do-not-disturb) off');
  c.ms(500); touch(c, 3, 5200); c.ms(300); check(c.out(1) && !c.out(0), 'bell: held 5 s -> do-not-disturb on (PB1), no ring');
  touch(c, 3, 100); c.ms(1000); check(!c.out(0), 'bell: do-not-disturb: a touch does not ring');
  c.ms(50); const ee = c.be.memory.slice();
  const d = chip('t13_BELL.hex', ee); d.ms(1500); check(d.out(1), 'bell: do-not-disturb kept over a power cut');
  touch(d, 3, 5200); d.ms(300); check(!d.out(1), 'bell: held 5 s again -> off'); touch(d, 3, 100); d.ms(200); check(d.out(0), 'bell: rings again');
  d.ms(4000); touch(d, 3, 3000); d.ms(200); check(d.out(0) && !d.out(1), 'bell: held 3 s (less than 5) and lifted: rings, do-not-disturb unchanged'); }
// bell time written by the programmer: 50 s and 0.5 s
{ const c = chip('t13_BELL.hex', null, { 0x3F8: 0xB5, 0x3F9: 500 & 255, 0x3FA: 500 >> 8 }); c.ms(1200); touch(c, 3, 100); const t = onTime(c, 0, 60000);
  check(t > 49500 && t < 50500, 'bell time 50 s from the programmer: ' + t + ' ms'); }
{ const c = chip('t13_BELL.hex', null, { 0x3F8: 0xB5, 0x3F9: 5, 0x3FA: 0 }); c.ms(1200); touch(c, 3, 100); const t = onTime(c, 0, 2000);
  check(t > 480 && t < 520, 'bell time 0.5 s: ' + t + ' ms'); }
// logo
{ const c = chip('t13_LOGO.hex'); c.ms(1200); check(c.out(0) && !c.out(3) && !c.out(1), 'logo: idle white');
  touch(c, 4, 100); c.ms(100); check(c.out(1) && c.out(3) && !c.out(0), 'logo: ringing: relay + red');
  c.ms(3100); check(!c.out(1) && c.out(0) && !c.out(3), 'logo: after 3 s back to white');
  touch(c, 4, 5200); c.ms(300); check(!c.out(1) && c.out(3) && !c.out(0), 'logo: held 5 s -> do-not-disturb: red, no relay');
  touch(c, 4, 100); c.ms(500); check(!c.out(1), 'logo: do-not-disturb: no ring');
  c.ms(50); const d = chip('t13_LOGO.hex', c.be.memory.slice()); d.ms(1500); check(d.out(3) && !d.out(0), 'logo: do-not-disturb kept over a power cut');
  check(d.minSp() > 0x70, 'logo: stack lowest 0x' + d.minSp().toString(16)); }
console.log(`${n - f}/${n} passed`);
