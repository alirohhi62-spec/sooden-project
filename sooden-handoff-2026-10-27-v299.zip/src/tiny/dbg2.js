const h=require('./harness');const {avrInstruction}=require('/home/claude/avrsim/node_modules/avr8js');
const n=h.load('old_1pol.hex'); let prev=[];
for(let i=0;i<3000000;i++){ const pc=n.cpu.pc; prev.push(pc*2); if(prev.length>8)prev.shift(); avrInstruction(n.cpu); n.cpu.tick(); if(Number.isNaN(n.cpu.pc)){console.log('NaN after',prev.map(x=>x.toString(16)), 'sp',n.cpu.SP, 'cycles',n.cpu.cycles);break;} }
