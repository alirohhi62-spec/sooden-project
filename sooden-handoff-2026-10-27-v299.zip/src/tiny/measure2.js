const h = require('./harness');
const first = (f, bit, t) => { const m = h.load(f); h.run(m, t); const b = h.out(m); h.press(m, bit, 1); h.run(m, 200); h.press(m, bit, 0); h.run(m, 1200); return m.trace.length > (f.includes('bell') ? 1 : 0); };
for (const [f, bit] of [['old_1pol.hex', 3], ['old_2pol.hex', 4], ['old_bell.hex', 4]]) {
  let lo = 0, hi = 3000; while (hi - lo > 2) { const mid = (lo + hi) >> 1; if (first(f, bit, mid)) hi = mid; else lo = mid; }
  console.log(f, 'press accepted if started at >=', hi, 'ms after power');
}
const thr = (f, bit) => { let lo = 1, hi = 200; while (hi - lo > 0.2) { const mid = (lo + hi) / 2; const m = h.load(f); h.run(m, 3000); m.trace = []; h.press(m, bit, 1); h.run(m, mid); h.press(m, bit, 0); h.run(m, 1500); if (m.trace.length) hi = mid; else lo = mid; } return hi.toFixed(1); };
console.log('bell min press', thr('old_bell.hex', 4), 'ms; 2pol pole2 min press', thr('old_2pol.hex', 4), 'ms; 1pol', thr('old_1pol.hex', 3));
// lockout after toggle: press, release right after toggle, press again quickly
for (const gap of [10, 100, 150, 200, 260]) {
  const m = h.load('old_1pol.hex'); h.run(m, 3000);
  h.press(m, 3, 1); h.run(m, 60); h.press(m, 3, 0); h.run(m, gap); h.press(m, 3, 1); h.run(m, 400); h.press(m, 3, 0); h.run(m, 400);
  console.log('1pol second press after release gap', gap, '-> toggles', m.trace.length);
}
// 2-pole: both pins pressed
{ const m = h.load('old_2pol.hex'); h.run(m, 3000); h.press(m, 2, 1); h.press(m, 4, 1); h.run(m, 1000); h.press(m, 2, 0); h.press(m, 4, 0); h.run(m, 500); console.log('2pol both held:', m.trace.map(([t, o]) => (t - 3000).toFixed(1) + ':' + o.toString(2)).join(' ')); }
