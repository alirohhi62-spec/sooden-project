/* Sooden ATtiny13 switches (no crystal): 1 pole, 2 pole, doorbell.
 * One source, three builds: -DMODEL_1POL / -DMODEL_2POL / -DMODEL_BELL
 * Behaviour and every time value copied from the original CodeVision firmwares
 * (measured in simulation at the real 1.2 MHz clock):
 *   power-on blind time 2400 ms, toggle after 54 ms of touch, 240 ms lock after a toggle,
 *   doorbell: 75 ms touch, 320 ms bell pulse + 240 ms pause, ~4.9 s touch = do-not-disturb.
 * Changes against the original:
 *   - pins are driven in the very first instructions (before the C start-up code)
 *   - watchdog enabled (resets the chip if it ever hangs)
 * Fuses: LOW 0x62 (9.6 MHz RC / 8 = 1.2 MHz, no 64 ms start-up delay), HIGH 0xFB (BOD 2.7 V)
 */
#ifndef F_CPU
#define F_CPU 1200000UL
#endif
#include <avr/io.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <stdint.h>

#if defined(MODEL_1POL)
#  define INIT_DDR  0xC3
#  define INIT_PORT 0x1C
#elif defined(MODEL_2POL)
#  define INIT_DDR  0xC3
#  define INIT_PORT 0x1C
#elif defined(MODEL_BELL)
#  define INIT_DDR  0xEF
#  define INIT_PORT 0x11
#else
#  error "define MODEL_1POL, MODEL_2POL or MODEL_BELL"
#endif

#define T_BOOT      2400   /* ms, touch ignored after power-on            */
#define T_DEB       54     /* ms, touch needed to toggle a pole           */
#define T_LOCK      240    /* ms, blind time after a toggle               */
#define T_DEB_BELL  75     /* ms, touch needed to ring                    */
#define T_RING      320    /* ms, bell pulse                              */
#define T_PAUSE     240    /* ms, pause after the bell / per DND step     */
#define DND_STEPS   20     /* 20 x 240 ms after the first 75 ms ≈ 4.9 s   */

/* first code after reset: outputs low / LEDs in their idle state, nothing floats */
void early_pins(void) __attribute__((naked, used, section(".init0")));
void early_pins(void)
{
    PORTB = INIT_PORT;
    DDRB = INIT_DDR;
}

static void wait_ms(uint16_t ms)
{
    while (ms--) { wdt_reset(); _delay_ms(1); }
}

#define PRESSED(bit) (!(PINB & _BV(bit)))

#if defined(MODEL_1POL) || defined(MODEL_2POL)
/* one pole: blocking while the key is held and armed (same as the original loop) */
static void pole(uint8_t in, uint8_t out, uint8_t *armed)
{
    uint8_t held = 0;
    while (PRESSED(in) && *armed) {
        if (held >= T_DEB) {
            PORTB ^= _BV(out);
            *armed = 0;
            wait_ms(T_LOCK);
        } else {
            held++;
            wait_ms(1);
        }
    }
    if (!PRESSED(in)) *armed = 1;       /* released: ready for the next touch */
}
#endif

int main(void)
{
#ifndef NO_WDT
    wdt_enable(WDTO_1S);
#endif
    PORTB = INIT_PORT;
    DDRB = INIT_DDR;
    wait_ms(T_BOOT);

#if defined(MODEL_1POL)
    uint8_t a1 = 1;
    for (;;) { wdt_reset(); pole(3, 0, &a1); }
#elif defined(MODEL_2POL)
    uint8_t a1 = 1, a2 = 1;
    for (;;) { wdt_reset(); pole(2, 0, &a1); pole(4, 1, &a2); }
#else
    /* doorbell: touch PB4; PB0 idle LED, PB1 bell, PB3 do-not-disturb */
    uint8_t ring_ok = 1, count_ok = 1, steps = 0;
    uint8_t held = 0;
    for (;;) {
        wdt_reset();
        while (PRESSED(4) && count_ok) {
            if (steps >= DND_STEPS) {           /* long touch: do-not-disturb on/off */
                steps = 0;
                PORTB ^= _BV(3);
                count_ok = 0;
            }
            if (held >= T_DEB_BELL) {
                steps++;
                ring_ok = 0;                    /* a valid touch happened */
                wait_ms(T_PAUSE);
            } else {
                held++;
                wait_ms(1);
            }
        }
        if (PRESSED(4) || ring_ok) continue;    /* wait for the release of a valid touch */
        if (!(PORTB & _BV(3))) {                /* not in do-not-disturb: ring */
            PORTB ^= _BV(0) | _BV(1) | _BV(3);
            wait_ms(T_RING);
            PORTB ^= _BV(0) | _BV(1) | _BV(3);
            wait_ms(T_PAUSE);
        }
        held = 0; steps = 0; ring_ok = 1; count_ok = 1;
    }
#endif
}
