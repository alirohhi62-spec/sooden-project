// ATtiny13 harness on avr8js: 1.2 MHz, PORTB only
const fs = require('fs');
const { CPU, avrInstruction, AVRIOPort } = require('/home/claude/avrsim/node_modules/avr8js');
const core = require('/home/claude/avrsim/cfgcore');
const F = 1.2e6, MS = 1200;
function load(file) {
  const mem = core.parseHex(fs.readFileSync(file, 'utf8'));
  const prog = new Uint16Array(512);
  for (const [a, v] of mem) { if (a >= 1024) throw new Error('beyond 1K flash'); if (a & 1) prog[a >> 1] |= v << 8; else prog[a >> 1] |= v; }
  const cpu = new CPU(prog, 64);
  cpu.writeHooks[0x5E] = () => true; cpu.data[0x5E] = 0;   /* ATtiny13 has no SPH */
  const pb = new AVRIOPort(cpu, { PIN: 0x36, DDR: 0x37, PORT: 0x38, externalInterrupts: [] });
  for (let i = 0; i < 6; i++) pb.setPin(i, true);   // BS813 outputs idle high
  const n = { cpu, pb, trace: [], last: -1 };
  // timer0 (tiny13): TCCR0B 0x53, TCCR0A 0x4F, OCR0A 0x56, TIMSK0 0x59, TIFR0 0x58; COMPA vector 6
  const T0 = { address: 12, flagRegister: 0x58, flagMask: 0x04, enableRegister: 0x59, enableMask: 0x04 };
  let acc = 0;
  n.tickT0 = () => {
    const cs = cpu.data[0x53] & 7; if (!cs) return;
    const pre = [0, 1, 8, 64, 256, 1024][cs] || 1;
    acc++; if (acc >= pre) { acc = 0; cpu.data[0x52] = (cpu.data[0x52] + 1) & 0xFF;
      if (cpu.data[0x52] === ((cpu.data[0x56] + 1) & 0xFF) || (cpu.data[0x52] === 0 && cpu.data[0x56] === 0xFF)) {
        if ((cpu.data[0x4F] & 3) === 2) cpu.data[0x52] = 0;   // CTC
        cpu.setInterruptFlag(T0);
      } }
  };
  return n;
}
function out(n) { const c = n.cpu; return (c.data[0x38] & c.data[0x37]) & 0x1F; }   // driven-high outputs
function run(n, ms, onStep) {
  const end = n.cpu.cycles + ms * MS;
  while (n.cpu.cycles < end) {
    const c0 = n.cpu.cycles;
    avrInstruction(n.cpu); n.cpu.tick();
    for (let k = c0; k < n.cpu.cycles; k++) n.tickT0();
    const o = out(n);
    if (o !== n.last) { n.trace.push([n.cpu.cycles / MS, o]); n.last = o; }
  }
}
function press(n, bit, v) { n.pb.setPin(bit, !v); }
module.exports = { load, run, press, out, MS };
