const h = require('./harness');
const fmt = t => t.map(([ms, o]) => ms.toFixed(1) + 'ms:' + o.toString(2).padStart(5, '0')).join('  ');
for (const [f, bit] of [['old_1pol.hex', 3], ['old_2pol.hex', 2]]) {
  const n = h.load(f);
  h.run(n, 3000);
  console.log(f, 'boot', fmt(n.trace)); n.trace = [];
  // find minimum press that toggles
  for (const p of [20, 30, 40, 45, 50, 55, 60, 80]) {
    const m = h.load(f); h.run(m, 3000); const before = h.out(m);
    h.press(m, bit, 1); h.run(m, p); h.press(m, bit, 0); h.run(m, 400);
    console.log('  press', p, 'ms ->', h.out(m) !== before ? 'TOGGLE' : '-');
  }
  // time from press to toggle, and lockout
  const m = h.load(f); h.run(m, 3000); m.trace = [];
  const t0 = m.cpu.cycles / h.MS; h.press(m, bit, 1); h.run(m, 1000); h.press(m, bit, 0); h.run(m, 50);
  h.press(m, bit, 1); h.run(m, 1000);
  console.log('  hold:', fmt(m.trace.map(([t, o]) => [t - t0, o])));
}
{
  const f = 'old_bell.hex', bit = 4;
  const n = h.load(f); h.run(n, 3000); console.log(f, 'boot', fmt(n.trace));
  const m = h.load(f); h.run(m, 3000); m.trace = []; let t0 = m.cpu.cycles / h.MS;
  h.press(m, bit, 1); h.run(m, 100); h.press(m, bit, 0); h.run(m, 1500);
  console.log('  short press 100ms:', fmt(m.trace.map(([t, o]) => [t - t0, o])));
  m.trace = []; t0 = m.cpu.cycles / h.MS;
  h.press(m, bit, 1); h.run(m, 7000); h.press(m, bit, 0); h.run(m, 1500);
  console.log('  long press 7s:', fmt(m.trace.map(([t, o]) => [t - t0, o])));
  m.trace = []; t0 = m.cpu.cycles / h.MS;
  h.press(m, bit, 1); h.run(m, 100); h.press(m, bit, 0); h.run(m, 1500);
  console.log('  short press in DND:', fmt(m.trace.map(([t, o]) => [t - t0, o])));
  m.trace = []; t0 = m.cpu.cycles / h.MS;
  h.press(m, bit, 1); h.run(m, 7000); h.press(m, bit, 0); h.run(m, 1500);
  console.log('  long press again:', fmt(m.trace.map(([t, o]) => [t - t0, o])));
  for (const p of [20, 40, 50, 60]) { const q = h.load(f); h.run(q, 3000); q.trace = []; h.press(q, bit, 1); h.run(q, p); h.press(q, bit, 0); h.run(q, 1000); console.log('  bell press', p, q.trace.length ? 'RING' : '-'); }
}
