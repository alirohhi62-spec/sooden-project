const h = require('./harness');
let fails = 0, checks = 0;
function runScenario(file, steps) {
  const m = h.load(file);
  for (const [ms, bit, v] of steps) { if (bit !== null) h.press(m, bit, v); h.run(m, ms); }
  return m.trace.filter((e, i, a) => i === 0 || e[1] !== a[i - 1][1]);
}
function cmp(name, oldF, newF, steps, tol) {
  const a = runScenario(oldF, steps), b = runScenario(newF, steps);
  // collapse simultaneous edges (old code toggles bits one by one within microseconds)
  const col = t => { const r = []; for (const [ms, o] of t) { if (r.length && ms - r[r.length - 1][0] < 0.5) r[r.length - 1] = [r[r.length - 1][0], o]; else r.push([ms, o]); } return r; };
  const A = col(a), B = col(b);
  let ok = A.length === B.length;
  let worst = 0;
  if (ok) for (let i = 0; i < A.length; i++) { if (A[i][1] !== B[i][1]) ok = false; worst = Math.max(worst, Math.abs(A[i][0] - B[i][0])); }
  const relTol = Math.max(tol, 0.03 * (A.length ? A[A.length - 1][0] : 0));
  if (worst > relTol) ok = false;
  checks++; if (!ok) fails++;
  console.log((ok ? '  ok   ' : '  FAIL ') + name + `  (edges ${A.length}/${B.length}, worst time diff ${worst.toFixed(1)} ms)`);
  if (!ok) { console.log('     old:', A.map(([t, o]) => t.toFixed(1) + ':' + o.toString(2)).join(' ')); console.log('     new:', B.map(([t, o]) => t.toFixed(1) + ':' + o.toString(2)).join(' ')); }
}
const P = (bit, hold, gap) => [[hold, bit, 1], [gap, bit, 0]];
const seq = (...xs) => xs.flat();
const boot = [[3000, null, 0]];
console.log('1 pole');
cmp('boot', 'old_1pol.hex', 'nwt_1pol.hex', boot, 2);
cmp('3 taps', 'old_1pol.hex', 'nwt_1pol.hex', seq(boot, P(3, 100, 400), P(3, 100, 400), P(3, 100, 400)), 5);
cmp('short taps 30ms ignored', 'old_1pol.hex', 'nwt_1pol.hex', seq(boot, P(3, 30, 300), P(3, 40, 300)), 5);
cmp('hold 3 s = one toggle', 'old_1pol.hex', 'nwt_1pol.hex', seq(boot, P(3, 3000, 500)), 5);
cmp('fast re-touch inside lock', 'old_1pol.hex', 'nwt_1pol.hex', seq(boot, P(3, 70, 60), P(3, 400, 400)), 5);
cmp('touch held from power-on', 'old_1pol.hex', 'nwt_1pol.hex', [[3500, 3, 1], [500, 3, 0]], 5);
console.log('2 pole');
cmp('pole1 taps', 'old_2pol.hex', 'nwt_2pol.hex', seq(boot, P(2, 100, 400), P(2, 100, 400)), 5);
cmp('pole2 taps', 'old_2pol.hex', 'nwt_2pol.hex', seq(boot, P(4, 100, 400), P(4, 100, 400)), 5);
cmp('both held together', 'old_2pol.hex', 'nwt_2pol.hex', seq(boot, [[0, 2, 1], [1000, 4, 1], [0, 2, 0], [500, 4, 0]]), 5);
cmp('alternating', 'old_2pol.hex', 'nwt_2pol.hex', seq(boot, P(2, 80, 300), P(4, 80, 300), P(2, 80, 300), P(4, 80, 300)), 5);
console.log('doorbell');
cmp('boot', 'old_bell.hex', 'nwt_bell.hex', boot, 2);
cmp('short press rings', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 100, 1500)), 6);
cmp('too short (50ms) no ring', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 50, 1500)), 6);
cmp('1 s press rings after release', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 1000, 1500)), 10);
cmp('long press -> DND, no ring', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 7000, 1500)), 40);
cmp('DND: short press silent', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 7000, 1500), P(4, 100, 1500)), 40);
cmp('long press again -> DND off (+ring, like original)', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 7000, 1500), P(4, 7000, 1500)), 60);
cmp('rapid presses', 'old_bell.hex', 'nwt_bell.hex', seq(boot, P(4, 100, 100), P(4, 100, 100), P(4, 100, 1500)), 10);
console.log('\n' + checks + ' checks, ' + fails + ' failed');
