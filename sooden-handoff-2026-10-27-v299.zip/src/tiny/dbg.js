const h=require('./harness');
const n=h.load('old_1pol.hex'); h.run(n,3000);
console.log('pc',(n.cpu.pc*2).toString(16),'PIN',n.cpu.data[0x36].toString(2),'DDR',n.cpu.data[0x37].toString(2),'PORT',n.cpu.data[0x38].toString(2));
h.press(n,3,1); h.run(n,1);
console.log('after press PIN',n.cpu.data[0x36].toString(2), 'pc',(n.cpu.pc*2).toString(16));
const pcs=new Set(); for(let i=0;i<2000;i++){ pcs.add((n.cpu.pc*2).toString(16)); require('/home/claude/avrsim/node_modules/avr8js').avrInstruction(n.cpu); n.cpu.tick(); }
console.log([...pcs].join(','));
