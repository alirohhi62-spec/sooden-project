const h = require('./harness');
const ok = (f, bit, t, hold) => { const m = h.load(f); h.run(m, t); m.trace = []; h.press(m, bit, 1); h.run(m, hold); h.press(m, bit, 0); h.run(m, 1500); return m.trace.length > 0; };
for (const [f, bit] of [['old_1pol.hex', 3], ['old_bell.hex', 4]]) {
  let lo = 0, hi = 3000; while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (ok(f, bit, mid, 100)) hi = mid; else lo = mid; }
  console.log(f, 'a 100ms press works if it starts >=', hi, 'ms after power');
  // press held from power-on
  const m = h.load(f); h.press(m, bit, 1); h.run(m, 4000); console.log('  held from power-on:', m.trace.map(([t, o]) => t.toFixed(1) + ':' + o.toString(2)).join(' '));
}
