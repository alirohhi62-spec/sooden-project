#!/bin/sh
# builds one hex per panel kind (ATmega8 @ 8 MHz); each holds only what that panel has
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
mkdir -p out
build() {   # name board remote pair [sec ilock scn px]
  # a build that does not fit is made again with -fno-reorder-blocks (about 70 bytes smaller)
  for X in "" "-fno-reorder-blocks"; do
    if avr-gcc $X -mmcu=atmega8 -DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 \
      -mcall-prologues -mrelax -fno-split-wide-types -fno-tree-scev-cprop -fno-move-loop-invariants -flto \
      -ffunction-sections -fdata-sections -Wl,--gc-sections \
      -Wl,--section-start=.swcfg=0x1F80 \
      -DFW_BOARD=$2 -DHAS_REMOTE=$3 -DHAS_PAIR=$4 -DHAS_SEC=${5:-0} -DHAS_ILOCK=${6:-0} -DHAS_SCN=${7:-0} -DHAS_PX=${8:-0} \
      $( [ "${8:-0}" = 1 ] && echo -Wl,--section-start=.swpx=0x1F40 ) \
      main_avr.c sw.c -o out/$1.elf 2>out/$1.log; then break; fi
    [ -n "$X" ] && { cat out/$1.log; exit 1; }
  done
  avr-objcopy -O ihex -R .eeprom out/$1.elf out/$1.hex
  printf "%-20s %-20s " $1 "$X"; avr-size out/$1.elf | tail -1
}
rm -f out/fw_4p*.hex out/fw_2p*.hex
#     name         board     remote pair
build fw_4p        BOARD_4P  0      0     # 4 pole, no crystal: no remote, no network
build fw_4p_r      BOARD_4P  1      0     # 4 pole, crystal + remote, single panel
build fw_4p_pair   BOARD_4P  0      1     # 4 pole in a two-panel network
build fw_4p_pair_r BOARD_4P  1      1     # 4 pole in a two-panel network + remote
build fw_2p_pair   BOARD_2P  0      1     # 1/2 pole board in a two-panel network
# extra pole kinds, only in the panels that use them:
#   s = push buttons (delayed off, push button / delayed push button)
#   i = interlocked poles (curtain, cooler) + off timer
#   x = EXIT / SLEEP / ELEVATOR scenarios
# (two-panel network + remote is full on the ATmega8: no extra pole kinds there)
for base in "fw_4p BOARD_4P 0 0" "fw_4p_r BOARD_4P 1 0" "fw_4p_pair BOARD_4P 0 1"; do
  set -- $base
  for g in s i x si sx ix six; do
    case $g in *s*) S=1;; *) S=0;; esac; case $g in *i*) I=1;; *) I=0;; esac; case $g in *x*) X=1;; *) X=0;; esac
    build ${1}_$g $2 $3 $4 $S $I $X
  done
done
# two-panel network v2 (px): every key reported, scenarios reach the other panel, links to any key of a 23-key panel;
# used whenever no ATmega8 of the pair has a remote (v1 above stays for pairs of 1..4 pole panels with remote)
build fw_2p_px     BOARD_2P  0      1     0 0 0 1
build fw_4p_px     BOARD_4P  0      1     0 0 0 1
for g in s i x si sx ix six; do
  case $g in *s*) S=1;; *) S=0;; esac; case $g in *i*) I=1;; *) I=0;; esac; case $g in *x*) X=1;; *) X=0;; esac
  build fw_4p_px_$g BOARD_4P 0 1 $S $I $X 1
done
