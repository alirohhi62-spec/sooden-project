/* Sooden 23-key board - Wi-Fi (ESP8266 with AT firmware on USART0) and the phone app protocol */
#ifndef WIFI64_H
#define WIFI64_H
#include "sw.h"

void wf_poll(Sw *s, uint32_t now);   /* call every main loop pass: powers the UART with the module, runs everything */

#ifdef SW_P12
/* 12-pole SIM panel: what the alarm MCU reported over bus B (main_p12.c fills it), shown to the phones */
typedef struct {
    uint8_t al, zones, open;     /* alarm view 0..4, armed zones, open zones */
    uint8_t gsm, bars, op;       /* module answers, signal 0..5, operator 0..3 */
    uint8_t crdBusy, crdGen;     /* credit check running; + 1 each time the credit is known again */
    uint8_t crdWant;             /* app asked for the credit, not yet sent to the alarm MCU (bus C busy) */
    char credit[12];             /* digits, "" = not known */
    uint8_t setRes;              /* answer to the last alarm setting: 1 saved, 2 refused */
    uint8_t armRes;              /* answer to the last app arm / disarm: 1 done, 2 wrong code, 3 busy (0 = none yet) */
} P12App;
extern P12App p12;
uint8_t wf_phones(void);
uint8_t p12_app_key(uint8_t k);                              /* main_p12.c: app touch of the child-lock key = lock on / off at once (1 = handled) */
pm_t p12_lock_bits(void);
uint8_t p12_pos(uint8_t c);
uint8_t p12_scn_off(uint8_t d);
uint8_t p12_app_free(void);                                   /* main_p12.c: app frames that still fit in the queue */
extern uint8_t p12acf[52]; extern uint8_t p12acfGen, p12acfOn;   /* alarm settings dump for the app */                               /* main_p12.c: scenario d off (0 = S1..S4), 1 = done */                                   /* main_p12.c: curtain c open, 0..99 percent */                                     /* main_p12.c: the child-lock key's bit while locked (shown red in the app) */                                       /* phones connected now (talking the new protocol) */
void wf_event(uint8_t code);                                   /* an alarm event (BB_C_EV code) */
uint8_t p12_app_send(uint8_t act, uint8_t zones, uint16_t code); /* main_p12.c: an app frame to the alarm MCU; 0 = bus busy */
#endif

#endif
