/* Sooden "12 economic" panel (E12) - one ATmega64 @ 8 MHz crystal (fuses Low 3F, High C1, Extended FF:
 * BOD 4 V, JTAG off, EESAVE, no ATmega103 mode). The same logic as the 23-key board (sw.c, 23 places):
 *   places 1..12 = poles 1..12, places 13..20 not on this panel, 21 / 22 / 23 = scenario left / centre / right.
 * On the glass:   1   9      10   2
 *                 3  11      12   4
 *                 5               6
 *                 7  [s1][s2][s3] 8
 * touch chip 1: valid PA1 (low = touched), code PA3 PA2 PA0 (bit 2 1 0)
 * touch chip 2: valid PC4, code PC3 PC1 PC0
 * white / red (= relay) pins: see PINS; scenario 2 white is lit by the supply, it has no red.
 * elevator relay PB1 (scenario 2 as ELEVATOR); the call shows on scenario 1's red for its 1 s.
 * Wi-Fi module: USART0 (wifi64.c), power PE6 (1 = on). 433 MHz receiver: PE7 (INT7).
 * two-panel network (HAS_PAIR builds): RS485 (auto-direction) on USART1, PD2 = RXD1, PD3 = TXD1, 9600 8N1
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <string.h>
#include "sw.h"
#include "wifi64.h"

const uint8_t cfg_flash[CFG_SIZE] __attribute__((section(".swcfg"), used)) = { [0 ... CFG_SIZE - 1] = 0xFF };

#if HAS_PAIR
const uint8_t px_flash[PX_SIZE] __attribute__((section(".swpx"), used)) = { [0 ... PX_SIZE - 1] = 0xFF };
static uint8_t px_mask(uint8_t k, uint8_t which, uint8_t *m)
{
    if (k >= SW_NP) return 0;
    const uint8_t *p = &px_flash[3 + (which ? 3 * SW_NP : 0) + 3 * k];
    m[2] = pgm_read_byte(p); m[1] = pgm_read_byte(p + 1); m[0] = pgm_read_byte(p + 2);
    m[2] &= 0x7F;
    return (uint8_t)(m[0] | m[1] | m[2]);
}
static uint8_t px_valid(void)
{
    uint8_t c = 0;
    for (uint16_t i = 0; i < PX_SIZE - 1; i++) {
        c ^= pgm_read_byte(&px_flash[i]);
        for (uint8_t j = 0; j < 8; j++) c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1);
    }
    return pgm_read_byte(&px_flash[0]) == PX_M0 && pgm_read_byte(&px_flash[1]) == PX_M1 &&
           pgm_read_byte(&px_flash[2]) == SW_NP && c == pgm_read_byte(&px_flash[PX_SIZE - 1]);
}
static volatile uint8_t n1rx[32], n1rh, n1rt, n1tx[32], n1th, n1tt;
ISR(USART1_RX_vect)
{
    uint8_t b = UDR1, n = (uint8_t)((n1rh + 1) & 31);
    if (n != n1rt) { n1rx[n1rh] = b; n1rh = n; }
}
ISR(USART1_UDRE_vect)
{
    if (n1tt != n1th) { UDR1 = n1tx[n1tt]; n1tt = (uint8_t)((n1tt + 1) & 31); }
    else UCSR1B &= (uint8_t)~_BV(UDRIE1);
}
static void n1_put(uint8_t b)
{
    uint8_t n = (uint8_t)((n1th + 1) & 31);
    while (n == n1tt) wdt_reset();
    n1tx[n1th] = b; n1th = n;
    UCSR1B |= _BV(UDRIE1);
}
static void net_tx(const uint8_t *p, uint8_t n)
{
    n1_put(0xFF);
    while (n--) n1_put(*p++);
}
#endif

#define P(port, bit) (uint8_t)(((port) << 4) | (bit))
enum { A, B, C, D, E, F, G };
static const uint8_t PINS[SW_NP][2] PROGMEM = {
    { P(F,2), P(F,3) }, { P(B,2), P(B,3) }, { P(F,4), P(F,6) }, { P(B,4), P(B,5) },   /* poles 1..4 */
    { P(F,5), P(A,6) }, { P(B,6), P(D,0) }, { P(A,7), P(C,7) }, { P(D,4), P(D,6) },   /* 5..8 */
    { P(F,1), P(F,0) }, { P(B,7), P(G,3) }, { P(A,4), P(A,5) }, { P(D,5), P(G,1) },   /* 9..12 */
    { 0xFF, 0xFF }, { 0xFF, 0xFF }, { 0xFF, 0xFF }, { 0xFF, 0xFF },                   /* places 13..20: */
    { 0xFF, 0xFF }, { 0xFF, 0xFF }, { 0xFF, 0xFF }, { 0xFF, 0xFF },                   /* not on this panel */
    { P(C,6), P(C,5) }, { 0xFF, 0xFF }, { P(D,7), P(G,0) },                           /* scenario 1, 2, 3 */
};
/* touch code -> place (0..11 poles, 20..22 scenarios), 0xFF = none */
static const uint8_t KEYMAP[2][8] PROGMEM = {
    /* chip 1 */ { 6, 2, 21, 8, 20, 4, 0, 10 },
    /* chip 2 */ { 11, 9, 1, 3, 5, 7, 22, 0xFF },
};
static volatile uint8_t *const PORTS[7] = { &PORTA, &PORTB, &PORTC, &PORTD, &PORTE, &PORTF, &PORTG };
static volatile uint8_t *const DDRS[7]  = { &DDRA, &DDRB, &DDRC, &DDRD, &DDRE, &DDRF, &DDRG };
static uint8_t outMask[7], restVal[7];

static Sw S;
static volatile uint32_t ms;
ISR(TIMER0_COMP_vect) { ms++; }
static uint32_t now_ms(void) { uint32_t v; cli(); v = ms; sei(); return v; }

static uint8_t ee_r(uint16_t a) { return eeprom_read_byte((const uint8_t *)a); }
static void ee_w(uint16_t a, uint8_t v) { eeprom_update_byte((uint8_t *)a, v); }

/* power-up motion: 1, 9, 10, 2, 4, 6, 8, s3, s2, s1, 7, 5, 3 - three rounds, 90 / 70 / 50 ms a step */
static const uint8_t RING[13] PROGMEM = { 0, 8, 9, 1, 3, 5, 7, 22, 21, 20, 6, 4, 2 };
pm_t e12_boot(uint16_t t)
{
    static const uint8_t STEP[3] = { 90, 70, 50 };
    for (uint8_t r = 0; r < 3; r++) {
        uint16_t len = (uint16_t)13 * STEP[r];
        if (t < len) return BIT(pgm_read_byte(&RING[t / STEP[r]]));
        t -= len;
    }
    return 0;
}

/* ---------------- 433 MHz (EV1527, 24 bit): the decoder of the other panels, on INT7 ---------------- */
static uint16_t rfLast, rfHi, rfT;
static uint8_t rfBits, rfOn;
static uint32_t rfAcc, rfPrev;
static volatile uint32_t rfCode;
static volatile uint8_t rfNew;
ISR(INT7_vect)
{
    uint16_t t = TCNT1, dt = t - rfLast;
    rfLast = t;
    if (!(PINE & _BV(7))) { rfHi = dt; return; }    /* falling edge: a high segment ended */
    uint16_t hi = rfHi, lo = dt;
    if (hi >= 100 && hi <= 1200 && lo >= hi * 18u && lo <= hi * 45u && lo >= 3000) {
        rfT = lo / 31; rfBits = 0; rfAcc = 0; rfOn = 1;
        return;
    }
    if (!rfOn) return;
    uint16_t T = rfT, sh, lg;
    uint8_t bit;
    if (hi > lo) { bit = 1; sh = lo; lg = hi; } else { bit = 0; sh = hi; lg = lo; }
    if (sh < T / 2 || sh > T * 2 || lg < T * 2 || lg > T * 5) { rfOn = 0; return; }
    rfAcc = (rfAcc << 1) | bit;
    if (++rfBits == 24) {
        rfOn = 0;
        if (rfAcc == rfPrev) { rfCode = rfAcc; rfNew = 1; }
        rfPrev = rfAcc;
    }
}

/* ---------------- touch ---------------- */
static pm_t read_keys(void)
{
    pm_t k = 0;
    uint8_t a = PINA, c = PINC;
    if (!(a & _BV(1))) {
        uint8_t code = (uint8_t)(((a >> 3) & 1) << 2 | ((a >> 2) & 1) << 1 | (a & 1));
        k |= BIT(pgm_read_byte(&KEYMAP[0][code]));
    }
    if (!(c & _BV(4))) {
        uint8_t code = (uint8_t)(((c >> 3) & 1) << 2 | ((c >> 1) & 1) << 1 | (c & 1));
        uint8_t p = pgm_read_byte(&KEYMAP[1][code]);
        if (p != 0xFF) k |= BIT(p);
    }
    return k;
}

static void write_outputs(pm_t w, pm_t r)
{
    uint8_t v[7];
    for (uint8_t p = 0; p < 7; p++) v[p] = restVal[p];
#if HAS_SCN
    if (S.elevLeft) r |= BIT(20);                       /* elevator call: scenario 1 red for its 1 s */
#endif
    for (uint8_t k = 0; k < SW_NP; k++) {
        uint8_t pw = pgm_read_byte(&PINS[k][0]), pr = pgm_read_byte(&PINS[k][1]);
        if (pw != 0xFF && (w & BIT(k))) v[pw >> 4] |= (uint8_t)_BV(pw & 7);
        if (pr != 0xFF && (r & BIT(k))) v[pr >> 4] |= (uint8_t)_BV(pr & 7);
    }
#if HAS_SCN
    if (S.elevLeft) v[B] |= _BV(1);                     /* elevator relay */
#endif
    if (S.wifi) v[E] |= _BV(6);                         /* Wi-Fi module power */
    for (uint8_t p = 0; p < 7; p++)
        *PORTS[p] = (uint8_t)((*PORTS[p] & (uint8_t)~outMask[p]) | (v[p] & outMask[p]));
}

static void __attribute__((noinline)) setup(void)
{
    uint8_t *buf = (uint8_t *)&S.c;
    for (uint16_t i = 0; i < CFG_SIZE; i++) buf[i] = pgm_read_byte(&cfg_flash[i]);
    const Cfg *cfg = &S.c;
    if (!sw_cfg_ok(cfg)) for (;;) ;                     /* not configured: every pin stays an input */

    for (uint8_t k = 0; k < SW_NP; k++)
        for (uint8_t j = 0; j < 2; j++) {
            uint8_t p = pgm_read_byte(&PINS[k][j]);
            if (p != 0xFF) outMask[p >> 4] |= (uint8_t)_BV(p & 7);   /* every LED / relay pin: output (a relay of an empty pole stays off) */
        }
    outMask[B] |= _BV(1);                               /* elevator relay */
    outMask[E] |= _BV(6);                               /* Wi-Fi power */
    uint8_t hiZ[7] = { 0 };
    hiZ[E] = _BV(0) | _BV(1) | _BV(7);                  /* Wi-Fi UART (no pull-up into an unpowered module), 433 receiver */
    hiZ[D] = _BV(2) | _BV(3);                           /* RS485 module */
    for (uint8_t p = 0; p < 7; p++) {
        uint8_t pull = (uint8_t)(~outMask[p] & ~hiZ[p]);   /* touch inputs and unused pins: pull-up */
        restVal[p] = pull;
        *PORTS[p] = pull;
        *DDRS[p] = outMask[p];
    }

    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS02);           /* 1 ms (8 MHz / 64 / 125) */
    TIMSK |= _BV(OCIE0);
    TCCR1A = 0; TCCR1B = _BV(CS11);                       /* 1 us ticks for the 433 decoder */
    EICRB = _BV(ISC70);                                   /* INT7 any change */
    EIFR = _BV(INTF7);
    EIMSK |= _BV(INT7);

    S.eer = ee_r; S.eew = ee_w;
    sw_init(&S, cfg, 0);
#if HAS_PAIR
    if (px_valid()) S.pxm = px_mask;
    UBRR1H = 0; UBRR1L = 51;                            /* 9600 at 8 MHz */
    UCSR1A = 0;
    UCSR1C = _BV(UCSZ11) | _BV(UCSZ10);
    UCSR1B = _BV(RXCIE1) | _BV(RXEN1) | _BV(TXEN1);
    S.tx = net_tx;
#endif
}

int main(void)
{
    uint8_t why = MCUCSR;
    MCUCSR |= _BV(JTD); MCUCSR |= _BV(JTD);           /* JTAG off (it would take PF4..PF7) */
    MCUCSR = 0;
    setup();
    S.logOn = (why & (_BV(PORF) | _BV(BORF))) != 0;     /* record remote codes only after a power-up */
    write_outputs(0, 0);
    wdt_enable(WDTO_1S);
    sei();

    /* touch: a code steady for tpress ms acts; the next touch after the finger was lifted and the gap passed
       (as the ATmega32 of the 23-key board) */
    pm_t keys = 0, raw = 0, stable = 0;
    uint8_t kMs = 0;
    uint16_t sincePress = 0xFFFF;
    uint32_t last = now_ms();
    for (;;) {
        wdt_reset();
        uint32_t now = now_ms();
        uint16_t dt = (uint16_t)(now - last);
        if (dt > 1000) dt = 1000;
        last = now;
        if (dt) {
            kMs = kMs + dt < 255 ? (uint8_t)(kMs + dt) : 255;
            sincePress = sincePress + dt < 0xFFFF ? (uint16_t)(sincePress + dt) : 0xFFFF;
        }
        pm_t k = read_keys();
        if (k != raw) { raw = k; kMs = 0; }
        else {
            uint8_t tp = S.c.tpress >= 1 && S.c.tpress <= 50 ? S.c.tpress : 2, tg = S.c.tgap2 >= 5 ? S.c.tgap2 : 30;
            pm_t pressed = k & ~stable;
            if (pressed && kMs >= tp) { stable |= pressed; sincePress = 0; }
            pm_t up = stable & ~k;
            if (up && kMs >= 3 && sincePress >= (uint16_t)tg * 2) stable &= k;
        }
        keys = stable;
        if (rfNew) { cli(); S.rfCode = rfCode; rfNew = 0; sei(); S.rfNew = 1; }
#if HAS_PAIR
        while (n1rt != n1rh) { uint8_t b = n1rx[n1rt]; n1rt = (uint8_t)((n1rt + 1) & 31); sw_rx(&S, b, now); }
#endif
        sw_tick(&S, now, keys);
        write_outputs(S.white, S.red);
        wf_poll(&S, now);
#if HAS_PAIR
        sw_link(&S, now);
#endif
    }
}
