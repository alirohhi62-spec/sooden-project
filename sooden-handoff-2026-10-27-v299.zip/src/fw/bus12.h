/* Bus A between M4 and the three M32 boards (12-pole SIM panel)
   5 lines, idle 11111. A frame = 3 symbols: [target 0..30] [value 0..30] [check = (target + value) mod 31]
   a data frame = 5 symbols: [0] [register 16..30] [hi] [lo] [check = (register + hi + lo) mod 31], value = hi * 31 + lo (0..960)
   each symbol is held 8 ms, then 4 ms idle; at least 20 ms idle between frames.
   The receiver samples every 1 ms: a symbol counts once it is the same 3 ms in a row after an idle;
   more than 12 ms idle drops a half frame; a wrong check drops the frame. Commands are absolute
   (a repeat does no harm) and M4 repeats every state now and then, so a lost frame heals by itself. */
#define BUS_IDLE   0x1F
#define BUS_HOLD   8
#define BUS_GAP    4
#define BUS_FGAP   20
/* targets */
#define TG_SYS     0     /* value 3 = run the power-up motion */
#define TG_A       25    /* indicator A (ok): value 4 = blink (custom scenario stored) */
#define TG_DISP    30    /* OLED view, D_xxx */
#define D_STATES   0     /* the poles of each board */
#define D_CLOCK    1     /* idle: weekday / date / time */
#define D_CUR      2     /* 2..5: curtain 1 opening, closing, curtain 2 opening, closing */
#define D_STANDBY  8     /* standby: the clock, indicators and keypad light dark */
#define D_SCNHOLD  9     /* OLED 1: a custom scenario key held, countdown (R_CNT) to storing */
#define D_SCNOK    10    /* OLED 1: "scenario stored" */
#define D_EXIT     11    /* OLED 1: exit scenario (S5) running, countdown R_CNT seconds */
#define D_ROOM     12    /* OLED 1: room R_ROOM (1..9) all on / off / no answer (R_RRES 1 / 0 / 2), 3 s */
/* data registers (data frames) */
#define R_FIRST    16
#define R_HOUR     16
#define R_MIN      17
#define R_WDAY     18    /* 0 = Saturday .. 6 = Friday */
#define R_YEAR     19    /* Jalali year - 1300 */
#define R_MON      20
#define R_DAY      21
#define R_POS1     22    /* curtain 1: open 0..100 % */
#define R_POS2     23
#define R_LEFT     24    /* seconds left of the run of the curtain in view */
#define R_MOV      25    /* bit 0/1 curtain 1 opening/closing, bit 2/3 curtain 2 */
#define R_CNT      26    /* seconds left of the scenario hold */
#define R_ROOM     27    /* 7-segment room 1..9 of the last command */
#define R_RRES     28    /* its result: 0 all off, 1 all on, 2 no answer */
#define R_LAST     28
#define R_N        (R_LAST - R_FIRST + 1)
/* values of a key */
#define V_OFF  0         /* white on, red (relay) off */
#define V_ON   1         /* red (relay) on, white off */
#define V_DARK 2         /* both off (standby) */
#define SYS_MOTION 3
#define A_BLINK 4
#define V_BLINK 5        /* red blinking, 1 s on / 1 s off (indicator D: weak signal) */
#define TG_C       27    /* indicator C (home, N3 Wi-Fi): V_ON red = a phone app is connected, V_OFF white = none */
#define TG_D       28    /* indicator D (SIM): V_ON red = good signal, V_BLINK = weak / no network, V_OFF white = no SIM or no module */
/* bus C (M4 -> alarm MCU): M4 PB2 PB0 PE7 -> alarm PB2 PB3 PB4 = bit 2..0, idle 111.
   A code is held 30 ms, then at least 10 ms idle (as the earlier firmware). The codes are states, not toggles:
   M4 sends a change at once and repeats both states every 2 s (a lost pulse heals). */
#define BC_IDLE     7
#define BC_STANDBY  3    /* 011 panel in standby: OLED 4, zone whites, D white, Led_N dark */
#define BC_AWAKE    2    /* 010 panel awake */
#define BC_LOCKED   6    /* 110 child lock on: the alarm keypad is locked too */
#define BC_UNLOCKED 1    /* 001 child lock off */
#define BC_EXITLK   4    /* 100 exit scenario running: the alarm keypad and SMS commands wait, the alarm remote still works */
#define BC_HOLD     30
#define BC_GAP      10
/* bus B (alarm -> M4): alarm PE5 PE6 PE7 PB0 -> M4 PB7 PB6 PB5 PB4 = bit 3..0, idle 1111, held 30 ms */
#define BB_IDLE     15
#define BB_WAKE     7
/* bus B frames (alarm -> M4): [command][argument][check = (c + a) mod 15], 4-bit symbols 0..14, held 8 ms, 4 ms apart, 20 ms between frames */
#define BB_C_SCNON  1    /* argument: scenario 1..4 */
#define BB_C_SCNOFF 2
#define BB_C_KON    3    /* argument: K 1..3 (keys 13..15) */
#define BB_C_KOFF   4
#define BB_C_CUR    5    /* 1/2/3 curtain 1 open / close / stop, 4/5/6 curtain 2 */
#define BB_C_BUSY   6    /* argument 1: the GSM module transmits (touches wait), 0: done */
#define BB_C_WAKE   7    /* wake the panel / a keypad or remote touch: the standby minute starts again */
#define BB_C_SIM    8    /* SIM state: 0 no SIM or no module, 1 weak signal or no network, 2 good signal */
/* bus C pole frame (M4 -> alarm): 0, then 6 base-7 digits of the pole mask (poles 1..15 on), then their sum mod 7 */
/* for the phone app (Wi-Fi) - alarm -> M4 on bus B: */
#define BB_C_MISC   0    /* 1/2/3 app arm or disarm: done / wrong code / busy, 4+op operator (0 none 1 MCI 2 Irancell 3 Rightel),
                            8/9 pole 12 on / off (BB_C_KON/KOFF arguments 4..14 = poles 1..11 on / off) */
#define BB_C_AL     9    /* alarm view: 0 off, 1 exit time, 2 armed, 3 entry time, 4 siren */
#define BB_C_ZN     10   /* armed zones (bit 0..2) */
#define BB_C_OPEN   11   /* zones whose sensor is open now (bit 0..2) */
#define BB_C_GSM    12   /* signal bars 0..5, + 8 when the module answers */
#define BB_C_CRD    13   /* credit: 10 start, then its digits 0..9, 11 end; 12 not known; 13 checking */
#define BB_C_EV     14   /* event: 1..4 armed by keypad / remote / SMS / app, 5..8 disarmed by the same, 9..11 siren zone 1..3,
                            12 power cut, 13 magnet opened */
/* app frame on bus C (M4 -> alarm): 5, action, zones - 1, 6 base-7 digits of the code (one digit per nibble), sum mod 7;
   action 1 arm, 2 arm at once (no exit time), 3 disarm, 4 check the credit, 5 send every state again */
#define BC_APP      5
