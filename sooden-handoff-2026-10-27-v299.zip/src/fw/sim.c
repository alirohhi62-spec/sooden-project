/* Host simulation of two Sooden switches on one RS485 line */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sw.h"

static Sw N[2];
static uint8_t ee[2][512];
static uint32_t T;                      /* ms */
static int fails, checks;
static int busOn = 1, echo = 1, dropPct = 0;
static int turnHold = 3;   /* auto-direction module keeps driving ~3 ms after its last byte */

/* ---- bus: each byte takes ~1.04 ms; overlapping transmissions collide ---- */
typedef struct { uint32_t at; uint8_t b; int to; } Ev;
static Ev q[4096]; static int qn;
static uint32_t busyUntil[2];
static int txCount[2];

static void push(int to, uint32_t at, uint8_t b) { if (qn < 4096) { q[qn].at = at; q[qn].b = b; q[qn].to = to; qn++; } }

static void tx_any(int me, const uint8_t *p, uint8_t n)
{
    txCount[me]++;
    if (!busOn) return;
    uint32_t start = T, end = T + n;
    int other = !me;
    int coll = busyUntil[other] + turnHold > start;
    busyUntil[me] = end;
    for (int i = 0; i < n; i++) {
        uint8_t b = coll ? (uint8_t)(p[i] ^ 0x5A) : p[i];
        if (dropPct && rand() % 100 < dropPct) continue;
        push(other, start + 1 + i, b);
        if (echo) push(me, start + 1 + i, b);
    }
    if (coll) {   /* corrupt the other's still-queued bytes too */
        for (int i = 0; i < qn; i++) if (q[i].at >= start) q[i].b ^= 0x33;
    }
}
static void tx0(const uint8_t *p, uint8_t n) { tx_any(0, p, n); }
static void tx1(const uint8_t *p, uint8_t n) { tx_any(1, p, n); }
static uint8_t er0(uint16_t a) { return ee[0][a]; }
static uint8_t er1(uint16_t a) { return ee[1][a]; }
static int eeWrites[2];
static void ew0(uint16_t a, uint8_t v) { ee[0][a] = v; eeWrites[0]++; }
static void ew1(uint16_t a, uint8_t v) { ee[1][a] = v; eeWrites[1]++; }

static uint8_t keys[2];

static void step(void)
{
    for (int i = 0; i < qn;) {
        if (q[i].at <= T) { sw_rx(&N[q[i].to], q[i].b, T); q[i] = q[--qn]; }
        else i++;
    }
    /* keep delivery order by time: simple approach since queue small */
    sw_tick(&N[0], T, keys[0]); sw_link(&N[0], T);
    sw_tick(&N[1], T, keys[1]); sw_link(&N[1], T);
    T++;
}
static void run(uint32_t ms) { while (ms--) step(); }

static void tap(int n, int pole) { keys[n] = (uint8_t)(1 << pole); run(60); keys[n] = 0; run(60); }
static void hold(int n, int pole, uint32_t ms) { keys[n] = (uint8_t)(1 << pole); run(ms); keys[n] = 0; run(40); }

#define CHECK(cond, msg) do { checks++; if (!(cond)) { fails++; printf("  FAIL: %s  (line %d, t=%u)\n", msg, __LINE__, T); } } while (0)

/* ---- config builder ---- */
static Cfg mk(uint8_t role, uint8_t npoles)
{
    Cfg c; memset(&c, 0, sizeof c);
    c.m0 = CFG_M0; c.m1 = CFG_M1; c.ver = CFG_VER; c.role = role;
    c.board = npoles <= 2 ? BOARD_2P : BOARD_4P;
    c.npoles = npoles;
    for (int i = 0; i < 4; i++) { c.link[i] = NO_LINK; c.type[i] = (i < npoles) ? T_NORMAL : T_OFF; }
    if (npoles == 3) { c.type[3] = T_MASTER; c.onmask[3] = 0x07; }
    c.nslot = N_SLOTS;
    c.tpress = T_PRESS; c.tgap2 = T_GAP / 2;
    for (int t = 0; t < N_SLOTS; t++) { c.rmap[t][1] = 0x01; c.rmap[t][2] = 0x02; c.rmap[t][4] = 0x04; c.rmap[t][8] = 0x08; }
    return c;
}
static void seal(Cfg *c) { c->crc = sw_crc8((uint8_t *)c, CFG_SIZE - 1); }

static void boot(Cfg a, Cfg b)
{
    seal(&a); seal(&b);
    if (!sw_cfg_ok(&a) || !sw_cfg_ok(&b)) { printf("  FAIL: config invalid\n"); fails++; }
    T = 1000; qn = 0; busyUntil[0] = busyUntil[1] = 0; keys[0] = keys[1] = 0;
    N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0;
    N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1;
    sw_init(&N[0], &a, T);
    sw_init(&N[1], &b, T);
    run(800 + T_BOOTSTEP * 4 * BOOT_ROUNDS);
}

/* ---- EV1527 waveform ---- */
static void rf_send(Sw *s, uint32_t code, int frames, uint16_t Tu)
{
    for (int f = 0; f < frames; f++) {
        /* sync: high T, low 31T */
        sw_rf_edge(s, 5000, 1);          /* rising edge after some idle low (not a sync: hi unknown) */
        sw_rf_edge(s, Tu, 0);            /* high T ended */
        sw_rf_edge(s, (uint16_t)(31 * Tu), 1);
        for (int i = 23; i >= 0; i--) {
            int b = (code >> i) & 1;
            uint16_t hi = b ? 3 * Tu : Tu, lo = b ? Tu : 3 * Tu;
            sw_rf_edge(s, hi, 0);
            sw_rf_edge(s, lo, 1);
        }
        /* next frame's sync high starts here */
        sw_rf_edge(s, Tu, 0);
        sw_rf_edge(s, (uint16_t)(31 * Tu), 1);
        run(40);
    }
}

static int remote_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_REMOTES; i++) if (N[0].rid[i] != NO_REMOTE) n++;
    return n;
}
static int remote_ok8(void)
{
    /* the type2 remote r4 (learned first) was the oldest and must be gone; the 8 new ones are there */
    for (int i = 0; i < MAX_REMOTES; i++) if (N[0].rid[i] == 0x111110) return 0;
    return 1;
}
static int st(int n, int pole) { return (N[n].state >> pole) & 1; }

int main(void)
{
    srand(7);
    memset(ee, 0xFF, sizeof ee);

    printf("1) 4 pole A <-> 4 pole B, links 1-1 2-2 3-3, pole 4 independent\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        for (int i = 0; i < 3; i++) { a.link[i] = (uint8_t)i; b.link[i] = (uint8_t)i; }
        boot(a, b);
        CHECK(N[0].online && N[1].online, "both online after boot");
        CHECK(N[0].white == 0x0F && N[0].red == 0, "A all white at boot");
        tap(0, 0); run(200);
        CHECK(st(0, 0) && st(1, 0), "A pole1 -> both on");
        CHECK((N[1].red & 1) && !(N[1].white & 1), "B pole1 red, white off");
        tap(1, 0); run(200);
        CHECK(!st(0, 0) && !st(1, 0), "B pole1 -> both off");
        tap(0, 3); run(200);
        CHECK(st(0, 3) && !st(1, 3), "pole4 independent");
        tap(1, 2); run(200);
        CHECK(st(0, 2) && st(1, 2), "B pole3 -> A pole3");
        /* simultaneous presses on the same linked pair */
        keys[0] = 1; keys[1] = 1; run(60); keys[0] = keys[1] = 0; run(800);
        CHECK(st(0, 0) == st(1, 0), "simultaneous press stays consistent");
        keys[0] = 2; keys[1] = 2; run(60); keys[0] = keys[1] = 0; run(800);
        CHECK(st(0, 1) == st(1, 1), "simultaneous press stays consistent (2)");
    }

    printf("2) cross mapping A1<->B4, A2<->B2 with 4P and 2P\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.link[0] = 3; b.link[3] = 0;
        boot(a, b);
        tap(0, 0); run(200);
        CHECK(st(0, 0) && st(1, 3) && !st(1, 0), "A1 -> B4");
        tap(1, 3); run(200);
        CHECK(!st(0, 0) && !st(1, 3), "B4 -> A1 off");

        Cfg c = mk(0, 4), d = mk(1, 2);
        c.link[1] = 1; d.link[1] = 1; c.link[3] = 0; d.link[0] = 3;
        boot(c, d);
        tap(1, 0); run(200);
        CHECK(st(1, 0) && st(0, 3), "2P B1 -> 4P A4");
        CHECK(N[1].red == 1, "2P output pole1 on");
        tap(0, 1); run(200);
        CHECK(st(0, 1) && st(1, 1) && N[1].red == 3, "4P A2 -> 2P B2");

        Cfg e = mk(0, 1), f = mk(1, 1);
        e.link[0] = 0; f.link[0] = 0;
        boot(e, f);
        tap(0, 0); run(200);
        CHECK(st(0, 0) && st(1, 0), "1 pole <-> 1 pole");
        keys[0] = 2; run(100); keys[0] = 0; run(100);
        CHECK(N[0].state == 1, "1 pole: second touch input ignored");
    }

    printf("3) 3 pole switch: pole 4 master\n");
    {
        Cfg a = mk(0, 3), b = mk(1, 3);
        for (int i = 0; i < 3; i++) { a.link[i] = (uint8_t)i; b.link[i] = (uint8_t)i; }
        boot(a, b);
        CHECK(N[0].white == 0x0F, "master white on");
        uint32_t t0 = T;
        uint32_t on[3] = {0, 0, 0};
        keys[0] = 8;
        for (int k = 0; k < 430; k++) { if (k == 30) keys[0] = 0; step(); for (int p = 0; p < 3; p++) if (!on[p] && st(0, p)) on[p] = T; }
        CHECK(on[0] && on[1] && on[2], "master turns 1-3 on");
        CHECK(on[1] - on[0] >= 80 && on[2] - on[1] >= 80, "staggered 80 ms in order");
        printf("     on at +%u +%u +%u ms\n", on[0] - t0, on[1] - t0, on[2] - t0);
        run(400);
        CHECK(N[1].state == 0x07, "B follows master via links");
        CHECK((N[0].red & 8) == 0, "master relay stays off");
        tap(1, 0); run(300);           /* one off -> master: any on => all off */
        tap(0, 3); run(500);
        CHECK(N[0].state == 0 && N[1].state == 0, "master: all off");
        tap(0, 3); run(500);
        CHECK(N[0].state == 7 && N[1].state == 7, "master: all on again");
    }

    printf("4) service scenario exactly like the original firmware (pole4: 1 off, 3 on, 4 relay on)\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.type[3] = T_TIMER; a.offmask[3] = 0x01; a.onmask[3] = 0x04; a.minutes[3] = 1;
        a.link[0] = 0; b.link[0] = 0; a.link[2] = 2; b.link[2] = 2;
        boot(a, b);
        CHECK(N[0].white == 0x0F && N[0].red == 0, "idle: pole4 white, relay off");
        tap(0, 0); tap(0, 1); run(300);
        CHECK(N[0].state == 0x03, "poles 1,2 on");
        tap(0, 3); run(400);
        CHECK(N[0].state == 0x0E, "service: 1 off, 2 untouched, 3 on, 4 on");
        CHECK((N[0].red & 8) && !(N[0].white & 8), "pole4 red (relay on) while timer runs");
        CHECK(!st(1, 0) && st(1, 2), "linked poles on B follow (B1 off, B3 on)");
        run(30000); tap(0, 3); run(300);
        CHECK(N[0].state == 0x0E, "touch again while running: restart, nothing toggles");
        run(45000);
        CHECK(st(0, 2) && st(0, 3), "restarted timer still running at 45 s");
        run(16000);
        CHECK(!st(0, 2) && !st(0, 3) && st(0, 1), "timeout: 3 and 4 off, 2 untouched");
        CHECK(!st(1, 2), "timeout reaches linked B3");
        CHECK((N[0].white & 8) && !(N[0].red & 8), "pole4 back to white");
        tap(0, 3); run(400);
        CHECK(st(0, 2) && st(0, 3), "service on again");
        tap(0, 2); run(300);
        CHECK(!st(0, 2) && !st(0, 3), "pole3 off by hand -> pole4 off too");
        tap(0, 3); run(400); tap(1, 2); run(400);
        CHECK(!st(0, 2) && !st(0, 3), "pole3 off from B -> pole4 off too");
        tap(0, 2); run(300); run(70000);
        CHECK(st(0, 2), "pole3 on by hand later is not timed");
        /* dimming does not happen while the service runs */
    }

    printf("4b) service scenario on B with linked pole (A broadcasts every second)\n");
    {
        Cfg a = mk(0, 2), b = mk(1, 4);
        b.type[3] = T_TIMER; b.onmask[3] = 0x01; b.minutes[3] = 1;
        b.link[0] = 0; a.link[0] = 0;
        boot(a, b);
        tap(1, 3); run(300);
        CHECK(st(1, 0) && st(0, 0) && st(1, 3), "B service turns on linked pole + B4");
        run(59000);
        CHECK(st(1, 0) && st(0, 0) && st(1, 3), "still on before 1 min");
        run(2000);
        CHECK(!st(1, 0) && !st(0, 0) && !st(1, 3), "auto-off on both after 1 min");
    }

    printf("5) link loss and recovery\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.link[0] = 0; b.link[0] = 0; a.link[1] = 1; b.link[1] = 1;
        boot(a, b);
        busOn = 0;
        tap(0, 0); run(6000);
        CHECK(st(0, 0) && !st(1, 0), "offline: local works");
        CHECK(!N[0].online, "A detects offline");
        tap(1, 1); run(200);
        CHECK(st(1, 1), "offline: B local works");
        busOn = 1; run(4000);
        CHECK(st(1, 0) && st(0, 1), "after reconnect both synced");
        /* B reboots alone while A has pole 1 on */
        Cfg b2 = b; seal(&b2);
        sw_init(&N[1], &b2, T);
        CHECK(N[1].state == 0, "B after reboot all off");
        run(1500);
        CHECK(st(1, 0) && st(1, 1), "B takes A's state after reboot");
    }

    printf("6) noise on the line\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.link[0] = 0; b.link[0] = 0;
        boot(a, b);
        for (int i = 0; i < 3000; i++) { if (rand() % 3 == 0) push(rand() & 1, T, (uint8_t)rand()); step(); }
        CHECK(N[0].state == 0 && N[1].state == 0, "random bytes change nothing");
        tap(0, 0); run(2500);   /* after a 3 s noise burst the link may need its next ping to come back */
        if (!(st(0, 0) && st(1, 0))) printf("  dbg: A=%d B=%d onlineA=%d onlineB=%d outActive=%d txMask=%d\n", st(0,0), st(1,0), N[0].online, N[1].online, N[0].outActive, N[0].txMask);
        CHECK(st(0, 0) && st(1, 0), "still works after noise");
    }

    printf("7) remote places: learn in order on pole 1, choose a place, erase on pole 2\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.remote = 1; a.link[0] = 0; b.link[0] = 0; a.dimsec = 0;
        memset(a.rmap, 0, sizeof a.rmap);
        a.rmap[0][1] = 0x01; a.rmap[0][2] = 0x02; a.rmap[0][4] = 0x04; a.rmap[0][8] = 0x08;   /* place 1: 4-ch A..D -> 1..4 */
        a.rmap[1][12] = 0x08; a.rmap[1][4] = 0x01;                                          /* place 2: 12-ch */
        a.rmap[2][1] = 0x0F;                                                                /* place 3: A -> all */
        a.rmap[3][1] = 0x02;                                                                /* place 4: A -> pole 2 */
        a.nslot = 4;
        memset(ee, 0xFF, sizeof ee);
        boot(a, b);
        uint32_t R1 = 0xA5C3B0, R2 = 0x2222A0, R3 = 0x333330, R4 = 0x444440, R5 = 0x555550;
        rf_send(&N[0], R1 | 1, 4, 350); run(500);
        CHECK(!st(0, 0), "unknown remote ignored");
        /* place 1 */
        keys[0] = 1; run(5100);
        CHECK(N[0].mode == M_LEARN && N[0].lslot == 0, "hold pole1 5 s -> learn, next free place = 1");
        keys[0] = 0; run(40);
        CHECK(!st(0, 0) && !st(1, 0), "short-press toggle undone");
        int on = 0, off = 0;
        for (int i = 0; i < 1000; i++) { step(); if (N[0].white & 1) on++; else off++; }
        CHECK(on > 300 && off > 300, "pole1 white blinking");
        rf_send(&N[0], R1 | 2, 3, 350); run(50);
        CHECK(N[0].mode == M_OK && (N[0].white & 1), "learned -> blinking stops (solid white)");
        CHECK(!st(0, 1), "learn press does not switch");
        run(2100);
        CHECK(N[0].mode == M_NORMAL && N[0].rid[0] == (R1 & 0xFFFFF0), "R1 in place 1");
        /* places 2, 3 in order */
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        CHECK(N[0].lslot == 1, "next free place = 2");
        rf_send(&N[0], R2 | 12, 3, 350); run(2200);
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        rf_send(&N[0], R3 | 1, 3, 350); run(2200);
        CHECK(N[0].rid[1] == (R2 & 0xFFFFF0) && N[0].rid[2] == (R3 & 0xFFFFF0) && N[0].rid[3] == NO_REMOTE, "R2 place 2, R3 place 3");
        /* each place uses its own table */
        rf_send(&N[0], R1 | 1, 4, 350); run(400);
        CHECK(st(0, 0) && st(1, 0), "R1 A -> pole1 + linked peer");
        rf_send(&N[0], R1 | 1, 4, 350); run(100);
        CHECK(!st(0, 0), "second press toggles off");
        rf_send(&N[0], R2 | 12, 4, 350); run(300);
        CHECK(N[0].state == 0x08, "R2 code12 -> pole4 (place 2 table)");
        rf_send(&N[0], R2 | 1, 4, 350); run(300);
        CHECK(N[0].state == 0x08, "R2 code1 not in place-2 table -> nothing");
        rf_send(&N[0], R3 | 1, 4, 350); run(1000);
        CHECK(N[0].state == 0x00, "R3 A (all, toggle) with pole4 on -> all off");
        rf_send(&N[0], R1 | 8, 6, 420); run(300);
        CHECK(st(0, 3), "btn D -> pole4, T=420us remote");
        rf_send(&N[0], R1 | 4, 4, 250); run(300);
        CHECK(st(0, 2), "btn C -> pole3, T=250us remote");
        rf_send(&N[0], R1 | 2, 20, 350); run(300);
        CHECK(st(0, 1), "held button toggles once");
        for (int i = 0; i < 200000; i++) sw_rf_edge(&N[0], (uint16_t)(50 + rand() % 3000), (uint8_t)(i & 1));
        int s0 = N[0].state; run(500);
        CHECK(N[0].state == s0, "receiver noise does nothing");
        /* place 4 by order, then all full: a 5th remote is not stored (blinking goes on until timeout) */
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        rf_send(&N[0], R4 | 1, 3, 350); run(2200);
        CHECK(N[0].rid[3] == (R4 & 0xFFFFF0), "R4 place 4");
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        CHECK(N[0].lslot == 0xFF, "no free place");
        rf_send(&N[0], R5 | 1, 3, 350); run(300);
        CHECK(N[0].mode == M_LEARN && remote_count() == 4 && N[0].rid[3] == (R4 & 0xFFFFF0), "5th remote not stored, still blinking");
        run(5300);
        CHECK(N[0].mode == M_NORMAL, "learn timeout -> normal");
        /* replace place 4: hold pole1, touch pole4 (blink moves to pole 4), press the new remote */
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        tap(0, 3);
        CHECK(N[0].mode == M_LEARN && N[0].lslot == 3 && N[0].modePole == 3, "touch pole4 -> place 4 chosen");
        on = off = 0;
        for (int i = 0; i < 1000; i++) { step(); if (N[0].white & 8) on++; else off++; }
        CHECK(on > 300 && off > 300, "pole4 white blinks now");
        CHECK(N[0].state == s0 || 1, "");
        int sb = N[0].state;
        rf_send(&N[0], R5 | 1, 3, 350); run(50);
        CHECK(N[0].mode == M_OK && N[0].rid[3] == (R5 & 0xFFFFF0) && N[0].rid[0] == (R1 & 0xFFFFF0) && N[0].rid[2] == (R3 & 0xFFFFF0), "R5 replaced R4 in place 4, others kept");
        CHECK(N[0].state == sb, "touching pole4 in learn mode did not switch it");
        run(2200);
        rf_send(&N[0], R4 | 1, 4, 350); run(300);
        CHECK(N[0].state == sb, "old R4 no longer works");
        rf_send(&N[0], R5 | 1, 4, 350); run(300);
        CHECK(N[0].state == (sb ^ 0x02), "R5 A -> pole2 (place-4 table)");
        /* the same remote learned again into another place moves there */
        keys[0] = 1; run(5100); keys[0] = 0; run(40); tap(0, 1);
        rf_send(&N[0], R5 | 1, 3, 350); run(2200);
        CHECK(N[0].rid[1] == (R5 & 0xFFFFF0) && N[0].rid[3] == NO_REMOTE, "same remote never in two places");
        /* power loss: reload from EEPROM, damage one copy */
        ee[0][EE_COPY0 + 2] ^= 0xFF;
        Cfg a2 = a; seal(&a2); sw_init(&N[0], &a2, T); run(500 + T_BOOTSTEP * 4 * BOOT_ROUNDS);
        CHECK(N[0].rid[0] == (R1 & 0xFFFFF0) && N[0].rid[1] == (R5 & 0xFFFFF0), "remotes kept after damaged copy");
        CHECK(ee[0][EE_COPY0 + 2] == ee[0][EE_COPY1 + 2], "damaged copy repaired");
        /* erase window without confirm */
        keys[0] = 2; run(5100); keys[0] = 0; run(5300);
        CHECK(remote_count() == 3 && N[0].mode == M_NORMAL, "no confirm -> remotes kept");
        /* erase: hold pole2 5 s, touch again */
        keys[0] = 2; run(5100); keys[0] = 0; run(300);
        CHECK(N[0].mode == M_ERASE, "erase window");
        tap(0, 1);
        CHECK(N[0].mode == M_OK && remote_count() == 0, "all erased after confirm touch");
        run(2200);
        s0 = N[0].state;
        rf_send(&N[0], R1 | 1, 4, 350); run(300);
        CHECK(N[0].state == s0, "remote no longer works");
        /* fewer places defined: only 2 */
        Cfg a3 = a; a3.nslot = 2; seal(&a3); memset(ee[0], 0xFF, 256);
        sw_init(&N[0], &a3, T); run(1600);
        keys[0] = 1; run(5100); keys[0] = 0; run(40); tap(0, 3);
        CHECK(N[0].lslot == 0 && N[0].modePole == 0, "touch on a pole beyond the defined places is ignored");
        rf_send(&N[0], R1 | 1, 3, 350); run(2200);
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        rf_send(&N[0], R2 | 1, 3, 350); run(2200);
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        CHECK(N[0].lslot == 0xFF, "2 places full");
        run(5300);
    }

    printf("8) dimming\n");
    {
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.dimsec = 10; a.link[0] = 0; b.link[0] = 0;
        boot(a, b);
        run(10500);
        CHECK(N[0].dimmed && N[0].white == 0x08, "dimmed: only pole4 white");
        tap(0, 1);
        CHECK(!N[0].dimmed && st(0, 1), "first touch wakes and switches at once");
        run(20000);
        CHECK(!N[0].dimmed, "no dim while a pole is on");
        tap(0, 1); run(10500);
        CHECK(N[0].dimmed, "dim again");
        tap(1, 0); run(300);
        CHECK(!N[0].dimmed && st(0, 0), "peer change wakes");
    }

    printf("9) config validation\n");
    {
        Cfg c = mk(0, 2); c.type[2] = T_NORMAL; seal(&c);   /* (remote on 2P: the 2P hex has no remote code at all) */
        CHECK(!sw_cfg_ok(&c), "pole 3 on 2P rejected");
        c = mk(0, 4); c.link[3] = 2; c.type[3] = T_MASTER; seal(&c);
        CHECK(!sw_cfg_ok(&c), "linked scenario rejected");
        c = mk(0, 4); seal(&c); c.type[0] = 2;
        CHECK(!sw_cfg_ok(&c), "bad crc rejected");
        uint8_t blank[CFG_SIZE]; memset(blank, 0xFF, CFG_SIZE);
        CHECK(!sw_cfg_ok((Cfg *)blank), "blank block rejected");
    }

    printf("10) stress: random presses both sides, lossy line\n");
    for (int seed = 1; seed <= 300; seed++) {
        srand(seed);
        Cfg a = mk(0, 4), b = mk(1, 4);
        a.link[0] = 0; b.link[0] = 0; a.link[1] = 3; b.link[3] = 1; a.link[2] = 2; b.link[2] = 2;
        if (seed & 1) { a.type[3] = T_MASTER; a.onmask[3] = 0x07; }
        else { a.type[3] = T_TIMER; a.offmask[3] = 0x02; a.onmask[3] = 0x05; a.minutes[3] = 1; }
        boot(a, b);
        dropPct = seed % 5 == 0 ? 0 : (seed % 5) * 5;
        for (int i = 0; i < 400; i++) {
            int n = rand() & 1, p = rand() % 4;
            keys[n] = (uint8_t)(1 << p);
            run(30 + rand() % 40);
            keys[n] = 0;
            run((uint32_t)(rand() % 300));
            if (rand() % 50 == 0) { busOn = 0; run((uint32_t)(rand() % 6000)); busOn = 1; }
        }
        dropPct = 0;
        run(8000);
        int ok = st(0, 0) == st(1, 0) && st(0, 1) == st(1, 3) && st(0, 2) == st(1, 2);
        CHECK(ok, "stress converged");
        if (!ok) printf("     seed %d: A=%x B=%x\n", seed, N[0].state, N[1].state);
    }

    printf("11) single panel 4 pole: silent line, power-up circle, buzzer\n");
    {
        Cfg a = mk(0, 4), b = mk(0, 4);          /* two independent single panels, no links */
        a.beep = 0x05; a.dimsec = 10; a.remote = 1;   /* beep on poles 1 and 3 */
        seal(&a); seal(&b);
        CHECK(sw_cfg_ok(&a), "single config valid");
        T = 50000; qn = 0; keys[0] = keys[1] = 0; txCount[0] = txCount[1] = 0;
        memset(ee, 0xFF, sizeof ee);
        N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0;
        N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1;
        sw_init(&N[0], &a, T); sw_init(&N[1], &b, T);
        uint32_t t0 = T;
        /* circle 1 -> 2 -> 4 -> 3, three times, one white at a time, no red, touch ignored */
        static const uint8_t want[4] = { 1, 2, 8, 4 };
        int seqOk = 1, oneLed = 1, redOff = 1, buzzOff = 1;
        keys[0] = 1;                              /* finger already on pole 1 at power-up */
        for (uint32_t k = 0; k < T_BOOTSTEP * 4 * BOOT_ROUNDS; k++) {
            step();
            uint32_t ph = (T - 1 - t0) / T_BOOTSTEP;
            if (N[0].white != want[ph & 3]) seqOk = 0;
            if (__builtin_popcount(N[0].white) != 1) oneLed = 0;
            if (N[0].red || N[0].state) redOff = 0;
            if (N[0].buzz) buzzOff = 0;
        }
        CHECK(seqOk && oneLed, "power-up circle 1-2-4-3 x3");
        CHECK(redOff && buzzOff, "no red/relay/buzzer during power-up");
        run(5);
        CHECK(N[0].white == 0x0F && N[0].state == 0, "after circle: all white, all off");
        run(500);
        CHECK(N[0].state == 0, "key held through power-up does not switch");
        keys[0] = 0; run(100);

        /* buzzer */
        keys[0] = 1; int bz = 0, first = -1;
        for (int k = 0; k < 120; k++) { step(); if (N[0].buzz) { bz++; if (first < 0) first = k; } }
        keys[0] = 0; run(100);
        CHECK(st(0, 0), "pole1 on");
        CHECK(bz >= T_BEEP - 1 && bz <= T_BEEP + 1, "pole1 beep ~40 ms");
        CHECK(first >= 0 && first <= T_PRESS + 2, "beep with the touch");
        bz = 0; keys[0] = 2;
        for (int k = 0; k < 120; k++) { step(); if (N[0].buzz) bz++; }
        keys[0] = 0; run(100);
        CHECK(st(0, 1) && bz == 0, "pole2 switches, no beep (not selected)");
        tap(0, 2); CHECK(st(0, 2), "pole3 on");
        tap(0, 3); CHECK(st(0, 3), "pole4 on");
        tap(0, 0); tap(0, 1); tap(0, 2); tap(0, 3);
        CHECK(N[0].state == 0, "all off again");
        CHECK(N[0].red == 0 && N[0].white == 0x0F, "LEDs white when off");

        /* remote does not beep */
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        rf_send(&N[0], 0x123450 | 1, 3, 350); run(2200);
        bz = 0;
        rf_send(&N[0], 0x123450 | 4, 1, 350);
        for (int k = 0; k < 300; k++) { step(); if (N[0].buzz) bz++; }
        rf_send(&N[0], 0x123450 | 4, 1, 350);
        CHECK(st(0, 2) && bz == 0, "remote switches pole3 without beep");

        /* dimming counts from the end of power-up */
        Cfg a3 = a; a3.remote = 0; seal(&a3);
        sw_init(&N[0], &a3, T); t0 = T;
        run(T_BOOTSTEP * 4 * BOOT_ROUNDS + 9000);
        CHECK(!N[0].dimmed, "not dimmed 9 s after the circle");
        run(1500);
        CHECK(N[0].dimmed && N[0].white == 0x08, "dimmed 10 s after the circle");

        CHECK(txCount[0] == 0 && txCount[1] == 0, "single panel never sends on the line");
    }

    printf("12) button actions, stagger, EEPROM writes, code log\n");
    {
        Cfg a = mk(0, 4), b = mk(0, 4);
        a.remote = 1; a.stag10 = 25; a.nslot = 4;
        memset(a.rmap, 0, sizeof a.rmap);
        a.rmap[0][1] = 0x04;                               /* code 1 -> pole 3 (toggle) */
        a.rmap[0][2] = 0x0F;                               /* code 2 -> all 4, toggle like a master */
        a.rmap[0][3] = 0x03 | (A_ON << 4);                 /* code 3 -> poles 1+2 only on */
        a.rmap[0][5] = 0x0F | (A_OFF << 4);                /* code 5 -> all off */
        seal(&a); seal(&b);
        CHECK(sw_cfg_ok(&a), "v3 config valid");
        Cfg bad = a; bad.nslot = 5; seal(&bad);
        CHECK(!sw_cfg_ok(&bad), "more places than poles rejected");
        memset(ee, 0xFF, sizeof ee);
        T = 100000; qn = 0; keys[0] = keys[1] = 0; txCount[0] = txCount[1] = 0;
        N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0; N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1;
        sw_init(&N[0], &a, T); sw_init(&N[1], &b, T);
        run(1500);
        uint32_t r4 = 0x111110;
        keys[0] = 1; run(5100); keys[0] = 0; run(40);
        rf_send(&N[0], r4 | 1, 3, 350); run(2500);
        rf_send(&N[0], r4 | 1, 2, 350); run(500);
        CHECK(N[0].state == 0x04, "code1 -> pole3 (remapped)");
        rf_send(&N[0], r4 | 1, 2, 350); run(500);
        CHECK(N[0].state == 0, "again -> pole3 off");
        rf_send(&N[0], r4 | 2, 2, 350);
        uint32_t t0 = T; int on[4] = { -1, -1, -1, -1 };
        for (int i = 0; i < 1200; i++) { step(); for (int p = 0; p < 4; p++) if (on[p] < 0 && st(0, p)) on[p] = (int)(T - t0); }
        CHECK(N[0].state == 0x0F, "code2 -> all 4 on");
        printf("     on at +%d +%d +%d +%d ms\n", on[0], on[1], on[2], on[3]);
        CHECK(on[1] > on[0] && on[2] - on[1] >= 248 && on[2] - on[1] <= 252 && on[3] - on[2] >= 248 && on[3] - on[2] <= 252, "pole 1,2,3,4 in order, 250 ms steps");
        rf_send(&N[0], r4 | 2, 2, 350);
        t0 = T; int off[4] = { -1, -1, -1, -1 };
        for (int i = 0; i < 1200; i++) { step(); for (int p = 0; p < 4; p++) if (off[p] < 0 && !st(0, p)) off[p] = (int)(T - t0); }
        CHECK(N[0].state == 0 && off[2] - off[1] >= 248 && off[2] - off[1] <= 252 && off[3] - off[2] >= 248 && off[3] - off[2] <= 252, "again -> all off in order, 250 ms steps");
        tap(0, 1); run(300);
        rf_send(&N[0], r4 | 2, 2, 350); run(1200);
        CHECK(N[0].state == 0, "mixed -> all off (like master)");
        rf_send(&N[0], r4 | 3, 2, 350); run(700);
        CHECK(N[0].state == 0x03, "only-on -> poles 1+2 on");
        rf_send(&N[0], r4 | 3, 2, 350); run(700);
        CHECK(N[0].state == 0x03, "only-on again -> still on");
        rf_send(&N[0], r4 | 5, 2, 350); run(1200);
        CHECK(N[0].state == 0, "only-off -> all off");
        rf_send(&N[0], r4 | 5, 2, 350); run(700);
        CHECK(N[0].state == 0, "only-off again -> still off");
        /* no EEPROM write in daily use (outside the log window) */
        T = N[0].bootAt + T_LOGWIN + 10;
        int w0 = eeWrites[0];
        for (int k = 0; k < 6; k++) { rf_send(&N[0], r4 | (k & 1 ? 1 : 2), 2, 350); run(1200); tap(0, k & 3); }
        CHECK(eeWrites[0] == w0, "no EEPROM write in daily use");
        /* recording: after power-up, 15 min, in the order received; a held/repeated button only once in a row
           (the programmer drops the other repeats) */
        Cfg a3 = a; seal(&a3); memset(ee[0], 0xFF, 512);
        sw_init(&N[0], &a3, T); run(1600);
        uint32_t seq[] = { 0x2222A1, 0x2222A2, 0x2222A1, 0x2222A3, 0x5A3C18, 0x5A3C14, 0x2222A2 };
        for (int k = 0; k < 7; k++) { rf_send(&N[0], seq[k], 3, 350); run(500); }
        int base = EE_REC;
        CHECK(ee[0][base] == EE_RECMAGIC && ee[0][base + 2] == 7 && ee[0][base + 1] == 7, "7 presses recorded in order");
        int ord = 1;
        for (int k = 0; k < 7; k++) { int a = base + 3 + k * 3; if (((uint32_t)ee[0][a] << 16 | ee[0][a + 1] << 8 | ee[0][a + 2]) != seq[k]) ord = 0; }
        CHECK(ord, "in the order received, both remotes");
        int w2 = eeWrites[0];
        rf_send(&N[0], 0x2222A2, 3, 350); run(200); rf_send(&N[0], 0x2222A2, 3, 350); run(600);
        CHECK(eeWrites[0] == w2, "the same button again in a row is not written");
        /* ring: 100 places, oldest replaced */
        for (int k = 0; k < 100; k++) { rf_send(&N[0], 0x700000 + (uint32_t)k * 16 + 1, 3, 350); run(450); }
        CHECK(ee[0][base + 2] == 100 && ee[0][base + 1] == 7, "full: 100 kept, next write position wraps");
        CHECK(ee[0][base + 3] == 0x70 && ee[0][base + 4] == 0x05 && ee[0][base + 5] == 0xD1, "oldest entries replaced");
        /* not after 15 minutes */
        T = N[0].bootAt + T_LOGWIN + 5;
        w2 = eeWrites[0];
        rf_send(&N[0], 0x666661, 3, 350); run(300);
        CHECK(eeWrites[0] == w2, "no recording after 15 min");
        /* not after a reset that was not a power-up (programmer, watchdog) */
        memset(ee[0], 0xFF, 512); sw_init(&N[0], &a3, T); N[0].logOn = 0; run(1600);
        w2 = eeWrites[0];
        rf_send(&N[0], 0x123451, 3, 350); run(300);
        CHECK(eeWrites[0] == w2 && ee[0][base] == 0xFF, "no recording without a power-up");
    }

    printf("13) remote hold: 5 s timer, 15 s choose the timer length\n");
    {
        Cfg a = mk(0, 4), b = mk(0, 4);
        a.remote = 1; a.nslot = 1; a.stag10 = 8;
        memset(a.rmap, 0, sizeof a.rmap);
        a.rmap[0][1] = 0x01 | RT_TIMER;                    /* A: pole 1, timer on hold */
        a.rmap[0][2] = 0x06 | RT_TIMER;                    /* B: poles 2+3, timer on hold */
        a.rmap[0][4] = 0x08;                               /* C: pole 4, no timer */
        a.tmin[0] = 1; a.tmin[1] = 2; a.tmin[2] = 3; a.tmin[3] = 4;
        a.tdef[0] = 0x10;                                  /* code1 -> length 0 (1 min), code2 -> length 1 (2 min) */
        seal(&a); seal(&b);
        memset(ee, 0xFF, sizeof ee);
        T = 2000000; qn = 0; keys[0] = keys[1] = 0;
        N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0; N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1;
        sw_init(&N[0], &a, T); sw_init(&N[1], &b, T); run(1600);
        uint32_t R = 0x4444A0;
        keys[0] = 1; run(5100); keys[0] = 0; run(40); rf_send(&N[0], R | 1, 3, 350); run(2500);
        CHECK(N[0].rid[0] == R, "remote learned");
        /* short press: normal toggle, no timer */
        rf_send(&N[0], R | 1, 3, 350); run(600);
        CHECK(st(0, 0) && !N[0].rtMask && !N[0].blkN, "short press: pole1 on, no timer");
        rf_send(&N[0], R | 1, 3, 350); run(600);
        CHECK(!st(0, 0), "short press again: off");
        /* hold 6 s: 2 blinks at 5 s, release -> timer (1 min) */
        int dark = 0;
        for (int f = 0; f < 150; f++) { rf_send(&N[0], R | 1, 1, 350); if (N[0].blkN && !N[0].white) dark++; }
        CHECK(N[0].hOn && N[0].hStage == 1, "held 6 s: stage 1 (2 blinks shown)");
        CHECK(dark > 0, "whites went dark for the blinks");
        run(600);
        CHECK(st(0, 0) && (N[0].rtMask & 1), "released: pole1 on with timer");
        run(55000);
        CHECK(st(0, 0), "still on after 55 s");
        run(6000);
        CHECK(!st(0, 0) && !N[0].rtMask, "off after 1 min");
        /* touch off before the end cancels the timer */
        for (int f = 0; f < 150; f++) rf_send(&N[0], R | 1, 1, 350);
        run(600);
        CHECK(st(0, 0) && (N[0].rtMask & 1), "timer again");
        run(10000); tap(0, 0); run(300);
        CHECK(!st(0, 0) && !N[0].rtMask, "touched off: timer cancelled");
        tap(0, 0); run(70000);
        CHECK(st(0, 0), "switched on by touch later: stays on");
        tap(0, 0); run(300);
        /* group with timer: poles 2+3, 2 min */
        for (int f = 0; f < 150; f++) rf_send(&N[0], R | 2, 1, 350);
        run(1000);
        CHECK(st(0, 1) && st(0, 2) && N[0].rtMask == 0x06, "B held: poles 2+3 on with timer");
        run(115000);
        CHECK(st(0, 1) && st(0, 2), "on after 1 min 55 s");
        run(7000);
        CHECK(!st(0, 1) && !st(0, 2), "off after 2 min");
        /* a button without timer: holding does nothing special */
        for (int f = 0; f < 150; f++) rf_send(&N[0], R | 4, 1, 350);
        run(600);
        CHECK(st(0, 3) && !N[0].rtMask && !N[0].hOn, "C held: just toggled, no timer");
        rf_send(&N[0], R | 4, 3, 350); run(600);
        /* hold 16 s -> choose length: 3 presses = length 3 (3 min) */
        int stage2 = 0;
        for (int f = 0; f < 410; f++) { rf_send(&N[0], R | 1, 1, 350); if (N[0].hStage == 2) stage2 = 1; }
        CHECK(stage2, "held 16 s: stage 2 (2 more blinks)");
        run(600);
        CHECK(N[0].mode == M_TSET && !(N[0].rtMask & 1), "released after 15 s: choosing, no timer started");
        for (int k = 0; k < 3; k++) { rf_send(&N[0], R | 1, 3, 350); run(700); }
        CHECK(N[0].tsN == 3 && N[0].mode == M_TSET, "3 presses counted");
        run(9000);
        CHECK(N[0].mode == M_TSET, "still choosing 9 s after the last press");
        int saw3 = 0;
        for (int q = 0; q < 15; q++) { run(100); if (N[0].mode == M_NORMAL && N[0].blkN == 3) saw3 = 1; }
        CHECK(N[0].mode == M_NORMAL && saw3, "10 s idle: saved, 3 blinks");
        run(2000);
        int sx = st(0, 0);
        if (sx) { tap(0, 0); run(300); }
        for (int f = 0; f < 150; f++) rf_send(&N[0], R | 1, 1, 350);
        run(600);
        run(150000);
        CHECK(st(0, 0), "new length: still on after 2.5 min");
        run(35000);
        CHECK(!st(0, 0), "off after 3 min");
        /* the choice survives a power cut */
        Cfg a2 = a; seal(&a2); sw_init(&N[0], &a2, T); run(1600);
        for (int f = 0; f < 150; f++) rf_send(&N[0], R | 1, 1, 350);
        run(600);
        run(150000);
        CHECK(st(0, 0), "after reset: still the 3 min length");
        run(35000);
        CHECK(!st(0, 0), "off after 3 min");
        /* choosing, nothing pressed: back to normal, unchanged */
        for (int f = 0; f < 410; f++) rf_send(&N[0], R | 2, 1, 350);
        run(600);
        CHECK(N[0].mode == M_TSET, "choosing for B");
        run(10500);
        CHECK(N[0].mode == M_NORMAL && N[0].blkN == 0, "no press: back to normal, nothing saved");
        /* more than 4 presses stay at 4 */
        for (int f = 0; f < 410; f++) rf_send(&N[0], R | 2, 1, 350);
        run(600);
        for (int k = 0; k < 6; k++) { rf_send(&N[0], R | 2, 3, 350); run(700); }
        run(10500);
        CHECK(((N[0].tsel[0] >> 4) & 3) == 3, "6 presses -> length 4");
        /* a touch ends choosing */
        for (int f = 0; f < 410; f++) rf_send(&N[0], R | 1, 1, 350);
        run(600); tap(0, 3); run(300);
        CHECK(N[0].mode == M_NORMAL, "touch ends choosing");
    }


#define SINGLE(cfg) do { Cfg b_ = mk(0, 4); seal(&(cfg)); seal(&b_); CHECK(sw_cfg_ok(&(cfg)), "config valid"); \
    T = 900000; qn = 0; keys[0] = keys[1] = 0; memset(ee, 0xFF, sizeof ee); \
    N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0; N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1; \
    sw_init(&N[0], &(cfg), T); sw_init(&N[1], &b_, T); run(1600); } while (0)
#define RUNW(ms, m) do { for (uint32_t k_ = 0; k_ < (ms); k_++) { run(1); if ((N[0].state & (m)) == (m)) both = 1; } } while (0)
#if HAS_SEC && HAS_ILOCK
    printf("14) new pole kinds: curtain, cooler, off timer, push buttons, delayed off\n");
    {
        int both;
        /* curtain: pole 1 open, pole 2 close, 45 s, 0.5 s change-over */
        Cfg a = mk(0, 4);
        a.type[0] = a.type[1] = T_ILOCK; a.offmask[0] = 0x02; a.offmask[1] = 0x01;
        a.sec1[0] = a.sec1[1] = 45; a.sec2[0] = a.sec2[1] = 5;
        SINGLE(a);
        both = 0;
        tap(0, 0); RUNW(44000, 0x03);
        CHECK(st(0, 0) && !st(0, 1), "curtain open: running at 44 s");
        RUNW(1500, 0x03);
        CHECK(!st(0, 0), "curtain open: stops by itself after 45 s");
        tap(0, 0); run(2000); tap(0, 0); run(200);
        CHECK(!st(0, 0) && !st(0, 1), "touch while running: stops");
        tap(0, 0); run(3000); tap(0, 1);
        CHECK(!st(0, 0) && !st(0, 1), "close touched while opening: open stops");
        RUNW(3000, 0x03); CHECK(!st(0, 0) && !st(0, 1), "and close does not start (opposite key only stops)");
        tap(0, 1); run(200); CHECK(st(0, 1) && !st(0, 0), "close from rest: runs at once");
        tap(0, 0); RUNW(2000, 0x03); CHECK(!st(0, 0) && !st(0, 1), "open touched while closing: only stops");
        CHECK(!both, "open and close never on together");
        CHECK((N[0].white & 0x03) == 0x03 && !(N[0].red & 0x03), "idle: whites on, reds off");
        /* cooler: pole 1 pump, 2 slow, 3 fast, 4 off timer (1 min) */
        Cfg c = mk(0, 4);
        c.type[1] = c.type[2] = T_ILOCK; c.offmask[1] = 0x04; c.offmask[2] = 0x02; c.onmask[1] = c.onmask[2] = 0x01;
        c.sec2[1] = c.sec2[2] = 10;
        c.type[3] = T_OFFTMR; c.minutes[3] = 1; c.offmask[3] = 0x07;
        SINGLE(c);
        both = 0;
        tap(0, 0); run(500);
        CHECK(st(0, 0) && !st(0, 1) && !st(0, 2), "pump alone: nothing else");
        tap(0, 0); run(500); tap(0, 1); run(800);
        CHECK(st(0, 1) && st(0, 0), "slow on: pump on with it");
        run(300000); CHECK(st(0, 1), "slow: no time limit");
        tap(0, 2); RUNW(700, 0x06);
        CHECK(!st(0, 1) && !st(0, 2), "fast: slow off first, pause");
        RUNW(800, 0x06);
        CHECK(st(0, 2) && st(0, 0), "fast on after 1 s, pump on");
        CHECK(!both, "slow and fast never on together");
        tap(0, 2); run(500);
        CHECK(!st(0, 2) && st(0, 0), "fast off: pump stays");
        tap(0, 1); run(800);
        tap(0, 3); run(500);
        CHECK(st(0, 3) && (N[0].red & 0x08), "off timer started (red)");
        run(58000); CHECK(st(0, 1) && st(0, 0), "still running at 58 s");
        run(3000); CHECK(!st(0, 0) && !st(0, 1) && !st(0, 2) && !st(0, 3), "1 min: pump, slow, fast and the timer off");
        tap(0, 1); run(800); tap(0, 3); run(500); tap(0, 3); run(70000);
        CHECK(st(0, 1) && !st(0, 3), "off timer touched again: cancelled");
        /* push buttons and delayed off */
        Cfg d = mk(0, 4);
        d.type[0] = T_DELAY; d.sec1[0] = 0; d.sec2[0] = 3;          /* pulse 3 s */
        d.type[1] = T_DELAY; d.sec1[1] = 5; d.sec2[1] = 0;          /* on after 5 s, stays */
        d.type[2] = T_DELAY; d.sec1[2] = 2; d.sec2[2] = 4;          /* on after 2 s for 4 s */
        d.type[3] = T_DELOFF; d.sec1[3] = 10;                       /* delayed off 10 s */
        SINGLE(d);
        tap(0, 0); run(100); CHECK(st(0, 0), "pulse: on at once");
        run(2600); CHECK(st(0, 0), "pulse: on at 2.8 s");
        run(400); CHECK(!st(0, 0), "pulse: off after 3 s");
        tap(0, 0); run(2000); tap(0, 0); run(2000); CHECK(st(0, 0), "pulse touched again: restarts");
        run(1500); CHECK(!st(0, 0), "restarted pulse ends");
        tap(0, 1);
        int blinked = 0, w1 = 1;
        for (int k = 0; k < 4500; k++) { run(1); int w = (N[0].white >> 1) & 1; if (w != w1) blinked++; w1 = w; }
        CHECK(!st(0, 1) && blinked >= 4, "delay: waiting, white blinks");
        run(700); CHECK(st(0, 1), "delay: on after 5 s");
        run(60000); CHECK(st(0, 1), "permanent kind: stays on");
        tap(0, 1); run(200); CHECK(!st(0, 1), "touch: off");
        tap(0, 1); run(2000); tap(0, 1); run(5000); CHECK(!st(0, 1), "touch while waiting: cancelled");
        tap(0, 2); run(1700); CHECK(!st(0, 2), "delayed pulse: waiting at 1.8 s");
        run(500); CHECK(st(0, 2), "delayed pulse: on after 2 s");
        run(3500); CHECK(st(0, 2), "on at 3.5 s");
        run(800); CHECK(!st(0, 2), "off after 4 s");
        tap(0, 3); run(200); CHECK(st(0, 3), "delayed off: touch on");
        tap(0, 3); run(9000); CHECK(st(0, 3), "second touch: still on at 9 s");
        run(1500); CHECK(!st(0, 3), "off after 10 s");
        tap(0, 3); run(200); tap(0, 3); run(2000); tap(0, 3); run(200); CHECK(!st(0, 3), "third touch while waiting: off now");
        run(15000); CHECK(!st(0, 3), "and stays off");
        /* service scenario turning off a curtain pole: the curtain forgets its run */
        Cfg e = mk(0, 4);
        e.type[0] = e.type[1] = T_ILOCK; e.offmask[0] = 0x02; e.offmask[1] = 0x01; e.sec1[0] = e.sec1[1] = 45; e.sec2[0] = e.sec2[1] = 5;
        e.type[3] = T_TIMER; e.offmask[3] = 0x03; e.onmask[3] = 0x04; e.minutes[3] = 1;
        SINGLE(e);
        tap(0, 0); run(1000); tap(0, 3); run(800);
        CHECK(!st(0, 0) && st(0, 2) && N[0].ph[0] == 0, "service scenario stops the curtain");
    }
#endif
#if HAS_SCN
    printf("16) EXIT / SLEEP / ELEVATOR on a 4 pole panel, short scenario locks the panel\n");
    {
        int both = 0;
        /* poles 1, 2 normal; pole 3 EXIT 20 s (off 1, 2); pole 4 SLEEP 70 s (off 1, night light 2) */
        Cfg a = mk(0, 4);
        a.type[2] = T_EXIT; a.sec1[2] = 20; a.offmask[2] = 0x03;
        a.type[3] = T_SLEEP; a.sec1[3] = 70; a.offmask[3] = 0x01; a.onmask[3] = 0x02;
        SINGLE(a);
        tap(0, 0); tap(0, 1); run(300);
        tap(0, 2); run(100);
        CHECK(st(0, 2) && (N[0].red & 0x04) && st(0, 0) && st(0, 1), "EXIT: red on, poles still on");
        tap(0, 0); run(300); CHECK(st(0, 0), "EXIT under 1 min: panel locked (touch ignored)");
        tap(0, 2); run(300); CHECK(st(0, 2), "and its own key does not cancel it");
        run(18000); CHECK(st(0, 0) && st(0, 1) && st(0, 2), "still running at 19 s");
        { int t0 = -1, t1 = -1; for (int k = 0; k < 2500; k++) { run(1); if (t0 < 0 && !st(0, 0)) t0 = k; if (t1 < 0 && !st(0, 1)) t1 = k; }
          CHECK(t0 >= 0 && t1 - t0 >= 75, "EXIT end: poles go off step by step");
          printf("     EXIT end: pole 1 off at %d ms, pole 2 at %d ms\n", t0, t1); }
        CHECK(!st(0, 0) && !st(0, 1) && !st(0, 2), "20 s: everything off, EXIT ended");
        tap(0, 0); run(200); CHECK(st(0, 0), "unlocked after");
        tap(0, 3); run(200); CHECK(st(0, 3), "SLEEP started");
        tap(0, 1); run(200); CHECK(st(0, 1), "SLEEP of 1 min or more: panel not locked");
        tap(0, 1); run(200);
        tap(0, 3); run(200); CHECK(!st(0, 3), "a touch cancels it");
        run(80000); CHECK(st(0, 0) && !st(0, 1), "cancelled: nothing happens later");
        tap(0, 3); run(69000); CHECK(st(0, 3) && st(0, 0) && !st(0, 1), "SLEEP at 69 s");
        run(2500); CHECK(!st(0, 0) && st(0, 1) && !st(0, 3), "70 s: pole 1 off, night light (off before) on");
        /* elevator: hold 1 s -> 1 s relay */
        Cfg e = mk(0, 4);
        e.type[0] = T_ELEV; e.onmask[0] = 0x01;
        SINGLE(e);
        tap(0, 0); run(300); CHECK(!(N[0].red & 1), "elevator: a short touch does nothing");
        keys[0] = 1; int on = -1, len = 0;
        for (int k = 0; k < 2500; k++) { run(1); if (N[0].red & 1) { if (on < 0) on = k; len++; } }
        keys[0] = 0; run(100);
        CHECK(on >= 990 && on <= 1020 && len >= 990 && len <= 1020, "held: relay on after 1 s, for 1 s");
        printf("     elevator: on after %d ms, for %d ms\n", on, len);
        keys[0] = 1; run(1100); keys[0] = 0; run(50); tap(0, 1); run(100);
        CHECK(!st(0, 1), "during the elevator pulse: locked");
        run(1500); tap(0, 1); run(100); CHECK(st(0, 1), "then free again");
        CHECK(!st(0, 0), "the elevator pole has no state of its own");
#if HAS_ILOCK
        /* EXIT closing the curtain: 1 open, 2 close, 4 normal; EXIT 3 (5 s, off 1 + 4, close 2) */
        Cfg x = mk(0, 4);
        x.type[0] = x.type[1] = T_ILOCK; x.offmask[0] = 0x02; x.offmask[1] = 0x01; x.sec1[0] = x.sec1[1] = 45; x.sec2[0] = x.sec2[1] = 5;
        x.type[2] = T_EXIT; x.sec1[2] = 5; x.offmask[2] = 0x09; x.onmask[2] = 0x02;
        SINGLE(x);
        tap(0, 3); tap(0, 0); run(300);
        tap(0, 2);
        int k = 0; while (st(0, 0) && k < 8000) { run(1); k++; }
        CHECK(k >= 4000 && k <= 6000, "EXIT ends after about 5 s");
        both = 0; RUNW(200, 0x03);
        CHECK(!st(0, 0) && !st(0, 1) && !st(0, 3), "EXIT end: open stops, pole 4 off, close waits the pause");
        RUNW(700, 0x03); CHECK(st(0, 1) && !both, "then the curtain closes");
        RUNW(46000, 0x03); CHECK(!st(0, 1), "close stops after its run time");
#endif
    }
#endif
#if HAS_SEC

    printf("15) touch speed, release, stuck key, glitches, 49-day clock wrap\n");
    {
        Cfg a = mk(0, 4); a.stag10 = 25;            /* 250 ms group steps */
        seal(&a);
        T = 0xFFFFFFFFUL - 20000;                   /* the ms clock wraps 20 s from now */
        qn = 0; keys[0] = keys[1] = 0; memset(ee, 0xFF, sizeof ee);
        N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0; N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1;
        Cfg b2 = mk(0, 4); seal(&b2);
        sw_init(&N[0], &a, T); sw_init(&N[1], &b2, T); run(1600);
        /* latency: touch -> relay */
        keys[0] = 1; int lat = -1;
        for (int k = 0; k < 50; k++) { run(1); if (st(0, 0)) { lat = k + 1; break; } }
        keys[0] = 0; run(40);
        CHECK(lat >= 1 && lat <= 4, "touch -> relay within 4 ms");
        printf("     touch -> relay: %d ms\n", lat);
        /* two poles quickly one after the other: no 250 ms group wait */
        keys[0] = 2; run(5); keys[0] = 0; run(35); keys[0] = 4; run(5); keys[0] = 0;
        CHECK(st(0, 1) && st(0, 2), "two quick touches: both at once (no group step)");
        run(40);
        /* release under 30 ms does not count as a new touch (chatter) */
        keys[0] = 8; run(20); keys[0] = 0; run(10); keys[0] = 8; run(20); keys[0] = 0; run(40);
        CHECK(st(0, 3), "chatter during one touch: toggled once");
        /* fast tapping like a person: 35 ms on, 25 ms off -> every tap counts */
        int before = N[0].state;
        for (int k = 0; k < 6; k++) { keys[0] = 2; run(35); keys[0] = 0; run(25); }
        run(40);
        CHECK(N[0].state == before, "6 fast taps (60 ms apart): 6 toggles, back to the start");
        int cnt = 0, last = st(0, 1);
        for (int k = 0; k < 5; k++) { keys[0] = 2; run(35); keys[0] = 0; run(25); if (st(0, 1) != last) cnt++; last = st(0, 1); }
        CHECK(cnt == 5, "every fast tap toggles");
        /* a longer gap setting refuses taps that come too soon */
        N[0].c.tgap2 = 50;                          /* 100 ms */
        cnt = 0; last = st(0, 1);
        for (int k = 0; k < 4; k++) { keys[0] = 2; run(35); keys[0] = 0; run(25); if (st(0, 1) != last) cnt++; last = st(0, 1); }
        run(150);
        CHECK(cnt == 2, "gap 100 ms: 4 taps 60 ms apart -> only every other one counts");
        N[0].c.tgap2 = 15;
        /* a slower press setting needs the touch to last longer */
        N[0].c.tpress = 20;
        before = N[0].state;
        keys[0] = 2; run(15); keys[0] = 0; run(60);
        CHECK(N[0].state == before, "press 20 ms: a 15 ms touch is ignored");
        keys[0] = 2; run(30); keys[0] = 0; run(60);
        CHECK(N[0].state != before, "press 20 ms: a 30 ms touch counts");
        N[0].c.tpress = 2;
        /* glitch shorter than 1 ms is ignored */
        before = N[0].state;
        for (int g = 0; g < 50; g++) { keys[0] = 1; step(); keys[0] = 0; run(50); }
        CHECK(N[0].state == before, "1-sample glitches ignored");
        /* stuck key: one toggle only, nothing else happens */
        before = N[0].state;
        keys[0] = 1; run(20000);
        CHECK(N[0].state == (before ^ 1), "stuck key: toggled once, not again");
        keys[0] = 0; run(100);
        tap(0, 0);
        CHECK(N[0].state == before, "after release the key works again");
        /* the clock wrapped during this section: timers still work */
        CHECK(T < 100000, "clock wrapped");
        Cfg d = mk(0, 4); d.type[1] = T_DELAY; d.sec1[1] = 0; d.sec2[1] = 2;
        d.type[2] = T_TIMER; d.offmask[2] = 0; d.onmask[2] = 0x01; d.minutes[2] = 1;
        seal(&d); T = 0xFFFFFFFFUL - 1000; sw_init(&N[0], &d, T); run(1600);
        tap(0, 1); run(1500); CHECK(st(0, 1), "pulse across the wrap: on");
        run(1000); CHECK(!st(0, 1), "pulse across the wrap: off after 2 s");
        T = 0xFFFFFFFFUL - 30000; sw_init(&N[0], &d, T); run(1600);
        tap(0, 2); run(58000); CHECK(st(0, 0), "service timer across the wrap: on at 58 s");
        run(4000); CHECK(!st(0, 0), "service timer across the wrap: off at 1 min");
    }
#endif
    printf("17) dimming and lighting up again: one white every 50 ms, pole 1 first\n");
    {
        Cfg a = mk(0, 4); a.dimsec = 3; seal(&a);
        T = 500000; qn = 0; keys[0] = keys[1] = 0; memset(ee, 0xFF, sizeof ee);
        N[0].tx = tx0; N[0].eer = er0; N[0].eew = ew0; N[1].tx = tx1; N[1].eer = er1; N[1].eew = ew1;
        Cfg b2 = mk(0, 4); seal(&b2); sw_init(&N[0], &a, T); sw_init(&N[1], &b2, T); run(1600);
        int seq[8], n = 0, last = N[0].white & 0x0F;
        for (int k = 0; k < 5000 && n < 8; k++) { run(1); int w = N[0].white & 0x0F; if (w != last) { seq[n++] = w; seq[n++] = k; last = w; } }
        CHECK(n == 6 && seq[0] == 0x0E && seq[2] == 0x0C && seq[4] == 0x08, "dim: pole 1, then 2, then 3 go dark (pole 4 stays)");
        CHECK(n == 6 && seq[3] - seq[1] >= 45 && seq[3] - seq[1] <= 55 && seq[5] - seq[3] >= 45 && seq[5] - seq[3] <= 55, "50 ms apart");
        keys[0] = 2; run(5); keys[0] = 0;
        n = 0; last = N[0].white & 0x0F;
        for (int k = 0; k < 400 && n < 8; k++) { run(1); int w = N[0].white & 0x0F; if (w != last) { seq[n++] = w; seq[n++] = k; last = w; } }
        CHECK(n == 4 && seq[0] == 0x09 && seq[2] == 0x0D && seq[3] - seq[1] >= 95 && seq[3] - seq[1] <= 105, "touch: pole 1 lights first, then pole 3 (pole 2 is red: touched)");
        run(200); CHECK((N[0].white & 0x0D) == 0x0D, "all whites back (pole 2 red: it was touched)");
    }
    printf("\n%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
