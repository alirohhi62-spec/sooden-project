/* Sooden 23-key board: link between the ATmega32 (touch, 433 MHz, buzzer) and the ATmega64 (relays, LEDs, logic)
 *
 * Two clocked one-way lines, so no baud rate has to match:
 *   32 -> 64 : clock ATmega32 PD1 -> ATmega64 PE5 (INT5),  data ATmega32 PD4 -> ATmega64 PE2
 *   64 -> 32 : clock ATmega64 PE3 -> ATmega32 PD2 (INT0),  data ATmega64 PE4 -> ATmega32 PD0
 * The sender puts a bit on the data line, then raises the clock; the receiver reads the data line
 * on the rising clock edge (it has LK_HOLD_US to do so). Bytes MSB first. The clock rests low; a pause of more than LK_GAP_US
 * starts a new frame. Every frame is 8 bytes with a CRC-8; anything else is dropped.
 *
 * frame: LK_SOF, type, seq, d0, d1, d2, d3, crc8(type..d3)
 */
#ifndef LINK_H
#define LINK_H
#include <stdint.h>

#define LK_SOF     0xA5
#define LK_LEN     8
#define LK_SETUP_US 2          /* data on the line this long before the clock edge */
#define LK_HOLD_US  16         /* and kept this long after it (the receiver may be busy) */
#define LK_GAP_US  200         /* a pause longer than this starts a new frame */

/* 32 -> 64 */
#define LK_KDOWN   0x01        /* d0 = key 0..22 (a touch, already filtered) */
#define LK_KUP     0x02        /* d0 = key 0..22 (finger lifted) */
#define LK_RF      0x03        /* d0..d2 = 24-bit remote code (seen twice in a row) */
#define LK_HELLO   0x04        /* every 300 ms: d0 = firmware version, d1 bit0 = fresh start */

/* 64 -> 32 */
#define LK_ACK     0x81        /* seq = the acknowledged key frame */
#define LK_SET     0x82        /* every 500 ms: d0 = press ms, d1 = gap / 2 ms, d2 = flags */
#define LK_F_WIFI  0x01        /* flags: Wi-Fi module powered (ATmega32 PD5 high -> MP2315 EN) */
#define LK_BUZ     0x83        /* d0 = 1 on / 0 off, d1 = safety off after d1 x 10 ms */

#define IO32_VERSION 1

static inline uint8_t lk_crc(const uint8_t *p, uint8_t n)
{
    uint8_t c = 0;
    while (n--) {
        c ^= *p++;
        for (uint8_t i = 0; i < 8; i++) c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1);
    }
    return c;
}

#endif
