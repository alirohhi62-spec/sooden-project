/* Sooden 23-key board - ATmega64 @ 8 MHz crystal (fuses Low 3F, High C1, Extended FF:
 * BOD 4 V, JTAG off, EESAVE, no ATmega103 mode)
 * Relays (on the red LED pins), white LEDs, all panel logic (same core as the 4 pole panels, 23 keys),
 * remotes in EEPROM. Touches and remote codes come from the ATmega32 over the clocked link (link.h);
 * this chip sends back the touch timing and the buzzer.
 * link in: clock PE5 (INT5), data PE2      link out: clock PE3, data PE4
 * PE0/PE1 = Wi-Fi module (USART0, wifi64.c), PB1 = ISP clock (shared): inputs
 * two-panel network (HAS_PAIR builds): RS485 module (auto-direction) on USART1, PD2 = RXD1, PD3 = TXD1, 9600 8N1
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <string.h>
#include "sw.h"
#include "link.h"
#include "wifi64.h"

const uint8_t cfg_flash[CFG_SIZE] __attribute__((section(".swcfg"), used)) = { [0 ... CFG_SIZE - 1] = 0xFF };

#if HAS_PAIR
/* two-panel network: keys of the other panel in each key's scenario (and, for the phone app, the other panel itself) */
const uint8_t px_flash[PX_SIZE] __attribute__((section(".swpx"), used)) = { [0 ... PX_SIZE - 1] = 0xFF };
static uint8_t px_mask(uint8_t k, uint8_t which, uint8_t *m)
{
    if (k >= SW_NP) return 0;
    const uint8_t *p = &px_flash[3 + (which ? 3 * SW_NP : 0) + 3 * k];
    m[2] = pgm_read_byte(p); m[1] = pgm_read_byte(p + 1); m[0] = pgm_read_byte(p + 2);   /* stored high byte first */
    m[2] &= 0x7F;
    return (uint8_t)(m[0] | m[1] | m[2]);
}
static uint8_t px_valid(void)
{
    uint8_t c = 0;
    for (uint16_t i = 0; i < PX_SIZE - 1; i++) {      /* CRC-8 straight from flash (no 256-byte buffer) */
        c ^= pgm_read_byte(&px_flash[i]);
        for (uint8_t j = 0; j < 8; j++) c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1);
    }
    return pgm_read_byte(&px_flash[0]) == PX_M0 && pgm_read_byte(&px_flash[1]) == PX_M1 &&
           pgm_read_byte(&px_flash[2]) == SW_NP && c == pgm_read_byte(&px_flash[PX_SIZE - 1]);
}
/* USART1: frames in through a ring (ISR), out through a ring (UDRE interrupt): the main loop never waits */
static volatile uint8_t n1rx[32], n1rh, n1rt, n1tx[32], n1th, n1tt;
ISR(USART1_RX_vect)
{
    uint8_t b = UDR1, n = (uint8_t)((n1rh + 1) & 31);  /* framing errors kept: every frame has its CRC */
    if (n != n1rt) { n1rx[n1rh] = b; n1rh = n; }
}
ISR(USART1_UDRE_vect)
{
    if (n1tt != n1th) { UDR1 = n1tx[n1tt]; n1tt = (uint8_t)((n1tt + 1) & 31); }
    else UCSR1B &= (uint8_t)~_BV(UDRIE1);
}
static void n1_put(uint8_t b)
{
    uint8_t n = (uint8_t)((n1th + 1) & 31);
    while (n == n1tt) wdt_reset();
    n1tx[n1th] = b; n1th = n;
    UCSR1B |= _BV(UDRIE1);
}
static void net_tx(const uint8_t *p, uint8_t n)
{
    n1_put(0xFF);                                      /* lead-in byte, as the ATmega8 panels */
    while (n--) n1_put(*p++);
}
#endif

/* white / red (= relay) pin of every key: port (0=A .. 6=G) << 4 | bit, 0xFF = none */
#define P(port, bit) (uint8_t)(((port) << 4) | (bit))
enum { A, B, C, D, E, F, G };
static const uint8_t PINS[SW_NP][2] PROGMEM = {
    { P(F,4), P(F,5) }, { P(E,7), P(B,0) }, { P(A,5), P(A,4) }, { P(B,2), P(B,3) },   /* places 1..4 */
    { P(A,3), P(A,2) }, { P(G,4), P(G,3) }, { P(A,1), P(A,0) }, { P(B,6), P(B,7) },   /* 5..8 */
    { P(F,7), P(F,6) }, { P(B,5), P(B,4) }, { P(A,7), P(G,2) }, { P(G,1), P(C,0) },   /* 9..12 */
    { P(F,3), P(F,2) }, { P(E,6), P(D,0) }, { P(F,1), P(F,0) }, { P(D,1), P(D,4) },   /* 13..16 */
    { P(C,3), P(C,4) }, { P(D,5), P(D,6) }, { P(C,5), P(A,6) }, { P(D,7), P(G,0) },   /* 17..20 */
    { P(C,7), P(C,6) }, { 0xFF, 0xFF }, { P(C,1), P(C,2) },                           /* scenario 1, 2 (no LED), 3 */
};
static volatile uint8_t *const PORTS[7] = { &PORTA, &PORTB, &PORTC, &PORTD, &PORTE, &PORTF, &PORTG };
static volatile uint8_t *const DDRS[7]  = { &DDRA, &DDRB, &DDRC, &DDRD, &DDRE, &DDRF, &DDRG };
static uint8_t outMask[7], restVal[7];

static Sw S;
static volatile uint32_t ms;
ISR(TIMER0_COMP_vect) { ms++; }
static uint32_t now_ms(void) { uint32_t v; cli(); v = ms; sei(); return v; }

static uint8_t ee_r(uint16_t a) { return eeprom_read_byte((const uint8_t *)a); }
static void ee_w(uint16_t a, uint8_t v) { eeprom_update_byte((uint8_t *)a, v); }

/* ---------------- link in (from the ATmega32) ---------------- */
static uint16_t lkLast;
static uint8_t lkBits, lkN, lkByte, lkBuf[LK_LEN];
#define RQ 8
static volatile uint8_t rq[RQ][LK_LEN], rqh, rqt;
ISR(INT5_vect)
{
    uint16_t t = TCNT1;
    if ((uint16_t)(t - lkLast) > LK_GAP_US) { lkBits = 0; lkN = 0; }
    lkLast = t;
    lkByte = (uint8_t)((lkByte << 1) | ((PINE & _BV(2)) ? 1 : 0));
    if (++lkBits < 8) return;
    lkBits = 0;
    if (lkN == 0 && lkByte != LK_SOF) return;
    lkBuf[lkN++] = lkByte;
    if (lkN < LK_LEN) return;
    lkN = 0;
    if (lk_crc(lkBuf + 1, LK_LEN - 2) != lkBuf[LK_LEN - 1]) return;
    uint8_t n = (uint8_t)((rqt + 1) % RQ);
    if (n == rqh) return;                               /* full (cannot happen in practice) */
    for (uint8_t i = 0; i < LK_LEN; i++) rq[rqt][i] = lkBuf[i];
    rqt = n;
}

/* ---------------- link out (to the ATmega32) ---------------- */
static void lk_send(uint8_t type, uint8_t seq, uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3)
{
    uint8_t f[LK_LEN] = { LK_SOF, type, seq, d0, d1, d2, d3, 0 };
    f[LK_LEN - 1] = lk_crc(f + 1, LK_LEN - 2);
    PORTE &= (uint8_t)~_BV(3);
    _delay_us(LK_GAP_US + 50);
    for (uint8_t i = 0; i < LK_LEN; i++) {
        for (uint8_t b = 0x80; b; b >>= 1) {
            if (f[i] & b) PORTE |= _BV(4); else PORTE &= (uint8_t)~_BV(4);
            _delay_us(LK_SETUP_US);
            PORTE |= _BV(3);
            _delay_us(LK_HOLD_US);
            PORTE &= (uint8_t)~_BV(3);
        }
    }
    wdt_reset();
}

static void write_outputs(pm_t w, pm_t r)
{
    uint8_t v[7];
    for (uint8_t p = 0; p < 7; p++) v[p] = restVal[p];
    for (uint8_t k = 0; k < SW_NP; k++) {
        uint8_t pw = pgm_read_byte(&PINS[k][0]), pr = pgm_read_byte(&PINS[k][1]);
        if (pw != 0xFF && (w & BIT(k))) v[pw >> 4] |= (uint8_t)_BV(pw & 7);
        if (pr != 0xFF && (r & BIT(k))) v[pr >> 4] |= (uint8_t)_BV(pr & 7);
    }
    for (uint8_t p = 0; p < 7; p++) {
        uint8_t keep = (uint8_t)~outMask[p], val = v[p] & outMask[p];
        if (p == E) {                                   /* PORTE also carries the link-out pins */
            cli(); PORTE = (uint8_t)((PORTE & keep) | val); sei();
        } else *PORTS[p] = (uint8_t)((*PORTS[p] & keep) | val);
    }
}

/* pins and S from the settings (copied from flash straight into S.c) */
static void __attribute__((noinline)) setup(void)
{
    uint8_t *buf = (uint8_t *)&S.c;                    /* straight into the logic's own copy */
    for (uint16_t i = 0; i < CFG_SIZE; i++) buf[i] = pgm_read_byte(&cfg_flash[i]);
    const Cfg *cfg = &S.c;
    if (!sw_cfg_ok(cfg)) for (;;) ;                     /* not configured: every pin stays an input */

    /* outputs: every LED / relay pin; the rest are inputs with pull-up, except the shared ISP clock.
       A key without a relay (empty, keypad, function key) leaves its red pin an input: on the alarm
       boards that pin may be jumpered to the PIR sensor (key 17) or the siren (key 16): no pull-up either,
       so nothing is pushed into the siren driver or against the sensor output. */
    uint8_t hiZ[7] = { 0 };
    pm_t elev = 0;                                      /* the elevator relay sits on another key's red pin */
#if HAS_SCN
    for (uint8_t k = 0; k < SW_NP; k++) if (cfg->type[k] == T_ELEV) elev |= cfg->onmask[k];
#endif
#if HAS_ILOCK
    for (uint8_t k = 0; k < SW_NP; k++) if (cfg->type[k] == T_ILOCK && cfg->sec1[k]) elev |= cfg->onmask[k];   /* a curtain's relay on another key's red pin */
#endif
    for (uint8_t k = 0; k < SW_NP; k++)
        for (uint8_t j = 0; j < 2; j++) {
            uint8_t p = pgm_read_byte(&PINS[k][j]);
            if (p == 0xFF) continue;
            if (j && (cfg->type[k] == T_OFF || cfg->type[k] == T_KEY) && !(elev & BIT(k))) hiZ[p >> 4] |= (uint8_t)_BV(p & 7);
            else outMask[p >> 4] |= (uint8_t)_BV(p & 7);
        }

    outMask[E] |= _BV(3) | _BV(4);                      /* link out: written by lk_send */
    hiZ[E] |= _BV(0) | _BV(1);                          /* Wi-Fi UART: no pull-up into an unpowered module */
    for (uint8_t p = 0; p < 7; p++) {
        uint8_t pull = (uint8_t)(~outMask[p] & ~hiZ[p]);
        if (p == B) pull &= (uint8_t)~_BV(1);           /* ISP clock: plain input */
        restVal[p] = pull;
        *PORTS[p] = pull;
        *DDRS[p] = outMask[p];
    }
#if HAS_ALARM
    /* alarm panels: sensor on the red pin of place 17 (PC4, normally closed to GND: high = alarm): input with pull-up;
       siren on the red pin of place 16 (PD4): output, starts off (PORTD4 is 0 here) */
    if (cfg->alarm) { PORTC |= _BV(4); PORTD &= (uint8_t)~_BV(4); DDRD |= _BV(4); }
#endif
    outMask[E] &= (uint8_t)~(_BV(3) | _BV(4));          /* write_outputs leaves the link pins alone */

    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS02);           /* 1 ms (8 MHz / 64 / 125) */
    TIMSK |= _BV(OCIE0);
    TCCR1A = 0; TCCR1B = _BV(CS11);                       /* 1 us ticks for the link */
    EICRB = _BV(ISC51) | _BV(ISC50);                      /* INT5 rising edge */
    EIFR = _BV(INTF5);
    EIMSK |= _BV(INT5);

    S.eer = ee_r; S.eew = ee_w;
    sw_init(&S, cfg, 0);
#if HAS_PAIR
    if (px_valid()) S.pxm = px_mask;
    UBRR1H = 0; UBRR1L = 51;                            /* 9600 at 8 MHz */
    UCSR1A = 0;
    UCSR1C = _BV(UCSZ11) | _BV(UCSZ10);
    UCSR1B = _BV(RXCIE1) | _BV(RXEN1) | _BV(TXEN1);
    S.tx = net_tx;
#endif
}

int main(void)
{
    uint8_t why = MCUCSR;
    MCUCSR |= _BV(JTD); MCUCSR |= _BV(JTD);           /* JTAG off (it would take PF4..PF7) */
    MCUCSR = 0;
    setup();
    S.logOn = (why & (_BV(PORF) | _BV(BORF))) != 0;     /* record remote codes only after a power-up */
    write_outputs(0, 0);
    wdt_enable(WDTO_1S);
    sei();

    pm_t keys = 0;
    uint8_t lastSeq = 0, buzSent = 0, wifiSent = 0xFF;
    uint16_t helloAge = 0, setMs = 0, buzMs = 0;
    uint32_t last = now_ms();
    for (;;) {
        wdt_reset();
        uint32_t now = now_ms();
        uint16_t dt = (uint16_t)(now - last);
        if (dt > 1000) dt = 1000;
        last = now;
        helloAge = helloAge + dt < 60000U ? (uint16_t)(helloAge + dt) : 60000U;
        setMs += dt; buzMs += dt;

        uint8_t ack = 0, ackSeq = 0;
        while (rqh != rqt) {
            uint8_t f[LK_LEN];
            for (uint8_t i = 0; i < LK_LEN; i++) f[i] = rq[rqh][i];
            rqh = (uint8_t)((rqh + 1) % RQ);
            uint8_t type = f[1], seq = f[2], key = f[3];
            if (type == LK_KDOWN || type == LK_KUP) {
                ack = 1; ackSeq = seq;
                if (seq == lastSeq || key >= SW_NP) continue;   /* a repeat (our ACK was lost) */
                lastSeq = seq;
                if (type == LK_KDOWN) keys |= BIT(key); else keys &= (pm_t)~BIT(key);
            } else if (type == LK_RF) {
                S.rfCode = ((uint32_t)f[3] << 16) | ((uint16_t)f[4] << 8) | f[5];
                S.rfNew = 1;
            } else if (type == LK_HELLO) {
                helloAge = 0;
                if (f[4] & 1) { setMs = 60000U; lastSeq = 0; }   /* the ATmega32 (re)started: settings now */
            }
        }
        if (helloAge > 1000) keys = 0;                  /* ATmega32 silent: no key stays pressed */
#if HAS_PAIR
        while (n1rt != n1rh) { uint8_t b = n1rx[n1rt]; n1rt = (uint8_t)((n1rt + 1) & 31); sw_rx(&S, b, now); }
#endif

#if HAS_ALARM
        S.pir = S.c.alarm && (PINC & _BV(4)) && now >= 60000UL;   /* as the SIM panel: high = contact open (or wire cut) = someone; ignored the first minute (PIR sensors settle) */
#endif
        sw_tick(&S, now, keys);                         /* act first, answer after */
        write_outputs(S.white, S.red);
        wf_poll(&S, now);
#if HAS_PAIR
        sw_link(&S, now);
#endif
#if HAS_ALARM
        if (S.c.alarm) { if (S.sirenPin) PORTD |= _BV(4); else PORTD &= (uint8_t)~_BV(4); }
#endif
        if (ack) lk_send(LK_ACK, ackSeq, 0, 0, 0, 0);

        if (setMs >= 500 || S.wifi != wifiSent) {       /* settings; Wi-Fi power at once when it changes */
            setMs = 0; wifiSent = S.wifi;
            lk_send(LK_SET, 0, S.c.tpress, S.c.tgap2, S.wifi ? LK_F_WIFI : 0, 0);
        }
        if (S.buzz != buzSent || (S.buzz && buzMs >= 200)) {
            buzSent = S.buzz; buzMs = 0;
            lk_send(LK_BUZ, 0, S.buzz, 30, 0, 0);       /* the ATmega32 stops by itself after 300 ms */
        }
    }
}
