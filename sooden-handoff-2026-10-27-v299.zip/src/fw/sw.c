/* Sooden two-way switch - hardware independent logic */
#include <string.h>
#include <stddef.h>
#include "sw.h"

#ifdef __AVR__
#include <avr/interrupt.h>
#define IRQ_OFF() uint8_t _sreg = SREG; cli()
#define IRQ_ON()  SREG = _sreg
#else
#define IRQ_OFF()
#define IRQ_ON()
#endif

#define AFTER(a, b) ((int32_t)((a) - (b)) >= 0)
#if HAS_SCN
#define NIGHT(s)   ((s)->nightMask)
#define ELEV_ON(s) ((s)->elevLeft)
#else
#define NIGHT(s)   0
#define ELEV_ON(s) 0
#endif
#if HAS_ALARM
#define AL_BUSY(s) ((s)->alSt >= AL_ENTRY || (s)->enPw || (s)->enOn)   /* armed (or arming): the panel may still go dark */
#else
#define AL_BUSY(s) 0
#endif
#define EER(s, a)    (s)->eer(a)
#define EEW(s, a, v) (s)->eew((a), (v))

#ifdef SW_BIG
#ifdef SW_P12
const pm_t bit32[32] PROGMEM = {   /* 12-pole SIM panel: in flash (RAM is short with Wi-Fi) */
#else
const pm_t bit32[32] = {
#endif           /* 1 << i without a slow 32-bit shift loop */
    1UL << 0, 1UL << 1, 1UL << 2, 1UL << 3, 1UL << 4, 1UL << 5, 1UL << 6, 1UL << 7,
    1UL << 8, 1UL << 9, 1UL << 10, 1UL << 11, 1UL << 12, 1UL << 13, 1UL << 14, 1UL << 15,
    1UL << 16, 1UL << 17, 1UL << 18, 1UL << 19, 1UL << 20, 1UL << 21, 1UL << 22, 1UL << 23,
    1UL << 24, 1UL << 25, 1UL << 26, 1UL << 27, 1UL << 28, 1UL << 29, 1UL << 30, 1UL << 31 };
#endif

uint8_t sw_crc8(const uint8_t *p, crc_n_t n)
{
    uint8_t c = 0;
    while (n--) {
        c ^= *p++;
        for (uint8_t i = 0; i < 8; i++)
            c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1);
    }
    return c;
}

uint8_t sw_cfg_ok(const Cfg *c)
{
    if (c->m0 != CFG_M0 || c->m1 != CFG_M1 || c->ver != CFG_VER) return 0;
    if (sw_crc8((const uint8_t *)c, CFG_SIZE - 1) != c->crc) return 0;
    if (c->role > 1) return 0;
#ifdef FW_BOARD
    if (c->board != FW_BOARD) return 0;               /* hex made for another board */
#endif
#if !HAS_REMOTE
    if (c->remote) return 0;
#endif
    if (c->nslot > N_SLOTS) return 0;     /* the button tables are checked by the programmer */
#ifdef SW_BIG
    uint8_t nphys = SW_NP;
#else
    uint8_t nphys = c->board == BOARD_4P ? 4 : 2;
#endif
    for (uint8_t i = 0; i < SW_NP; i++) {
        uint8_t t = c->type[i];
        if (t > T_TIMER
#if HAS_ALARM
            && t != T_KEY && t != T_ALON && t != T_ALPW
#endif
#if HAS_SCN
            && t != T_EXIT && t != T_SLEEP && t != T_ELEV
#ifdef SW_BIG
            && t != T_CUSTOM && t != T_GROUP
#endif
#endif
#if HAS_SEC
            && t != T_DELOFF && t != T_DELAY
#endif
#if HAS_ILOCK
            && t != T_OFFTMR && t != T_ILOCK
#endif
           ) return 0;                                 /* this pole kind is not in this hex */
        if (i >= nphys && c->type[i] != T_OFF) return 0;
#if HAS_PX && defined(SW_P12)
        /* 12-pole panel: poles, keys 13..15, the curtain keys and the elevator (the 20 keys with a network number) may follow the other panel */
        if (c->link[i] != NO_LINK && (c->link[i] >= 23 || (c->type[i] != T_NORMAL && c->type[i] != T_ILOCK && c->type[i] != T_ELEV) ||
            !(i < 15 || i == 22 || i >= 23))) return 0;
#elif HAS_PX
        if (c->link[i] != NO_LINK && (c->link[i] >= 23 || c->type[i] != T_NORMAL)) return 0;   /* any key of the other panel */
#elif HAS_PAIR
        if (c->link[i] != NO_LINK && (c->link[i] > 3 || c->type[i] != T_NORMAL)) return 0;
#else
        if (c->link[i] != NO_LINK) return 0;           /* no network in this firmware */
#endif
    }
    return 1;
}

#if HAS_REMOTE
/* ---------------- remotes in EEPROM: one id per place, 3 copies ---------------- */
static const uint16_t ee_base[3] = { EE_COPY0, EE_COPY1, EE_COPY2 };

/* a block in EEPROM kept in 3 copies: [magic, data..., crc]; save writes every copy (only changed bytes) */
static void blk_save(Sw *s, uint8_t *b, uint8_t len, const uint16_t *base)
{
    b[len - 1] = sw_crc8(b, len - 1);
    for (uint8_t c = 0; c < 3; c++)
        for (uint8_t i = 0; i < len; i++) EEW(s, base[c] + i, b[i]);
}
/* first good copy -> b; the damaged copies are repaired */
static uint8_t blk_load(Sw *s, uint8_t *b, uint8_t len, const uint16_t *base, uint8_t magic)
{
    for (uint8_t c = 0; c < 3; c++) {
        for (uint8_t i = 0; i < len; i++) b[i] = EER(s, base[c] + i);
        if (b[0] == magic && sw_crc8(b, len - 1) == b[len - 1]) { blk_save(s, b, len, base); return 1; }
    }
    return 0;
}

static void ee_save(Sw *s)
{
    uint8_t buf[EE_LEN];
    buf[0] = EE_MAGIC;
    for (uint8_t i = 0; i < MAX_REMOTES; i++) {
        uint32_t v = s->rid[i];
        buf[1 + i * 3] = (uint8_t)(v >> 16);
        buf[2 + i * 3] = (uint8_t)(v >> 8);
        buf[3 + i * 3] = (uint8_t)v;
    }
    blk_save(s, buf, EE_LEN, ee_base);
}

static void ee_load(Sw *s)
{
    uint8_t buf[EE_LEN];
    if (!blk_load(s, buf, EE_LEN, ee_base, EE_MAGIC)) return;
    for (uint8_t i = 0; i < MAX_REMOTES; i++)
        s->rid[i] = ((uint32_t)buf[1 + i * 3] << 16) | ((uint32_t)buf[2 + i * 3] << 8) | buf[3 + i * 3];
}

/* place of a learned remote, only places defined for this panel count */
static uint8_t remote_find(Sw *s, uint32_t id)
{
    for (uint8_t i = 0; i < s->c.nslot; i++) if (s->rid[i] == id) return i;
    return 0xFF;
}

static uint8_t first_free(Sw *s)
{
    for (uint8_t i = 0; i < s->c.nslot; i++) if (s->rid[i] == NO_REMOTE) return i;
    return 0xFF;
}

/* put a remote into a place; the same remote is never kept in two places */
static void remote_store(Sw *s, uint8_t slot, uint32_t id)
{
    for (uint8_t i = 0; i < MAX_REMOTES; i++) if (s->rid[i] == id) s->rid[i] = NO_REMOTE;
    s->rid[slot] = id;
    ee_save(s);
}

/* timer length chosen per place/button: 2 bits each, 3 copies; defaults come from the programmer */
static const uint16_t ts_base[3] = { EE_TS0, EE_TS1, EE_TS2 };
static uint8_t tsel_get(Sw *s, uint8_t k, uint8_t c) { uint8_t n = (uint8_t)(k * 16 + c); return (s->tsel[n >> 2] >> ((n & 3) * 2)) & 3; }
static void tsel_save(Sw *s)
{
    uint8_t buf[EE_TSLEN];
    buf[0] = EE_TSMAGIC;
    memcpy(buf + 1, s->tsel, sizeof s->tsel);
    blk_save(s, buf, EE_TSLEN, ts_base);
}
static void tsel_load(Sw *s)
{
    uint8_t buf[EE_TSLEN];
    memcpy(s->tsel, blk_load(s, buf, EE_TSLEN, ts_base, EE_TSMAGIC) ? buf + 1 : s->c.tdef, sizeof s->tsel);
}

static void remote_clear(Sw *s)
{
    for (uint8_t i = 0; i < MAX_REMOTES; i++) s->rid[i] = NO_REMOTE;
    ee_save(s);
}

/* recording for the programmer: after power-up, 15 min, every new code in the order received */
static void log_code(Sw *s, uint32_t code, uint32_t now)
{
    if (!s->logOn || code == s->logged || AFTER(now, s->bootAt + T_LOGWIN)) return;
    s->logged = code;
    uint8_t b[4] = { 0, (uint8_t)(code >> 16), (uint8_t)(code >> 8), (uint8_t)code };
    /* recording, in the order pressed (the programmer drops repeats) */
    uint8_t next = 0, count = 0;
    if (EER(s, EE_REC) == EE_RECMAGIC) {
        next = EER(s, EE_REC + 1); count = EER(s, EE_REC + 2);
        if (next >= EE_RECN || count > EE_RECN) next = count = 0;
    }
    uint16_t a = EE_REC + 3 + next * 3;
    for (uint8_t i = 0; i < 3; i++) EEW(s, a + i, b[1 + i]);
    if (++next >= EE_RECN) next = 0;
    if (count < EE_RECN) count++;
    EEW(s, EE_REC + 1, next); EEW(s, EE_REC + 2, count); EEW(s, EE_REC, EE_RECMAGIC);
}

#endif /* HAS_REMOTE */

#if HAS_PAIR
/* ---------------- link ---------------- */
static uint16_t rnd(Sw *s)
{
    uint16_t x = s->rng;            /* 16-bit xorshift */
    x ^= x << 7; x ^= x >> 9; x ^= x << 8;
    return s->rng = x;
}

#if HAS_ROOM
static void send_a(Sw *s, uint8_t a, uint8_t type, uint8_t seq, uint8_t d)
{
    uint8_t f[6] = { F_SOF, a, type, seq, d, 0 };
    f[5] = sw_crc8(f + 1, 4);
    s->tx(f, 6);
    s->txMs = 0;
}
static void send(Sw *s, uint8_t type, uint8_t seq, uint8_t d, uint32_t now)
{
    send_a(s, s->c.role, type, seq, d);
    (void)now;
}
#else
static void send(Sw *s, uint8_t type, uint8_t seq, uint8_t d, uint32_t now)
{
    uint8_t f[6] = { F_SOF, s->c.role, type, seq, d, 0 };
    f[5] = sw_crc8(f + 1, 4);
    s->tx(f, 6);
    s->txMs = 0;
    (void)now;
}
#endif
static void req(Sw *s, uint8_t i, uint8_t v, uint8_t notify);
#if HAS_ROOM
/* this panel is a room: every pole (lights; no curtain, scenario or master) on / off, stepped like a scenario; always answered */
static void room_cmd(Sw *s, uint8_t seq, uint8_t d)
{
    if (seq != s->roomSeq) {                               /* a repeat (our answer was lost) acts only once */
        s->roomSeq = seq;
        for (uint8_t k = 0; k < s->nphys; k++) {
            uint8_t t = s->c.type[k];
            if (t == T_NORMAL
#if HAS_SEC
                || t == T_DELOFF
#endif
               ) req(s, k, (uint8_t)(d & 1), 1);
        }
    }
    send_a(s, ROOM_FROM(s->c.room), F_RACK, seq, d);
}
#ifdef SW_P12
void sw_room_send(Sw *s, uint8_t room, uint8_t seq, uint8_t on) { send_a(s, ROOM_TO(room), F_ROOM, seq, on); }
#endif
#endif

#if !HAS_PX
static uint8_t any_link(Sw *s)
{
    for (uint8_t i = 0; i < 4; i++) if (s->c.link[i] != NO_LINK) return 1;
    return 0;
}
#endif

static void queue_tx(Sw *s, uint8_t i, uint8_t v)
{
    s->txMask |= BIT(i);
    if (v) s->txVal |= BIT(i); else s->txVal &= (pm_t)~BIT(i);
}

#endif /* HAS_PAIR */

/* ---------------- poles ---------------- */
static uint8_t target(Sw *s, uint8_t i)
{
    if (s->pendMask & BIT(i)) return GETB(s->pendVal, i);
    return GETB(s->state, i);
}

static void activity(Sw *s, uint32_t now) { (void)now; s->idleSec = 0; s->idleMs = 0; s->dimmed = 0; }
void sw_wake(Sw *s) { activity(s, 0); }               /* a phone connected (Wi-Fi): out of the dark, nothing switched */

static void req(Sw *s, uint8_t i, uint8_t v, uint8_t notify)
{
    uint8_t t = s->c.type[i];
    if (i >= s->nphys || t == T_MASTER || t == T_OFF
#ifdef SW_BIG
        || t == T_KEY || t == T_ALON || t == T_ALPW || t == T_CUSTOM || t == T_GROUP
#endif
#if HAS_SCN
        || t == T_ELEV
#endif
       ) return;                                    /* poles with a relay (EXIT / SLEEP: on = running) */
    pm_t b = BIT(i);
    if (!(s->pendMask & b) && GETB(s->state, i) == v) return;
    s->pendMask |= b;
    if (v) s->pendVal |= b; else s->pendVal &= (pm_t)~b;
    if (notify) s->pendNotify |= b;
}


/* switch a pole off and forget what it was waiting for */
static void pole_off(Sw *s, uint8_t k)
{
    req(s, k, 0, 1);
#if HAS_PH
    s->ph[k] = 0;
#endif
}
static void offmask_off(Sw *s, pm_t m)
{
    for (uint8_t k = 0; k < s->nphys; k++) if (m & BIT(k)) pole_off(s, k);
}

#if HAS_PH
static __attribute__((unused)) void ph_go(Sw *s, uint8_t i, uint8_t ph, uint8_t t10) { s->ph[i] = ph; s->cnt[i] = t10; }
static void ph_go_s(Sw *s, uint8_t i, uint8_t ph, uint8_t sec) { s->ph[i] = ph; s->cnt[i] = (uint16_t)sec * 10; }
/* switch on now; with a time limit when the configuration gives one */
static void timed_on(Sw *s, uint8_t i, uint8_t sec)
{
    req(s, i, 1, 1);
    s->ph[i] = 0;
    if (sec) ph_go_s(s, i, 2, sec);
}
#if HAS_ILOCK
static void il_on(Sw *s, uint8_t i)
{
#ifdef SW_BIG
    if (!s->c.sec1[i])                                    /* cooler: its pump (a curtain's onmask = its extra relay, see the outputs) */
#endif
    for (uint8_t k = 0; k < s->nphys; k++) if (s->c.onmask[i] & BIT(k)) req(s, k, 1, 1);   /* pump */
    timed_on(s, i, s->c.sec1[i]);
}
/* is the other side (curtain open/close, cooler speed) running or about to start? */
static uint8_t il_busy(Sw *s, uint8_t i)
{
    pm_t m = s->c.offmask[i];
    for (uint8_t k = 0; k < s->nphys; k++) if ((m & BIT(k)) && (target(s, k) || s->ph[k] == 1)) return 1;
    return 0;
}
/* start: the other side off first, a pause, then this one */
static void il_start(Sw *s, uint8_t i)
{
    if (il_busy(s, i)) { offmask_off(s, s->c.offmask[i]); ph_go(s, i, 1, s->c.sec2[i]); }
    else il_on(s, i);
}
#endif
#endif

#if HAS_PX
/* ---------------- two-panel network v2: keys of the other panel in our scenarios ---------------- */
/* keys of the other panel as 3 bytes (bit p of byte p >> 3 = its key p): cheaper than 32-bit masks on the AVR */
static void bset(uint8_t *a, uint8_t p, uint8_t v) { uint8_t b = (uint8_t)(1 << (p & 7)); if (v) a[p >> 3] |= b; else a[p >> 3] &= (uint8_t)~b; }
static uint8_t bget(const uint8_t *a, uint8_t p) { return (uint8_t)((a[p >> 3] >> (p & 7)) & 1); }
static uint8_t px_m(Sw *s, uint8_t k, uint8_t which, uint8_t *m) { m[0] = m[1] = m[2] = 0; return s->pxm ? s->pxm(k, which, m) : 0; }
/* what the other panel's keys are (or are about to be: our commands not yet sent), byte j */
static uint8_t px_tb(Sw *s, uint8_t j) { return (uint8_t)((s->pst[j] & (uint8_t)~s->sMask[j]) | (s->sVal[j] & s->sMask[j])); }
/* switch the keys of the other panel in key k's list (sent one by one; the other panel steps them like its own) */
static void px_q(Sw *s, uint8_t k, uint8_t which, uint8_t v)
{
    uint8_t m[3];
    if (!px_m(s, k, which, m)) return;
    for (uint8_t j = 0; j < 3; j++) { s->sMask[j] |= m[j]; if (v) s->sVal[j] |= m[j]; else s->sVal[j] &= (uint8_t)~m[j]; }
}
/* 1: some (all = 0) / every (all = 1) key of key k's on-list on the other panel is on */
static uint8_t px_on(Sw *s, uint8_t k, uint8_t all)
{
    uint8_t m[3];
    px_m(s, k, PX_ON, m);
    for (uint8_t j = 0; j < 3; j++) {
        uint8_t t = px_tb(s, j) & m[j];
        if (all ? t != m[j] : t != 0) return !all;
    }
    return all;
}
static uint8_t px_has(Sw *s, uint8_t k) { uint8_t m[3]; return px_m(s, k, PX_ON, m); }
#define PXQ(s, k, w, v) px_q((s), (k), (w), (v))
/* the other panel asked for our key k to be v */
static void px_set_local(Sw *s, uint8_t k, uint8_t v)
{
    if (k >= s->nphys) return;
#if HAS_ILOCK
    if (s->c.type[k] == T_ILOCK) {                     /* curtain / cooler speed: starts the way a touch would */
        if (!v) pole_off(s, k);
        else if (!target(s, k) && s->ph[k] != 1) il_start(s, k);
        return;
    }
#endif
    if (v) req(s, k, 1, 1); else pole_off(s, k);
}
#else
#define PXQ(s, k, w, v) ((void)0)
#endif

#if HAS_SCN
static uint16_t scn_len(Sw *s, uint8_t i) { return (uint16_t)(s->c.sec1[i] | ((uint16_t)s->c.sec2[i] << 8)); }
/* EXIT / SLEEP time is up: everything in offmask off, then onmask (curtain close / night light) on */
static void scn_end(Sw *s, uint8_t i)
{
    /* onmask first: a curtain to close still sees its other side moving and pauses before it starts
       (the programmer never puts the same pole in both masks) */
    for (uint8_t k = 0; k < s->nphys; k++) {
        if (!(s->c.onmask[i] & BIT(k))) continue;
#if HAS_ILOCK
        if (s->c.type[k] == T_ILOCK) { il_start(s, k); continue; }
#endif
        req(s, k, 1, 1);
    }
    offmask_off(s, s->c.offmask[i]);
    PXQ(s, i, PX_ON, 1); PXQ(s, i, PX_OFF, 0);
    req(s, i, 0, 0);
    s->tmrSec[i] = 0;
}
#if defined(SW_P12) && HAS_PX
/* 12-pole panel: an elevator key linked to a key of the other panel shows the call there (on while the relay is on) */
static void elev_state(Sw *s, uint8_t v)
{
    for (uint8_t i = 0; i < s->nphys; i++)
        if (s->c.type[i] == T_ELEV && s->c.link[i] != NO_LINK && GETB(s->state, i) != v) {
            if (v) s->state |= BIT(i); else s->state &= (pm_t)~BIT(i);
            queue_tx(s, i, v);
        }
}
#else
#define elev_state(s, v) ((void)0)
#endif
static void elev_fire(Sw *s)
{
    s->elevLeft = T_ELEVON; s->beepLeft = T_ELEVBEEP;    /* the beep confirms the call (never while running: locked) */
    elev_state(s, 1);
}
/* a short scenario (or the elevator call) is running: touches and remotes wait */
#ifdef SW_P12
uint8_t sw_mlock;                                   /* 12-pole panel: the master steps run, everything waits (set by main_p12.c) */
#endif
static uint8_t locked(Sw *s)
{
#ifdef SW_P12
    if (sw_mlock) return 1;
#endif
    if (s->elevLeft) return 1;
    for (uint8_t i = 0; i < s->nphys; i++) {
        uint8_t t = s->c.type[i];
        if ((t == T_EXIT || t == T_SLEEP) && target(s, i) && scn_len(s, i) < T_SCN_LONG) return 1;
    }
    return 0;
}
#endif

#ifdef SW_BIG
/* ---------------- custom scenarios, groups, phone scenarios (23 keys) ---------------- */
#if HAS_ILOCK
#define IS_CURTAIN(s, k) ((s)->c.type[k] == T_ILOCK && (s)->c.sec1[k])
#else
#define IS_CURTAIN(s, k) 0
#endif
/* poles a scenario may switch: normal poles, delayed off, curtains and cooler speeds (places 1..20) */
#ifdef SW_P12
#define SCN_NK SW_NP
#define SCN_SKIP(s, k) 0              /* 12-pole panel: a moving curtain is stored too */
#else
#define SCN_NK 20
#define SCN_SKIP(s, k) IS_CURTAIN(s, k)
#endif
pm_t sw_scn_poles(Sw *s)
{
    pm_t m = 0;
    for (uint8_t k = 0; k < SCN_NK; k++) {
        uint8_t t = s->c.type[k];
        if (t == T_NORMAL
#if HAS_SEC
            || t == T_DELOFF
#endif
#if HAS_ILOCK
            || t == T_ILOCK
#endif
           ) m |= BIT(k);
    }
    return m;
}
/* on first (a curtain or cooler speed starts the way a touch would), then off; stepped like every group change */
static void scn_apply(Sw *s, pm_t on, pm_t off)
{
    for (uint8_t k = 0; k < s->nphys; k++) {
        if (!(on & BIT(k))) continue;
#if HAS_ILOCK
        if (s->c.type[k] == T_ILOCK) { if (!target(s, k) && s->ph[k] != 1) il_start(s, k); continue; }
#endif
        req(s, k, 1, 1);
    }
    offmask_off(s, off & (pm_t)~on);
}
/* settings changed: written to EEPROM bit by bit from the main loop (sw_ov_step) */
static uint8_t crc8_up(uint8_t c, uint8_t b)
{
    c ^= b;
    for (uint8_t i = 0; i < 8; i++) c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1);
    return c;
}
static uint8_t ov_byte(Sw *s, uint8_t j)
{
    const Cfg *c = &s->c;
    if (j == 0) return EE_OVMAGIC;
    if (j == 1) return c->crc;
    j = (uint8_t)(j - 2);
    if (j < SW_NP) return c->minutes[j];
    j = (uint8_t)(j - SW_NP);
    if (j < SW_NP) return c->sec1[j];
    j = (uint8_t)(j - SW_NP);
    if (j < SW_NP) return c->sec2[j];
    j = (uint8_t)(j - SW_NP);
    if (j < 4 * OV_NK) return (uint8_t)(c->onmask[OV_K0 + (j >> 2)] >> (8 * (j & 3)));
    j = (uint8_t)(j - 4 * OV_NK);
    if (j < 4 * OV_NK) return (uint8_t)(c->offmask[OV_K0 + (j >> 2)] >> (8 * (j & 3)));
    j = (uint8_t)(j - 4 * OV_NK);
    if (j == 0) return c->alArm;
    if (j == 1) return c->alEntry;
    if (j == 2) return c->alSiren;
    if (j == 3) return c->dimsec;
    return s->ovCrc;
}
static void ov_put(Sw *s, uint8_t j, uint8_t v)
{
    Cfg *c = &s->c;
    if (j < 2) return;
    j = (uint8_t)(j - 2);
    if (j < SW_NP) { c->minutes[j] = v; return; }
    j = (uint8_t)(j - SW_NP);
    if (j < SW_NP) { c->sec1[j] = v; return; }
    j = (uint8_t)(j - SW_NP);
    if (j < SW_NP) { c->sec2[j] = v; return; }
    j = (uint8_t)(j - SW_NP);
    uint8_t sh = (uint8_t)(8 * (j & 3));
    if (j < 4 * OV_NK) { pm_t *m = &c->onmask[OV_K0 + (j >> 2)]; *m = (*m & ~((pm_t)0xFF << sh)) | ((pm_t)v << sh); return; }
    j = (uint8_t)(j - 4 * OV_NK);
    if (j < 4 * OV_NK) { pm_t *m = &c->offmask[OV_K0 + (j >> 2)]; *m = (*m & ~((pm_t)0xFF << sh)) | ((pm_t)v << sh); return; }
    j = (uint8_t)(j - 4 * OV_NK);
    if (j == 0) c->alArm = v;
    else if (j == 1) c->alEntry = v;
    else if (j == 2) c->alSiren = v;
    else if (j == 3) c->dimsec = v;
}
static void ov_mark(Sw *s)
{
    uint8_t c = 0;
    for (uint8_t j = 0; j < OV_LEN - 1; j++) c = crc8_up(c, ov_byte(s, j));
    s->ovCrc = c; s->ovPos = 0; s->ovDirty = 1;
}
void sw_ov_step(Sw *s)
{
    while (s->ovDirty) {
        uint8_t j = s->ovPos, b = ov_byte(s, j);
        if (++s->ovPos >= OV_LEN) s->ovDirty = 0;
        if (EER(s, EE_OV + j) != b) { EEW(s, EE_OV + j, b); return; }   /* one write per call: the loop never waits */
    }
}
void sw_ov_clear(Sw *s) { s->ovDirty = 0; EEW(s, EE_OV, 0xFF); }
/* the last phone settings, when they belong to this programming */
static void ov_load(Sw *s)
{
    uint8_t c = 0;
    if (EER(s, EE_OV) != EE_OVMAGIC || EER(s, EE_OV + 1) != s->c.crc) return;
    for (uint8_t j = 0; j < OV_LEN - 1; j++) c = crc8_up(c, EER(s, EE_OV + j));
    if (c != EER(s, EE_OV + OV_LEN - 1)) return;
    for (uint8_t j = 2; j < OV_LEN - 1; j++) ov_put(s, j, EER(s, EE_OV + j));
}
/* held 4 s: what is on now becomes the scenario / the group (curtains are left out: they may be half way) */
static void scn_store(Sw *s, uint8_t i)
{
    pm_t m = sw_scn_poles(s), onNow = 0;
    for (uint8_t k = 0; k < SCN_NK; k++) {
        if (!(m & BIT(k)) || k == i || SCN_SKIP(s, k)) { m &= (pm_t)~BIT(k); continue; }
        if (s->c.type[i] == T_GROUP && s->c.type[k] != T_NORMAL
#if HAS_SEC
            && s->c.type[k] != T_DELOFF
#endif
           ) { m &= (pm_t)~BIT(k); continue; }
        if (target(s, k)) onNow |= BIT(k);
    }
    s->c.onmask[i] = onNow;
    s->c.offmask[i] = s->c.type[i] == T_CUSTOM ? (m & (pm_t)~onNow) : 0;
    ov_mark(s);
#ifdef SW_P12
    s->scnEv = 1; s->scnKey = i;
#endif
}
#define HOLD_SCN(s, i) ((s)->c.type[i] == T_CUSTOM || (s)->c.type[i] == T_GROUP)
#endif

/* returns 1 if it was a plain toggle of a normal pole */
static uint8_t press_pole(Sw *s, uint8_t i)
{
    if (i >= s->nphys) return 0;
    uint8_t t = s->c.type[i];
    if (t == T_NORMAL) {
        req(s, i, (uint8_t)!target(s, i), 1);
        s->pendFast |= s->pendMask & BIT(i);       /* a pole touched by itself does not wait for the group steps */
        return 1;
    }
#ifdef SW_BIG
    if (t == T_CUSTOM) {
#ifdef SW_P12
        s->scnEv = 2; s->scnKey = i;
#endif
        scn_apply(s, s->c.onmask[i], s->c.offmask[i]); PXQ(s, i, PX_ON, 1); PXQ(s, i, PX_OFF, 0); return 0;
    }
#endif
    if (t == T_MASTER
#ifdef SW_BIG
        || t == T_GROUP
#endif
       ) {
        pm_t m = s->c.onmask[i];
        uint8_t anyOn = 0;
        for (uint8_t k = 0; k < s->nphys; k++) if ((m & BIT(k)) && target(s, k)) anyOn = 1;
#if HAS_PX
        if (px_on(s, i, 0)) anyOn = 1;                    /* keys of the other panel count too */
#endif
#ifdef SW_BIG
        if (t == T_MASTER) {                              /* master: "all on" first (every 23-key / 12-pole / 12 economic panel) - only when every pole is on, all off */
            uint8_t allOn = 1;
            for (uint8_t k = 0; k < s->nphys; k++) if ((m & BIT(k)) && !target(s, k)) allOn = 0;
            anyOn = allOn;
        }
#endif
        for (uint8_t k = 0; k < s->nphys; k++) if (m & BIT(k)) req(s, k, (uint8_t)!anyOn, 1);
        PXQ(s, i, PX_ON, !anyOn);
    } else if (t == T_TIMER) {
        /* service scenario: switch off offmask, switch on onmask, the scenario pole itself
           (relay + red) stays on while the timer runs; touching it again restarts the timer */
        offmask_off(s, s->c.offmask[i]);
        for (uint8_t k = 0; k < s->nphys; k++) if (s->c.onmask[i] & BIT(k)) req(s, k, 1, 1);
        PXQ(s, i, PX_OFF, 0); PXQ(s, i, PX_ON, 1);
#if HAS_PX
        if (s->c.onmask[i] || px_has(s, i)) {
#else
        if (s->c.onmask[i]) {
#endif
            req(s, i, 1, 0);
            s->tmrSec[i] = (uint16_t)s->c.minutes[i] * 60;
        }
    }
#if HAS_SCN
    else if (t == T_EXIT || t == T_SLEEP) {
        if (target(s, i)) {                               /* running: a long one is cancelled by a touch */
            if (scn_len(s, i) >= T_SCN_LONG) { req(s, i, 0, 0); s->tmrSec[i] = 0; }
        } else {
            req(s, i, 1, 0);
            s->pendFast |= s->pendMask & BIT(i);          /* its light at once */
            s->tmrSec[i] = scn_len(s, i);
            if (!s->tmrSec[i]) scn_end(s, i);
        }
    } else if (t == T_ELEV) elev_fire(s);   /* (a touch waits for the 1 s hold first) */
#endif
#if HAS_PH
    else {
        uint8_t on = target(s, i), ph = s->ph[i];
#if HAS_ILOCK
        if (t == T_OFFTMR) {             /* off timer: start, or cancel when running */
            req(s, i, (uint8_t)!on, 0);
            s->tmrSec[i] = (uint16_t)s->c.minutes[i] * 60;
        } else if (t == T_ILOCK) {
            if (ph == 1) s->ph[i] = 0;                      /* waiting for the change-over: cancel */
            else if (on) pole_off(s, i);                    /* running: stop */
            else if (s->c.sec1[i] && il_busy(s, i)) offmask_off(s, s->c.offmask[i]);   /* curtain moving the other way: only stop */
            else il_start(s, i);                            /* cooler: other speed off, pause, this one */
        }
#endif
#if HAS_SEC
        if (t == T_DELOFF) {
            if (ph == 1) pole_off(s, i);                    /* touched while waiting: off now */
            else if (on) ph_go_s(s, i, 1, s->c.sec1[i]);    /* off after sec1 */
            else req(s, i, 1, 1);
        } else if (t == T_DELAY) {
            if (ph == 1) s->ph[i] = 0;                      /* touched while waiting: cancel */
            else if (on && !s->c.sec2[i]) pole_off(s, i);   /* stays-on kind: off */
            else if (on || !s->c.sec1[i]) timed_on(s, i, s->c.sec2[i]);   /* pulse (again) */
            else ph_go_s(s, i, 1, s->c.sec1[i]);            /* on after the delay */
        }
#endif
    }
#endif
    return 0;
}

static void apply_pending(Sw *s, uint32_t now)
{
    if (!s->pendMask) return;
    uint8_t ready = s->stagMs >= s->stag;
    for (uint8_t i = 0; i < SW_NP; i++) {
        pm_t b = BIT(i);
        if (!(s->pendMask & b) || (!ready && !(s->pendFast & b))) continue;
        uint8_t v = GETB(s->pendVal, i), notify = TRUTH(s->pendNotify & b), fast = TRUTH(s->pendFast & b);
        s->pendMask &= (pm_t)~b; s->pendNotify &= (pm_t)~b; s->pendFast &= (pm_t)~b;
        if (GETB(s->state, i) == v) continue;              /* no change: try next */
        if (v) s->state |= b; else s->state &= (pm_t)~b;
        activity(s, now);
#if HAS_PX
        (void)notify; queue_tx(s, i, v);                   /* v2: every change goes to the other panel */
#elif HAS_PAIR
        if (notify && s->c.link[i] != NO_LINK) queue_tx(s, i, v);
#else
        (void)notify;
#endif
        if (fast) continue;                                /* direct touch: no group step */
        s->stagMs = 0;
        return;                                            /* one change per stagger slot */
    }
}

#if HAS_PAIR && !HAS_PX
/* peer told us its pole p is v */
static void peer_set(Sw *s, uint8_t p, uint8_t v)
{
    for (uint8_t k = 0; k < s->nphys; k++) {
        if (s->c.link[k] != p) continue;
        if (s->txMask & BIT(k)) {
            if (s->c.role == 0) continue;                 /* A wins a simultaneous change */
            s->txMask &= (uint8_t)~BIT(k);                /* B accepts A's value */
        }
        if (target(s, k) != v) req(s, k, v, 0);
    }
}

void sw_rx(Sw *s, uint8_t b, uint32_t now)
{
    (void)now;
    if (s->rxn && s->rxMs > 10) s->rxn = 0;                /* gap > 10 ms: resync */
    s->rxMs = 0;
    if (s->rxn == 0 && b != F_SOF) return;
    s->rxb[s->rxn++] = b;
    if (s->rxn < 6) return;
    s->rxn = 0;
    uint8_t *f = s->rxb;
    if (sw_crc8(f + 1, 4) != f[5]) return;
#if HAS_ROOM
    if (f[2] == F_ROOM && s->c.room && s->c.room <= 9 && f[1] == ROOM_TO(s->c.room)) { room_cmd(s, f[3], f[4]); return; }
#endif
    if (f[1] > 1 || f[1] == s->c.role) return;             /* own echo or garbage */
    s->peerMs = 0;
    s->online = 1;
    if (s->nextWait < T_TURN) s->nextWait = T_TURN;
    uint8_t seq = f[3], d = f[4];
    switch (f[2]) {
    case F_STATE:
        s->ackSeq = seq; s->ackDue = 1; s->ackWait = T_TURN;
        peer_set(s, d & 3, (d >> 4) & 1);
        break;
    case F_ACK:
        if (s->outActive && seq == s->outSeq) {
            s->outActive = 0; s->outTries = 0;
            if (((s->txVal >> s->outPole) & 1) == s->outVal) s->txMask &= (uint8_t)~BIT(s->outPole);
            s->nextWait = 5;
        }
        break;
    case F_HELLO:
        s->needFull = 1;
        if (s->nextWait < T_TURN) s->nextWait = T_TURN;
        break;
    case F_FULL:
        s->synced = 1;
        for (uint8_t k = 0; k < s->nphys; k++) {
            uint8_t p = s->c.link[k];
            if (p == NO_LINK || (s->txMask & BIT(k))) continue;
            uint8_t v = (d >> p) & 1;
            if (target(s, k) != v) req(s, k, v, 0);
        }
        break;
    default: break;
    }
}

void sw_link(Sw *s, uint32_t now)
{
    if (!any_link(s)) return;
    {   /* advance the link counters */
        uint32_t d = now - s->linkNow;
        uint16_t dt = d > 60000UL ? 60000 : (uint16_t)d;
        s->linkNow = now;
        s->nextWait = s->nextWait > dt ? s->nextWait - dt : 0;
        s->ackWait = s->ackWait > dt ? (uint8_t)(s->ackWait - dt) : 0;
        s->outMs = s->outMs + dt < 60000U ? s->outMs + dt : 60000U;
        s->txMs = s->txMs + dt < 60000U ? s->txMs + dt : 60000U;
        s->peerMs = s->peerMs + dt < 60000U ? s->peerMs + dt : 60000U;
        s->rxMs = s->rxMs + dt < 250 ? (uint8_t)(s->rxMs + dt) : 250;
    }
    if (!s->helloDone && !s->nextWait) {        /* boot: ask the peer for its state */
        s->helloDone = 1;
        send(s, F_HELLO, 0, 0, now);
        s->nextWait = 20;
        return;
    }
    if (s->online && s->peerMs >= T_OFFLINE) s->online = 0;
    if (s->ackDue && !s->ackWait) {
        s->ackDue = 0;
        send(s, F_ACK, s->ackSeq, 0, now);
        if (s->nextWait < T_TURN) s->nextWait = T_TURN;
        return;
    }

    if (s->outActive) {
        if (s->outMs < T_ACK) return;
        s->outActive = 0;
        if (++s->outTries >= N_RETRY) {                    /* peer not answering */
            s->online = 0; s->outTries = 0;
            s->nextWait = 500;
        } else {
            s->nextWait = 15 + (rnd(s) & 63) + (s->c.role ? 25 : 0);
        }
        return;
    }
    if (s->nextWait) return;

    if (s->needFull) {
        s->needFull = 0;
        uint8_t m = 0;
        for (uint8_t i = 0; i < s->nphys; i++) if (target(s, i)) m |= BIT(i);
        send(s, F_FULL, 0, m, now);
        s->nextWait = 10;
        return;
    }
    if (s->txMask && s->online) {
        uint8_t i = 0;
        while (!(s->txMask & BIT(i))) i++;
        uint8_t v = (s->txVal >> i) & 1;
        if (i != s->outPole || v != s->outVal) s->outTries = 0;
        s->outPole = i; s->outVal = v; s->outSeq = ++s->seq;
        send(s, F_STATE, s->outSeq, (uint8_t)(i | (v << 4)), now);
        s->outActive = 1; s->outMs = 0;
        return;
    }
    if (s->txMs >= T_PING + s->jit) {
        s->jit = rnd(s) & 255;                             /* never fall into lock-step with the peer */
        /* A is the reference: once it has the peer's state it repeats its own
           linked states every second so both sides always converge.
           Until then A keeps asking (HELLO). B only pings. */
        if (s->c.role == 0) {
            if (s->synced) {
                uint8_t m = 0;
                for (uint8_t i = 0; i < s->nphys; i++) if (target(s, i)) m |= BIT(i);
                send(s, F_FULL, 0, m, now);
            } else send(s, F_HELLO, 0, 0, now);
        } else send(s, F_PING, 0, 0, now);
        s->nextWait = 10;
    }
}

#endif /* HAS_PAIR */

#if HAS_PX
/* ---------------- two-panel network v2 ----------------
 * Every change of every key of ours goes to the other panel (F_ST, acked), so it always knows our keys
 * (linked keys follow, its master / service scenarios see them, the phone app shows them). Our scenarios switch
 * its keys with F_SET (acked). A (role 0) is the reference: every second it sends one chunk of its keys with
 * FULL_APPLY (the linked keys of B follow); B sends its chunks too, only to be known. After a start, HELLO
 * asks the other side for all its chunks (with FULL_APPLY: a panel that lost power takes the linked keys back). */
#ifdef SW_P12
/* 12-pole panel on the line: its keys get network numbers 0..19 (poles 1..12, keys 13..15, curtain 1 open / close,
   curtain 2 open / close, elevator), so every other panel (keys 0..22) can link to any of them; S1..S6 and the master stay local */
#include <avr/pgmspace.h>
static const uint8_t NETKEY[20] PROGMEM = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 23, 24, 25, 26, 22 };
#define NET_N 20
static uint8_t key_of(uint8_t n) { return n < NET_N ? pgm_read_byte(&NETKEY[n]) : 0xFF; }
static uint8_t net_of(uint8_t k) { for (uint8_t n = 0; n < NET_N; n++) if (pgm_read_byte(&NETKEY[n]) == k) return n; return 0xFF; }
#define PX_CHUNKS(s) ((uint8_t)((NET_N + 7) >> 3))
#else
#define key_of(n) (n)
#define net_of(k) (k)
#define PX_CHUNKS(s) ((uint8_t)(((s)->nphys + 7) >> 3))
#endif
static uint8_t px_chunk(Sw *s, uint8_t c)
{
    uint8_t m = 0;
    for (uint8_t j = 0; j < 8; j++) { uint8_t k = key_of((uint8_t)(c * 8 + j)); if (k < s->nphys && target(s, k)) m |= (uint8_t)(1 << j); }
    return m;
}
/* the other panel's key p is v: remember it, our keys linked to it follow.
   follow 1 (it says its key changed): A keeps its own change still on the way (A wins), B gives in;
   follow 2 (a chunk of A's keys): a change of ours still on the way is not undone */
static void px_peer(Sw *s, uint8_t p, uint8_t v, uint8_t follow)
{
#if defined(SW_P12) && HAS_SCN
    uint8_t old = bget(s->pst, p);
#endif
    bset(s->pst, p, v);
    if (!follow) return;
    for (uint8_t k = 0; k < s->nphys; k++) {
        if (s->c.link[k] != p) continue;
#if defined(SW_P12) && HAS_SCN
        if (s->c.type[k] == T_ELEV) { if (!old && v && follow == 1 && !locked(s)) elev_fire(s); continue; }   /* its linked key went on: call the elevator (the key shows the relay, so it goes off again by itself) */
#endif
        if ((s->txMask & BIT(k)) && (s->c.role == 0 || follow == 2)) continue;
        if (target(s, k) != v) req(s, k, v, 0);
    }
}
void sw_rx(Sw *s, uint8_t b, uint32_t now)
{
    (void)now;
    if (s->rxn && s->rxMs > 10) s->rxn = 0;                /* gap > 10 ms: resync */
    s->rxMs = 0;
    if (s->rxn == 0 && b != F_SOF) return;
    s->rxb[s->rxn++] = b;
    if (s->rxn < 6) return;
    s->rxn = 0;
    uint8_t *f = s->rxb;
    if (sw_crc8(f + 1, 4) != f[5]) return;
#if HAS_ROOM
    if (f[2] == F_ROOM && s->c.room && s->c.room <= 9 && f[1] == ROOM_TO(s->c.room)) { room_cmd(s, f[3], f[4]); return; }
#ifdef SW_P12
    if (f[2] == F_RACK && (f[1] & 0xF0) == 0x20) { s->rackFrom = f[1]; s->rackSeq = f[3]; return; }
#endif
#endif
    if (f[1] > 1 || f[1] == s->c.role) return;             /* own echo or garbage */
    s->peerMs = 0;
    s->online = 1;
    if (s->nextWait < T_TURN) s->nextWait = T_TURN;
    uint8_t seq = f[3], d = f[4], k = (uint8_t)(d & 0x7F), v = (uint8_t)(d >> 7);
    switch (f[2]) {
    case F_ST: case F_SET: case F_PRESS:
        s->ackSeq = seq; s->ackDue = 1; s->ackWait = T_TURN;
        if (f[2] == F_ST) { if (k < 23) px_peer(s, k, v, 1); }       /* (a repeat does no harm) */
        else if (f[2] == F_SET) px_set_local(s, key_of(k), v);
        else if (seq != s->pressSeq) {                     /* a touch only once (a repeat: our ACK was lost) */
            s->pressSeq = seq;
#ifdef SW_BIG
            { uint8_t kk = key_of(k); if (kk < SW_NP) sw_app_press(s, kk, s->lastNow); }
#else
            if (k < s->nphys) {                            /* like a remote: no beep */
                activity(s, s->lastNow);
#if HAS_SCN
                if (!locked(s))
#endif
                    press_pole(s, k);
            }
#endif
        }
        break;
    case F_ACK:
        if (s->outActive && seq == s->outSeq) {
            s->outActive = 0; s->outTries = 0;
            uint8_t p = s->outPole;
            if (s->outKind == 0) { if (GETB(s->state, p) == s->outVal) s->txMask &= (pm_t)~BIT(p); }
#ifdef SW_BIG
            else if (s->outKind == 2) { if (s->pressK == p) s->pressK = 0xFF; }   /* the other panel has it */
#endif
            else {
                if (bget(s->sVal, p) == s->outVal) bset(s->sMask, p, 0);
                bset(s->pst, p, s->outVal);                /* until it reports the key itself */
            }
            s->nextWait = 5;
        }
        break;
    case F_HELLO:                                          /* the other panel (re)started */
        s->fullN = PX_CHUNKS(s);
        s->pressSeq = 0xFFFF;
        if (s->nextWait < T_TURN) s->nextWait = T_TURN;
        break;
    case F_FULL: {
        uint8_t c = (uint8_t)(seq & 0x7F), apply = (seq & FULL_APPLY) != 0;
        if (c > 2) break;
        if (apply) s->synced = 1;
        for (uint8_t j = 0; j < 8; j++) {
            uint8_t p = (uint8_t)(c * 8 + j);
            if (p >= 23) break;
            uint8_t pv = (d >> j) & 1;
            if (bget(s->sMask, p)) { bset(s->pst, p, pv); continue; }
            px_peer(s, p, pv, apply ? 2 : 0);
        }
        break;
    }
    default: break;
    }
}

#ifdef SW_BIG
/* phone app: touch key k of the other panel (0 = it cannot be reached now) */
uint8_t sw_px_press(Sw *s, uint8_t k)
{
    if (!s->online || k >= SW_NP) return 0;
    s->pressK = k;
    return 1;
}
#endif
#if HAS_ROOM
static uint8_t px_any(Sw *s)       /* any key of ours follows the other panel, or reaches it from a scenario */
{
    if (s->pxm) return 1;
    for (uint8_t k = 0; k < s->nphys; k++) if (s->c.link[k] != NO_LINK) return 1;
    return 0;
}
#endif
void sw_link(Sw *s, uint32_t now)
{
#if HAS_ROOM
    if (s->c.room && s->c.room <= 9 && !px_any(s)) return;   /* only a room on the line, no other panel: never talks first (a room answers in sw_rx) */
#ifdef SW_P12
    if (!px_any(s)) return;   /* 12-pole panel with no key linked: only the 7-segment rooms on the line, no two-panel talk */
#endif
#endif
    {   /* advance the link counters */
        uint32_t d = now - s->linkNow;
        uint16_t dt = d > 60000UL ? 60000 : (uint16_t)d;
        s->linkNow = now;
        s->nextWait = s->nextWait > dt ? s->nextWait - dt : 0;
        s->ackWait = s->ackWait > dt ? (uint8_t)(s->ackWait - dt) : 0;
        s->outMs = s->outMs + dt < 60000U ? s->outMs + dt : 60000U;
        s->txMs = s->txMs + dt < 60000U ? s->txMs + dt : 60000U;
        s->peerMs = s->peerMs + dt < 60000U ? s->peerMs + dt : 60000U;
        s->rxMs = s->rxMs + dt < 250 ? (uint8_t)(s->rxMs + dt) : 250;
    }
    if (!s->helloDone && !s->nextWait) {        /* start: ask the other panel for its keys */
        s->helloDone = 1;
        send(s, F_HELLO, 0, 0, now);
        s->nextWait = 20;
        return;
    }
    if (s->online && s->peerMs >= T_OFFLINE) s->online = 0;
    if (s->ackDue && !s->ackWait) {
        s->ackDue = 0;
        send(s, F_ACK, s->ackSeq, 0, now);
        if (s->nextWait < T_TURN) s->nextWait = T_TURN;
        return;
    }
    if (s->outActive) {
        if (s->outMs < T_ACK) return;
        s->outActive = 0;
        if (++s->outTries >= N_RETRY) {                    /* the other panel does not answer */
            s->online = 0; s->outTries = 0;
#ifdef SW_BIG
            if (s->outKind == 2) s->pressK = 0xFF;        /* a touch from the app does not wait for later */
#endif
            s->nextWait = 500;
        } else {
            s->nextWait = 15 + (rnd(s) & 63) + (s->c.role ? 25 : 0);
        }
        return;
    }
    if (s->nextWait) return;

    if (s->fullN) {                                        /* answer to HELLO: every chunk, to be followed */
        uint8_t c = (uint8_t)(PX_CHUNKS(s) - s->fullN--);
        send(s, F_FULL, (uint8_t)(c | FULL_APPLY), px_chunk(s, c), now);
        s->nextWait = 10;
        return;
    }
#ifdef SW_BIG
    if (s->online && s->pressK != 0xFF) {                 /* a key of the other panel touched in the phone app */
        if (s->outKind != 2 || s->outPole != s->pressK) s->outTries = 0;
        s->outKind = 2; s->outPole = s->pressK; s->outVal = 0; s->outSeq = ++s->seq;
        send(s, F_PRESS, s->outSeq, s->pressK, now);
        s->outActive = 1; s->outMs = 0;
        return;
    }
#endif
    uint8_t anyS = s->sMask[0] | s->sMask[1] | s->sMask[2];
    if (s->online && (anyS || s->txMask)) {
        uint8_t kind, p = 0;
        if (anyS) { kind = 1; while (!bget(s->sMask, p)) p++; }
        else { kind = 0; while (!(s->txMask & BIT(p))) p++; }
        uint8_t v = kind ? bget(s->sVal, p) : GETB(s->state, p);
#ifdef SW_P12
        if (!kind && net_of(p) == 0xFF) { s->txMask &= (pm_t)~BIT(p); return; }   /* a local-only key (scenario, master) */
#endif
        if (kind != s->outKind || p != s->outPole || v != s->outVal) s->outTries = 0;
        s->outKind = kind; s->outPole = p; s->outVal = v; s->outSeq = ++s->seq;
        send(s, kind ? F_SET : F_ST, s->outSeq, (uint8_t)((kind ? p : net_of(p)) | (v << 7)), now);
        s->outActive = 1; s->outMs = 0;
        return;
    }
    if (s->txMs >= T_PING + s->jit) {
        s->jit = rnd(s) & 255;                             /* never fall into lock-step with the other panel */
        if (s->c.role == 0 && !s->synced) send(s, F_HELLO, 0, 0, now);
        else {
            uint8_t c = s->fullC;
            if (++s->fullC >= PX_CHUNKS(s)) s->fullC = 0;
            send(s, F_FULL, (uint8_t)(c | (s->c.role == 0 ? FULL_APPLY : 0)), px_chunk(s, c), now);
        }
        s->nextWait = 10;
    }
}
#endif /* HAS_PX */

#if HAS_REMOTE
/* ---------------- RF 433 (EV1527 style, 24 bit) ---------------- */
void sw_rf_edge(Sw *s, uint16_t dt, uint8_t level)
{
    if (!level) { s->rfHi = dt; return; }     /* falling edge: a high segment ended */
    uint16_t hi = s->rfHi, lo = dt;           /* rising edge: a low segment ended */
    if (hi >= 100 && hi <= 1200 && lo >= hi * 18u && lo <= hi * 45u && lo >= 3000) {
        s->rfT = lo / 31; s->rfBits = 0; s->rfAcc = 0; s->rfOn = 1;   /* sync */
        return;
    }
    if (!s->rfOn) return;
    uint16_t T = s->rfT, sh, lg;
    uint8_t bit;
    if (hi > lo) { bit = 1; sh = lo; lg = hi; } else { bit = 0; sh = hi; lg = lo; }
    if (sh < T / 2 || sh > T * 2 || lg < T * 2 || lg > T * 5) { s->rfOn = 0; return; }
    s->rfAcc = (s->rfAcc << 1) | bit;
    if (++s->rfBits == 24) {
        s->rfOn = 0;
        if (s->rfAcc == s->rfPrev) { s->rfCode = s->rfAcc; s->rfNew = 1; }
        s->rfPrev = s->rfAcc;
    }
}

static void blink(Sw *s, uint8_t n, uint32_t now) { s->blkN = n; s->blkMs = 0; activity(s, now); }

/* remote timer: switch the button's poles on and let them go off after the chosen length */
static void rt_start(Sw *s, uint8_t k, uint8_t c)
{
    uint8_t min = s->c.tmin[tsel_get(s, k, c)];
    pm_t m = RM_POLES(s->c.rmap[k][c]);
    if (!min) return;
    for (uint8_t i = 0; i < s->nphys; i++) {
        if (!(m & BIT(i)) || s->c.type[i] != T_NORMAL) continue;
        req(s, i, 1, 1);
        s->rtMask |= BIT(i);
        s->rtSec[i] = (uint16_t)min * 60;
    }
}

static void rt_tick(Sw *s, uint32_t now, uint16_t dt, uint8_t sec)
{
    if (s->hOn) {
        if (AFTER(now, s->lastRfAt + T_RFREPEAT)) {            /* button released */
            s->hOn = 0;
            if (s->hStage == 1) rt_start(s, s->hK, s->hC);
            else if (s->hStage == 2) { s->mode = M_TSET; s->tsK = s->hK; s->tsC = s->hC; s->tsN = 0; s->tsLeft = T_RTIDLE; }
        } else {
            s->hMs += dt;
            if (s->hStage < 2 && s->hMs >= (s->hStage ? T_RTSET : T_RTHOLD)) { s->hStage++; blink(s, 2, now); }
        }
    }
    if (s->mode == M_TSET) {
        if (s->tsLeft > dt) s->tsLeft -= dt;
        else {
            if (s->tsN) {
                uint8_t n = (uint8_t)(s->tsK * 16 + s->tsC), sh = (n & 3) * 2;
                s->tsel[n >> 2] = (uint8_t)((s->tsel[n >> 2] & ~(3 << sh)) | ((s->tsN - 1) << sh));
                tsel_save(s);
                blink(s, s->tsN, now);
            }
            s->mode = M_NORMAL;
        }
    }
    for (uint8_t i = 0; i < s->nphys; i++) {
        if (!(s->rtMask & BIT(i))) continue;
        if (!target(s, i)) s->rtMask &= (pm_t)~BIT(i);     /* switched off by hand: timer cancelled */
        else if (sec && !--s->rtSec[i]) { req(s, i, 0, 1); s->rtMask &= (pm_t)~BIT(i); }
    }
}

static void rf_tick(Sw *s, uint32_t now)
{
    if (!s->rfNew) return;
    uint32_t code;
    { IRQ_OFF(); code = s->rfCode; s->rfNew = 0; IRQ_ON(); }
    if (!s->c.remote || s->booting) return;
    if (code == s->lastRf && !AFTER(now, s->lastRfAt + T_RFREPEAT)) { s->lastRfAt = now; return; }
    s->lastRf = code; s->lastRfAt = now;
    log_code(s, code, now);
    uint32_t id = code & 0xFFFFF0UL;
    uint8_t btn = code & 0x0F;
    if (s->mode == M_LEARN) {
        if (s->lslot == 0xFF) return;              /* every place is used and none was chosen */
        remote_store(s, s->lslot, id);
        s->mode = M_OK; s->modeMs = 0; s->modePole = s->lslot;   /* blinking stops */
        activity(s, now);
        return;
    }
    uint8_t k = remote_find(s, id);
    if (s->mode == M_ERASE || k == 0xFF) return;
#if HAS_SCN
    if (locked(s)) return;                         /* a short scenario runs */
#endif
    if (s->mode == M_TSET) {                       /* choosing the timer length: count presses of that button */
        if (k == s->tsK && btn == s->tsC) {
            if (s->tsN < 4) s->tsN++;
            s->tsLeft = T_RTIDLE;
            blink(s, 1, now);
        }
        return;
    }
    rm_t e = s->c.rmap[k][btn];
#ifdef SW_E12
    if (!e && k < 12 && s->c.type[k] != T_OFF) e = (rm_t)(k + 1);   /* 12 economic: a button without a job switches the pole of its place */
#endif
    pm_t m = RM_POLES(e) & PM_ALL(s->nphys);
    uint8_t act = RM_ACT(e);
    if (!m) return;
    if (s->mode == M_OK) s->mode = M_NORMAL;
    activity(s, now);
    if (e & RT_TIMER) { s->hOn = 1; s->hK = k; s->hC = btn; s->hMs = 0; s->hStage = 0; }   /* watch for a long hold */
    if (!(m & (m - 1))) {                          /* one pole */
        uint8_t i = 0;
        while (!(m & BIT(i))) i++;
        if (s->c.type[i] != T_NORMAL) { press_pole(s, i); return; }   /* scenario pole: like a touch */
        req(s, i, act == A_ON ? 1 : act == A_OFF ? 0 : (uint8_t)!target(s, i), 1);
        return;
    }
    /* several poles (normal poles only): toggle = like a master, or only on / only off */
    uint8_t anyOn = 0;
    for (uint8_t i = 0; i < s->nphys; i++) if ((m & BIT(i)) && s->c.type[i] == T_NORMAL && target(s, i)) anyOn = 1;
    uint8_t v = act == A_ON ? 1 : act == A_OFF ? 0 : (uint8_t)!anyOn;
    for (uint8_t i = 0; i < s->nphys; i++) if ((m & BIT(i)) && s->c.type[i] == T_NORMAL) req(s, i, v, 1);
}

#endif /* HAS_REMOTE */

#if HAS_ALARM
/* ---------------- alarm (keypad, ON/OFF, change password, sensor, siren) ----------------
   Works on its own: scenarios, the lock and the poles never touch it. */
static const uint16_t al_base[3] = { EE_AL0, EE_AL1, EE_AL2 };
static void al_save(Sw *s)
{
    uint8_t b[EE_ALLEN] = { EE_ALMAGIC, (uint8_t)(s->pin >> 8), (uint8_t)s->pin, s->alSt != AL_OFF, 0 };
    blk_save(s, b, EE_ALLEN, al_base);
}
static void en_open(Sw *s, uint8_t timed)          /* digits lit: a password may be entered */
{
    s->enOn = 1; s->enN = 0; s->enVal = 0;
    s->enIdle = timed ? T_ENTRYIDLE : 0xFFFF;
    s->bootDig = 0;
}
static void en_close(Sw *s) { s->enOn = 0; s->enPw = 0; }
/* ON/OFF red: armed (arming too); blinking during the entry time, the siren and after */
static uint8_t al_red(Sw *s)
{
    return s->alSt == AL_ARMING || s->alSt == AL_ARMED || (s->alSt != AL_OFF && ((s->lastNow / 250) & 1));
}
static void al_armed(Sw *s) { s->alSt = AL_ARMED; s->sirenBeep = T_ALBEEP; }   /* ready: one short siren beep */
static void al_arm(Sw *s)
{
    if (s->c.alArm) { s->alSt = AL_ARMING; s->alLeft = (uint32_t)s->c.alArm * 1000; }
    else al_armed(s);
}
static void al_init(Sw *s)
{
    uint8_t b[EE_ALLEN];
    s->pin = 0x1234;
    if (!s->c.alarm) return;
    if (blk_load(s, b, EE_ALLEN, al_base, EE_ALMAGIC)) {
        s->pin = (uint16_t)((b[1] << 8) | b[2]);
        if (b[3]) al_arm(s);                       /* armed before the power cut: arms again */
    }
    s->bootDig = T_DIGSHOW;
}
/* a touch on an alarm key (works while scenarios lock the panel) */
static void al_key(Sw *s, uint8_t i, uint32_t now)
{
    uint8_t t = s->c.type[i];
    activity(s, now);
    if (t == T_ALON) { en_open(s, s->alSt != AL_ENTRY); s->enPw = 0; return; }
    if (t != T_KEY || !s->enOn) return;            /* digits only while they are lit */
    s->beepLeft = T_BEEP;
    s->enVal = (uint16_t)((s->enVal << 4) | (s->c.sec1[i] & 15));
    if (s->enIdle != 0xFFFF) s->enIdle = T_ENTRYIDLE;
    if (++s->enN < 4) return;
    s->redPrev = (uint8_t)(al_red(s) | (s->enPw << 1));   /* last digit: reds wait 0.5 s for its beep */
    s->redHoldMs = T_REDHOLD;
    uint8_t pw = s->enPw;
    en_close(s);                                   /* wrong password: the digits just go dark */
    if (pw) { s->pin = s->enVal; s->alSaveDue = 1; s->beepLeft = 200; return; }
    if (s->enVal != s->pin) return;
    if (s->alSt == AL_OFF) al_arm(s);
    else { s->alSt = AL_OFF; s->sirenOn = 0; s->sirenBeep = 0; }
    s->alSaveDue = 1;
}
static uint8_t al_count(uint32_t *left, uint16_t dt) { if (*left > dt) { *left -= dt; return 0; } *left = 0; return 1; }
static void al_tick(Sw *s, uint16_t dt, uint32_t now)
{
    if (!s->c.alarm) return;
    if (s->enOn && s->enIdle != 0xFFFF) { if (s->enIdle > dt) s->enIdle -= dt; else en_close(s); }
    s->bootDig = s->bootDig > dt ? s->bootDig - dt : 0;
    s->sirenBeep = s->sirenBeep > dt ? s->sirenBeep - dt : 0;
    if (s->alSaveDue && !s->redHoldMs) { s->alSaveDue = 0; al_save(s); }   /* after the beep, once the red has changed */
    s->redHoldMs = s->redHoldMs > dt ? s->redHoldMs - dt : 0;
    if (s->pir) s->pirMs = s->pirMs + dt < 255 ? (uint8_t)(s->pirMs + dt) : 255; else s->pirMs = 0;
    switch (s->alSt) {
    case AL_ARMING: if (al_count(&s->alLeft, dt)) al_armed(s); break;
    case AL_ARMED:
        if (s->pirMs >= T_PIRMS && !s->sirenBeep) {           /* someone there: time to enter the password */
            s->alSt = AL_ENTRY; s->alLeft = (uint32_t)s->c.alEntry * 1000;
            en_open(s, 0);
            activity(s, now);
        }
        break;
    case AL_ENTRY:
        if (al_count(&s->alLeft, dt)) {
            s->alSt = AL_SIREN; s->alLeft = (uint32_t)s->c.alSiren * 1000; s->sirenOn = 1;
            en_close(s);
            activity(s, now);
        }
        break;
    case AL_SIREN: if (al_count(&s->alLeft, dt)) { s->alSt = AL_PAUSE; s->alLeft = T_ALPAUSE; s->sirenOn = 0; } break;
    case AL_PAUSE: if (al_count(&s->alLeft, dt)) al_armed(s); break;
    default: break;
    }
    s->sirenPin = s->sirenOn || s->sirenBeep;
}
#endif

/* ---------------- touch ---------------- */
#ifdef SW_BIG
static const uint16_t wf_base[3] = { EE_WF0, EE_WF1, EE_WF2 };
static void wifi_set(Sw *s, uint8_t on)
{
    uint8_t b[EE_WFLEN] = { EE_WFMAGIC, on, 0 };
    s->wifi = on;
    blk_save(s, b, EE_WFLEN, wf_base);
}
#endif
/* what a touch does (scenario 3 on the 23-key board: when the finger is lifted) */
static void key_act(Sw *s, uint8_t i)
{
    if (s->c.beep & BIT(i)) s->beepLeft = T_BEEP;
#if HAS_SCN
    if (locked(s)) { s->holdKey = 0xFF; return; }  /* a short scenario runs: nothing else until it ends */
    if (s->c.type[i] == T_ELEV) return;            /* the elevator waits for a 1 s hold */
#endif
    s->holdToggled = press_pole(s, i);
}
static void on_press(Sw *s, uint8_t i, uint32_t now)
{
#ifdef SW_BIG
    if (s->dimmed) { activity(s, now); s->holdKey = 0xFF; return; }   /* dark panel: a touch only lights it */
#endif
    s->holdKey = i; s->holdMs = 0; s->holdDone = 0; s->holdToggled = 0;
#if HAS_ALARM
    { uint8_t t = s->c.type[i]; if (t == T_KEY || t == T_ALON || t == T_ALPW) { al_key(s, i, now); return; } }
#endif
#if HAS_REMOTE
    if (s->mode == M_TSET) s->mode = M_NORMAL;      /* a touch ends choosing the timer length */
#endif
    activity(s, now);                              /* wakes the dimmed lights and acts at once */
#if HAS_REMOTE
    if (s->mode == M_ERASE) {
        if (i == s->modePole) { remote_clear(s); s->mode = M_OK; s->modeMs = 0; }
        s->holdKey = 0xFF;
        return;
    }
    if (s->mode == M_LEARN) {                     /* touch pole N: the remote goes to place N */
        if (i < s->c.nslot) { s->lslot = i; s->modePole = i; s->modeMs = 0; }
        s->holdKey = 0xFF;
        return;
    }
#endif
    if (s->mode == M_OK) s->mode = M_NORMAL;
#ifdef SW_BIG
    if (i == WIFI_KEY) return;                     /* scenario 3: lifted before 7 s = its scenario, held 7 s = Wi-Fi */
    if (HOLD_SCN(s, i)) return;                    /* custom scenario / group: lifted before 4 s = run, held 4 s = store */
#endif
    key_act(s, i);
}

static void touch_tick(Sw *s, uint32_t now, pm_t keys)
{
    keys &= PM_ALL(s->nphys);
    if (s->booting) {                 /* power-up show: touches are not read, a held key never fires */
        s->kRaw = s->kStable = keys; s->kMs = 0;
        return;
    }
    if (keys != s->kRaw) { s->kRaw = keys; s->kMs = 0; }
#ifndef SW_BIG
    else
#endif
    {
        /* like the original firmware: a touch acts as soon as the code is steady (2 ms); the next
           one is taken once the finger was lifted and 30 ms have passed since the last touch.
           Both times can be changed in the programmer. */
        pm_t pressed = keys & (pm_t)~s->kStable;
        if (pressed && s->kMs >= KEY_PRESS_MS(s)) {
            s->kStable |= pressed;
            for (uint8_t i = 0; i < s->nphys; i++) if (pressed & BIT(i)) { on_press(s, i, now); break; }
        }
        if ((s->kStable & (pm_t)~keys) && s->kMs >= KEY_REL_MS &&
            s->holdMs >= KEY_GAP_MS(s)) {
            s->kStable &= keys;
            if (s->holdKey != 0xFF && !(keys & BIT(s->holdKey))) {
#ifdef SW_BIG
                if ((s->holdKey == WIFI_KEY || HOLD_SCN(s, s->holdKey)) && !s->holdDone) key_act(s, s->holdKey);   /* lifted early */
#endif
                s->holdKey = 0xFF;
            }
        }
    }
#ifdef SW_BIG
    if (s->holdKey != 0xFF && !s->holdDone && HOLD_SCN(s, s->holdKey) && s->holdMs >= T_SCNHOLD) {
        s->holdDone = 1;                           /* held 4 s: store what is on now, confirmation beep */
        scn_store(s, s->holdKey);
        s->beepLeft = T_WIFIBEEP;
        activity(s, now);
    }
    if (s->holdKey == WIFI_KEY && !s->holdDone && s->holdMs >= T_WIFIHOLD) {
        s->holdDone = 1;                           /* held 7 s: Wi-Fi on <-> off, its scenario does not run */
        wifi_set(s, !s->wifi);
        s->beepLeft = T_WIFIBEEP;
        activity(s, now);
    }
#endif
#if HAS_SCN
#if defined(SW_P12) || defined(SW_E12)
    if (s->holdKey != 0xFF && s->c.type[s->holdKey] == T_ELEV && !(keys & BIT(s->holdKey))) s->holdMs = 0;   /* the elevator: 1 s without a single break (radio pulses are broken) */
#endif
    if (s->holdKey != 0xFF && !s->holdDone && s->c.type[s->holdKey] == T_ELEV && s->holdMs >= T_ELEVHOLD) {
        s->holdDone = 1;
        elev_fire(s);
    }
#endif
#if HAS_ALARM
    if (s->holdKey != 0xFF && !s->holdDone && s->c.type[s->holdKey] == T_ALPW && s->holdMs >= T_PWHOLD && s->alSt == AL_OFF) {
        s->holdDone = 1;                           /* change password: no old password needed, only when disarmed */
        en_open(s, 1); s->enPw = 1;
        activity(s, now);
    }
#endif
#if HAS_REMOTE
    /* long press (with remote places only): pole 1 = learn (next free place, or touch pole N
       for place N), pole 2 = erase every remote (confirmed by one more touch of pole 2) */
    if (IS_LEARN_KEY(s->holdKey) && !s->holdDone && s->c.remote && s->c.nslot && s->mode == M_NORMAL &&
        s->holdMs >= T_HOLD) {
        s->holdDone = 1;
        uint8_t i = s->holdKey;
        if (s->holdToggled) req(s, i, (uint8_t)!target(s, i), 1);   /* undo the short-press toggle */
        s->mode = LEARN_MODE(i);
        s->lslot = first_free(s);
        s->modePole = i; s->modeMs = 0;
        activity(s, now);
    }
#endif
}

#ifdef SW_BIG
/* ---------------- phone app ---------------- */
uint8_t sw_app_press(Sw *s, uint8_t i, uint32_t now)
{
    if (i >= SW_NP) return 0;
    uint8_t t = s->c.type[i];
    if (t == T_OFF
#if HAS_ALARM
        || t == T_KEY || t == T_ALON || t == T_ALPW
#endif
       ) return 0;
    activity(s, now);                              /* a dark panel lights up and acts at once, like a remote */
#if HAS_SCN
    if (locked(s)) return 0;                       /* a short scenario runs */
    if (t == T_ELEV) { elev_fire(s); return 1; }   /* no 1 s hold from the app */
#endif
    press_pole(s, i);
    return 1;
}
/* one setting of key k from the phone: M minutes, T 16 bit seconds (EXIT / SLEEP), 1 sec1, 2 sec2,
   O / F poles on / off of a custom scenario (O: the poles of a group or of the master) */
uint8_t sw_set(Sw *s, uint8_t k, char f, uint32_t v)
{
    if (k >= SW_NP) return 0;
    Cfg *c = &s->c;
    uint8_t t = c->type[k];
    switch (f) {
    case 'M':
        if ((t != T_TIMER && t != T_OFFTMR) || v < 1 || v > 255) return 0;
        c->minutes[k] = (uint8_t)v; break;
    case 'T':
        if ((t != T_EXIT && t != T_SLEEP) || v > 0xFFFF) return 0;
        c->sec1[k] = (uint8_t)v; c->sec2[k] = (uint8_t)(v >> 8); break;
    case '1':
        if (v > 255 || !((t == T_ILOCK && c->sec1[k] && v) || (t == T_DELOFF && v) || t == T_DELAY)) return 0;
        c->sec1[k] = (uint8_t)v; break;
    case '2':
        if (t != T_DELAY || v > 255) return 0;
        c->sec2[k] = (uint8_t)v; break;
    case 'O': case 'F': {
        pm_t m = sw_scn_poles(s) & (pm_t)~BIT(k);
        if (t == T_MASTER) {                              /* master: the poles it switches */
            if (f != 'O') return 0;
            c->onmask[k] = (pm_t)v & m; c->offmask[k] = 0;
            break;
        }
        if (t == T_GROUP) {
            if (f != 'O') return 0;
            for (uint8_t j = 0; j < 20; j++) if (c->type[j] == T_ILOCK) m &= (pm_t)~BIT(j);
        } else if (t != T_CUSTOM) return 0;
        if (f == 'O') { c->onmask[k] = (pm_t)v & m; c->offmask[k] &= (pm_t)~c->onmask[k]; }
        else c->offmask[k] = (pm_t)v & m & (pm_t)~c->onmask[k];
        break;
    }
    default: return 0;
    }
    ov_mark(s);
    return 1;
}
uint8_t sw_set_al(Sw *s, uint8_t arm, uint8_t entry, uint8_t siren, uint8_t dim)
{
    if (!entry || !siren) return 0;
    s->c.alArm = arm; s->c.alEntry = entry; s->c.alSiren = siren; s->c.dimsec = dim;
    ov_mark(s);
    return 1;
}
uint8_t sw_apply(Sw *s, pm_t on, pm_t off)
{
#if HAS_SCN
    if (locked(s)) return 0;
#endif
    pm_t m = sw_scn_poles(s);
    activity(s, s->lastNow);
    scn_apply(s, on & m, off & m);
    return 1;
}
uint16_t sw_left(Sw *s, uint8_t k)
{
    if (k >= SW_NP) return 0;
    if (s->tmrSec[k]) return s->tmrSec[k];
#if HAS_PH
    if (s->ph[k]) return (uint16_t)((s->cnt[k] + 9) / 10);
#endif
    return 0;
}
uint8_t sw_al_state(Sw *s)
{
#if HAS_ALARM
    static const uint8_t m[] = { 0, 1, 2, 3, 4, 2 };   /* off, arming, armed, entry, siren, pause (= armed) */
    return s->c.alarm ? m[s->alSt] : 0;
#else
    (void)s; return 0;
#endif
}
uint8_t sw_al_code(Sw *s, uint16_t code)
{
#if HAS_ALARM
    if (!s->c.alarm || code != s->pin) return 0;
    if (s->alSt == AL_OFF) al_arm(s);
    else { s->alSt = AL_OFF; s->sirenOn = 0; s->sirenBeep = 0; }
    en_close(s);
    s->alSaveDue = 1;
    return 1;
#else
    (void)s; (void)code; return 0;
#endif
}
uint8_t sw_al_setpin(Sw *s, uint16_t code)
{
#if HAS_ALARM
    if (!s->c.alarm || s->alSt != AL_OFF) return 0;
    s->pin = code; s->alSaveDue = 1;
    return 1;
#else
    (void)s; (void)code; return 0;
#endif
}
#endif

/* ---------------- main ---------------- */
void sw_init(Sw *s, const Cfg *c, uint32_t now)
{
    void (*tx)(const uint8_t *, uint8_t) = s->tx;
    uint8_t (*eer)(uint16_t) = s->eer;
    void (*eew)(uint16_t, uint8_t) = s->eew;
    memset(s, 0, offsetof(Sw, c));                 /* the settings may already be in s->c (copied from flash) */
    s->tx = tx; s->eer = eer; s->eew = eew;
    if (c != &s->c) s->c = *c;
    c = &s->c;
#ifdef SW_BIG
    s->nphys = SW_NP;
#else
    s->nphys = c->board == BOARD_4P ? 4 : 2;
#endif
    s->holdKey = 0xFF;
    s->stag = c->stag10 ? (uint16_t)c->stag10 * 10 : T_STAGGER;
    s->stagMs = s->stag;              /* the first change may happen at once */
    s->logged = 0xFFFFFFFFUL;
    s->logOn = 1;                      /* main clears it when the reset was not a power-up */
    s->lastNow = now;
    s->bootAt = now;
    s->booting = c->board != BOARD_2P;
    s->rng = (uint16_t)(0xACE1u ^ (c->role ? 0x5A3Cu : 0x1234u) ^ c->crc);
    s->outPole = 0xFF;
#if HAS_PX
    s->pressSeq = 0xFFFF;
#ifdef SW_BIG
    s->pressK = 0xFF;
#endif
#endif
    s->nextWait = c->role ? 300 : 150;                  /* first HELLO */
    s->linkNow = now;
#if HAS_REMOTE
    for (uint8_t i = 0; i < MAX_REMOTES; i++) s->rid[i] = NO_REMOTE;
    if (c->remote) { ee_load(s); tsel_load(s); }
#endif
#if HAS_SCN
    for (uint8_t i = 0; i < s->nphys; i++) {
        if (c->type[i] == T_ELEV) s->elevOut |= c->onmask[i] ? c->onmask[i] : BIT(i);
        if (c->type[i] == T_SLEEP) s->nightMask |= c->onmask[i];
    }
#endif
#if HAS_ALARM
    al_init(s);
#endif
#ifdef SW_BIG
#ifdef SW_P12
    s->wifi = 1;                                   /* 12-pole SIM panel: Wi-Fi on until the master hold turns it off */
#endif
    { uint8_t b[EE_WFLEN]; if (blk_load(s, b, EE_WFLEN, wf_base, EE_WFMAGIC)) s->wifi = b[1] & 1; }   /* last state */
    ov_load(s);                                         /* times / scenarios changed from the phone */
#endif
}

void sw_tick(Sw *s, uint32_t now, pm_t keys)
{
    /* advance the elapsed-time counters */
    uint32_t d32 = now - s->lastNow;
    uint16_t dt = d32 > 60000UL ? 60000 : (uint16_t)d32;
    uint8_t sec = 0;
    s->lastNow = now;
    s->msAcc += dt;
    if (s->msAcc >= 1000) { s->msAcc -= 1000; sec = 1; }
#define ADV(x, max) do { if ((uint32_t)(x) + dt < (max)) (x) += dt; else (x) = (max); } while (0)
    ADV(s->kMs, 255); ADV(s->holdMs, 65535U); ADV(s->modeMs, 65535U); ADV(s->bootMs, 65535U); ADV(s->stagMs, 65535U);
    s->idleMs += dt;
    while (s->idleMs >= 1000) { s->idleMs -= 1000; if (s->idleSec < 255) s->idleSec++; }
    s->beepLeft = s->beepLeft > dt ? (uint8_t)(s->beepLeft - dt) : 0;
    if (s->booting && s->bootMs >= BOOT_TOTAL) {
        s->booting = 0;
        activity(s, now);            /* idle (dimming) time starts after the show */
    }
    touch_tick(s, now, keys);
#if HAS_REMOTE
    rf_tick(s, now);
    rt_tick(s, now, dt, sec);
#endif

    /* auto-off timers */
    /* service scenarios: end on timeout, or when one of their poles was switched off by hand */
    for (uint8_t i = 0; i < s->nphys; i++) {
        if (s->c.type[i] != T_TIMER || !target(s, i)) continue;
        pm_t m = s->c.onmask[i];
        uint8_t cancel = 0;
        for (uint8_t k = 0; k < s->nphys; k++) if ((m & BIT(k)) && !target(s, k)) cancel = 1;
#if HAS_PX
        if (!px_on(s, i, 1)) cancel = 1;                  /* switched off on the other panel */
#endif
        if (cancel) req(s, i, 0, 0);
        else if (s->c.minutes[i] && sec && s->tmrSec[i] && !--s->tmrSec[i]) {
            for (uint8_t k = 0; k < s->nphys; k++) if (m & BIT(k)) req(s, k, 0, 1);
            PXQ(s, i, PX_ON, 0);
            req(s, i, 0, 0);
        }
    }

#if HAS_SCN
    if (s->elevLeft && s->elevLeft <= dt) elev_state(s, 0);
    s->elevLeft = s->elevLeft > dt ? s->elevLeft - dt : 0;
    for (uint8_t i = 0; i < s->nphys; i++) {      /* EXIT / SLEEP */
        uint8_t t = s->c.type[i];
        if ((t == T_EXIT || t == T_SLEEP) && target(s, i) && sec && s->tmrSec[i] && !--s->tmrSec[i]) scn_end(s, i);
    }
#endif
#if HAS_ALARM
    al_tick(s, dt, now);
#endif
#if HAS_ILOCK
    for (uint8_t i = 0; i < s->nphys; i++)       /* off timers */
        if (s->c.type[i] == T_OFFTMR && target(s, i) && sec && s->tmrSec[i] && !--s->tmrSec[i]) {
            offmask_off(s, s->c.offmask[i]);
            PXQ(s, i, PX_OFF, 0);
            req(s, i, 0, 0);
        }
#endif
#if HAS_PH
    /* 100 ms steps: delays, delayed off, pulses, run times, change-over pauses */
    s->tenAcc += (uint8_t)(dt > 100 ? 100 : dt);
    uint8_t ten = s->tenAcc >= 100;
    if (ten) s->tenAcc -= 100;
    for (uint8_t i = 0; i < s->nphys; i++) {
        uint8_t ph = s->ph[i];
        if (!ph) continue;
        if (ph == 2 && !target(s, i)) { s->ph[i] = 0; continue; }   /* switched off some other way */
        if (!ten || (s->cnt[i] && --s->cnt[i])) continue;
        s->ph[i] = 0;
        uint8_t t = s->c.type[i];
        if (ph == 2 || t == T_DELOFF) req(s, i, 0, 1);       /* time is up: off */
#if HAS_SEC
        else if (t == T_DELAY) timed_on(s, i, s->c.sec2[i]);
#endif
#if HAS_ILOCK
        else il_on(s, i);                                    /* change-over pause over */
#endif
    }
#endif

    apply_pending(s, now);

    /* mode timeouts */
    if ((s->mode == M_LEARN || s->mode == M_ERASE) && s->modeMs >= T_WINDOW) s->mode = M_NORMAL;
    if (s->mode == M_OK && s->modeMs >= T_OKSHOW) s->mode = M_NORMAL;

    /* dimming (4P): only when every normal pole is off and nothing happens */
#ifdef SW_BIG
    /* dark: no red lit (a SLEEP night light may stay on) and nothing happening */
    if (s->c.dimsec && !s->dimmed && s->mode == M_NORMAL && !(s->state & ~NIGHT(s)) && !s->pendMask &&
        !ELEV_ON(s) && !AL_BUSY(s) && s->idleSec >= s->c.dimsec)
        s->dimmed = 1;
#else
    if (s->c.board != BOARD_2P && s->c.dimsec && !s->dimmed && s->mode == M_NORMAL &&
        !s->state && !s->pendMask && s->idleSec >= s->c.dimsec)
        s->dimmed = 1;
#endif

    /* outputs */
    pm_t w = 0, r = 0;
    for (uint8_t i = 0; i < s->nphys; i++) {
        uint8_t t = s->c.type[i];
        if (t == T_MASTER
#ifdef SW_BIG
            || t == T_CUSTOM || t == T_GROUP
#endif
           ) w |= BIT(i);
#if HAS_ALARM
        else if (t == T_KEY) { if (s->enOn || s->bootDig) w |= BIT(i); }      /* digits: lit while a password may be entered */
        else if (t == T_ALON || t == T_ALPW) {
            w |= BIT(i);
            uint8_t on = t == T_ALPW ? s->enPw : al_red(s);
            if (s->redHoldMs) on = (s->redPrev >> (t == T_ALPW)) & 1;   /* just after the last digit: as before */
            if (on) r |= BIT(i);
        }
#endif
        else if (t != T_OFF) { if (GETB(s->state, i)) r |= BIT(i); else w |= BIT(i); }
#ifdef SW_BIG
#ifndef SW_P12
#ifdef SW_E12
        if ((i == 20 || i == 22) && !GETB(r, i)) w |= BIT(i);   /* 12 economic: scenario 1 / 3 white on, off while red (it runs); 2 is lit by the supply */
#else
        if (i == 20 || i == 21 || (i == 22 && !GETB(r, i))) w |= BIT(i);   /* scenario keys: white on (3: off while red) */
#endif
#endif
#endif
#if HAS_SEC
        if (s->ph[i] == 1 && t != T_ILOCK && ((s->cnt[i] >> 1) & 1)) w &= (pm_t)~BIT(i);   /* waiting: white blinks */
#endif
    }
#if HAS_SCN
    r &= (pm_t)~s->elevOut;                            /* elevator call: its own output */
    if (s->elevLeft) {
        r |= s->elevOut;
#ifndef SW_BIG
        w &= (pm_t)~s->elevOut;
#endif
    }
#endif
#if HAS_ILOCK && defined(SW_BIG)
    /* a curtain with its relay on another key (the programmer's "relay of this curtain"): that relay runs with it */
    for (uint8_t i = 0; i < s->nphys; i++)
        if (s->c.type[i] == T_ILOCK && s->c.sec1[i] && (r & BIT(i))) r |= s->c.onmask[i];
#endif
    /* dim (4 pole: pole 4 white stays) / dark (23 keys): the whites go, and come back, one at a time */
    if (s->dimmed || s->darkMask) {
        if ((s->dkMs += dt) >= T_DARKSTEP) {
            s->dkMs = 0;                               /* dark: the next place goes too; light: the lowest dark place comes back */
            s->darkMask = s->dimmed ? (pm_t)((s->darkMask << 1) | 1) : (pm_t)(s->darkMask & (s->darkMask - 1));
        }
        w &= (pm_t)~(s->darkMask & (pm_t)~DIM_KEEP);
    }
    if (s->mode == M_LEARN || s->mode == M_ERASE) {
        if ((s->modeMs / T_BLINK) & 1) w &= (pm_t)~BIT(s->modePole);
        else w |= BIT(s->modePole);
    } else if (s->mode == M_OK) w |= BIT(s->modePole);
    if (s->booting) {                /* circle 1 -> 2 -> 4 -> 3 (key layout 1 2 / 3 4); relays/red follow the state */
        BOOT_SHOW(w);
    }
    uint8_t bz = s->beepLeft != 0;
#if HAS_REMOTE
    if (s->blkN) {               /* confirmation: every visible white goes dark N times (buzzer too, if fitted) */
        uint8_t ph = (uint8_t)(s->blkMs / T_BLK);
        s->blkMs += dt;
        if (ph >= 2u * s->blkN) s->blkN = 0;
        else if (!(ph & 1)) { w = 0; bz = 1; }
    }
#endif
    s->white = w; s->red = r; s->buzz = bz;
}
