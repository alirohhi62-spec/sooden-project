#!/bin/sh
# 12-pole SIM panel: M4 (ATmega64) with the panel logic, and M1/M2/M3 (ATmega32)
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
mkdir -p out
F="-DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 -mcall-prologues -mrelax -flto -ffunction-sections -fdata-sections -Wl,--gc-sections"
avr-gcc -mmcu=atmega64 $F -DSW_BIG -DSW_P12 -DFW_BOARD=BOARD_P12 -DHAS_REMOTE=1 -DHAS_PX=1 -DHAS_SEC=1 -DHAS_ILOCK=1 -DHAS_SCN=1 -DHAS_ALARM=0 -Wl,--section-start=.swpx=0xF300 \
  -Wl,--section-start=.swcfg=0xF000 main_p12.c sw.c wifi64.c -o out/fw_p12_m4.elf
avr-objcopy -O ihex -R .eeprom out/fw_p12_m4.elf out/fw_p12_m4.hex
printf "%-16s " fw_p12_m4; avr-size out/fw_p12_m4.elf | tail -1
for b in 1 2 3; do
  avr-gcc -mmcu=atmega32 $F -DBOARD=$b -Wl,--section-start=.rmname=0x7000 -I/home/claude/p12/fw /home/claude/p12/fw/m32_p12.c -o out/fw_p12_m$b.elf
  avr-objcopy -O ihex -R .eeprom out/fw_p12_m$b.elf out/fw_p12_m$b.hex
  printf "%-16s " fw_p12_m$b; avr-size out/fw_p12_m$b.elf | tail -1
done
avr-gcc -mmcu=atmega64 $F -Wl,--section-start=.alcfg=0xF000 -I/home/claude/p12/fw /home/claude/p12/fw/alarm_p12.c -o out/fw_p12_alarm.elf
avr-objcopy -O ihex -R .eeprom out/fw_p12_alarm.elf out/fw_p12_alarm.hex
printf "%-16s " fw_p12_alarm; avr-size out/fw_p12_alarm.elf | tail -1
