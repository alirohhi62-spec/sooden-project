#!/bin/sh
# 1/2-pole board (ATmega8 + crystal, two-panel network): 1 pole, 2 poles, bell push
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
b() {   # name pair px bell
  for X in "" "-fno-reorder-blocks"; do
    if avr-gcc $X -mmcu=atmega8 -DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 \
      -mcall-prologues -mrelax -fno-split-wide-types -fno-tree-scev-cprop -fno-move-loop-invariants -flto \
      -ffunction-sections -fdata-sections -Wl,--gc-sections -Wl,--section-start=.swcfg=0x1F80 \
      -DFW_BOARD=BOARD_2P -DHAS_REMOTE=0 -DHAS_PAIR=1 -DHAS_SEC=0 -DHAS_ILOCK=0 -DHAS_SCN=0 -DHAS_PX=$2 -DHAS_BELL=$3 \
      $( [ "$2" = 1 ] && echo -Wl,--section-start=.swpx=0x1F40 ) main_avr.c sw.c -o out/$1.elf 2>out/$1.log; then break; fi
    [ -n "$X" ] && { cat out/$1.log; exit 1; }
  done
  avr-objcopy -O ihex -R .eeprom out/$1.elf out/$1.hex
  printf "%-14s " $1; avr-size out/$1.elf | tail -1
}
b fw_2p_pair 0 0
b fw_2p_px   1 0
b fw_2p_bell 1 1
