/* Sooden 12-pole SIM panel - M4 (ATmega64A, 8 MHz crystal, fuses Low 3F, High C1, Extended FF)
 * The keys, the panel logic (sw.c, as every Sooden panel: master, custom scenarios, curtains, elevator,
 * timers, stepped switching, standby) and the 433 MHz remotes. M1/M2/M3 get every output over bus A (bus12.h).
 * keys (index): 0..11 poles 1..12, 12..14 keys 13..15, 15..20 S1..S6, 21 master, 22 elevator, 23..26 curtain 1 open/close, 2 open/close
 * touch: 4 x BS818A-2 (valid low + 3 code lines): IC1 PA4 / PA5 PA6 PA7, IC2 PC6 / PC5 PC4 PD7, IC3 PC0 / PC1 PC2 PC3, IC4 PA3 / PA2 PA1 PA0
 * bus A out: PD6 PD5 PD4 PD1 PD0 (bit 4..0)     keys 14 / 15: white PG1 / PG2, red + relay PG0 / PG4
 * click relay (sound of keys without a relay): PG3     433 MHz receiver: PE6 (INT6)
 * RS485 (PD2/PD3, USART1): two-panel network (sw.c, v2) and the rooms of the 7-segment (all poles of room 1..9 on / off)
 * 7-segment (PORTF, common anode): A PF0 B PF1 C PF2 D PF6 E PF5 F PF4 G PF3; PF7 = Wi-Fi LED
 * not used yet: Wi-Fi (PE0/PE1) */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <string.h>
#include "sw.h"
#include "bus12.h"
#include "wifi64.h"

#define K_P(n)  ((n) - 1)          /* pole n (1..12) */
#define K_13 12
#define K_14 13
#define K_15 14
#define K_S(n)  (14 + (n))         /* S1..S6 */
#define K_M  21
#define K_EL 22
#define K_P1O 23
#define K_P1C 24
#define K_P2O 25
#define K_P2C 26

/* settings block (the programmer will write it here later); erased = built-in defaults below */
const uint8_t cfg_flash[CFG_SIZE] __attribute__((section(".swcfg"), used)) = { [0 ... CFG_SIZE - 1] = 0xFF };
/* two-panel network v2: for every key the keys of the other panel its scenario switches on / off (written by the programmer) */
const uint8_t px_flash[PX_SIZE] __attribute__((section(".swpx"), used)) = { [0 ... PX_SIZE - 1] = 0xFF };
static uint8_t px_mask(uint8_t k, uint8_t which, uint8_t *m)
{
    if (k >= SW_NP) return 0;
    const uint8_t *p = &px_flash[3 + (which ? 3 * SW_NP : 0) + 3 * k];
    m[2] = pgm_read_byte(p); m[1] = pgm_read_byte(p + 1); m[0] = pgm_read_byte(p + 2);   /* stored high byte first */
    m[2] &= 0x7F;
    return (uint8_t)(m[0] | m[1] | m[2]);
}
static uint8_t px_valid(void)
{
    uint8_t c = 0;
    for (uint16_t i = 0; i < PX_SIZE - 1; i++) {
        c ^= pgm_read_byte(&px_flash[i]);
        for (uint8_t j = 0; j < 8; j++) c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1);
    }
    return pgm_read_byte(&px_flash[0]) == PX_M0 && pgm_read_byte(&px_flash[1]) == PX_M1 &&
           pgm_read_byte(&px_flash[2]) == SW_NP && c == pgm_read_byte(&px_flash[PX_SIZE - 1]);
}
/* USART1 (RS485, auto-direction module): bytes in / out through rings, the main loop never waits */
static volatile uint8_t n1rx[64], n1rh, n1rt, n1tx[32], n1th, n1tt;
ISR(USART1_RX_vect)
{
    uint8_t b = UDR1, n = (uint8_t)((n1rh + 1) & 63);
    if (n != n1rt) { n1rx[n1rh] = b; n1rh = n; }
}
ISR(USART1_UDRE_vect)
{
    if (n1tt != n1th) { UDR1 = n1tx[n1tt]; n1tt = (uint8_t)((n1tt + 1) & 31); }
    else UCSR1B &= (uint8_t)~_BV(UDRIE1);
}
static void n1_put(uint8_t b)
{
    uint8_t n = (uint8_t)((n1th + 1) & 31);
    while (n == n1tt) wdt_reset();
    n1tx[n1th] = b; n1th = n;
    UCSR1B |= _BV(UDRIE1);
}
static void net_tx(const uint8_t *p, uint8_t n)
{
    n1_put(0xFF);                                      /* lead-in byte, as every Sooden panel */
    while (n--) n1_put(*p++);
}
/* 7-segment: digit 0..9, 10 = dash, 11 = dark; segments are low = lit */
static const uint8_t SEG[12] PROGMEM = {
    0x77, 0x06, 0x6B, 0x4F, 0x1E, 0x5D, 0x7D, 0x07, 0x7F, 0x5F, 0x08, 0x00 };   /* bit: A0 B1 C2 G3 F4 E5 D6 */
static void seg_show(uint8_t d) { PORTF = (uint8_t)((PORTF & 0x80) | (~pgm_read_byte(&SEG[d]) & 0x7F)); }

static Sw S;
static volatile uint32_t ms;
static uint32_t now_ms(void) { uint32_t v; cli(); v = ms; sei(); return v; }
static uint8_t ee_r(uint16_t a) { return eeprom_read_byte((const uint8_t *)a); }
static void ee_w(uint16_t a, uint8_t v) { eeprom_update_byte((uint8_t *)a, v); }

/* ---------------- bus A sender (in the 1 ms interrupt) ---------------- */
#define TQ 40
static volatile uint8_t qT[TQ], qH, qN;                 /* target, or 0x80 | register for a data frame */
static volatile uint16_t qV[TQ];
static volatile uint8_t qL[TQ], txLvl, txT; static volatile uint16_t txV;                  /* level of each waiting frame / of the frame on the bus */
static volatile uint8_t qF2, qF1;                       /* how many level-2 / level-1 frames wait at the head (send) */
static uint8_t txSym[5], txN, txI, txPh, txLeft;       /* phase 0 idle gap, 1 symbol held, 2 short idle */
static void bus_out(uint8_t c)
{
    uint8_t d = PORTD & (uint8_t)~0x73;
    if (c & 16) d |= _BV(6);
    if (c & 8) d |= _BV(5);
    if (c & 4) d |= _BV(4);
    if (c & 2) d |= _BV(1);
    if (c & 1) d |= _BV(0);
    PORTD = d;
}
static void bus_step(void)
{
    if (txLeft) { txLeft--; return; }
    if (txPh == 1) { bus_out(BUS_IDLE); txPh = 2; txLeft = BUS_GAP - 1; if (++txI == txN) { txPh = 0; txLeft = BUS_FGAP - 1; } return; }
    if (txPh == 2) { bus_out(txSym[txI]); txPh = 1; txLeft = BUS_HOLD - 1; return; }
    if (!qN) return;                                      /* phase 0: next frame */
    uint8_t t = qT[qH]; uint16_t v = qV[qH];
    if (t & 0x80) {                                       /* data frame: [0] [register] [hi] [lo] [check] */
        uint8_t r = t & 0x7F, hi = (uint8_t)(v / 31), lo = (uint8_t)(v % 31);
        txSym[0] = TG_SYS; txSym[1] = r; txSym[2] = hi; txSym[3] = lo; txSym[4] = (uint8_t)((r + hi + lo) % 31); txN = 5;
    } else { txSym[0] = t; txSym[1] = (uint8_t)v; txSym[2] = (uint8_t)((t + v) % 31); txN = 3; }
    txLvl = qL[qH]; txT = t; txV = v;
    qH = (uint8_t)((qH + 1) % TQ); qN--;
    if (qF2) qF2--; else if (qF1) qF1--;
    txI = 0; bus_out(txSym[0]); txPh = 1; txLeft = BUS_HOLD - 1;
}
/* queue a frame; a frame for the same target still waiting is only updated.
   front = 2: a key / pole (ahead of everything), 1: another change the user waits for (after the keys), 0: refresh (at the end).
   Frames of the same level keep their order, so the master steps leave one by one, evenly. */

static void q_ins(uint8_t at, uint8_t tg, uint16_t v, uint8_t l)   /* (interrupts off) */
{
    for (uint8_t k = qN; k > at; k--) { uint8_t d = (uint8_t)((qH + k) % TQ), s2 = (uint8_t)((qH + k - 1) % TQ); qT[d] = qT[s2]; qV[d] = qV[s2]; qL[d] = qL[s2]; }
    uint8_t i = (uint8_t)((qH + at) % TQ); qT[i] = tg; qV[i] = v; qL[i] = l;
    qN++;
    if (l == 2) qF2++; else if (l == 1) qF1++;
}
static void send(uint8_t tg, uint16_t v, uint8_t front)
{
    cli();
    for (uint8_t k = 0; k < qN; k++) { uint8_t i = (uint8_t)((qH + k) % TQ); if (qT[i] == tg) { qV[i] = v; sei(); return; } }
    if (qN < TQ) {
        q_ins(front == 2 ? qF2 : front == 1 ? (uint8_t)(qF2 + qF1) : qN, tg, v, front);
        if (front == 2) {                                 /* a key / pole leaves at once: the master steps stay even */
            if (txPh && txLvl < 2) {                      /* another frame on the bus: cut it (the boards drop a half frame after 12 ms idle), it goes again later */
                bus_out(BUS_IDLE); txPh = 0; txLeft = 14;
                uint8_t dup = 0;
                for (uint8_t k = 0; k < qN; k++) if (qT[(uint8_t)((qH + k) % TQ)] == txT) dup = 1;
                if (!dup && qN < TQ) q_ins(txLvl == 1 ? qF2 : (uint8_t)(qF2 + qF1), txT, txV, txLvl);
            }
            else if (!txPh && txLeft > 3) txLeft = 3;     /* the pause after a finished frame: 3 ms idle are enough */
        }
    }
    sei();
}
/* bus B from the alarm MCU, sampled every 1 ms here (the main loop can be slow while bus A sends): finished frames into a small queue */
static volatile uint8_t bbQ[8][2], bbQh, bbQt;
static uint8_t bbLast = 0x0F, bbCnt, bbIdle = 20, bbN, bbSym[3];
static void bb_sample(void)
{
    uint8_t b = (uint8_t)(PINB >> 4);
    if (b == bbLast) { if (bbCnt < 255) bbCnt++; } else { bbLast = b; bbCnt = 1; }
    if (b == BB_IDLE) { if (bbCnt >= 3 && bbIdle < 255) bbIdle = bbCnt; if (bbCnt > 12) bbN = 0; }
    else if (bbCnt == 3 && bbIdle >= 3) {
        bbIdle = 0; bbSym[bbN++] = b;
        if (bbN == 3) { bbN = 0; if ((uint8_t)((bbSym[0] + bbSym[1]) % 15) == bbSym[2] && (uint8_t)(bbQh - bbQt) < 8) { bbQ[bbQh & 7][0] = bbSym[0]; bbQ[bbQh & 7][1] = bbSym[1]; bbQh++; } }
    }
}
ISR(TIMER0_COMP_vect) { ms++; bus_step(); bb_sample(); }
ISR(INT6_vect)
{
    static uint16_t last;
    uint16_t t = TCNT1, dt = t - last;
    last = t;
    sw_rf_edge(&S, dt, (PINE & _BV(6)) ? 1 : 0);
}

/* ---------------- touch ---------------- */
#define NK 0xFF
#define SG_ON 0xF0                 /* the 4 keys around the 7-segment (not panel keys) */
#define SG_UP 0xF1
#define SG_OFF 0xF2
#define SG_DN 0xF3
static const uint8_t KEYIDX[32] PROGMEM = {
    /* IC1 code 0..7 */ K_P(8), K_P(6), K_P(4), K_P(2), K_P(1), K_P(3), K_P(5), K_P(7),
    /* IC2 */           K_S(3), K_S(4), K_P(12), K_P(10), K_P(9), K_P(11), K_S(1), K_S(2),
    /* IC3 */           K_S(5), K_S(6), K_M, K_13, K_14, K_15, SG_DN, NK,
    /* IC4 */           SG_ON, SG_UP, SG_OFF, K_P2O, K_P1O, K_EL, K_P1C, K_P2C };   /* curtains: the left key opens (rule for every panel) */
static uint8_t touch_raw(void)
{
    if (!(PINA & _BV(4))) return (uint8_t)(1 + (((PINA >> 5) & 1) << 2 | ((PINA >> 6) & 1) << 1 | ((PINA >> 7) & 1)));
    if (!(PINC & _BV(6))) return (uint8_t)(9 + (((PINC >> 5) & 1) << 2 | ((PINC >> 4) & 1) << 1 | ((PIND >> 7) & 1)));
    if (!(PINC & _BV(0))) return (uint8_t)(17 + (((PINC >> 1) & 1) << 2 | ((PINC >> 2) & 1) << 1 | ((PINC >> 3) & 1)));
    if (!(PINA & _BV(3))) return (uint8_t)(25 + (((PINA >> 2) & 1) << 2 | ((PINA >> 1) & 1) << 1 | (PINA & 1)));
    return 0;
}

/* ---------------- default settings (until the programmer writes its own) ---------------- */
static void defaults(Cfg *c)
{
    memset(c, 0, sizeof *c);
    c->m0 = CFG_M0; c->m1 = CFG_M1; c->ver = CFG_VER; c->board = BOARD_P12; c->npoles = 15; c->remote = 1;
    for (uint8_t k = 0; k < SW_NP; k++) { c->type[k] = T_NORMAL; c->link[k] = NO_LINK; }
    for (uint8_t n = 1; n <= 6; n++) {                   /* S1..S6: custom scenarios holding "all off" (S6 = child lock, main loop) */
        c->type[K_S(n)] = T_CUSTOM;
        c->offmask[K_S(n)] = 0x7FFFUL | BIT(K_P1O) | BIT(K_P1C) | BIT(K_P2O) | BIT(K_P2C);   /* keys 1..15 and the curtains */
    }
    /* S5 = exit: 20 s with the panel locked, then poles 1..12 off and the open curtains close (main loop); the programmer can change both */
    c->type[K_S(5)] = T_EXIT; c->sec1[K_S(5)] = 20; c->sec2[K_S(5)] = 0; c->minutes[K_S(5)] = 1;
    c->offmask[K_S(5)] = 0x0FFFUL | BIT(K_P1O) | BIT(K_P2O);
    c->type[K_M] = T_MASTER; c->onmask[K_M] = 0x0FFFUL;                  /* poles 1..12 */
    c->type[K_EL] = T_ELEV;
    static const uint8_t cur[4][2] = { {K_P1O, K_P1C}, {K_P1C, K_P1O}, {K_P2O, K_P2C}, {K_P2C, K_P2O} };
    for (uint8_t i = 0; i < 4; i++) { uint8_t k = cur[i][0]; c->type[k] = T_ILOCK; c->offmask[k] = BIT(cur[i][1]); c->sec1[k] = 45; c->sec2[k] = 5; }
    c->beep = BIT(K_M) | BIT(K_S(1)) | BIT(K_S(2)) | BIT(K_S(3)) | BIT(K_S(4)) | BIT(K_S(5)) | BIT(K_S(6));
#ifdef TEST_LINK
    c->link[0] = 0; c->link[K_P1O] = 1; c->link[K_EL] = 2;   /* simulator test only: pole 1, curtain 1 open, elevator <-> keys 1..3 of a 4-pole panel */
#endif
    c->rooms = 0x1FF; c->clk = K_S(6) + 1;                                     /* rooms 1..9 on the 7-segment (the programmer names and limits them) */
    c->dimsec = 60; c->stag10 = 10; c->nslot = 12; c->tpress = 2; c->tgap2 = 15;
    for (uint8_t p = 0; p < 12; p++) for (uint8_t b = 1; b < 16; b++) c->rmap[p][b] = (rm_t)(p + 1);   /* remote place N: its buttons toggle pole N */
    c->tmin[0] = 5; c->tmin[1] = 10; c->tmin[2] = 30; c->tmin[3] = 60;
    c->crc = sw_crc8((const uint8_t *)c, CFG_SIZE - 1);
}

/* ---------------- outputs ---------------- */
/* bus target of every key (0 = none) */
static const uint8_t TGT[SW_NP] PROGMEM = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,  13, 0, 0,  19, 20, 21, 22, 23, 24,  0, 14,  15, 16, 17, 18 };
static uint8_t sentV[31];
static uint16_t regV[R_N];
static uint8_t refreshI = 1;
static uint8_t clk, exk;                    /* child-lock key, exit-scenario key (0xFF / SW_NP: none) */
static uint32_t refreshAt;
/* power-up motion of the own whites (keys 14 / 15), the same scanner as M1..M3 */
static void motion_whites(uint16_t t)
{
    uint8_t w14 = (t >= 525 && t < 625) || t >= 850, w15 = (t >= 475 && t < 575) || t >= 900;
    PORTG = (uint8_t)((PORTG & (uint8_t)~(_BV(1) | _BV(2) | _BV(0) | _BV(4))) | (w14 ? _BV(1) : 0) | (w15 ? _BV(2) : 0));
}
static void set_reg(uint8_t r, uint16_t v) { if (regV[r - R_FIRST] != v) { regV[r - R_FIRST] = v; send((uint8_t)(0x80 | r), v, 1); } }

/* ---------------- clock (counted here; starts at Saturday 1405/01/01 00:00 after power-up, the app will set it) ---------------- */
static uint8_t cH, cM, cS, cWd, cMo = 1, cD = 1;
static uint16_t cY = 1405;
static uint8_t leap(uint16_t y) { uint8_t r = (uint8_t)(y % 33); return r == 1 || r == 5 || r == 9 || r == 13 || r == 17 || r == 22 || r == 26 || r == 30; }
static uint8_t mdays(void) { return cMo <= 6 ? 31 : cMo <= 11 ? 30 : leap(cY) ? 30 : 29; }
static void clock_sec(void)
{
    if (++cS < 60) return;
    cS = 0; if (++cM < 60) return;
    cM = 0; if (++cH < 24) return;
    cH = 0; cWd = (uint8_t)((cWd + 1) % 7);
    if (++cD <= mdays()) return;
    cD = 1; if (++cMo <= 12) return;
    cMo = 1; cY++;
}

/* ---------------- curtains: where each one is (0..1000 = closed..open), from the run time ---------------- */
#define EE_POS 0x7F0
static const uint8_t CK[2][2] = { { K_P1O, K_P1C }, { K_P2O, K_P2C } };
static uint16_t pos[2], pacc[2];
uint8_t p12_pos(uint8_t c) { uint16_t v = (uint16_t)((pos[c & 1] + 5) / 10); return (uint8_t)(v > 99 ? 99 : v); }
static uint32_t runMs[2];

static void busC(uint8_t c)                               /* PB2 PB0 PE7 = bit 2..0 */
{
    if (c & 4) PORTB |= _BV(2); else PORTB &= (uint8_t)~_BV(2);
    if (c & 2) PORTB |= _BV(0); else PORTB &= (uint8_t)~_BV(0);
    if (c & 1) PORTE |= _BV(7); else PORTE &= (uint8_t)~_BV(7);
}
/* ---------------- commands from the alarm MCU (SMS) ---------------- */
static uint8_t gsmBusy, curPend, simSt; static uint32_t gsmFreeAt, curPendAt;
extern uint8_t sw_mlock;
/* the alarm settings dump (bus B: MISC 10, then CRD symbols) for the app, two symbols a byte (0..9 digit, 10 ',', 12 '+', 15 end):
   "exit,entry,siren,code,s1,s2,s3,c1,c2,c3" */
uint8_t p12acf[52], p12acfGen, p12acfOn;
static uint8_t acfN = 0xFF;
static void acf_put(uint8_t v) { if (acfN < 2 * sizeof p12acf - 1) { uint8_t *b = &p12acf[acfN >> 1]; *b = (acfN & 1) ? (uint8_t)((*b & 0xF0) | v) : (uint8_t)(v << 4 | 15); acfN++; } }
static uint8_t acf_sym(uint8_t i) { return (uint8_t)((i & 1) ? p12acf[i >> 1] & 15 : p12acf[i >> 1] >> 4); }
/* the dump ended: whole only with 9 commas and the right check (last two digits = sum of the symbols mod 100);
   otherwise dropped (the app side asks again) */
static void acf_end(void)
{
    uint8_t n = acfN, ok = n >= 2 && n < 2 * sizeof p12acf - 1, commas = 0; uint16_t sum = 0;
    if (ok) {
        for (uint8_t i = 0; i < n - 2; i++) { uint8_t v = acf_sym(i); sum += v; if (v == 10) commas++; }
        uint8_t c1 = acf_sym((uint8_t)(n - 2)), c0 = acf_sym((uint8_t)(n - 1));
        ok = commas == 9 && c1 <= 9 && c0 <= 9 && (uint8_t)(c1 * 10 + c0) == sum % 100;
    }
    if (ok) { acfN = (uint8_t)(n - 2); acf_put(15); p12acfOn = 1; p12acfGen++; }
    acfN = 0xFF;
}
/* scenario d (1..4, 0 = all four) off: its poles off, its curtains the other way (a curtain two scenarios move both ways: left alone) */
uint8_t p12_scn_off(uint8_t d)
{
    pm_t m = 0, on = 0, off = 0;
    for (uint8_t i = 1; i <= 4; i++) if (!d || d == i) m |= S.c.onmask[K_S(i)];
    for (uint8_t k = 0; k < SW_NP; k++) if (m & BIT(k)) {
        if (k == K_P1O) on |= BIT(K_P1C); else if (k == K_P1C) on |= BIT(K_P1O); else if (k == K_P2O) on |= BIT(K_P2C); else if (k == K_P2C) on |= BIT(K_P2O); else off |= BIT(k);
    }
    if ((on & BIT(K_P1O)) && (on & BIT(K_P1C))) on &= (pm_t)~(BIT(K_P1O) | BIT(K_P1C));
    if ((on & BIT(K_P2O)) && (on & BIT(K_P2C))) on &= (pm_t)~(BIT(K_P2O) | BIT(K_P2C));
    return sw_apply(&S, on, off);
}
static void bb_cmd(uint8_t c, uint8_t a, uint32_t now)
{
    if (c == BB_C_WAKE) { S.dimmed = 0; S.idleSec = 0; S.idleMs = 0; return; }   /* alarm keypad / remote used: wakes, and the standby minute starts again */
    if (c == BB_C_BUSY) { gsmBusy = a; if (!a) gsmFreeAt = now + 2000; return; }
    if (c == BB_C_SIM) { if (a <= 2) simSt = a; return; }   /* indicator D */
    if (c == BB_C_SCNON && a >= 1 && a <= 4) { sw_app_press(&S, K_S(a), now); return; }
    if (c == BB_C_SCNOFF && a >= 1 && a <= 5) { p12_scn_off(a == 5 ? 0 : a); return; }   /* 5: every scenario (SMS SOFF) */
    if ((c == BB_C_KON || c == BB_C_KOFF) && a >= 1 && a <= 14) {      /* 1..3: K1..K3 (keys 13..15), 4..14: poles 1..11 */
        pm_t b = a <= 3 ? BIT(11 + a) : BIT(a - 4);
        if (c == BB_C_KON) sw_apply(&S, b, 0); else sw_apply(&S, 0, b);
        return;
    }
    /* for the phone app */
    if (c == BB_C_MISC) {
        if (a >= 1 && a <= 3) p12.armRes = a;
        else if (a == 10) { acfN = 0; p12acf[0] = 0xFF; }
        else if (a == 11 || a == 12) p12.setRes = (uint8_t)(a - 10);
        else if (a >= 4 && a <= 7) p12.op = (uint8_t)(a - 4);
        else if (a == 8) sw_apply(&S, BIT(11), 0);
        else if (a == 9) sw_apply(&S, 0, BIT(11));
        return;
    }
    if (c == BB_C_AL) { if (a <= 4) p12.al = a; return; }
    if (c == BB_C_ZN) { p12.zones = (uint8_t)(a & 7); return; }
    if (c == BB_C_OPEN) { p12.open = (uint8_t)(a & 7); return; }
    if (c == BB_C_GSM) { p12.bars = (uint8_t)(a & 7); p12.gsm = (a & 8) != 0; return; }
    if (c == BB_C_CRD && acfN != 0xFF) {                   /* the alarm settings (after MISC 10) */
        if (a <= 10 || a == 12) acf_put(a);
        else if (a == 11) acf_end();
        return;
    }
    if (c == BB_C_CRD) {
        static char cb[12]; static uint8_t cn = 0xFF;
        if (a == 10) cn = 0;
        else if (a <= 9) { if (cn < sizeof cb - 1) cb[cn++] = (char)('0' + a); }
        else if (a == 11) { if (cn != 0xFF) { cb[cn] = 0; memcpy(p12.credit, cb, cn + 1); p12.crdBusy = 0; p12.crdGen++; } cn = 0xFF; }
        else if (a == 12) { p12.credit[0] = 0; p12.crdBusy = 0; p12.crdGen++; cn = 0xFF; }
        else if (a == 13) p12.crdBusy = 1;
        return;
    }
    if (c == BB_C_EV) { if (a >= 1 && a <= 13) wf_event(a); return; }
    if (c == BB_C_CUR && a >= 1 && a <= 6) {
        uint8_t ci = (uint8_t)((a - 1) / 3), op = (uint8_t)((a - 1) % 3), ko = CK[ci][0], kc = CK[ci][1];
        if (S.c.type[ko] != T_ILOCK) return;
        uint8_t ro = (S.red & BIT(ko)) != 0, rc = (S.red & BIT(kc)) != 0;
        if (op == 2) { if (ro) sw_app_press(&S, ko, now); else if (rc) sw_app_press(&S, kc, now); return; }
        uint8_t want = op == 0 ? ko : kc, other = op == 0 ? kc : ko;
        if (S.red & BIT(want)) return;
        if (S.red & BIT(other)) { sw_app_press(&S, other, now); curPend = want; curPendAt = now + 600; }   /* stop first, then the new way */
        else sw_app_press(&S, want, now);
    }
}
/* ---------------- app commands to the alarm MCU (bus C frame 5, ..., see bus12.h) ---------------- */
static uint8_t apWant, apAct, apZn; static uint16_t apCode;
static uint8_t apQ[6][4], apN;                 /* app frames waiting (settings: up to 6 for one phone number) */
uint8_t p12_app_free(void) { return (uint8_t)(6 - apN); }
uint8_t p12_app_send(uint8_t act, uint8_t zones, uint16_t code)
{
    if (apN >= 6) return 0;
    apQ[apN][0] = act; apQ[apN][1] = zones ? zones : 7; apQ[apN][2] = (uint8_t)(code >> 8); apQ[apN][3] = (uint8_t)code; apN++;
    if (!apWant) { apAct = apQ[0][0]; apZn = apQ[0][1]; apCode = (uint16_t)(apQ[0][2] << 8 | apQ[0][3]); apN--; memmove(apQ[0], apQ[1], apN * 4); apWant = 1; }
    return 1;
}
/* ---------------- child lock (S6 held 7 s): touches do nothing, the remote still works ---------------- */
#define T_LOCKHOLD 7000
static uint8_t lockFlip, lockNow;
uint8_t p12_app_key(uint8_t k) { if (k != clk || clk >= SW_NP) return 0; lockFlip = 1; return 1; }
pm_t p12_lock_bits(void) { return lockNow && clk < SW_NP ? BIT(clk) : 0; }

int main(void)
{
    uint8_t why = MCUCSR;
    MCUCSR |= _BV(JTD); MCUCSR |= _BV(JTD);              /* JTAG off: PF4..PF7 */
    MCUCSR = 0;
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0x0D; PORTB = 0xF7;                            /* bus C idle: PB2 PB0 high */
    DDRC = 0x80; PORTC = 0x7F;
    DDRD = 0x7B; PORTD = 0xF3;                            /* bus A idle 11111 */
    DDRE = 0xBE; PORTE = 0xC0;                            /* bus C: PE7 high */
    DDRF = 0xFF; PORTF = 0x7F;                            /* 7-segment dark (common anode); PF7 = Wi-Fi module EN, low until 8 s after power-up */
    DDRG = 0xFF; PORTG = 0x00;                            /* everything off until the motion */
    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS02);           /* 1 ms */
    TIMSK |= _BV(OCIE0);
    TCCR1A = 0; TCCR1B = _BV(CS11);                       /* 1 us for the remote */
    EICRB = _BV(ISC60); EIFR = _BV(INTF6); EIMSK |= _BV(INT6);

    for (uint16_t i = 0; i < CFG_SIZE; i++) ((uint8_t *)&S.c)[i] = pgm_read_byte(&cfg_flash[i]);
    if (!sw_cfg_ok(&S.c)) defaults(&S.c);
    S.eer = ee_r; S.eew = ee_w;
    for (uint8_t c = 0; c < 2; c++) { pos[c] = eeprom_read_word((const uint16_t *)(EE_POS + 2 * c)); if (pos[c] > 1000) pos[c] = 0; }
    uint32_t t0 = now_ms();
    sei();
    sw_init(&S, &S.c, t0);
    if (px_valid()) S.pxm = px_mask;
    clk = (uint8_t)(S.c.clk - 1);                         /* 0xFF: no child lock */
    for (exk = 0; exk < SW_NP && S.c.type[exk] != T_EXIT; exk++) ;   /* the exit scenario (S5 by default) */
    UBRR1H = 0; UBRR1L = 51;                              /* 9600 at 8 MHz */
    UCSR1A = 0;
    UCSR1C = _BV(UCSZ11) | _BV(UCSZ10);
    UCSR1B = _BV(RXCIE1) | _BV(RXEN1) | _BV(TXEN1);
    S.tx = net_tx;
    S.logOn = (why & (_BV(PORF) | _BV(BORF))) != 0;
    wdt_enable(WDTO_1S);
    memset(sentV, V_OFF, sizeof sentV);                   /* the boards start with every key off */
    memset(regV, 0xFF, sizeof regV);

    uint8_t kLast = 0, kCnt = 0, wasDim = 0, disp = 0xFF, motionSent = 0, view = 0, movWas = 0;
    uint8_t locked = 0, s6Hold = 0, s6Ok = 0, s6Done = 0, exitRun = 0, sgKey = 0, room = 0, rSeq = 0, rWait = 0, rTry = 0, rOn = 0, rRoom = 0;
    uint32_t sgAt = 0, rAt = 0, roomShowUntil = 0;
    uint16_t red12 = 0, s6Ms = 0, clickMs = 0;
    pm_t keys = 0;
    uint32_t motAt = t0 + 300, lastAct = t0, flashUntil = 0, last = t0, overUntil = 0, clkAt = t0;
    uint8_t flashK = 0xFF;
    uint32_t scnOkUntil = 0;
    uint8_t bcSt = 0, bcLk = 0, bcWant = 0, bcPh = 0, bcSeq[10], bcSN = 0, bcSI = 0, bcRound = 0;
    uint16_t bcPm = 0xFFFF;
    uint16_t bcMs = 0;
    uint32_t bcAt = t0;
    for (;;) {
        wdt_reset();
        uint32_t now = now_ms();
        if (now == last) continue;
        uint16_t dt = (uint16_t)(now - last);
        last = now;
        while (now - clkAt >= 1000) { clkAt += 1000; clock_sec(); }
        uint8_t inMotion = !motionSent || (now - motAt) < 1500;
        /* touch: the code steady for 3 ms */
        uint8_t r = touch_raw();
        if (r == kLast) { if (kCnt < 255) kCnt++; } else { kLast = r; kCnt = 0; }
        if (kCnt == 3) {
            uint8_t k = r ? pgm_read_byte(&KEYIDX[r - 1]) : NK;
            if (k >= SG_ON && k != NK) { sgKey = k; k = NK; }   /* a 7-segment key: handled below, not a panel key */
            keys = k == NK ? 0 : BIT(k);
            if (r && !locked && !S.dimmed && !inMotion) {
                lastAct = now;
                if (k != K_P1O && k != K_P1C && k != K_P2O && k != K_P2C && k != clk) overUntil = now + 5000;   /* the command touched is shown first */
            }
        }
        /* child lock (S6 by default; the programmer picks the key or none), held 7 s (a touch that only wakes the panel does not count) */
        if (clk < SW_NP && (keys & BIT(clk))) {
            if (!s6Hold) { s6Hold = 1; s6Ms = 0; s6Done = 0; s6Ok = !S.dimmed && !inMotion; }
            else if (s6Ms < 65000) s6Ms += dt;
            if (s6Ok && !s6Done && s6Ms >= T_LOCKHOLD) { s6Done = 1; locked = !locked; clickMs = 150; lastAct = now; }
        } else s6Hold = 0;
        if (lockFlip) { lockFlip = 0; locked = !locked; clickMs = 150; lastAct = now; }   /* the phone app touched the child-lock key */
        lockNow = locked;
        pm_t k2 = keys;
        if (clk < SW_NP && !S.dimmed) k2 &= (pm_t)~BIT(clk);   /* the child-lock key does nothing else; in standby it only wakes */
        if (locked) { k2 = 0; S.idleSec = 0; }               /* locked: no touch reaches the panel, and no standby */
        if ((gsmBusy || (int32_t)(now - gsmFreeAt) < 0) && S.c.type[K_EL] == T_ELEV) k2 &= (pm_t)~BIT(K_EL);   /* the GSM module works (SMS in / out, call): the elevator key waits (its radio can look like a touch); the other keys work */
        sw_tick(&S, now, k2);
        /* master: once it starts stepping, everything waits until the last pole is done */
        if (!sw_mlock && (k2 & BIT(K_M)) && S.pendMask) sw_mlock = 1;
        if (sw_mlock && !S.pendMask) sw_mlock = 0;
        /* exit scenario (S5): counting down -> OLED 1 shows it; at the end the curtains that are open close */
        {
            static uint8_t exWas;
            uint8_t ex = exk < SW_NP && (S.red & BIT(exk)) != 0;
            if (exWas && !ex && (S.c.minutes[exk] & 1))
                for (uint8_t c = 0; c < 2; c++) {
                    uint8_t ko = CK[c][0], kc = CK[c][1];
                    if (S.c.type[ko] == T_ILOCK && !(S.red & BIT(kc)) && pos[c] > 0) { if (S.red & BIT(ko)) { curPend = kc; curPendAt = now + 600; } else sw_app_press(&S, kc, now); }
                }
            exWas = ex;
            exitRun = ex;
            if (ex) set_reg(R_CNT, S.tmrSec[exk]);
        }
        /* custom scenario: stored -> A blinks; run -> its red for a moment */
        if (S.scnEv == 1) { send(TG_A, A_BLINK, 1); lastAct = now; scnOkUntil = now + 2000; }
        if (S.scnEv == 2) { flashK = S.scnKey; flashUntil = now + 300; }
        S.scnEv = 0;
        /* curtains: position from the run time */
        uint8_t mov = 0;
        for (uint8_t c = 0; c < 2; c++) {
            if (S.c.type[CK[c][0]] != T_ILOCK) continue;   /* the curtain keys are plain poles in this project */
            uint8_t o = (S.red & BIT(CK[c][0])) != 0, cl = (S.red & BIT(CK[c][1])) != 0;
            uint8_t sec = S.c.sec1[CK[c][cl]]; if (!sec) sec = 45;
            if (o || cl) {
                if (!(movWas & (3 << (2 * c)))) { runMs[c] = 0; pacc[c] = 0; view = (uint8_t)(c + 1); overUntil = 0; }
                runMs[c] += dt; pacc[c] += dt;
                while (pacc[c] >= sec) { pacc[c] -= sec; if (o && pos[c] < 1000) pos[c]++; if (cl && pos[c] > 0) pos[c]--; }
                mov |= (uint8_t)((o ? 1 : 2) << (2 * c));
            } else if (movWas & (3 << (2 * c))) eeprom_update_word((uint16_t *)(EE_POS + 2 * c), pos[c]);
        }
        if (view && !(mov & (3 << (2 * (view - 1))))) {       /* the curtain in view stopped: the other one, or the usual view */
            uint8_t other = view == 1 ? 2 : 1;
            view = (mov & (3 << (2 * (other - 1)))) ? other : 0;
            if (!view) { lastAct = now; overUntil = 0; }
        }
        if (mov) lastAct = now;
        movWas = mov;
        /* the power-up motion (and the same when waking from standby) */
        if (!motionSent && (int32_t)(now - motAt) >= 0) {
            send(TG_SYS, SYS_MOTION, 1); motionSent = 1; motAt = now;
            for (uint8_t i = 0; i < sizeof sentV; i++) if (sentV[i] == V_DARK || sentV[i] == 0xFF) sentV[i] = V_OFF;   /* the boards do the same */
        }
        if (S.dimmed) wasDim = 1;
        else if (wasDim) { wasDim = 0; motionSent = 0; motAt = now; lastAct = now; }
        /* bus C to the alarm MCU: standby / awake and child lock, a change at once, both again every 2 s */
        {
            uint8_t st = S.dimmed ? BC_STANDBY : BC_AWAKE, lk = locked ? BC_LOCKED : exitRun ? BC_EXITLK : BC_UNLOCKED;
            if (st != bcSt) { bcSt = st; bcWant |= 1; }
            if (lk != bcLk) { bcLk = lk; bcWant |= 2; }
            uint16_t pm = (uint16_t)(S.red & 0x7FFF);                      /* poles 1..15 on: for the SMS status */
            if (pm != bcPm) { bcPm = pm; bcWant |= 4; }
            if (now - bcAt >= 2000) { bcAt = now; bcWant |= 3; if (++bcRound >= 5) { bcRound = 0; bcWant |= 4; } }
            if (bcMs) bcMs = bcMs > dt ? (uint16_t)(bcMs - dt) : 0;
            if (!bcMs) {
                if (bcPh == 1) { busC(BC_IDLE); bcPh = 0; bcMs = BC_GAP; }
                else if (bcSI < bcSN) { busC(bcSeq[bcSI++]); bcPh = 1; bcMs = BC_HOLD; }
                else if ((bcWant || apWant) && (now - t0 > 2000 || (motionSent && now - motAt >= 1400))) {   /* the first states as soon as the power-up motion ends */
                    bcSN = 0; bcSI = 0;
                    if (apWant) {                                            /* app frame: 5, action, zones - 1, 6 base-7 digits of the code, sum mod 7 */
                        uint16_t v = apCode; uint8_t d[6], sum = 0;
                        for (int8_t i = 5; i >= 0; i--) { d[i] = (uint8_t)(v % 7); v /= 7; }
                        bcSeq[bcSN++] = BC_APP; bcSeq[bcSN++] = apAct; bcSeq[bcSN++] = (uint8_t)(apZn - 1);
                        sum = (uint8_t)(apAct + apZn - 1);
                        for (uint8_t i = 0; i < 6; i++) { bcSeq[bcSN++] = d[i]; sum = (uint8_t)(sum + d[i]); }
                        bcSeq[bcSN++] = (uint8_t)(sum % 7);
                        apWant = 0;
                        if (apN) { apAct = apQ[0][0]; apZn = apQ[0][1]; apCode = (uint16_t)(apQ[0][2] << 8 | apQ[0][3]); apN--; memmove(apQ[0], apQ[1], apN * 4); apWant = 1; }
                    }
                    else if (bcWant & 1) { bcSeq[bcSN++] = bcSt; bcWant &= (uint8_t)~1; }
                    else if (bcWant & 2) { bcSeq[bcSN++] = bcLk; bcWant &= (uint8_t)~2; }
                    else {                                                   /* pole frame: 0, 6 base-7 digits, check */
                        bcWant &= (uint8_t)~4; uint16_t v = bcPm; uint8_t d[6], sum = 0;
                        for (int8_t i = 5; i >= 0; i--) { d[i] = (uint8_t)(v % 7); v /= 7; }
                        bcSeq[bcSN++] = 0; for (uint8_t i = 0; i < 6; i++) { bcSeq[bcSN++] = d[i]; sum = (uint8_t)(sum + d[i]); } bcSeq[bcSN++] = (uint8_t)(sum % 7);
                    }
                }
            }
        }
        /* bus B frames from the alarm MCU (SMS commands, GSM busy, wake): a symbol counts steady 3 ms after an idle */
        while (bbQt != bbQh) { uint8_t c = bbQ[bbQt & 7][0], a = bbQ[bbQt & 7][1]; bbQt++; bb_cmd(c, a, now); }
        /* RS485: the other panel (sw.c) and the rooms' answers */
        while (n1rt != n1rh) { uint8_t b = n1rx[n1rt]; n1rt = (uint8_t)((n1rt + 1) & 63); sw_rx(&S, b, now); }
        sw_link(&S, now);
        /* Wi-Fi: PF7 = the module's EN (as the earlier firmware: on 8 s after power-up, the master held 3 s turns it on / off,
           kept over a power cut); the UART starts with it */
        {
            uint8_t want = S.wifi, on = want && now - t0 >= 8000;
            if (on) PORTF |= 0x80; else PORTF &= (uint8_t)~0x80;
            S.wifi = on; wf_poll(&S, now); S.wifi = want;
        }
        /* credit asked by the app: sent to the alarm MCU as soon as bus C is free; no answer in 35 s = "not done" for the app */
        {
            static uint32_t crdAt; static uint8_t was;
            if (p12.crdBusy && !was) crdAt = now;
            was = p12.crdBusy;
            if (p12.crdWant && p12_app_send(4, 1, 0)) { p12.crdWant = 0; crdAt = now; }
            else if (p12.crdBusy && !p12.crdWant && now - crdAt >= 35000) { p12.credit[0] = 0; p12.crdBusy = 0; p12.crdGen++; was = 0; }
        }
        /* a phone app connected: ask the alarm MCU for its states (it reports for 60 s after each ask) */
        {
            static uint32_t askAt; static uint8_t had;
            uint8_t ph = wf_phones() != 0;
            if (ph && (!had || now - askAt >= 30000) && p12_app_send(5, 1, 0)) { askAt = now; had = 1; }
            if (!ph) had = 0;
        }
        /* 7-segment: up / down = room 1..9, left (OFF) / right (ON) = all poles of that room off / on; 10 s alone = dash */
        if (sgKey) {
            uint8_t k = sgKey; sgKey = 0;
            if (S.dimmed) { S.dimmed = 0; S.idleSec = 0; S.idleMs = 0; }          /* a dark panel: the touch only wakes it */
            else if (!locked && !inMotion && !sw_mlock && !exitRun) {
                S.idleSec = 0; S.idleMs = 0; lastAct = now; sgAt = now; clickMs = 60;
                uint16_t rm = S.c.rooms & 0x1FF;
                if ((k == SG_UP || k == SG_DN) && rm) {
                    uint8_t r = room;
                    for (uint8_t i = 0; i < 9; i++) {
                        r = k == SG_UP ? (uint8_t)(r % 9 + 1) : (uint8_t)(r <= 1 ? 9 : r - 1);
                        if (rm & (1 << (r - 1))) break;
                    }
                    room = r;
                }
                else if ((k == SG_ON || k == SG_OFF) && room && !rWait) {
                    rRoom = room; rOn = k == SG_ON; rSeq = (uint8_t)(rSeq + 1 ? rSeq + 1 : 1); rTry = 0; rWait = 1; rAt = now - 1000;
                }
            }
        }
        if (room && now - sgAt >= 10000) room = 0;
        if (rWait) {                                       /* send, wait 200 ms for the answer, 4 tries */
            if (S.rackFrom == ROOM_FROM(rRoom) && S.rackSeq == rSeq) {
                rWait = 0; S.rackFrom = 0;
                set_reg(R_ROOM, rRoom); set_reg(R_RRES, rOn); roomShowUntil = now + 3000; lastAct = now;
            } else if (now - rAt >= 200) {
                if (rTry < 4) { rTry++; rAt = now; sw_room_send(&S, rRoom, rSeq, rOn); }
                else { rWait = 0; set_reg(R_ROOM, rRoom); set_reg(R_RRES, 2); roomShowUntil = now + 3000; lastAct = now; }
            }
        }
        if (S.dimmed) PORTF |= 0x7F;                       /* standby: dark */
        else seg_show(inMotion ? 11 : room ? room : 10);
        if (curPend && (int32_t)(now - curPendAt) >= 0) { uint8_t k = curPend; curPend = 0; if (!(S.red & BIT(k))) sw_app_press(&S, k, now); }
        if (inMotion) { motion_whites(motionSent ? (uint16_t)(now - motAt) : 0); PORTG &= (uint8_t)~_BV(3); continue; }
        /* own keys 14 and 15, click relay */
        uint8_t g = PORTG & (uint8_t)~(_BV(0) | _BV(1) | _BV(2) | _BV(3) | _BV(4));
        if (S.white & BIT(K_14)) g |= _BV(1);
        if (S.red & BIT(K_14)) g |= _BV(0);
        if (S.white & BIT(K_15)) g |= _BV(2);
        if (S.red & BIT(K_15)) g |= _BV(4);
        if (clickMs) { clickMs = clickMs > dt ? (uint16_t)(clickMs - dt) : 0; g |= _BV(3); }
        if (S.buzz) g |= _BV(3);
        PORTG = g;
        /* the other keys: over bus A, each time one changes */
        for (uint8_t k = 0; k < SW_NP; k++) {
            uint8_t tg = pgm_read_byte(&TGT[k]);
            if (!tg) continue;
            uint8_t v = (S.red & BIT(k)) ? V_ON : (S.white & BIT(k)) ? V_OFF : V_DARK;
            if (k == flashK && (int32_t)(now - flashUntil) < 0) v = V_ON;
            if (k == clk) v = locked ? V_ON : v;            /* child lock: S6 red */
            if (v != sentV[tg]) { if (v != V_DARK) lastAct = now; sentV[tg] = v; send(tg, v, 2); }
        }
        if ((int32_t)(now - flashUntil) >= 0) flashK = 0xFF;
        /* indicator D: the SIM state from the alarm MCU (good signal red, weak blinking red, no SIM white) */
        { uint8_t v = simSt == 2 ? V_ON : simSt == 1 ? V_BLINK : V_OFF; if (v != sentV[TG_D]) { sentV[TG_D] = v; send(TG_D, v, 1); } }
        /* indicator C (home, N3): red while the Wi-Fi module is on (its EN high), white when the master hold turned it off */
        { uint8_t v = (S.wifi && now - t0 >= 8000) ? V_ON : V_OFF; if (v != sentV[TG_C]) { sentV[TG_C] = v; send(TG_C, v, 1); } }
        /* a pole 1..12 changed (from anywhere): its state is shown first, for 5 s */
        uint16_t r12 = (uint16_t)(S.red & 0x0FFF);
        if (r12 != red12) { red12 = r12; overUntil = now + 5000; lastAct = now; }
        /* OLED data */
        set_reg(R_HOUR, cH); set_reg(R_MIN, cM); set_reg(R_WDAY, cWd); set_reg(R_YEAR, (uint16_t)(cY - 1300)); set_reg(R_MON, cMo); set_reg(R_DAY, cD);
        set_reg(R_POS1, (uint16_t)((pos[0] + 5) / 10)); set_reg(R_POS2, (uint16_t)((pos[1] + 5) / 10)); set_reg(R_MOV, mov);
        if (view) {
            uint8_t c = (uint8_t)(view - 1), cl = (mov >> (2 * c + 1)) & 1;
            uint8_t sec = S.c.sec1[CK[c][cl]]; if (!sec) sec = 45;
            uint32_t ms2 = (uint32_t)sec * 1000;
            set_reg(R_LEFT, runMs[c] >= ms2 ? 0 : (uint16_t)((ms2 - runMs[c] + 999) / 1000));
        }
        /* OLED view: a pole change / a touched command first (5 s), a moving curtain, the usual view, the clock after 1 minute */
        uint8_t d;
        uint8_t scnHold = S.holdKey != 0xFF && !S.holdDone && S.c.type[S.holdKey] == T_CUSTOM && S.holdMs >= 300;
        if (scnHold) set_reg(R_CNT, (uint16_t)((T_SCNHOLD - S.holdMs + 999) / 1000));
        if (S.dimmed) d = D_STANDBY;
        else if (exitRun) d = D_EXIT;
        else if ((int32_t)(now - roomShowUntil) < 0) d = D_ROOM;
        else if (scnHold) d = D_SCNHOLD;
        else if ((int32_t)(now - scnOkUntil) < 0) d = D_SCNOK;
        else if ((int32_t)(now - overUntil) < 0) d = D_STATES;
        else if (view) d = (uint8_t)(D_CUR + 2 * (view - 1) + ((mov >> (2 * (view - 1) + 1)) & 1));
        else d = (now - lastAct >= 60000UL) ? D_CLOCK : D_STATES;
        if (d != disp) { disp = d; send(TG_DISP, d, 1); }
        /* every state again now and then (a lost frame heals), when nothing else waits */
        if (!qN && !S.pendMask && now - refreshAt >= 150) {   /* not while the master steps: each pole frame then leaves at once, even rhythm */
            refreshAt = now;
            if (refreshI == 25) refreshI = TG_C;
            if (refreshI == TG_C) { send(TG_C, sentV[TG_C], 0); refreshI = TG_D; }
            else if (refreshI == TG_D) { send(TG_D, sentV[TG_D], 0); refreshI = TG_DISP; }
            else
            if (refreshI == TG_DISP) { send(TG_DISP, disp, 0); refreshI = 32; }
            else if (refreshI >= 32) { uint8_t rg = (uint8_t)(refreshI - 32 + R_FIRST); send((uint8_t)(0x80 | rg), regV[rg - R_FIRST], 0); if (++refreshI >= 32 + R_N) refreshI = 1; }
            else { if (sentV[refreshI] != 0xFF) send(refreshI, sentV[refreshI], 0); refreshI++; }
        }
    }
}
