#!/bin/sh
# 23-key board (ATmega32 inputs + ATmega64 main): one ATmega32 program for every model,
# ATmega64 programs only with the pole kinds the panel uses (_s push buttons, _i curtain/cooler/off timer)
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
mkdir -p out
rm -f out/fw_big*.hex
F="-DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 -mcall-prologues -mrelax -flto -ffunction-sections -fdata-sections -Wl,--gc-sections"
avr-gcc -mmcu=atmega32 $F io32.c -o out/fw_big_io32.elf
avr-objcopy -O ihex -R .eeprom out/fw_big_io32.elf out/fw_big_io32.hex
printf "%-20s " fw_big_io32; avr-size out/fw_big_io32.elf | tail -1
big() {   # name sec ilock scn alarm [pair]
  P="-DHAS_PAIR=0 -DHAS_PX=0"; [ "$6" = 1 ] && P="-DHAS_PX=1 -Wl,--section-start=.swpx=0xF300"
  avr-gcc -mmcu=atmega64 $F -DSW_BIG -DFW_BOARD=BOARD_BIG -DHAS_REMOTE=1 $P -DHAS_SEC=$2 -DHAS_ILOCK=$3 -DHAS_SCN=$4 -DHAS_ALARM=$5 \
    -Wl,--section-start=.swcfg=0xF000 main64.c sw.c wifi64.c -o out/$1.elf
  avr-objcopy -O ihex -R .eeprom out/$1.elf out/$1.hex
  printf "%-20s " $1; avr-size out/$1.elf | tail -1
}
# fw_big[_a][_s][i][x][_p]: _a = alarm panels, s = push buttons, i = curtain/cooler/off timer, x = EXIT/SLEEP/ELEVATOR,
# _p = two-panel network (RS485 on USART1; only these hexes hold the network)
for p in 0 1; do for a in 0 1; do for g in "" s i x si sx ix six; do
  n=fw_big; [ $a = 1 ] && n=${n}_a; [ -n "$g" ] && n=${n}_$g; [ $p = 1 ] && n=${n}_p
  case $g in *s*) S=1;; *) S=0;; esac; case $g in *i*) I=1;; *) I=0;; esac; case $g in *x*) X=1;; *) X=0;; esac
  big $n $S $I $X $a $p
done; done; done
