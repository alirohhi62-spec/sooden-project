/* Sooden panels - ATmega8 @ 8 MHz (crystal: fuses 3F/D1, internal RC: 24/D1)
 * One source, one hex per panel kind; each hex holds only what that panel has:
 *   FW_BOARD    BOARD_4P or BOARD_2P
 *   HAS_REMOTE  433 MHz receiver (4P only)
 *   HAS_PAIR    RS485 link to one other panel (two-panel network, no CPU)
 * 4P board (3/4 pole): touch BS818A-2 on PC2 (valid, low) + PC3..PC5 (code)
 *   pole1 W=PB1 R=PB2, pole2 W=PB0 R=PD7, pole3 W=PC0 R=PC1, pole4 W=PD5 R=PD6
 *   433 MHz data on PD3 (INT1), active buzzer on PD2 (high = beep)
 * 2P board (1/2 pole): touch pole1=PB5, pole2=PD4 (active low), out pole1=PB3 pole2=PB4
 *   1-pole panel (npoles = 1): touch PD5 (centre pad), out PB4 (as the earlier 1-pole network firmware)
 *   HAS_BELL (bell push, same board): touch PD5, bell relay PB3 (the other pole), do-not-disturb red PB4;
 *     short touch (lifted) = the bell for its time (sec1 | sec2 << 8 of pole 1, 0.1 s), held 5 s = do-not-disturb
 *     (kept in EEPROM); the other panel's linked key rings it too (the bell is pole 1, an ordinary pole on the network)
 * RS485 (auto-direction MAX485 module): RXD/TXD, 9600 8N1
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include "sw.h"

#ifndef F_CPU
#define F_CPU 8000000UL
#endif
#ifndef FW_BOARD
#error "build with -DFW_BOARD=BOARD_4P or -DFW_BOARD=BOARD_2P"
#endif
#if FW_BOARD == BOARD_2P && HAS_REMOTE
#error "the 1/2 pole board has no 433 MHz receiver"
#endif

/* configuration block, patched by the programmer (0xFF = not configured) */
const uint8_t cfg_flash[CFG_SIZE] __attribute__((section(".swcfg"), used)) = { [0 ... CFG_SIZE - 1] = 0xFF };
#if HAS_PX
/* two-panel network v2: keys of the other panel in each key's scenario, patched by the programmer */
const uint8_t px_flash[PX_SIZE] __attribute__((section(".swpx"), used)) = { [0 ... PX_SIZE - 1] = 0xFF };
static uint8_t px_mask(uint8_t k, uint8_t which, uint8_t *m)
{
    if (k >= 4) return 0;
    const uint8_t *p = &px_flash[3 + (which ? 12 : 0) + 3 * k];
    m[2] = pgm_read_byte(p); m[1] = pgm_read_byte(p + 1); m[0] = pgm_read_byte(p + 2);   /* stored high byte first */
    m[2] &= 0x7F;
    return (uint8_t)(m[0] | m[1] | m[2]);
}
static uint8_t px_valid(void)
{
    uint8_t b[PX_SIZE];
    for (uint8_t i = 0; i < PX_SIZE; i++) b[i] = pgm_read_byte(&px_flash[i]);
    return b[0] == PX_M0 && b[1] == PX_M1 && b[2] == 4 && sw_crc8(b, PX_SIZE - 1) == b[PX_SIZE - 1];
}
#endif

static Sw S;
static volatile uint32_t ms;

ISR(TIMER2_COMP_vect) { ms++; }

static uint32_t now_ms(void)
{
    uint32_t v;
    cli(); v = ms; sei();
    return v;
}

#if HAS_PAIR
static volatile uint8_t rxq[32];
static volatile uint8_t rxh, rxt;

ISR(USART_RXC_vect)
{
    /* framing errors are NOT dropped: auto-direction RS485 modules often bend the stop bit;
       every frame is protected by its CRC anyway (same as the original firmware) */
    uint8_t b = UDR;
    uint8_t n = (uint8_t)((rxh + 1) & 31);
    if (n != rxt) { rxq[rxh] = b; rxh = n; }
}

static void uart_put(uint8_t b)
{
    while (!(UCSRA & _BV(UDRE))) wdt_reset();
    UDR = b;
}

static void uart_tx(const uint8_t *p, uint8_t n)
{
    uart_put(0xFF);                   /* lead-in byte: lets the auto-direction module and the
                                         far receiver settle; ignored by the frame parser */
    while (n--) uart_put(*p++);
}
#endif

#if HAS_REMOTE
static uint16_t rfLast;
ISR(INT1_vect)
{
    uint16_t t = TCNT1;
    uint16_t dt = t - rfLast;
    rfLast = t;
    sw_rf_edge(&S, dt, (PIND & _BV(3)) ? 1 : 0);
}
static uint8_t ee_r(uint16_t a) { return eeprom_read_byte((const uint8_t *)a); }
static void ee_w(uint16_t a, uint8_t v) { eeprom_update_byte((uint8_t *)a, v); }
#endif

#if FW_BOARD == BOARD_4P
static uint8_t read_keys(void)
{
    if (PINC & _BV(2)) return 0;              /* no touch */
    uint8_t code = (PINC >> 3) & 7;           /* PC3=bit0 PC4=bit1 PC5=bit2 */
    switch (code) {
    case 7: return 0x01;
    case 0: return 0x02;
    case 3: return 0x04;
    case 4: return 0x08;
    default: return 0;
    }
}

static void write_outputs(uint8_t w, uint8_t r, uint8_t bz)
{
    uint8_t b = PORTB & (uint8_t)~(_BV(0) | _BV(1) | _BV(2));
    uint8_t c = PORTC & (uint8_t)~(_BV(0) | _BV(1));
    uint8_t d = PORTD & (uint8_t)~(_BV(2) | _BV(5) | _BV(6) | _BV(7));
    if (bz) d |= _BV(2);                      /* active buzzer on PD2 */
    if (w & 1) b |= _BV(1);
    if (r & 1) b |= _BV(2);
    if (w & 2) b |= _BV(0);
    if (r & 2) d |= _BV(7);
    if (w & 4) c |= _BV(0);
    if (r & 4) c |= _BV(1);
    if (w & 8) d |= _BV(5);
    if (r & 8) d |= _BV(6);
    PORTB = b; PORTC = c; PORTD = d;
}
#else
static uint8_t onePole;                       /* 1-pole panel: centre pad PD5, out PB4 */
#if HAS_BELL
static uint8_t dnd;
static uint8_t bellPress;                     /* ms left of a made-up touch of pole 1 (the core switches it like a touch) */
#endif
static uint8_t read_keys(void)
{
    uint8_t k = 0;
#if HAS_BELL
    return bellPress ? 0x01 : 0;              /* the bell key itself is read in the main loop */
#endif
    if (onePole) { if (!(PIND & _BV(5))) k |= 0x01; return k; }
    if (!(PINB & _BV(5))) k |= 0x01;
    if (!(PIND & _BV(4))) k |= 0x02;
    return k;
}

static void write_outputs(uint8_t w, uint8_t r, uint8_t bz)
{
    (void)w; (void)bz;
    uint8_t b = PORTB & (uint8_t)~(_BV(3) | _BV(4));
#if HAS_BELL
    if (r & 1) b |= _BV(3);
    if (dnd) b |= _BV(4);
#else
    if (onePole) { if (r & 1) b |= _BV(4); }
    else {
        if (r & 1) b |= _BV(3);
        if (r & 2) b |= _BV(4);
    }
#endif
    PORTB = b;
}
#endif

int main(void)
{
    uint8_t why = MCUCSR;                     /* reset cause: power-on / brown-out / external (ISP) / watchdog */
    MCUCSR = 0;
    (void)why;
    uint8_t buf[CFG_SIZE];
    for (uint8_t i = 0; i < CFG_SIZE; i++) buf[i] = pgm_read_byte(&cfg_flash[i]);
    const Cfg *cfg = (const Cfg *)buf;

    if (!sw_cfg_ok(cfg)) {
        /* not configured (or settings made for another panel kind): every pin stays an input */
        for (;;) ;
    }

    /* pin directions copied from the original firmwares (unused pins driven low);
       PB6/PB7 are the crystal pins and are left alone */
#if FW_BOARD == BOARD_4P
    DDRB = 0x3F;  PORTB = 0x00;
    DDRC = 0x03;  PORTC = 0x3C;               /* touch PC2..PC5 inputs with pull-up */
    DDRD = 0xF6;  PORTD = 0x08;               /* PD0 RXD, PD3 RF input with pull-up */
#else
    DDRB = 0x1F;  PORTB = 0x20;               /* PB5 touch input with pull-up */
    DDRC = 0x3F;  PORTC = 0x00;
    DDRD = 0xCE;  PORTD = 0x30;               /* PD0 RXD, PD4 touch, PD5 pull-up */
#endif

#if FW_BOARD == BOARD_2P
    onePole = cfg->npoles == 1;
#endif
#if HAS_PAIR
    /* UART 9600 8N1 @ 8 MHz */
    UBRRH = 0; UBRRL = 51;
    UCSRA = 0;
    UCSRC = _BV(URSEL) | _BV(UCSZ1) | _BV(UCSZ0);
    UCSRB = _BV(RXCIE) | _BV(RXEN) | _BV(TXEN);
    S.tx = uart_tx;
#endif

    /* Timer2: 1 ms CTC (8 MHz / 64 / 125) */
    OCR2 = 124;
    TCCR2 = _BV(WGM21) | _BV(CS22);
    TIMSK |= _BV(OCIE2);

#if HAS_REMOTE
    S.eer = ee_r; S.eew = ee_w;
#endif
    sw_init(&S, cfg, 0);
#if HAS_PX
    if (px_valid()) S.pxm = px_mask;
#endif
#if HAS_REMOTE
    /* remote codes are recorded only after the mains was switched off and on again,
       not after the programmer (external reset) or the watchdog restarted the chip */
    S.logOn = (why & (_BV(PORF) | _BV(BORF))) != 0;
#endif

#if HAS_REMOTE
    if (cfg->remote) {
        TCCR1A = 0; TCCR1B = _BV(CS11);           /* 1 us ticks */
        MCUCR = (MCUCR & 0xF3) | _BV(ISC10);      /* INT1 any change */
        GIFR = _BV(INTF1);
        GICR |= _BV(INT1);
    }
#endif

    write_outputs(0, 0, 0);
    wdt_enable(WDTO_1S);
    sei();
#if HAS_BELL
    #define EE_DND ((uint8_t *)0x1F0)
    dnd = eeprom_read_byte(EE_DND) == 0xA5;
    uint16_t bellT = (uint16_t)(cfg->sec1[0] | cfg->sec2[0] << 8);
    if (!bellT || bellT > 6000) bellT = 30;
    uint32_t bellMs = (uint32_t)bellT * 100, ringAt = 0, lastMs = now_ms();
    uint16_t bCnt = 0, bHold = 0, quiet = 1000, bGap = 0;
    uint8_t bDown = 0, bReady = 0, bDone = 0, ringing = 0;
#endif

    for (;;) {
        wdt_reset();
        uint32_t now = now_ms();
#if HAS_PAIR
        while (rxt != rxh) {
            uint8_t b = rxq[rxt];
            rxt = (uint8_t)((rxt + 1) & 31);
            sw_rx(&S, b, now);
        }
#endif
#if FW_BOARD == BOARD_2P
        /* the touch IC calibrates after power-up and may show a touch: nothing in the first second,
           then a key counts only after it was seen released */
        {
            static uint8_t relSeen;
            uint8_t k = read_keys();
            if (now < 1000) { relSeen = 0; k = 0; }
            else { relSeen |= (uint8_t)(~k & 3); k &= relSeen; }
            sw_tick(&S, now, k);
        }
#else
        sw_tick(&S, now, read_keys());
#endif
#if HAS_BELL
        /* bell key PD5: a touch counts after 40 ms without a break, the next after 80 ms released, nothing in the
           first second, not before a released input was seen, 300 ms quiet after the relay changes */
        while (lastMs != now) {
            lastMs++;
            if (quiet) quiet--;
            if (bellPress) bellPress--; else if (bGap) bGap--;
            uint8_t low = !(PIND & _BV(5));
            if (!bDown) {
                if (low) { if (bCnt < 0xFFFF) bCnt++; } else { bCnt = 0; bReady = 1; }
                if (low && bReady && !quiet && bCnt >= 40) { bDown = 1; bCnt = 0; bHold = 40; bDone = 0; }
            } else {
                if (bHold < 0xFFFF) bHold++;
                if (!bDone && bHold >= 5000) {                    /* held 5 s: do-not-disturb on / off */
                    bDone = 1; dnd = !dnd; eeprom_update_byte(EE_DND, dnd ? 0xA5 : 0); quiet = 300;
                }
                if (!low) {
                    if (++bCnt >= 80) {
                        bDown = 0; bCnt = 0;
                        if (!bDone && !dnd && !(S.red & 1) && !bellPress && !bGap) { bellPress = 80; bGap = 200; quiet = 300; }   /* short touch: ring */
                    }
                } else bCnt = 0;
            }
        }
        /* the bell (from here or from the other panel's linked key): off after its time, at once in do-not-disturb */
        if (S.red & 1) {
            if (!ringing) { ringing = 1; ringAt = now; }
            if ((dnd || now - ringAt >= bellMs) && !bellPress && !bGap) { bellPress = 80; bGap = 200; quiet = 300; }   /* off: touch it again */
        } else ringing = 0;
#endif
        write_outputs(S.white, S.red, S.buzz);
#if HAS_PAIR
        sw_link(&S, now);
#endif
    }
}
