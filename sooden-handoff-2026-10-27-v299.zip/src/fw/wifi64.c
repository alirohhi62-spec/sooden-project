/* Sooden 23-key board - Wi-Fi: ESP8266 with AT firmware on USART0 (PE0 = RXD from the ESP, PE1 = TXD to the ESP),
 * 9600 8N1, powered by the ATmega32 (PD5 -> MP2315 EN) when Wi-Fi is on.
 *
 * Same AT start-up and same phone app protocol family as the RF-12 panel (cod_gcc.c v3), but nothing here waits:
 * the UART runs on interrupts with ring buffers, every AT step has a time limit, and the touch / link / relay work
 * of the main loop goes on meanwhile.
 *
 * ESP start-up: AT+CWMODE=3, AT+CIFSR (MAC), AT+CWSAP="<name>","sooden123",1,3 (when the name is new), AT+CIPMUX=1,
 * AT+CIPSERVER=1,6269, AT+CIFSR.  "ready" from the ESP (it restarted) starts it all again.
 *
 * Phone app commands (TCP 6269; up to 5 phones):
 *   @M_IP            -> %mac(17)+ip(16)+router name(20)%            (connection start / heartbeat, as RF-12)
 *   @M_F_C / @M_F_T  -> #T  /  #T*A1/Uaaaaaaaaaa/Vp1*L+#X1*Z1++     (old handshake, as RF-12)
 *   @M_MDL           -> $MDL=SD23-<model>-1.0$                       (the app opens the 23-key page)
 *   @M_VER           -> $VER=SD23-1.0$
 *   @M_LAY           -> $LAY#<23 letters>$                           (role of every key, place 1..20, scenario 1..3)
 *   @M_CAP           -> $CAP#A<alarm 0/1>R<remote 0/1>W1$
 *   @K               -> $K#xxxxxx$                                   (on/off of the 23 keys, bit 0 = place 1, hex)
 *   &K#nn            -> $A#nn#1$ done / $A#nn#0$ refused (panel locked by a short scenario, or not a key for that)
 *   @X1Z             -> $AL#n$     n: 0 off, 1 arming, 2 armed, 3 entry time, 4 siren
 *   &X1Z1#dddd       -> $ARM#ok$ (right password: arms / disarms) or $ARM#no$, then $AL#n$
 *   &X1P#dddd        -> $PASS=ok$ / $PASS=no$                        (only when disarmed; digits of this keypad)
 *   Lbl#nn#ii~text#  -> ok\n                                         (icon + up to 40 bytes of text, key nn = 01..23)
 *   @M_LBL#nn        -> $Lnn#ii~text$
 *   &CLK#ddddd#mmmm#ss / @M_CLK -> $CLK#1#ddddd#mmmm#P|N$ or $CLK#0$   (panel clock, Iran time; also from SNTP)
 *   Vac#... / @M_VAC -> $V#...$                                      (vacation program, see vac_cmd)
 *   #AT+CWJAP="router","password"#   -> later @M_S=<ip>  /  @M_S=Repeat\n  /  @M_S=Error\n
 *   *AT+CWSAP="name","password",1,4* -> (new panel network name / password; " , \ in them as \" \, \\)
 * Home router off: 20 s without it the module's station part stops (its own network stays usable), and every
 * 2 min with no phone connected the module restarts and tries the router again.
 * Every change of the panel goes to every connected phone by itself: $K#...$ (at most every 250 ms per phone,
 * so stepped switching becomes a few messages) and $AL#n$.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <string.h>
#include "wifi64.h"

#define AFTER(a, b) ((int32_t)((a) - (b)) >= 0)
#define NCONN   5
#ifdef SW_P12
#define LBL_TXT 20                     /* 12-pole SIM panel: 27 keys x 21 bytes at 0x540..0x776 (0x400.. holds its remotes) */
#define EE_LBL  0x540
#else
#define LBL_TXT 40
#define EE_LBL  0x400                  /* 23 x 41 bytes: 0x400..0x7AE */
#endif
#define LBL_SZ  (1 + LBL_TXT)          /* icon number (0xFF = none) + text (0-terminated if shorter) */
#define EE_APINIT 0x7C0                /* 0x5A: the default network name was given to the ESP once */
#define EE_USER 0x7C1                  /* router name, 20 bytes (shown by @M_IP) */
#define T_KGAP  250                    /* ms between two state messages to the same phone */

/* ---------------- UART ---------------- */
static volatile uint8_t rxb[256], rxh, rxt;
#define TXN 128
static volatile uint8_t txb[TXN], txh, txt;

ISR(USART0_RX_vect)
{
    uint8_t c = UDR0, n = (uint8_t)(rxh + 1);
    if (n != rxt) { rxb[rxh] = c; rxh = n; }
}
ISR(USART0_UDRE_vect)
{
    if (txt != txh) { UDR0 = txb[txt]; txt = (uint8_t)((txt + 1) & (TXN - 1)); }
    else UCSR0B &= (uint8_t)~_BV(UDRIE0);
}
static void tx(uint8_t c)
{
    uint8_t n = (uint8_t)((txh + 1) & (TXN - 1));
    while (n == txt) wdt_reset();                  /* full: wait for the interrupt to make room */
    txb[txh] = c; txh = n;
    UCSR0B |= _BV(UDRIE0);
}
static void tx_P(const char *p) { char c; while ((c = (char)pgm_read_byte(p++))) tx((uint8_t)c); }
static void tx_s(const char *s) { while (*s) tx((uint8_t)*s++); }
static void tx_nl(void) { tx('\r'); tx('\n'); }

static void uart_on(void)
{
    rxh = rxt = 0; txh = txt = 0;
    UBRR0H = 0; UBRR0L = 51;                       /* 9600 at 8 MHz */
    UCSR0A = 0;
    UCSR0C = _BV(UCSZ01) | _BV(UCSZ00);
    UCSR0B = _BV(RXCIE0) | _BV(RXEN0) | _BV(TXEN0);
}
static void uart_off(void)
{
    UCSR0B = 0;                                    /* the module has no power: drive nothing into it */
    DDRE &= (uint8_t)~0x03; PORTE &= (uint8_t)~0x03;
}

/* ---------------- EEPROM, written a byte at a time so the main loop never waits ---------------- */
/* up to two pieces at a time (a phone scenario: its data and its name), written from ewB */
#ifdef SW_P12
#define EE_VAC  0x780                  /* 12-pole SIM panel: 0x780..0x7A9 (0x7F0.. holds the curtain positions) */
#else
#define EE_VAC  0x7D5                  /* vacation program, VAC_LEN bytes: 0x7D5..0x7FE */
#endif
#define VAC_LEN 42
#define EWB_SZ  (VAC_LEN > LBL_SZ ? VAC_LEN : LBL_SZ)
static uint16_t ewA[2];
static uint8_t ewB[EWB_SZ], ewL[2], ewN, ewP;     /* ewN bytes in ewB: piece 0 = ewL[0] bytes, piece 1 the rest */
static uint16_t ew_addr(uint8_t p) { return p < ewL[0] ? ewA[0] + p : ewA[1] + (p - ewL[0]); }
static void ew_flush(void)
{
    while (ewP < ewN) { eeprom_update_byte((uint8_t *)ew_addr(ewP), ewB[ewP]); ewP++; wdt_reset(); }
}
static void ew_start(uint16_t a, uint8_t n, uint16_t a2, uint8_t n2)   /* data already in ewB */
{
    ewA[0] = a; ewL[0] = n; ewA[1] = a2; ewN = (uint8_t)(n + n2); ewP = 0;
}
static void ew_poll(void)
{
    if (ewP >= ewN || !eeprom_is_ready()) return;
    uint8_t *a = (uint8_t *)ew_addr(ewP);
    if (eeprom_read_byte(a) != ewB[ewP]) eeprom_write_byte(a, ewB[ewP]);
    ewP++;
}
static uint8_t ee_get(uint16_t a)                 /* the newest value of an EEPROM byte (maybe still waiting to be written) */
{
    for (uint8_t p = ewP; p < ewN; p++) if (ew_addr(p) == a) return ewB[p];
    return eeprom_read_byte((const uint8_t *)a);
}
static uint8_t lbl_byte(uint8_t n, uint8_t k) { return ee_get((uint16_t)(EE_LBL + (uint16_t)n * LBL_SZ + k)); }
#ifdef SW_P12
/* 12-pole SIM panel: key names kept one byte a letter (Persian letters, digits, signs: 0x80 + their place in LT),
   so 20 bytes hold 20 letters (UTF-8 needs 2 bytes a Persian letter). EE_LBLV marks the new form (old names are dropped once). */
#define EE_LBLV 0x7AA
#define LBLV_MAGIC 0x16
static const uint16_t LT[] PROGMEM = {
    0x0621, 0x0622, 0x0623, 0x0624, 0x0625, 0x0626, 0x0627, 0x0628, 0x0629, 0x062A, 0x062B, 0x062C, 0x062D, 0x062E, 0x062F,
    0x0630, 0x0631, 0x0632, 0x0633, 0x0634, 0x0635, 0x0636, 0x0637, 0x0638, 0x0639, 0x063A, 0x0640, 0x0641, 0x0642, 0x0643,
    0x0644, 0x0645, 0x0646, 0x0647, 0x0648, 0x0649, 0x064A, 0x064B, 0x064C, 0x064D, 0x064E, 0x064F, 0x0650, 0x0651, 0x0652,
    0x067E, 0x0686, 0x0698, 0x06A9, 0x06AF, 0x06CC, 0x06C0, 0x06BE, 0x0654, 0x060C, 0x061B, 0x061F, 0x200C, 0x00AB, 0x00BB,
    0x06F0, 0x06F1, 0x06F2, 0x06F3, 0x06F4, 0x06F5, 0x06F6, 0x06F7, 0x06F8, 0x06F9,
    0x0660, 0x0661, 0x0662, 0x0663, 0x0664, 0x0665, 0x0666, 0x0667, 0x0668, 0x0669, 0x2013, 0x00D7 };
#define LT_N (sizeof LT / sizeof LT[0])
/* UTF-8 text -> one byte a letter; returns the bytes written (at most max); unknown letters are left out */
static uint8_t lbl_pack(const char *p, uint8_t n, uint8_t *o, uint8_t max)
{
    uint8_t k = 0, w = 0;
    while (k < n && w < max) {
        uint8_t c = (uint8_t)p[k];
        uint16_t u;
        if (c < 0x80) { u = c; k++; }
        else if ((c & 0xE0) == 0xC0 && k + 1 < n) { u = (uint16_t)(((c & 0x1F) << 6) | ((uint8_t)p[k + 1] & 0x3F)); k += 2; }
        else if ((c & 0xF0) == 0xE0 && k + 2 < n) { u = (uint16_t)(((uint16_t)(c & 0x0F) << 12) | (((uint8_t)p[k + 1] & 0x3F) << 6) | ((uint8_t)p[k + 2] & 0x3F)); k += 3; }
        else { k++; continue; }
        if (u < 0x80) { if (u >= 0x20) o[w++] = (uint8_t)u; continue; }
        for (uint8_t i = 0; i < LT_N; i++) if (pgm_read_word(&LT[i]) == u) { o[w++] = (uint8_t)(0x80 + i); break; }
    }
    return w;
}
#endif

/* ---------------- ESP state ---------------- */
enum { W_OFF, W_BOOT, W_INIT, W_IDLE, W_AP, W_JOIN, W_JOINIP, W_IP, W_SEND1, W_SEND2, W_SNTPC, W_SNTPT, W_STA, W_JOINW };
static uint8_t wst, step, conn, wasOn;
static uint32_t until;
static uint8_t evOk, evErr, evSendOk, evGotIp, evPrompt, needIp;
/* as the old panel program: the address is read 2 s after "WIFI GOT IP" (right away the module may still say
   0.0.0.0); a join that still shows 0.0.0.0 is asked again, up to 3 times, before the phone gets "Repeat" */
static uint32_t tNow, gotIpAt;
static uint8_t ipTry;
static char mac[18], ip[16];

/* commands waiting for their turn */
/* one buffer for both (the app sends them from two different buttons; the newer one wins): names and passwords
   of any letters, with \" \, \\ escaped by the app, up to 32 + 64 bytes */
static char atCmd[120];
static uint8_t apReq, joinReq, joinId;
/* the answer to #AT+CWJAP# (as the old panel program): while the module joins the router its own network changes
   channel and the phone drops and connects again, so the answer goes to the phone that asks next (up to 60 s),
   not only to the link that sent the command; a late "WIFI GOT IP" (after the 30 s) still answers */
#define T_JOIN     30000UL
#define T_JOINANS  60000UL
static uint8_t joinRes, joinFail, joinSent;      /* joinRes 1 Error, 2 Repeat, 3 address; joinSent: links told */
static uint32_t joinAt, joinEnd;
/* the home router is off: the module would look for it for ever and its own network (the phone's way in) would
   hardly work. 20 s without the router -> the module stops looking for it (AT+CWQAP; never a mode change: switching the
   module from AP-only back to AP+station hung it on the 6-pole board, 2026-10-27); every 2 min,
   when no phone is connected, the module restarts and joins the router again by itself (saved in the module) */
#define T_STA_LOST  20000UL
#define T_STA_RETRY 120000UL
static uint8_t wakeReq;                            /* a phone connected: the panel lights up (confirmation) */
static uint8_t staOff;                             /* 1: router search stopped by AT+CWQAP */
static uint32_t staAt;

/* outgoing messages */
#ifdef SW_P12
#define QN 3                           /* 12-pole SIM panel: less RAM (its sw.c state is bigger) */
#else
#define QN 5
#endif
typedef struct { uint8_t id, len; char d[96]; } Msg;   /* the longest: $V#...$ of a 6-step vacation, 88 bytes */
static Msg q[QN];
static uint8_t qh, qn;
static Msg cur;                                    /* the message being sent */
static uint8_t curFromQ;
static pm_t kLast[NCONN];
#if HAS_PAIR
/* the other panel of a two-panel network, shown in the phone app through this panel (programmer: "Wi-Fi on this panel") */
extern const uint8_t px_flash[PX_SIZE];
static uint32_t p2Last[NCONN];                     /* its keys + online (bit 31) as last sent to each phone; 0xFFFFFFFF = not yet */
static uint8_t p2_on(Sw *s) { return s->pxm && pgm_read_byte(&px_flash[PX_WIFI]) == 1; }
static uint32_t p2_state(Sw *s) { return ((uint32_t)s->pst[2] << 16 | (uint16_t)s->pst[1] << 8 | s->pst[0]) | (s->online ? 0x80000000UL : 0); }
#endif
static uint8_t kForce, alLast[NCONN];
static uint8_t live;                  /* phones that talk the new protocol: they get the state pushed ($K, $AL, $P2K) */
static uint32_t kAt[NCONN];

/* phone payloads, received whole */
#ifdef SW_P12
#define PN 2
#else
#define PN 3
#endif
typedef struct { uint8_t id, len, pos; char d[128]; } Pay;   /* a router name and password (#AT+CWJAP=...#) fit */
static Pay pay[PN];
static uint8_t payFull;                            /* bit per slot */
static int8_t payIn = -1;                          /* slot being received, -1 none, -2 dropped */
static uint16_t payLeft;

/* ---------------- clock: Iran time (UTC +3:30, no summer time), counted from the crystal ----------------
 * Set by the phone (&CLK) or from the internet through the ESP (SNTP): right after the ESP starts or joins the
 * router, then every 2 hours; when that fails, again every 5 minutes. Unknown after a power cut until one of them. */
#define T_SNTP_OK   7200000UL
#define T_SNTP_FAIL 300000UL
#define IRAN_SEC    12600UL
static uint16_t ckDay;                             /* days since 2000-01-01 */
static uint32_t ckSec, ckMs;                       /* second of that day at ms counter ckMs */
static uint8_t ckOk, ckSrc, ckNew;                 /* ckSrc 'P' phone / 'N' internet; ckNew: was unknown, now set */
static uint8_t snCfg;                              /* SNTP: 0 not set up since the ESP started, 1 set up, 2 not supported */
static uint8_t snGot, snSoon;
static uint16_t snDay;
static uint32_t snSec, snAt;

static void ck_set(uint16_t day, uint32_t sec, uint32_t now, uint8_t src)
{
    while (sec >= 86400UL) { sec -= 86400UL; day++; }
    if (!ckOk) ckNew = 1;
    ckDay = day; ckSec = sec; ckMs = now; ckOk = 1; ckSrc = src;
}
static void ck_run(uint32_t now)                   /* move the base up to now (whole seconds) */
{
    uint32_t el = now - ckMs;
    if (el < 1000) return;
    uint32_t sec = el / 1000UL;
    ckMs += sec * 1000UL;
    ckSec += sec;
    while (ckSec >= 86400UL) { ckSec -= 86400UL; ckDay++; }
}
static uint16_t days2000(uint16_t y, uint8_t m, uint8_t d)   /* 2000..2099 */
{
    static const uint16_t cum[] PROGMEM = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
    uint16_t yy = (uint16_t)(y - 2000);
    uint16_t n = (uint16_t)(yy * 365U + (yy + 3U) / 4U + pgm_read_word(&cum[m - 1]) + d - 1U);
    if (m > 2 && !(yy & 3)) n++;
    return n;
}
static const char *skip_sp(const char *p) { while (*p == ' ') p++; return p; }
static const char *dec(const char *p, uint16_t *v)
{
    uint16_t x = 0; uint8_t k = 0;
    while (*p >= '0' && *p <= '9' && k < 5) { x = (uint16_t)(x * 10 + (*p++ - '0')); k++; }
    *v = k ? x : 0xFFFF;
    return p;
}
/* +CIPSNTPTIME:Thu Oct 14 04:10:12 2026 (UTC; 1970 = not synchronised yet) */
static void sntp_line(const char *p)
{
    static const char mon[] PROGMEM = "JanFebMarAprMayJunJulAugSepOctNovDec";
    uint16_t d, h, mi, se, y;
    uint8_t m = 0;
    p = skip_sp(p);
    while (*p && *p != ' ') p++;                   /* week day */
    p = skip_sp(p);
    for (uint8_t k = 0; k < 12; k++)
        if (p[0] == (char)pgm_read_byte(&mon[3 * k]) && p[1] == (char)pgm_read_byte(&mon[3 * k + 1]) &&
            p[2] == (char)pgm_read_byte(&mon[3 * k + 2])) { m = (uint8_t)(k + 1); break; }
    if (!m) return;
    p = dec(skip_sp(p + 3), &d);
    p = dec(skip_sp(p), &h); if (*p++ != ':') return;
    p = dec(p, &mi); if (*p++ != ':') return;
    p = dec(p, &se);
    dec(skip_sp(p), &y);
    if (y < 2024 || y > 2099 || d < 1 || d > 31 || h > 23 || mi > 59 || se > 59) return;
    snDay = days2000(y, m, (uint8_t)d);
    snSec = (uint32_t)h * 3600UL + mi * 60U + se + IRAN_SEC;
    snGot = 1;
}

#if HAS_PAIR
#define P2NEW(c) (p2Last[(c)] = 0xFFFFFFFFUL)
#else
#define P2NEW(c) ((void)0)
#endif
/* ---------------- receiving from the ESP ---------------- */
static char lb[100];
static uint8_t ln;

static uint8_t num(const char *p, uint8_t *used)   /* decimal number */
{
    uint8_t v = 0, k = 0;
    while (p[k] >= '0' && p[k] <= '9' && k < 5) { v = (uint8_t)(v * 10 + (p[k] - '0')); k++; }
    *used = k;
    return v;
}
static void copy_quoted(char *dst, uint8_t n, const char *src)   /* "...": up to n-1 characters (\x -> x) */
{
    const char *p = strchr(src, '"');
    uint8_t k = 0;
    if (p) for (p++; *p && *p != '"' && k < n - 1; p++) { if (*p == '\\' && p[1]) p++; dst[k++] = *p; }
    dst[k] = 0;
}
/* *AT+CWSAP=...* / #AT+CWJAP=...#: the AT command into atCmd, up to the end mark outside "..." (a name may hold
   * or #); returns the bytes used */
static int8_t take_at(const char *p, uint8_t rem, char end)
{
    uint8_t k = 1, j = 0, q = 0;
    for (; k < rem; k++) {
        char c = p[k];
        if (!q && c == end) { k++; break; }
        if (q && c == '\\' && k + 1 < rem) { if (j < sizeof atCmd - 2) { atCmd[j++] = c; atCmd[j++] = p[k + 1]; } k++; continue; }
        if (c == '"') q ^= 1;
        if (j < sizeof atCmd - 1) atCmd[j++] = c;
    }
    atCmd[j] = 0;
    return (int8_t)(k > 127 ? 127 : k);
}
static void line(void)
{
    const char *s = lb;
    if (!strcmp_P(s, PSTR("ready"))) {                 /* the ESP (re)started: start the server again */
        conn = 0; wst = W_BOOT; until = 0; evOk = 0; snCfg = 0; ip[0] = 0;
        return;
    }
    if (!strcmp_P(s, PSTR("OK"))) { evOk = 1; return; }
    if (!strcmp_P(s, PSTR("SEND OK"))) { evSendOk = 1; return; }
    if (!strcmp_P(s, PSTR("ERROR")) || !strcmp_P(s, PSTR("FAIL")) || !strcmp_P(s, PSTR("SEND FAIL"))) { evErr = 1; return; }
    if (!strcmp_P(s, PSTR("WIFI GOT IP"))) { evGotIp = 1; needIp = 1; snSoon = 1; gotIpAt = tNow; return; }   /* (re)joined: the time soon */
    if (!strncmp_P(s, PSTR("WIFI DISCONNECT"), 15)) { ip[0] = 0; return; }
    if (!strncmp_P(s, PSTR("+CIPSNTPTIME:"), 13)) { sntp_line(s + 13); return; }
    if (s[0] >= '0' && s[0] <= '4' && s[1] == ',') {
        uint8_t b = (uint8_t)(1 << (s[0] - '0'));
        if (!strcmp_P(s + 2, PSTR("CONNECT"))) { wakeReq = 1; joinSent &= (uint8_t)~b; conn |= b; live &= (uint8_t)~b; kForce |= b; alLast[s[0] - '0'] = 0xFF; P2NEW(s[0] - '0'); }
        else if (!strncmp_P(s + 2, PSTR("CLOSED"), 6) || !strncmp_P(s + 2, PSTR("CONNECT FAIL"), 12)) conn &= (uint8_t)~b;
        return;
    }
    if (!strncmp_P(s, PSTR("+CIFSR:STAMAC,"), 14)) { copy_quoted(mac, sizeof mac, s); return; }
    if (!strncmp_P(s, PSTR("+CIFSR:STAIP,"), 13)) { copy_quoted(ip, sizeof ip, s); return; }
}
static void rx_byte(uint8_t c)
{
    if (payIn != -1) {                                 /* phone data: exactly payLeft bytes */
        if (payIn >= 0) { Pay *p = &pay[payIn]; if (p->len < sizeof p->d) p->d[p->len++] = (char)c; }
        if (--payLeft == 0) { if (payIn >= 0) payFull |= (uint8_t)(1 << payIn); payIn = -1; }
        return;
    }
    if (c == '\n') { lb[ln] = 0; if (ln) line(); ln = 0; return; }
    if (c == '\r' || (ln == 0 && c == ' ')) return;
    if (ln == 0 && c == '>') { evPrompt = 1; return; }  /* "> ": the ESP waits for the data to send */
    if (ln < sizeof lb - 1) lb[ln++] = (char)c;
    if (c == ':' && ln > 7 && !strncmp_P(lb, PSTR("+IPD,"), 5)) {   /* +IPD,<id>,<len>:<data> */
        uint8_t u, id = num(lb + 5, &u), k = (uint8_t)(5 + u + 1);
        uint16_t len = 0;
        while (lb[k] >= '0' && lb[k] <= '9') len = (uint16_t)(len * 10 + (lb[k++] - '0'));
        ln = 0;
        if (!len) return;
        if (id < NCONN && !(conn & (1 << id))) { conn |= (uint8_t)(1 << id); kForce |= (uint8_t)(1 << id); alLast[id] = 0xFF; P2NEW(id); }
        payLeft = len; payIn = -2;
        for (uint8_t j = 0; j < PN; j++)
            if (!(payFull & (1 << j))) { payIn = (int8_t)j; pay[j].id = id; pay[j].len = 0; pay[j].pos = 0; break; }
    }
}

/* ---------------- sending to the phones ---------------- */
static Msg *q_new(uint8_t id)                          /* NULL when full */
{
    if (qn >= QN) return 0;
    Msg *m = &q[(qh + qn) % QN];
    qn++;
    m->id = id; m->len = 0;
    return m;
}
static void m_c(Msg *m, char c) { if (m->len < sizeof m->d) m->d[m->len++] = c; }
static void m_P(Msg *m, const char *p) { char c; while ((c = (char)pgm_read_byte(p++))) m_c(m, c); }
#ifdef SW_P12
static void m_lbl(Msg *m, uint8_t c)              /* one stored byte as UTF-8 */
{
    if (c < 0x80) { m_c(m, (char)c); return; }
    uint8_t i = (uint8_t)(c - 0x80);
    if (i >= LT_N) return;
    uint16_t u = pgm_read_word(&LT[i]);
    if (u < 0x800) { m_c(m, (char)(0xC0 | (u >> 6))); m_c(m, (char)(0x80 | (u & 0x3F))); }
    else { m_c(m, (char)(0xE0 | (u >> 12))); m_c(m, (char)(0x80 | ((u >> 6) & 0x3F))); m_c(m, (char)(0x80 | (u & 0x3F))); }
}
#endif
static void m_hex1(Msg *m, uint8_t v) { v &= 15; m_c(m, (char)(v < 10 ? '0' + v : 'A' + v - 10)); }
static void m_hex(Msg *m, uint8_t v) { const char *h = PSTR("0123456789ABCDEF"); m_c(m, (char)pgm_read_byte(h + (v >> 4))); m_c(m, (char)pgm_read_byte(h + (v & 15))); }
static void m_hx(Msg *m, uint32_t v, uint8_t n) { while (n--) m_hex1(m, (uint8_t)(v >> (4 * n))); }
static void m_2(Msg *m, uint8_t v) { m_c(m, (char)('0' + v / 10)); m_c(m, (char)('0' + v % 10)); }
static void m_dec(Msg *m, uint16_t v, uint8_t n)
{
    char b[5];
    for (uint8_t k = n; k--; ) { b[k] = (char)('0' + v % 10); v /= 10; }
    for (uint8_t k = 0; k < n; k++) m_c(m, b[k]);
}
static void clk_msg(Msg *m, uint32_t now)
{
    m_P(m, PSTR("$CLK#"));
    if (!ckOk) { m_P(m, PSTR("0$")); return; }
    ck_run(now);
    m_P(m, PSTR("1#")); m_dec(m, ckDay, 5); m_c(m, '#'); m_dec(m, (uint16_t)(ckSec / 60U), 4); m_c(m, '#');
    m_c(m, (char)ckSrc); m_c(m, '$');
}
static void m_k(Msg *m, pm_t red)
{
    m_P(m, PSTR("$K#"));
#ifdef SW_P12
    m_hex1(m, (uint8_t)(red >> 24));                   /* 27 keys: 7 hex digits */
#endif
    m_hex(m, (uint8_t)(red >> 16)); m_hex(m, (uint8_t)(red >> 8)); m_hex(m, (uint8_t)red);
    m_c(m, '$');
}
#ifdef SW_P12
/* ---------------- 12-pole SIM panel: alarm, SIM card and events (the alarm MCU reports them over bus B) ---------------- */
P12App p12;
#define EVN 8
static uint16_t evDay[EVN], evMin[EVN]; static uint8_t evCode[EVN], evTot, evSeen[NCONN];
static uint16_t alSent[NCONN]; static uint8_t simSent[NCONN], armId = 0xFF, setId = 0xFF, acfWant = 0xFF, acfSeen, acfTry;
static uint32_t acfAt;                             /* &ACR: when the alarm MCU was asked (asked again if the dump does not come whole) */
static uint16_t al_sig(void) { return (uint16_t)(p12.al | p12.zones << 3 | p12.open << 6); }
static uint8_t sim_sig(void) { return (uint8_t)((p12.gsm ? 1 : 0) | p12.bars << 1 | p12.op << 4 | (p12.crdBusy ? 0x40 : 0)) ^ (uint8_t)(p12.crdGen << 7); }
static void m_alp(Msg *m)
{
    m_P(m, PSTR("$AL#")); m_c(m, (char)('0' + p12.al)); m_c(m, '#'); m_c(m, (char)('0' + (p12.zones & 7))); m_c(m, '#'); m_c(m, (char)('0' + (p12.open & 7))); m_c(m, '$');
}
static void m_sim(Msg *m)
{
    m_P(m, PSTR("$SIM#")); m_c(m, p12.gsm ? '1' : '0'); m_c(m, '#'); m_c(m, (char)('0' + (p12.bars > 5 ? 5 : p12.bars))); m_c(m, '#'); m_c(m, (char)('0' + (p12.op & 3))); m_c(m, '#');
    if (p12.crdBusy) m_c(m, '?'); else if (!p12.credit[0]) m_c(m, '-'); else for (uint8_t k = 0; p12.credit[k] && k < sizeof p12.credit; k++) m_c(m, p12.credit[k]);
    m_c(m, '$');
}
/* day.minute.type.zone.source: type 1 armed, 2 disarmed (source 0 keypad 1 remote 2 SMS 3 app), 3 siren (zone), 6 magnet */
static void m_ev1(Msg *m, uint8_t i)
{
    uint8_t c = evCode[i], t = 0, z = 0, sr = 0;
    if (c >= 1 && c <= 4) { t = 1; sr = (uint8_t)(c - 1); } else if (c >= 5 && c <= 8) { t = 2; sr = (uint8_t)(c - 5); }
    else if (c >= 9 && c <= 11) { t = 3; z = (uint8_t)(c - 8); } else if (c == 12) t = 4; else if (c == 13) t = 6;
    m_dec(m, evDay[i], 5); m_c(m, '.'); m_dec(m, evMin[i], 4); m_c(m, '.'); m_c(m, (char)('0' + t)); m_c(m, '.'); m_c(m, (char)('0' + z)); m_c(m, '.'); m_c(m, (char)('0' + sr));
}
uint8_t wf_phones(void) { return conn & live; }
static uint32_t evNow;
void wf_event(uint8_t code)
{
    uint8_t i = (uint8_t)(evTot % EVN);
    ck_run(evNow);
    evDay[i] = ckOk ? ckDay : 0; evMin[i] = ckOk ? (uint16_t)(ckSec / 60U) : 0; evCode[i] = code;
    evTot++;
}
#endif
static void m_al(Msg *m, uint8_t a) { m_P(m, PSTR("$AL#")); m_c(m, (char)('0' + a)); m_c(m, '$'); }

static void cmd_P(const char *p, uint32_t now, uint16_t ms) { evOk = evErr = 0; tx_P(p); tx_nl(); until = now + ms; }

/* what the phone shows as "on" for each key: the switched state (not the pins: scenario 1's red pin may be
   the elevator relay), the elevator key while its relay is closed */
static pm_t app_state(Sw *s)
{
#ifdef SW_P12
    pm_t v = (s->state & 0x07FFFFFFUL) | p12_lock_bits();
#else
    pm_t v = s->state & 0x007FFFFFUL;
#endif
#if HAS_SCN
    if (s->elevLeft) for (uint8_t k = 0; k < SW_NP; k++) if (s->c.type[k] == T_ELEV) v |= BIT(k);
#endif
    return v;
}

/* the next thing to send, if any: a queued reply first, else a state message a phone has not seen yet */
static uint8_t next_msg(Sw *s, uint32_t now)
{
    if (qn) { cur = q[qh]; curFromQ = 1; return 1; }
    curFromQ = 0;
    pm_t red = app_state(s);
    uint8_t al = sw_al_state(s);
    for (uint8_t c = 0; c < NCONN; c++) {
        uint8_t b = (uint8_t)(1 << c);
        if (!(conn & live & b)) continue;
        if ((kForce & b) || (kLast[c] != red && AFTER(now, kAt[c] + T_KGAP))) {
            cur.id = c; cur.len = 0; m_k(&cur, red);
            kLast[c] = red; kAt[c] = now; kForce &= (uint8_t)~b;
            return 1;
        }
#if HAS_PAIR
        if (p2_on(s)) {                                /* the other panel: $P2K#xxxxxx#o$ */
            uint32_t v = p2_state(s);
            if (p2Last[c] != v && (p2Last[c] == 0xFFFFFFFFUL || AFTER(now, kAt[c] + T_KGAP))) {
                cur.id = c; cur.len = 0;
                m_P(&cur, PSTR("$P2K#")); m_hx(&cur, v & 0xFFFFFFUL, 6); m_c(&cur, '#'); m_c(&cur, (v >> 31) ? '1' : '0'); m_c(&cur, '$');
                p2Last[c] = v; kAt[c] = now;
                return 1;
            }
        }
#endif
        if (s->c.alarm && alLast[c] != al) {
            cur.id = c; cur.len = 0; m_al(&cur, al);
            alLast[c] = al;
            return 1;
        }
#ifdef SW_P12
        if (armId == c && p12.armRes) {
            cur.id = c; cur.len = 0; m_P(&cur, p12.armRes == 1 ? PSTR("$ARM#ok$") : p12.armRes == 2 ? PSTR("$ARM#no$") : PSTR("$ARM#busy$"));
            armId = 0xFF; p12.armRes = 0;
            return 1;
        }
        if (setId == c && p12.setRes) {                 /* an alarm setting saved / refused */
            cur.id = c; cur.len = 0; m_P(&cur, p12.setRes == 1 ? PSTR("$ACS#ok$") : PSTR("$ACS#no$"));
            setId = 0xFF; p12.setRes = 0;
            return 1;
        }
        if (acfWant == c && p12acfOn && acfSeen != p12acfGen) {   /* the alarm settings asked by this phone */
            cur.id = c; cur.len = 0; m_P(&cur, PSTR("$ACF#"));
            for (uint8_t k = 0; k < 2 * sizeof p12acf; k++) {
                uint8_t v = (uint8_t)((k & 1) ? p12acf[k >> 1] & 15 : p12acf[k >> 1] >> 4);
                if (v == 15) break;
                m_c(&cur, v == 10 ? ',' : v == 12 ? '+' : (char)('0' + v));
            }
            m_c(&cur, '$'); acfSeen = p12acfGen; acfWant = 0xFF;
            return 1;
        }
        if (alSent[c] != al_sig()) { cur.id = c; cur.len = 0; m_alp(&cur); alSent[c] = al_sig(); return 1; }
        if (simSent[c] != sim_sig()) { cur.id = c; cur.len = 0; m_sim(&cur); simSent[c] = sim_sig(); return 1; }
        if (evSeen[c] != evTot) {
            if ((uint8_t)(evTot - evSeen[c]) > EVN) evSeen[c] = (uint8_t)(evTot - EVN);
            cur.id = c; cur.len = 0; m_P(&cur, PSTR("$EV1#")); m_ev1(&cur, (uint8_t)(evSeen[c] % EVN)); m_c(&cur, '$');
            evSeen[c]++;
            return 1;
        }
#endif
    }
    return 0;
}

/* ---------------- phone scenarios (12, kept in the panel; the panel counts their timers) ---------------- */
#ifdef SW_P12
#define PS_N    1                      /* 12-pole SIM panel: no phone scenarios (RAM) */
#else
#define PS_N    12
#endif
#define PS_NAME 18
static uint16_t ps_name(uint8_t n) { return (uint16_t)(n < 9 ? 0x310 + 18 * n : 0x3C4 + 18 * (n - 9)); }
static uint16_t ps_data(uint8_t n) { return (uint16_t)(EE_PS + 8 * n); }
static uint32_t psAt[PS_N];
static pm_t psOn[PS_N];
static uint8_t psKind[PS_N];                       /* 0 none, 'F' poles off at psAt, 'D' runs at psAt */
static uint8_t rebootDue;
static uint32_t rebootAt;

/* poles on / off of scenario n (places 1..20: 0 off, 1 on, 2 unchanged) */
static void ps_masks(uint8_t n, pm_t *on, pm_t *off)
{
    *on = *off = 0;
    for (uint8_t p = 0; p < 20; p++) {
        uint8_t v = (uint8_t)((ee_get((uint16_t)(ps_data(n) + 3 + (p >> 2))) >> ((p & 3) * 2)) & 3);
        if (v == 1) *on |= BIT(p); else if (v == 0) *off |= BIT(p);
    }
}
static void ps_tick(Sw *s, uint32_t now)
{
    for (uint8_t n = 0; n < PS_N; n++) {
        if (!psKind[n] || !AFTER(now, psAt[n])) continue;
        pm_t on, off;
        if (psKind[n] == 'F') { if (sw_apply(s, 0, psOn[n])) psKind[n] = 0; }       /* its poles off again */
        else { ps_masks(n, &on, &off); if (sw_apply(s, on, off)) psKind[n] = 0; }  /* delayed run (waits while locked) */
    }
}
/* 1 ran (or started counting), 0 empty, 2 panel locked */
static uint8_t ps_run(Sw *s, uint8_t n, uint32_t now)
{
    uint8_t k = ee_get(ps_data(n));
    if (k != 'N' && k != 'F' && k != 'D') return 0;
    uint16_t min = (uint16_t)((ee_get((uint16_t)(ps_data(n) + 1)) << 8) | ee_get((uint16_t)(ps_data(n) + 2)));
    pm_t on, off;
    ps_masks(n, &on, &off);
    if (k == 'D' && min) { psKind[n] = 'D'; psAt[n] = now + (uint32_t)min * 60000UL; return 1; }
    if (!sw_apply(s, on, off)) return 2;
    if (k == 'F' && min && (on & sw_scn_poles(s))) { psKind[n] = 'F'; psOn[n] = on & sw_scn_poles(s); psAt[n] = now + (uint32_t)min * 60000UL; }
    else psKind[n] = 0;
    return 1;
}
/* ---------------- vacation program (kept in the panel, run by the panel clock) ----------------
 * EEPROM EE_VAC: on ('1' / '0', 0xFF = none), first night d0 (2), last night d1 (2), steps n (1),
 * 6 x (minutes from the midnight that starts the night (2), 20-bit mask (3)), end minutes (2), end mask (3), crc8.
 * Minutes run 0..2879 (after midnight = 1440 and up). Mask: lights (L / D places) on, the other lights off;
 * a curtain open (U) / close (W) bit starts that curtain. End: every light off and its curtain bits. */
#define VS_OFF  6
static uint8_t vb[VAC_LEN], vbLoaded, vCatch, vLast = '-';
static uint32_t vDone, vMin = 0xFFFFFFFFUL;        /* last event done (absolute minute + 1, 0 none), minute last looked at */

static uint8_t crc8(const uint8_t *p, uint8_t n)
{
    uint8_t c = 0x5A;
    while (n--) { c ^= *p++; for (uint8_t k = 0; k < 8; k++) c = (uint8_t)(c & 0x80 ? (c << 1) ^ 0x07 : c << 1); }
    return c;
}
static uint16_t vb16(uint8_t k) { return (uint16_t)((vb[k] << 8) | vb[k + 1]); }
static pm_t vb24(uint8_t k) { return ((pm_t)vb[k] << 16) | ((pm_t)vb[k + 1] << 8) | vb[k + 2]; }
static uint16_t v_rel(uint8_t e) { uint8_t n = vb[5]; return e < n ? vb16((uint8_t)(VS_OFF + 5 * e)) : vb16(VS_OFF + 30); }
#ifdef SW_P12
/* 12-pole SIM panel: bits 0..14 = poles 1..15, bits 15..18 = curtain keys 24..27 (open 1, close 1, open 2, close 2) */
static pm_t v_raw(uint8_t e) { uint8_t n = vb[5]; return (e < n ? vb24((uint8_t)(VS_OFF + 5 * e + 2)) : vb24(VS_OFF + 32)) & 0xFFFFFUL; }
static pm_t v_mask(uint8_t e) { pm_t r = v_raw(e); return (r & 0x7FFFUL) | (((r >> 15) & 0xFUL) << 23); }
#else
static pm_t v_mask(uint8_t e) { uint8_t n = vb[5]; return (e < n ? vb24((uint8_t)(VS_OFF + 5 * e + 2)) : vb24(VS_OFF + 32)) & 0xFFFFFUL; }
#define v_raw v_mask
#endif

static void v_kinds(Sw *s, pm_t *lights, pm_t *curt)
{
    *lights = *curt = 0;
    for (uint8_t k = 0; k < SW_NP; k++) {
        char c = s->c.lay[k];
        if (c == 'L' || c == 'D') *lights |= BIT(k);
        else if (c == 'U' || c == 'W') *curt |= BIT(k);
    }
}
/* the newest event (step or end) at or before minute a, as absolute minute + 1 (0 none); *ev = its number */
static uint32_t v_latest(uint32_t a, uint8_t *ev)
{
    uint32_t best = 0;
    uint16_t day = (uint16_t)(a / 1440UL), d0 = vb16(1), d1 = vb16(3);
    for (uint8_t j = 0; j < 2; j++) {
        uint16_t nd = (uint16_t)(day - j);          /* tonight, last night */
        if (nd < d0 || nd > d1 || (j && !day)) continue;
        for (uint8_t e = 0; e <= vb[5]; e++) {
            uint32_t t = (uint32_t)nd * 1440UL + v_rel(e) + 1;
            if (t <= a + 1 && t > best) { best = t; *ev = e; }
        }
    }
    return best;
}
static void vac_tick(Sw *s, uint32_t now)
{
    static uint32_t vAt;
    if (vbLoaded && !vCatch && !ckNew && (uint32_t)(now - vAt) < 1000) return;   /* looks once a second */
    vAt = now;
    if (ckOk) ck_run(now);
    if (!vbLoaded) {
        vbLoaded = 1;
        for (uint8_t k = 0; k < VAC_LEN; k++) vb[k] = eeprom_read_byte((const uint8_t *)(EE_VAC + k));
        if (crc8(vb, VAC_LEN - 1) != vb[VAC_LEN - 1] || vb[5] < 1 || vb[5] > 6) vb[0] = 0xFF;
        vCatch = 1;
    }
    if (!ckOk || vb[0] != '1') return;
    if (ckNew) { ckNew = 0; vCatch = 1; }           /* the clock was unknown: do what should be on by now */
    uint32_t a = (uint32_t)ckDay * 1440UL + ckSec / 60U;
    if (a == vMin && !vCatch) return;
    vMin = a;
    uint8_t e = 0;
    uint32_t t = v_latest(a, &e);
    if (!t || t == vDone) { vCatch = 0; return; }
    if (!vCatch && t + 5 <= a + 1) return;          /* older than 5 minutes: only after a clock set / a save */
    pm_t lights, curt, m = v_mask(e);
    v_kinds(s, &lights, &curt);
    uint8_t ok = e < vb[5] ? sw_apply(s, m & (lights | curt), lights & ~m) : sw_apply(s, m & curt, lights);
    if (!ok) { vMin = 0xFFFFFFFFUL; return; }       /* panel locked by a short scenario: again next pass */
    vDone = t; vCatch = 0;
    vLast = e < vb[5] ? (uint8_t)('1' + e) : 'E';
}
static uint8_t dec_n(const char *p, uint8_t n, uint16_t *v)
{
    uint16_t x = 0;
    for (uint8_t k = 0; k < n; k++) { if (p[k] < '0' || p[k] > '9') return 0; x = (uint16_t)(x * 10 + (p[k] - '0')); }
    *v = x;
    return 1;
}
static uint8_t hex_n(const char *p, uint8_t n, uint32_t *v);
/* Vac#o#ddddd#ddddd#n#<n x tttt hhhhh>#tttthhhhh#   -> 1 stored */
static uint8_t vac_cmd(const char *p, uint8_t rem)
{
    uint16_t d0, d1, t, prev = 0;
    uint32_t mk;
    if (rem < 20 || (p[4] != '0' && p[4] != '1') || p[5] != '#' || p[11] != '#' || p[17] != '#' || p[19] != '#') return 0;
    if (!dec_n(p + 6, 5, &d0) || !dec_n(p + 12, 5, &d1) || d1 < d0 || d1 - d0 > 400) return 0;
    uint8_t n = (uint8_t)(p[18] - '0');
    if (n < 1 || n > 6 || rem < (uint8_t)(20 + 9 * n + 11) || p[20 + 9 * n] != '#' || p[30 + 9 * n] != '#') return 0;
    uint8_t b[VAC_LEN];
    memset(b, 0, sizeof b);
    b[0] = (uint8_t)p[4]; b[1] = (uint8_t)(d0 >> 8); b[2] = (uint8_t)d0; b[3] = (uint8_t)(d1 >> 8); b[4] = (uint8_t)d1; b[5] = n;
    for (uint8_t e = 0; e <= n; e++) {
        const char *q = p + 20 + 9 * e + (e == n ? 1 : 0);
        if (!dec_n(q, 4, &t) || !hex_n(q + 4, 5, &mk) || t > 2879 || (e && t <= prev)) return 0;
        uint8_t o = (uint8_t)(e < n ? VS_OFF + 5 * e : VS_OFF + 30);
        b[o] = (uint8_t)(t >> 8); b[o + 1] = (uint8_t)t;
        b[o + 2] = (uint8_t)(mk >> 16); b[o + 3] = (uint8_t)(mk >> 8); b[o + 4] = (uint8_t)mk;
        prev = t;
    }
    b[VAC_LEN - 1] = crc8(b, VAC_LEN - 1);
    memcpy(vb, b, VAC_LEN);
    ew_flush();
    memcpy(ewB, b, VAC_LEN);
    ew_start(EE_VAC, VAC_LEN, 0, 0);
    vDone = 0; vCatch = 1; vLast = '-';
    return 1;
}

static uint8_t hexv(char c) { return (uint8_t)(c >= '0' && c <= '9' ? c - '0' : c >= 'A' && c <= 'F' ? c - 'A' + 10 : c >= 'a' && c <= 'f' ? c - 'a' + 10 : 0xFF); }
static uint8_t hex_n(const char *p, uint8_t n, uint32_t *v)   /* exactly n hex digits */
{
    uint32_t x = 0;
    for (uint8_t k = 0; k < n; k++) { uint8_t h = hexv(p[k]); if (h == 0xFF) return 0; x = (x << 4) | h; }
    *v = x;
    return 1;
}
/* hex number up to '#' (at most 8 digits); returns digits used, 0 = none / bad */
static uint8_t hexn(const char *p, uint8_t rem, uint32_t *v)
{
    uint8_t k = 0; uint32_t x = 0;
    while (k < rem && k < 8 && hexv(p[k]) != 0xFF) { x = (x << 4) | hexv(p[k]); k++; }
    if (!k || k >= rem || p[k] != '#') return 0;
    *v = x;
    return k;
}

/* ---------------- phone commands ---------------- */
static uint8_t digits4(const char *p, uint8_t maxd, uint16_t *v)   /* 4 digits 1..maxd -> 0x1234 form */
{
    uint16_t x = 0;
    for (uint8_t k = 0; k < 4; k++) {
        if (p[k] < '1' || p[k] > '0' + maxd) return 0;
        x = (uint16_t)((x << 4) | (uint8_t)(p[k] - '0'));
    }
    *v = x;
    return 1;
}
static uint8_t max_digit(Sw *s)
{
    uint8_t m = 0;
    for (uint8_t k = 0; k < SW_NP; k++) if (s->c.type[k] == T_KEY && s->c.sec1[k] > m) m = s->c.sec1[k];
    return m ? m : 6;
}
#define IS(lit) (rem >= (uint8_t)(sizeof(lit) - 1) && !strncmp_P(p, PSTR(lit), sizeof(lit) - 1))
#define D2(x) ((x)[0] >= '0' && (x)[0] <= '9' && (x)[1] >= '0' && (x)[1] <= '9')

/* $CF#nn#type#sec1#sec2#minutes#on#off#seconds left$ (hex) */
static void cf_msg(Sw *s, Msg *m, uint8_t k)
{
    m_P(m, PSTR("$CF#")); m_2(m, (uint8_t)(k + 1)); m_c(m, '#');
    m_hx(m, s->c.type[k], 2); m_c(m, '#');
    m_hx(m, s->c.sec1[k], 2); m_c(m, '#');
    m_hx(m, s->c.sec2[k], 2); m_c(m, '#');
    m_hx(m, s->c.minutes[k], 2); m_c(m, '#');
    m_hx(m, s->c.onmask[k] & 0x7FFFFFUL, 6); m_c(m, '#');
    m_hx(m, s->c.offmask[k] & 0x7FFFFFUL, 6); m_c(m, '#');
    m_hx(m, sw_left(s, k), 4); m_c(m, '$');
}

/* one command at p; returns how many bytes it used (0 = not a command here), or -1 = no room to answer yet */
static int8_t command(Sw *s, uint8_t id, const char *p, uint8_t rem, uint32_t now)
{
    Msg *m;
    /* the app's first steps (@M_IP, @M_F_C, @M_F_T, @TA1..) read every answer by its first character and stop on
       anything else: nothing is pushed to a phone until it sends one of the other commands (@M_MDL, @K, ...) */
    if (id < NCONN && !(live & (1 << id)) && !IS("@M_IP") && !IS("@M_F_") && !IS("@TA1") && (p[0] == '@' || p[0] == '&' || p[0] == '#' || p[0] == '*' || p[0] == 'L' || p[0] == 'V')) {
        live |= (uint8_t)(1 << id); kForce |= (uint8_t)(1 << id); alLast[id] = 0xFF; P2NEW(id);
#ifdef SW_P12
        alSent[id] = 0xFFFF; simSent[id] = (uint8_t)~sim_sig(); evSeen[id] = evTot; if (armId == id) armId = 0xFF; if (setId == id) setId = 0xFF; if (acfWant == id) acfWant = 0xFF;
#endif
    }
    if (IS("@M_IP")) {
        if (!(m = q_new(id))) return -1;
        m_c(m, '%');
        uint8_t nm = (uint8_t)strlen(mac), ni = strcmp_P(ip, PSTR("0.0.0.0")) ? (uint8_t)strlen(ip) : 0;
        for (uint8_t k = 0; k < 17; k++) m_c(m, k < nm ? mac[k] : ' ');
        m_c(m, '+');
        for (uint8_t k = 0; k < 16; k++) m_c(m, k < ni ? ip[k] : ' ');   /* not on a router: blank */
        m_c(m, '+');
        for (uint8_t k = 0; k < 20; k++) { uint8_t c = eeprom_read_byte((const uint8_t *)(EE_USER + k)); m_c(m, c == 0xFF ? 0 : (char)c); }
        m_c(m, '%');
        return 5;
    }
    if (IS("@M_F_C")) { if (!(m = q_new(id))) return -1; m_P(m, PSTR("#T")); return 6; }
    if (IS("@M_F_T")) { if (!(m = q_new(id))) return -1; m_P(m, PSTR("#T*A1/Uaaaaaaaaaa/Vp1*L+#X1*Z1++")); return 6; }
#ifdef SW_P12
    if (IS("@M_MDL")) { if (!(m = q_new(id))) return -1; m_P(m, PSTR("$MDL=SIM12-1.0$")); return 6; }
    if (IS("@M_VER")) { if (!(m = q_new(id))) return -1; m_P(m, PSTR("$VER=SIM12-1.0$")); return 6; }
    if (IS("@X1Z")) { if (!(m = q_new(id))) return -1; m_alp(m); alSent[id] = al_sig(); return 4; }
    if (IS("@M_SIM")) { if (!(m = q_new(id))) return -1; m_sim(m); simSent[id] = sim_sig(); return 6; }
    if (IS("@M_EV")) {                                /* the last 5 events, newest first */
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$EV#"));
        uint8_t n = evTot < 5 ? evTot : 5;
        for (uint8_t k = 0; k < n; k++) { if (k) m_c(m, ';'); m_ev1(m, (uint8_t)((uint8_t)(evTot - 1 - k) % EVN)); }
        m_c(m, '$'); evSeen[id] = evTot;
        return 5;
    }
    /* &X1A#m#f#dddd: arm zones m (1..7), f 1 = at once; &X1D#dddd: disarm. The alarm MCU checks the code: $ARM#ok|no|busy$ */
    if (IS("&X1A#") && rem >= 13 && p[5] >= '1' && p[5] <= '7' && p[6] == '#' && (p[7] == '0' || p[7] == '1') && p[8] == '#') {
        uint16_t v = 0; uint8_t ok = 1;
        for (uint8_t k = 0; k < 4; k++) { if (p[9 + k] < '0' || p[9 + k] > '9') ok = 0; v = (uint16_t)(v << 4 | (uint8_t)(p[9 + k] - '0')); }
        if (ok && p12_app_send(p[7] == '1' ? 2 : 1, (uint8_t)(p[5] - '0'), v)) { armId = id; p12.armRes = 0; }
        else { if (!(m = q_new(id))) return -1; m_P(m, ok ? PSTR("$ARM#busy$") : PSTR("$ARM#no$")); }
        return 13;
    }
    if (IS("&X1D#") && rem >= 9) {
        uint16_t v = 0; uint8_t ok = 1;
        for (uint8_t k = 0; k < 4; k++) { if (p[5 + k] < '0' || p[5 + k] > '9') ok = 0; v = (uint16_t)(v << 4 | (uint8_t)(p[5 + k] - '0')); }
        if (ok && p12_app_send(3, 7, v)) { armId = id; p12.armRes = 0; }
        else { if (!(m = q_new(id))) return -1; m_P(m, ok ? PSTR("$ARM#busy$") : PSTR("$ARM#no$")); }
        return 9;
    }
    /* alarm settings (installer): &ACR = send them ($ACF#exit,entry,siren,code,s1,s2,s3,c1,c2,c3$),
       &ACS#f#value# f: E exit s, N entry s, S siren s, P code, 1..3 SMS number, 4..6 call number ($ACS#ok|no|busy$) */
    if (IS("&ACR")) {
        if (p12_app_send(6, 1, 0)) { acfWant = id; acfSeen = p12acfGen; acfAt = now; acfTry = 1; }
        else { if (!(m = q_new(id))) return -1; m_P(m, PSTR("$ACS#busy$")); }
        return 4;
    }
    if (IS("&ACS#") && rem >= 8 && p[6] == '#') {
        uint8_t k = 7, nd = 0; char f = p[5]; uint8_t dg[14];
        while (k < rem && p[k] != '#') { char c = p[k++]; if (nd < sizeof dg && ((c >= '0' && c <= '9') || c == '+')) dg[nd++] = c == '+' ? 10 : (uint8_t)(c - '0'); }
        int8_t used = (int8_t)(k < rem ? k + 1 : k);
        uint8_t ok = 0;
        if (f >= '1' && f <= '6') {
            if (p12_app_free() >= (uint8_t)(2 + (nd + 3) / 4)) {
                p12_app_send(6, 6, 0xFFFF);
                for (uint8_t i = 0; i < nd; i += 4) {
                    uint16_t v = 0;
                    for (uint8_t j = 0; j < 4; j++) v = (uint16_t)(v << 4 | (i + j < nd ? dg[i + j] : 15));
                    p12_app_send(6, 6, v);
                }
                ok = p12_app_send(6, 7, (uint16_t)(f - '1'));
            }
        } else {
            uint16_t v = 0;
            if (f == 'P') { if (nd == 4) for (uint8_t j = 0; j < 4; j++) v = (uint16_t)(v << 4 | dg[j]); else nd = 0; }
            else for (uint8_t j = 0; j < nd && j < 5; j++) v = (uint16_t)(v * 10 + dg[j]);
            uint8_t sub = f == 'E' ? 2 : f == 'N' ? 3 : f == 'S' ? 4 : f == 'P' ? 5 : 0;
            if (sub && nd) ok = p12_app_send(6, sub, v);
        }
        if (ok) { setId = id; p12.setRes = 0; }
        else { if (!(m = q_new(id))) return -1; m_P(m, PSTR("$ACS#busy$")); }
        return used;
    }
    if (IS("&SOFF")) { if (!(m = q_new(id))) return -1; m_P(m, p12_scn_off(0) ? PSTR("$SOFF#1$") : PSTR("$SOFF#0$")); return 5; }   /* every scenario off (S1..S4) */
    if (IS("@M_POS")) { if (!(m = q_new(id))) return -1; m_P(m, PSTR("$POS#")); m_2(m, p12_pos(0)); m_c(m, '#'); m_2(m, p12_pos(1)); m_c(m, '$'); return 6; }   /* curtains open, percent (100 = 99) */
    if (IS("&CRD")) { p12.crdWant = 1; p12.crdBusy = 1; return 4; }
#endif
    if (IS("@M_MDL")) {
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$MDL=SD23-"));
        for (uint8_t k = 0; k < sizeof s->c.mdl && s->c.mdl[k] && (uint8_t)s->c.mdl[k] != 0xFF; k++) m_c(m, s->c.mdl[k]);
        m_P(m, PSTR("-1.0$"));
        return 6;
    }
    if (IS("@M_VER")) { if (!(m = q_new(id))) return -1; m_P(m, PSTR("$VER=SD23-1.0$")); return 6; }
    if (IS("@M_LAY")) {
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$LAY#"));
        for (uint8_t k = 0; k < SW_NP; k++) { char c = s->c.lay[k]; m_c(m, c > ' ' && c < 0x7F ? c : '-'); }
        m_c(m, '$');
        return 6;
    }
    if (IS("@M_CAP")) {
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$CAP#A")); m_c(m, s->c.alarm ? '1' : '0');
        m_c(m, 'R'); m_c(m, s->c.remote && s->c.nslot ? '1' : '0');
#if HAS_PAIR
        m_P(m, p2_on(s) ? PSTR("W1S1P1$") : PSTR("W1S1$"));   /* P1: the other panel is shown too */
#else
        m_P(m, PSTR("W1S1$"));
#endif
        return 6;
    }
    if (IS("@M_LBL#") && rem >= 9 && D2(p + 7)) {
        uint8_t n = (uint8_t)((p[7] - '0') * 10 + (p[8] - '0'));
        if (n < 1 || n > SW_NP) return 9;
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$L")); m_2(m, n); m_c(m, '#');
        uint8_t ic = lbl_byte((uint8_t)(n - 1), 0);
        if (ic < 100) { m_2(m, ic); m_c(m, '~'); }
#ifdef SW_P12
        if (eeprom_read_byte((const uint8_t *)EE_LBLV) == LBLV_MAGIC)
            for (uint8_t k = 1; k < LBL_SZ; k++) { uint8_t c = lbl_byte((uint8_t)(n - 1), k); if (!c || c == 0xFF) break; m_lbl(m, c); }
#else
        for (uint8_t k = 1; k < LBL_SZ; k++) { uint8_t c = lbl_byte((uint8_t)(n - 1), k); if (!c || c == 0xFF) break; m_c(m, (char)c); }
#endif
        m_c(m, '$');
        return 9;
    }
    if (IS("@X1Z")) { if (!(m = q_new(id))) return -1; m_al(m, sw_al_state(s)); alLast[id] = sw_al_state(s); return 4; }
    if (IS("@K")) { if (!(m = q_new(id))) return -1; pm_t r = app_state(s); m_k(m, r); kLast[id] = r; kAt[id] = now; return 2; }
    if (IS("&K#") && rem >= 5 && D2(p + 3)) {
        uint8_t n = (uint8_t)((p[3] - '0') * 10 + (p[4] - '0'));
        if (!(m = q_new(id))) return -1;
#ifdef SW_P12
        uint8_t ok = n >= 1 && n <= SW_NP && (p12_app_key((uint8_t)(n - 1)) || sw_app_press(s, (uint8_t)(n - 1), now));
#else
        uint8_t ok = n >= 1 && n <= SW_NP && sw_app_press(s, (uint8_t)(n - 1), now);
#endif
        m_P(m, PSTR("$A#")); m_2(m, n); m_c(m, '#'); m_c(m, ok ? '1' : '0'); m_c(m, '$');
        return 5;
    }
    if (IS("&X1Z1#") && rem >= 10) {
        if (!(m = q_new(id))) return -1;
        uint16_t v;
        uint8_t ok = digits4(p + 6, 9, &v) && sw_al_code(s, v);
        m_P(m, ok ? PSTR("$ARM#ok$") : PSTR("$ARM#no$"));
        return 10;
    }
    if (IS("&X1P#") && rem >= 9) {
        if (!(m = q_new(id))) return -1;
        uint16_t v;
        uint8_t ok = digits4(p + 5, max_digit(s), &v) && sw_al_setpin(s, v);
        m_P(m, ok ? PSTR("$PASS=ok$") : PSTR("$PASS=no$"));
        return 9;
    }
    if (IS("Lbl#") && rem >= 7 && D2(p + 4) && p[6] == '#') {
        uint8_t n = (uint8_t)((p[4] - '0') * 10 + (p[5] - '0')), k = 7, len = 0, ic = 0xFF;
        if (rem >= 10 && D2(p + 7) && p[9] == '~') { ic = (uint8_t)((p[7] - '0') * 10 + (p[8] - '0')); k = 10; }
        uint8_t t0 = k;
        while (k < rem && p[k] != '#') k++;
        if (n < 1 || n > SW_NP) return k < rem ? (int8_t)(k + 1) : (int8_t)k;
#ifdef SW_E12
        if (n >= 13 && n <= 20) return k < rem ? (int8_t)(k + 1) : (int8_t)k;   /* 12 economic: no such keys (their space holds the remotes) */
#endif
        if (!(m = q_new(id))) return -1;
        len = (uint8_t)(k - t0);
        ew_flush();
#ifdef SW_P12
        if (eeprom_read_byte((const uint8_t *)EE_LBLV) != LBLV_MAGIC) {   /* first name in the new form: the old ones (UTF-8) are dropped */
            for (uint8_t j = 0; j < SW_NP; j++) eeprom_update_byte((uint8_t *)(EE_LBL + (uint16_t)j * LBL_SZ + 1), 0);
            eeprom_update_byte((uint8_t *)EE_LBLV, LBLV_MAGIC);
        }
        len = lbl_pack(p + t0, len, ewB + 1, LBL_TXT);
        ewB[0] = ic;
#else
        if (len > LBL_TXT) {                           /* cut at a whole letter (UTF-8) */
            len = LBL_TXT;
            while (len && ((uint8_t)p[t0 + len] & 0xC0) == 0x80) len--;
        }
        ewB[0] = ic;
        memcpy(ewB + 1, p + t0, len);
#endif
        if (len < LBL_TXT) ewB[1 + len] = 0;
        ew_start(EE_LBL + (uint16_t)(n - 1) * LBL_SZ, (uint8_t)(len < LBL_TXT ? len + 2 : LBL_SZ), 0, 0);
        m_P(m, PSTR("ok\n"));
        return k < rem ? (int8_t)(k + 1) : (int8_t)k;
    }
    if (IS("@M_CF#AL")) {                            /* alarm times and dark time */
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$CF#AL#")); m_hx(m, s->c.alArm, 2); m_c(m, '#'); m_hx(m, s->c.alEntry, 2); m_c(m, '#');
        m_hx(m, s->c.alSiren, 2); m_c(m, '#'); m_hx(m, s->c.dimsec, 2); m_c(m, '$');
        return 8;
    }
    if (IS("@M_CF#") && rem >= 8 && D2(p + 6)) {     /* settings of key nn: type, sec1, sec2, minutes, on, off, seconds left */
        uint8_t n = (uint8_t)((p[6] - '0') * 10 + (p[7] - '0'));
        if (n < 1 || n > SW_NP) return 8;
        if (!(m = q_new(id))) return -1;
        cf_msg(s, m, (uint8_t)(n - 1));
        return 8;
    }
    if (IS("Set#AL#") && rem >= 19) {                /* Set#AL#aa#ee#ss#dd# */
        uint32_t a, e, sr, d; uint8_t k = 7, u;
        if (!(m = q_new(id))) return -1;
        uint8_t ok = (u = hexn(p + k, (uint8_t)(rem - k), &a)) && (k = (uint8_t)(k + u + 1)) &&
                     (u = hexn(p + k, (uint8_t)(rem - k), &e)) && (k = (uint8_t)(k + u + 1)) &&
                     (u = hexn(p + k, (uint8_t)(rem - k), &sr)) && (k = (uint8_t)(k + u + 1)) &&
                     (u = hexn(p + k, (uint8_t)(rem - k), &d)) && (k = (uint8_t)(k + u + 1)) &&
                     a < 256 && e < 256 && sr < 256 && d < 256 && sw_set_al(s, (uint8_t)a, (uint8_t)e, (uint8_t)sr, (uint8_t)d);
        if (ok) { m_P(m, PSTR("$CF#AL#")); m_hx(m, s->c.alArm, 2); m_c(m, '#'); m_hx(m, s->c.alEntry, 2); m_c(m, '#');
                  m_hx(m, s->c.alSiren, 2); m_c(m, '#'); m_hx(m, s->c.dimsec, 2); m_c(m, '$'); }
        else m_P(m, PSTR("$SET#AL#no$"));
        return (int8_t)(ok ? k : rem);
    }
    if (IS("Set#RS#")) {                             /* back to the programmed settings: forget, then start again */
        if (!(m = q_new(id))) return -1;
        sw_ov_clear(s);
        m_P(m, PSTR("$SET#RS#ok$"));
        rebootDue = 1; rebootAt = now + 1500;
        return 7;
    }
    if (IS("Set#") && rem >= 10 && D2(p + 4) && p[6] == '#' && p[8] == '#') {   /* Set#nn#f#hex# */
        uint8_t n = (uint8_t)((p[4] - '0') * 10 + (p[5] - '0')), u;
        uint32_t v;
        if (!(u = hexn(p + 9, (uint8_t)(rem - 9), &v))) return 9;
        if (!(m = q_new(id))) return -1;
        if (n >= 1 && n <= SW_NP && sw_set(s, (uint8_t)(n - 1), p[7], v)) cf_msg(s, m, (uint8_t)(n - 1));
        else { m_P(m, PSTR("$SET#")); m_2(m, n); m_P(m, PSTR("#no$")); }
        return (int8_t)(9 + u + 1);
    }
    /* phone scenarios: Scn#nn#<20 x 0/1/2><N|F|D><4 digit minutes>#name#   @M_SCN#nn   Scd#nn   &RUN#nn   &CAN#nn   @M_PND */
    if (IS("Scn#") && rem >= 33 && D2(p + 4) && p[6] == '#' && p[32] == '#') {
        uint8_t n = (uint8_t)((p[4] - '0') * 10 + (p[5] - '0')), k = 33, t0 = 33;
        while (k < rem && p[k] != '#') k++;
        int8_t used = (int8_t)(k < rem ? k + 1 : k);
        if (n < 1 || n > PS_N || (p[27] != 'N' && p[27] != 'F' && p[27] != 'D')) return used;
        for (uint8_t j = 0; j < 4; j++) if (p[28 + j] < '0' || p[28 + j] > '9') return used;
        for (uint8_t j = 0; j < 20; j++) if (p[7 + j] < '0' || p[7 + j] > '2') return used;
        uint16_t min = (uint16_t)((p[28] - '0') * 1000 + (p[29] - '0') * 100 + (p[30] - '0') * 10 + (p[31] - '0'));
        uint8_t len = (uint8_t)(k - t0);
        if (len > PS_NAME) { len = PS_NAME; while (len && ((uint8_t)p[t0 + len] & 0xC0) == 0x80) len--; }
        ew_flush();
        ewB[0] = (uint8_t)p[27]; ewB[1] = (uint8_t)(min >> 8); ewB[2] = (uint8_t)min;
        for (uint8_t j = 0; j < 5; j++) ewB[3 + j] = 0;
        for (uint8_t j = 0; j < 20; j++) ewB[3 + (j >> 2)] |= (uint8_t)((p[7 + j] - '0') << ((j & 3) * 2));
        memcpy(ewB + 8, p + t0, len);
        if (len < PS_NAME) ewB[8 + len] = 0;
        ew_start(ps_data((uint8_t)(n - 1)), 8, ps_name((uint8_t)(n - 1)), (uint8_t)(len < PS_NAME ? len + 1 : PS_NAME));
        psKind[n - 1] = 0;                           /* changed: a timer of the old one stops */
        return used;
    }
    if (IS("@M_SCN#") && rem >= 9 && D2(p + 7)) {
        uint8_t n = (uint8_t)((p[7] - '0') * 10 + (p[8] - '0'));
        if (n < 1 || n > PS_N) return 9;
        if (!(m = q_new(id))) return -1;
        n--;
        m_P(m, PSTR("$S")); m_2(m, (uint8_t)(n + 1)); m_c(m, '#');
        uint8_t k = ee_get(ps_data(n));
        if (k != 'N' && k != 'F' && k != 'D') { m_P(m, PSTR("-$")); return 9; }
        for (uint8_t j = 0; j < 20; j++) m_c(m, (char)('0' + ((ee_get((uint16_t)(ps_data(n) + 3 + (j >> 2))) >> ((j & 3) * 2)) & 3)));
        m_c(m, (char)k);
        uint16_t min = (uint16_t)((ee_get((uint16_t)(ps_data(n) + 1)) << 8) | ee_get((uint16_t)(ps_data(n) + 2)));
        m_c(m, (char)('0' + min / 1000 % 10)); m_c(m, (char)('0' + min / 100 % 10)); m_c(m, (char)('0' + min / 10 % 10)); m_c(m, (char)('0' + min % 10));
        m_c(m, '#');
        for (uint8_t j = 0; j < PS_NAME; j++) { uint8_t c = ee_get((uint16_t)(ps_name(n) + j)); if (!c || c == 0xFF) break; m_c(m, (char)c); }
        m_c(m, '$');
        return 9;
    }
    if (IS("Scd#") && rem >= 6 && D2(p + 4)) {
        uint8_t n = (uint8_t)((p[4] - '0') * 10 + (p[5] - '0'));
        if (n >= 1 && n <= PS_N) { ew_flush(); ewB[0] = 0xFF; ew_start(ps_data((uint8_t)(n - 1)), 1, 0, 0); psKind[n - 1] = 0; }
        return 6;
    }
    if (IS("&RUN#") && rem >= 7 && D2(p + 5)) {
        uint8_t n = (uint8_t)((p[5] - '0') * 10 + (p[6] - '0'));
        if (!(m = q_new(id))) return -1;
        uint8_t r = n >= 1 && n <= PS_N ? ps_run(s, (uint8_t)(n - 1), now) : 0;
        m_P(m, PSTR("$RUN=")); m_2(m, n); m_c(m, r == 1 ? 'R' : r == 2 ? 'L' : '-'); m_c(m, '$');
        return 7;
    }
    if (IS("&CAN#") && rem >= 7 && D2(p + 5)) {
        uint8_t n = (uint8_t)((p[5] - '0') * 10 + (p[6] - '0'));
        if (!(m = q_new(id))) return -1;
        if (n >= 1 && n <= PS_N) psKind[n - 1] = 0;
        m_P(m, PSTR("$PND#$"));
        return 7;
    }
    if (IS("@M_PND")) {                              /* timers counting: $PND#nn=mmmm#...$ (minutes left) */
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$PND#"));
        for (uint8_t n = 0; n < PS_N; n++) {
            if (!psKind[n] || m->len > sizeof m->d - 10) continue;
            uint32_t left = (uint32_t)(psAt[n] - now);
            uint16_t mn = (uint16_t)(AFTER(now, psAt[n]) ? 0 : (left + 59999UL) / 60000UL);
            m_2(m, (uint8_t)(n + 1)); m_c(m, psKind[n]); m_c(m, '=');
            m_c(m, (char)('0' + mn / 1000 % 10)); m_c(m, (char)('0' + mn / 100 % 10)); m_c(m, (char)('0' + mn / 10 % 10)); m_c(m, (char)('0' + mn % 10));
            m_c(m, '#');
        }
        m_c(m, '$');
        return 6;
    }
    /* clock: &CLK#ddddd#mmmm#ss (days since 2000-01-01, minute of the day, second; Iran time; not taken while the
       clock comes from the internet)  @M_CLK
       -> $CLK#1#ddddd#mmmm#P$ (P set by a phone, N from the internet)  /  $CLK#0$ (not known: power was cut) */
    if (IS("&CLK#") && rem >= 18 && p[10] == '#' && p[15] == '#') {
        uint16_t d, mi, se;
        if (!(m = q_new(id))) return -1;
        if (dec_n(p + 5, 5, &d) && dec_n(p + 11, 4, &mi) && dec_n(p + 16, 2, &se) && mi < 1440 && se < 60 && d < 36500 &&
            (!ckOk || ckSrc != 'N'))                 /* the internet time (every 2 hours) goes before a phone's */
            ck_set(d, (uint32_t)mi * 60U + se, now, 'P');
        clk_msg(m, now);
        return 18;
    }
    if (IS("@M_CLK")) { if (!(m = q_new(id))) return -1; clk_msg(m, now); return 6; }
    /* vacation: Vac#... (see vac_cmd), then the phone reads it back with @M_VAC:
       $V#o#ddddd#ddddd#n#<n x tttthhhhh>#tttthhhhh#k#l$  or  $V#-#k#l$   k clock known 1/0, l last done 1..6 / E / - */
    if (IS("Vac#")) {
        uint8_t k = 4, h = 0;
        while (k < rem && h < 6) if (p[k++] == '#') h++;  /* 6 more '#': the whole command */
        vac_cmd(p, rem);
        return (int8_t)k;
    }
    if (IS("@M_VAC")) {
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$V#"));
        if (vb[0] != '0' && vb[0] != '1') m_P(m, PSTR("-#"));
        else {
            m_c(m, (char)vb[0]); m_c(m, '#');
            m_dec(m, vb16(1), 5); m_c(m, '#'); m_dec(m, vb16(3), 5); m_c(m, '#');
            m_c(m, (char)('0' + vb[5])); m_c(m, '#');
            for (uint8_t e = 0; e <= vb[5]; e++) {
                if (e == vb[5]) m_c(m, '#');
                m_dec(m, v_rel(e), 4); m_hx(m, v_raw(e), 5);
            }
            m_c(m, '#');
        }
        m_c(m, ckOk ? '1' : '0'); m_c(m, '#'); m_c(m, (char)vLast); m_c(m, '$');
        return 6;
    }
#if HAS_PAIR
    /* the other panel: @M_P2 -> $P2#<model>#<23 key letters>#<online>$ (or $P2#-$)   &P2K#nn -> $P2A#nn#1|0$ */
    if (IS("@M_P2")) {
        if (!(m = q_new(id))) return -1;
        m_P(m, PSTR("$P2#"));
        if (!p2_on(s)) { m_P(m, PSTR("-$")); return 5; }
        for (uint8_t k = 0; k < 8; k++) { uint8_t c = pgm_read_byte(&px_flash[PX_PMDL + k]); if (!c || c > 0x7E) break; m_c(m, (char)c); }
        m_c(m, '#');
        for (uint8_t k = 0; k < SW_NP; k++) { uint8_t c = pgm_read_byte(&px_flash[PX_PLAY + k]); m_c(m, c > ' ' && c < 0x7F ? (char)c : '-'); }
        m_c(m, '#'); m_c(m, s->online ? '1' : '0'); m_c(m, '$');
        P2NEW(id);                                     /* its keys follow */
        return 5;
    }
    if (IS("&P2K#") && rem >= 7 && D2(p + 5)) {
        uint8_t n = (uint8_t)((p[5] - '0') * 10 + (p[6] - '0'));
        if (!(m = q_new(id))) return -1;
        uint8_t ok = p2_on(s) && n >= 1 && n <= SW_NP && sw_px_press(s, (uint8_t)(n - 1));
        m_P(m, PSTR("$P2A#")); m_2(m, n); m_c(m, '#'); m_c(m, ok ? '1' : '0'); m_c(m, '$');
        return 7;
    }
#endif
    if (IS("#AT+CWJAP=")) {                          /* join the home router: #AT+CWJAP="name","password"# */
        int8_t u = take_at(p, rem, '#');
        joinReq = 1; apReq = 0; joinId = id;
        char user[20];
        copy_quoted(user, sizeof user, atCmd);         /* the router name, shown by @M_IP */
        ew_flush();
        memset(ewB, 0, 20); memcpy(ewB, user, strlen(user));
        ew_start(EE_USER, 20, 0, 0);
        return u;
    }
    if (IS("*AT+CWSAP=")) {                            /* new panel network name / password: *AT+CWSAP=...* */
        int8_t u = take_at(p, rem, '*');
        apReq = 1; joinReq = 0;
        return u;
    }
    return 0;
}

static void dispatch(Sw *s, uint32_t now)
{
    for (uint8_t j = 0; j < PN; j++) {
        if (!(payFull & (1 << j))) continue;
        Pay *pl = &pay[j];
        while (pl->pos < pl->len) {
            int8_t u = command(s, pl->id, pl->d + pl->pos, (uint8_t)(pl->len - pl->pos), now);
            if (u < 0) return;                         /* answers waiting: go on later */
            pl->pos = (uint8_t)(pl->pos + (u ? u : 1));
        }
        payFull &= (uint8_t)~(1 << j);
    }
}

/* ---------------- main ---------------- */
static const char c0[] PROGMEM = "AT+CWMODE=3";
/* this panel's own network name: from the programmer, else "sooden-" + the last 4 hex of the module's MAC
   (two panels never show the same name); given to the module once, again when the programmed name changes.
   No buffer (RAM is short): the name is walked twice, once for its check value, once to send it. */
static uint8_t ap_ch(Sw *s, uint8_t k)            /* letter k of the name, 0 = end */
{
    uint8_t c = (uint8_t)s->c.ssid[0];
    if (c > 32 && c < 127) {
        if (k >= sizeof s->c.ssid) return 0;
        c = (uint8_t)s->c.ssid[k];
        return c <= 32 || c >= 127 ? 0 : c;
    }
    if (k < 7) return pgm_read_byte(PSTR("sooden-") + k);
    if (k >= 11) return 0;
    static const uint8_t at[4] PROGMEM = { 12, 13, 15, 16 };
    c = (uint8_t)mac[pgm_read_byte(&at[k - 7])];
    return c >= 'a' && c <= 'f' ? (uint8_t)(c - 32) : c;
}
static uint8_t __attribute__((noinline)) ap_crc(Sw *s)   /* 0 = no name yet (MAC not known) */
{
    if (!(s->c.ssid[0] > 32 && s->c.ssid[0] < 127) && strlen(mac) < 17) return 0;
    uint8_t c = 0, ch;
    for (uint8_t k = 0; (ch = ap_ch(s, k)); k++) { c ^= ch; for (uint8_t j = 0; j < 8; j++) c = (c & 0x80) ? (uint8_t)((c << 1) ^ 0x07) : (uint8_t)(c << 1); }
    return c == 0xFF || c == 0 ? 0xFE : c;             /* 0xFF = never given (erased EEPROM) */
}
static void __attribute__((noinline)) ap_send(Sw *s)
{
    uint8_t ch;
    tx_P(PSTR("AT+CWSAP=\""));
    for (uint8_t k = 0; (ch = ap_ch(s, k)); k++) { if (ch == '"' || ch == '\\' || ch == ',') tx('\\'); tx(ch); }
    tx_P(PSTR("\",\"sooden123\",1,3")); tx_nl();
}
static uint8_t apSent;
static const char c2[] PROGMEM = "AT+CIPMUX=1";
static const char c3[] PROGMEM = "AT+CIPSERVER=1,6269";
static const char c4[] PROGMEM = "AT+CIFSR";
static const char c5[] PROGMEM = "AT+CIPSNTPCFG=1,0,\"pool.ntp.org\",\"time.google.com\"";
static const char c6[] PROGMEM = "AT+CIPSNTPTIME?";
static const char c8[] PROGMEM = "AT+CWQAP";
static const char c9[] PROGMEM = "AT+RST";
static uint8_t has_ip(void) { return ip[0] && strcmp_P(ip, PSTR("0.0.0.0")); }
static uint8_t router_set(void) { uint8_t c = eeprom_read_byte((const uint8_t *)EE_USER); return c && c != 0xFF; }

void wf_poll(Sw *s, uint32_t now)
{
#ifdef SW_P12
    evNow = now;
    /* the alarm settings did not come whole (a bus B frame lost): ask the alarm MCU again, up to 3 times */
    if (acfWant != 0xFF && acfSeen == p12acfGen && AFTER(now, acfAt + 10000)) {
        if (acfTry >= 3) acfWant = 0xFF;
        else if (p12_app_send(6, 1, 0)) { acfAt = now; acfTry++; }
    }
#endif
    ew_poll();
    ps_tick(s, now);
    vac_tick(s, now);
    if (eeprom_is_ready()) sw_ov_step(s);
    if (rebootDue && AFTER(now, rebootAt) && !qn && (wst == W_IDLE || wst == W_OFF)) {
        ew_flush();
        while (!eeprom_is_ready()) ;
        wdt_enable(WDTO_15MS);                         /* start again with the programmed settings */
        for (;;) ;
    }
    if (!s->wifi) {
        if (wasOn) { uart_off(); wasOn = 0; wst = W_OFF; conn = 0; qn = 0; payFull = 0; payIn = -1; joinReq = apReq = 0; staOff = 0; joinRes = joinFail = 0; }
        return;
    }
    if (!wasOn) { uart_on(); wasOn = 1; wst = W_BOOT; until = now + 4000; ln = 0; }

    tNow = now;
    while (rxt != rxh) { uint8_t c = rxb[rxt]; rxt = (uint8_t)(rxt + 1); rx_byte(c); }
    dispatch(s, now);
    if (wakeReq) { wakeReq = 0; sw_wake(s); }

    switch (wst) {
    case W_BOOT:                                       /* wait for "ready" (or 4 s), then a short pause */
        if (until == 0) until = now + 500;             /* "ready" seen */
        if (AFTER(now, until)) { wst = W_INIT; step = 0; until = now; evOk = evErr = 1; }
        break;
    case W_INIT:
        if (!(evOk || evErr || AFTER(now, until))) break;
        if (step == 3 && apSent && evOk) eeprom_update_byte((uint8_t *)EE_APINIT, apSent);   /* the network name is set */
        if (step == 2) {                               /* the name, if the module does not have it yet */
            uint8_t cr = ap_crc(s);
            apSent = 0;
            if (cr && eeprom_read_byte((const uint8_t *)EE_APINIT) != cr) {
                apSent = cr; evOk = evErr = 0;
                ap_send(s);
                until = now + 6000; step = 3;
                break;
            }
            step = 3;
        }
        switch (step++) {
        case 0: cmd_P(c0, now, 2000); break;
        case 1: cmd_P(c4, now, 3000); break;           /* its MAC first (for the network name) */
        case 3: cmd_P(c2, now, 2000); break;
        case 4: cmd_P(c3, now, 2000); break;
        case 5: cmd_P(c4, now, 3000); break;
        default: wst = W_IDLE; needIp = 0; snAt = now + 1000; staOff = 0; staAt = now; break;   /* then the time (if on a router) */
        }
        break;
    case W_STA:                                        /* the module stops looking for the router: AT+CWQAP */
        if (evOk || evErr || AFTER(now, until)) wst = W_IDLE;
        break;
    case W_AP: case W_IP:
        if (evOk || evErr || AFTER(now, until)) {
            if (wst == W_IP && joinFail && has_ip() && !AFTER(now, joinEnd)) { joinRes = 3; joinFail = 0; joinSent = 0; joinAt = now; }   /* joined late */
            wst = W_IDLE;
        }
        break;
    case W_JOIN:                                       /* joining the router: up to 30 s */
        /* "WIFI CONNECTED", "WIFI GOT IP", then the OK of the command: ask the address after the OK */
        if (evOk || (evGotIp && AFTER(now, until))) { evGotIp = 0; ipTry = 0; until = now + 2000; wst = W_JOINW; break; }
        if (evErr || AFTER(now, until)) { joinRes = 1; joinFail = 1; joinSent = 0; joinAt = now; wst = W_IDLE; }
        break;
    case W_JOINW:                                      /* 2 s after joining, then the address */
        if (AFTER(now, until)) { ip[0] = 0; cmd_P(c4, now, 3000); wst = W_JOINIP; }
        break;
    case W_JOINIP:
        if (evOk || evErr || AFTER(now, until)) {
            if (!has_ip() && ++ipTry < 3) { until = now + 2000; wst = W_JOINW; break; }
            joinRes = has_ip() ? 3 : 2; joinFail = 0; joinSent = 0; joinAt = now;
            needIp = 0;
            wst = W_IDLE;
        }
        break;
    case W_SNTPC:                                      /* time servers set up once after each ESP start */
        if (evOk) { snCfg = 1; snAt = now + 15000; wst = W_IDLE; }   /* the ESP needs a few seconds for the first answer */
        else if (evErr) { snCfg = 2; wst = W_IDLE; }                 /* old AT firmware without SNTP: only the phone sets the clock */
        else if (AFTER(now, until)) { snAt = now + T_SNTP_FAIL; wst = W_IDLE; }
        break;
    case W_SNTPT:
        if (evOk || evErr || AFTER(now, until)) {
            if (snGot) { ck_set(snDay, snSec, now, 'N'); snAt = now + T_SNTP_OK; }
            else snAt = now + T_SNTP_FAIL;
            wst = W_IDLE;
        }
        break;
    case W_SEND1:                                      /* AT+CIPSEND sent: wait for "> " */
        if (evPrompt) {
            for (uint8_t k = 0; k < cur.len; k++) tx((uint8_t)cur.d[k]);
            evSendOk = evErr = 0; until = now + 2000; wst = W_SEND2;
        } else if (evErr || AFTER(now, until)) {
            if (evErr) conn &= (uint8_t)~(1 << cur.id);   /* "link is not valid" */
            if (curFromQ) { qh = (uint8_t)((qh + 1) % QN); qn--; }
            wst = W_IDLE;
        }
        break;
    case W_SEND2:
        if (evSendOk || evErr || AFTER(now, until)) {
            if (curFromQ) { qh = (uint8_t)((qh + 1) % QN); qn--; }
            wst = W_IDLE;
        }
        break;
    default: break;
    }
    if (wst != W_IDLE) return;

    if (apReq) { apReq = 0; evOk = evErr = 0; tx_s(atCmd); tx_nl(); until = now + 6000; wst = W_AP; return; }
    if (joinReq) {
        joinReq = 0; staOff = 0; staAt = now + T_JOIN; evOk = evErr = evGotIp = 0;
        joinRes = 0; joinFail = 0; joinSent = 0; joinEnd = now + T_JOIN + T_JOINANS;
        tx_s(atCmd); tx_nl(); until = now + T_JOIN; wst = W_JOIN;
        return;
    }
    if (has_ip()) staAt = now;                         /* on the router */
    else if (!staOff && AFTER(now, staAt + T_STA_LOST) && eeprom_is_ready() && router_set()) {
        staOff = 1; cmd_P(c8, now, 3000); wst = W_STA; return;      /* router gone: keep this panel's own network usable */
    }
    else if (staOff && AFTER(now, staAt + T_STA_LOST + T_STA_RETRY) && !conn && !qn) {
        staOff = 0; cmd_P(c9, now, 3000); wst = W_BOOT; until = now + 6000; return;   /* try the router again */
    }
    if (needIp && AFTER(now, gotIpAt + 2000)) { needIp = 0; cmd_P(c4, now, 3000); wst = W_IP; return; }
    if (joinRes) {                                     /* the join answer: its link, and every phone past its first steps */
        if (AFTER(now, joinAt + T_JOINANS)) joinRes = 0;
        else {
            uint8_t want = (uint8_t)(conn & (live | (uint8_t)(1 << joinId)) & (uint8_t)~joinSent);
            Msg *m;
            for (uint8_t to = 0; to < NCONN && want; to++) {
                if (!(want & (1 << to))) continue;
                if (!(m = q_new(to))) break;
                if (joinRes == 1) m_P(m, PSTR("@M_S=Error\n"));
                else if (joinRes == 2) m_P(m, PSTR("@M_S=Repeat\n"));
                else { m_P(m, PSTR("@M_S=")); for (uint8_t k = 0; ip[k]; k++) m_c(m, ip[k]); }
                joinSent |= (uint8_t)(1 << to);
                want &= (uint8_t)~(1 << to);
            }
        }
    }
    if (snSoon) { snSoon = 0; snAt = now + (snCfg == 1 ? 8000 : 1000); }   /* joined the router again: the time now */
    if (snCfg != 2 && ip[0] && strcmp_P(ip, PSTR("0.0.0.0")) && AFTER(now, snAt) && !qn) {
        snGot = 0;
        if (snCfg == 0) { cmd_P(c5, now, 3000); wst = W_SNTPC; }
        else { cmd_P(c6, now, 3000); wst = W_SNTPT; }
        return;
    }
    while (qn && !(conn & (1 << q[qh].id))) { qh = (uint8_t)((qh + 1) % QN); qn--; }   /* that phone left */
    if (next_msg(s, now)) {
        char b[24];
        uint8_t k = 0;
        const char *h = PSTR("AT+CIPSEND=");
        char c;
        while ((c = (char)pgm_read_byte(h++))) b[k++] = c;
        b[k++] = (char)('0' + cur.id); b[k++] = ',';
        if (cur.len >= 100) b[k++] = (char)('0' + cur.len / 100);
        if (cur.len >= 10) b[k++] = (char)('0' + cur.len / 10 % 10);
        b[k++] = (char)('0' + cur.len % 10); b[k] = 0;
        evPrompt = evErr = 0;
        tx_s(b); tx_nl();
        until = now + 1000; wst = W_SEND1;
    }
}
