#!/bin/sh
# 12 economic panel (one ATmega64): the 23-key logic with its own board file; programs only with the pole kinds the panel uses
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
mkdir -p out
rm -f out/fw_e12*.hex
F="-DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 -mcall-prologues -mrelax -flto -ffunction-sections -fdata-sections -Wl,--gc-sections"
e12() {   # name sec ilock scn pair
  P="-DHAS_PAIR=0 -DHAS_PX=0"; [ "$5" = 1 ] && P="-DHAS_PAIR=1 -DHAS_PX=1 -Wl,--section-start=.swpx=0xF300"
  avr-gcc -mmcu=atmega64 $F -DSW_BIG -DSW_E12 -DFW_BOARD=BOARD_BIG -DHAS_REMOTE=1 $P -DHAS_SEC=$2 -DHAS_ILOCK=$3 -DHAS_SCN=$4 -DHAS_ALARM=0 \
    -Wl,--section-start=.swcfg=0xF000 main_e12.c sw.c wifi64.c -o out/$1.elf
  avr-objcopy -O ihex -R .eeprom out/$1.elf out/$1.hex
  printf "%-20s " $1; avr-size out/$1.elf | tail -1
}
for p in 0 1; do for g in "" s i x si sx ix six; do
  n=fw_e12; [ -n "$g" ] && n=${n}_$g; [ $p = 1 ] && n=${n}_p
  case $g in *s*) S=1;; *) S=0;; esac; case $g in *i*) I=1;; *) I=0;; esac; case $g in *x*) X=1;; *) X=0;; esac
  e12 $n $S $I $X $p
done; done
