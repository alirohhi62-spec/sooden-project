# Design decisions for the rewrite (from user answers, 2026-10-17)

- Inter-MCU buses stay as they are: the 5-bit bus (M4 → M32s), the 4-bit bus (alarm → M4) and the 3-bit bus (M4 → alarm). The rewrite only makes the timing and protocol on these buses more robust.
- Compiler: CodeVision AVR. MCUs: M1, M2 and M3 are ATmega32A; M4 (WiFi) and the alarm MCU are ATmega64A.
- Relays are driven from each MCU's "red" pin through a ULN. The relay board has a hardware interlock between curtain open and close.
- Alarm keypad codes and the sensor/siren numbering: the program is correct, the old sheet is not.
- K1 (radiator), K2 (valve) and K3 (lock, bottom left) are latched outputs for now. They can also be controlled by SMS. SMS K1/K2/K3 must drive these same outputs (fixes the current code, where SMS K1 drives K3 and SMS K3 drives K1).
- The six bottom-right icons are user-defined scenarios. They can also be run by SMS.
- Glass icons are only print artwork and can change per project. Code must name keys by position and function (S1..S6, K1..K3, L1..L12, N1..N4), never by icon.
- M key: all ON takes priority. If everything is already on, a touch switches everything off.
- Indicator LEDs:
  - N1 is the lock-icon LED. It keeps its current behaviour: it only blinks to confirm that a scenario was saved.
  - N2 is the power-outage LED.
  - N3 is the WiFi LED.
  - N4 is the GSM signal LED.
  - Led_PoL is the ULN group power; it turns off in standby.
- Reserved inputs: E3, E4, E5 and E6 on M4, and PC7 on the alarm MCU. The alarm's PC7 is planned for power-fail detection, which will send an SMS on a power outage.
- The 7-segment display is common anode, with DP not connected. It selects a room or zone (1–9, A–Z, a–z) for network commands such as all on / all off; up and down change the selection.
- RS485 hardware: an auto-direction TTL-to-RS485 module (pins VCC/TXD/RXD/GND, A+/B-). There is no DE/RE pin, so firmware does no direction control. Firmware must still listen before talking and leave a short gap after each frame.
- Panel-to-panel network:
  - RS485 on M4 UART1 (PD2 = RXD1, PD3 = TXD1).
  - RF: transmitter on PC7, receiver on PE6.
  - The message format must be defined (draft proposed: RS485 frame with address, command, CRC and ACK; RF in EV1527-compatible 24-bit format).
- Timings stay as they are for now.
- No password for WiFi/app commands for now. The app can be changed if the protocol changes.
- GSM ATD/ATH work in practice; leave them as they are.
- The installed version is the latest .lst version, but it is customised slightly for each project.

- RF transmitter: 433 MHz ASK module (same band as the receivers).
- Network topology: both peer-to-peer and master/slave must be supported, selectable per project.
- RF output must also be able to control third-party 433 MHz relays and sockets (EV1527-style codes).
- Power-fail input: alarm PC7 (pin 42), confirmed by the user. Keep it as a #define. (PC4 is Sensor 1.)

Open questions:
- Extra features (question 30): the user will tell later.
