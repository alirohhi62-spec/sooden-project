#include <io.h>
#include <delay.h>


//---------------------------OLED----------------------------------


#include <stdio.h>
#include <i2c.h>
#include "ssd1306.c"


//---------------------------Touch----------------------------------


#define Touch      (PINA.1 ==0 || PINA.0 ==0 || PINB.0 ==0 || PINB.1 ==0 || PINB.2 ==0)

#define Touch_N2    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==1
#define Touch_N3    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==0
//#define Touch_N4    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==1
#define Touch_N4    PINB.7 ==0

#define Touch_L1    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==0
#define Touch_L2    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==0 && PINB.2 ==1
#define Touch_L3    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==0 && PINB.2 ==0
#define Touch_L4    PINA.1 ==1 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==1 && PINB.2 ==1

#define Touch_P1O   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==1 && PINB.2 ==0
#define Touch_P1C   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==1

#define Touch_P2O   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==0
#define Touch_P2C   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==1

#define Touch_Ss    PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==0 && PINB.1 ==0 && PINB.2 ==1
#define Touch_Sd    PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==0


//---------------------------Led----------------------------------


bit     N2 =0 , N3 =0 , N4 =0;


#define Led_N2        PORTA.7 =~ PORTA.7  , PORTA.6 =~ PORTA.6 , N2 =! N2
#define White_N2      PORTA.7
#define Red_N2        PORTA.6

#define Led_N3        PORTC.6 =~ PORTC.6  , PORTC.7 =~ PORTC.7 , N3 =! N3
#define White_N3      PORTC.6
#define Red_N3        PORTC.7

#define Led_N4        PORTC.4 =~ PORTC.4  , PORTC.5 =~ PORTC.5 , N4 =! N4
#define White_N4      PORTC.4
#define Red_N4        PORTC.5


#define Led_L1        PORTA.5 =~ PORTA.5  , PORTA.4 =~ PORTA.4 //, LCD_DrawImage(2)
#define White_L1      PORTA.5
#define Red_L1        PORTA.4

#define Led_L2        PORTD.1 =~ PORTD.1  , PORTD.0 =~ PORTD.0 //, LCD_DrawImage(0)
#define White_L2      PORTD.1
#define Red_L2        PORTD.0

#define Led_L3        PORTA.3 =~ PORTA.3  , PORTA.2 =~ PORTA.2 //, LCD_DrawImage(3)
#define White_L3      PORTA.3
#define Red_L3        PORTA.2

#define Led_L4        PORTB.4 =~ PORTB.4  , PORTB.3 =~ PORTB.3 //, LCD_DrawImage(1)
#define White_L4      PORTB.4
#define Red_L4        PORTB.3


#define Led_P1O       PORTD.7 =~ PORTD.7  , PORTD.4 =~ PORTD.4
#define White_P1O     PORTD.7
#define Red_P1O       PORTD.4

#define Led_P1C       PORTC.0 =~ PORTC.0  , PORTC.1 =~ PORTC.1
#define White_P1C     PORTC.0
#define Red_P1C       PORTC.1

#define Led_P2O       PORTD.3 =~ PORTD.3  , PORTD.2 =~ PORTD.2
#define White_P2O     PORTD.3
#define Red_P2O       PORTD.2

#define Led_P2C       PORTC.2 =~ PORTC.2  , PORTC.3 =~ PORTC.3
#define White_P2C     PORTC.2
#define Red_P2C       PORTC.3


#define Led_LP       PORTB.5 =~ PORTB.5


//---------------------------Stand_by--------------------------------


  void Stand_by (char Typ);


//---------------------------Status----------------------------------


void Status(void);

#define Status_Time   Status_Countr >= 60000


//---------------------------Function  Main----------------------------------


void main(void)
 {

 //long unsigned int Status_Countr =0;

 bit L =1 , L1 =1 , S_by =0;


 delay_ms(300);


    DDRA  = 0b11111100;
    PORTA = 0b10101011;

    DDRB  = 0b00111000;
    PORTB = 0b10110111;

    DDRC  = 0b11111111;
    PORTC = 0b01010101;

    DDRD  = 0b11111111;
    PORTD = 0b10001010;

    i2c_init();
    LCD_init();
    LCD_Contrast(255);
    LCD_Mode(0);

    delay_ms(300);

    LCD_DrawImage(5);

    Status();

    delay_ms(300);

 while(1)
  {
      //if(Status_Time) Status() , Status_Countr =0;


      if(Touch && L)
        {
            delay_ms(20);

            if(Touch_N2)   Led_N2;

            if(Touch_N3)   Led_N3;

            //if(Touch_N4)   Led_N4;


            if(Touch_L1)   Led_L1 , Status(); //Status_Countr =1;

            if(Touch_L2)   Led_L2 , Status(); //Status_Countr =1;

            if(Touch_L3)   Led_L3 , Status(); //Status_Countr =1;

            if(Touch_L4)   Led_L4 , Status(); //Status_Countr =1;


            if(Touch_P1O)  Led_P1O ;

            if(Touch_P1C)  Led_P1C ;


            if(Touch_P2O)  Led_P2O ;

            if(Touch_P2C)  Led_P2C ;


            if(Touch_Ss)   { if(S_by) S_by =0 , Stand_by(1) ; else  S_by =1 , Stand_by(0) ; }

            if(Touch_Sd)     S_by =0 , Stand_by(2) ;


        //------------------------------------------------------------------

            L =0;
        }

      if(!Touch && !L)    L =1;


      if(Touch_N4 && L1)   Led_N4 , L1 =0;

      if(!Touch_N4 && !L1) L1 =1;


      //if(Status_Countr >= 1) Status_Countr ++;
  }

 }


//---------------------------Function  Stand_by------------------------------


    void Stand_by (char Typ)
     {
        if(Typ == 0)   // OFF
         {
             White_N2 =0  , Red_N2  =0;

             White_N3 =0  , Red_N3  =0;

             //White_N4 =0  , Red_N4  =0;

             delay_ms(100);

             White_L1 =0  , Red_L1  =0;

             White_L2 =0  , Red_L2  =0;

             White_L3 =0  , Red_L3  =0;

             White_L4 =0  , Red_L4  =0;

             delay_ms(500);

             White_P1O =0 , Red_P1O =0;

             White_P1C =0 , Red_P1C =0;

             White_P2O =0 , Red_P2O =0;

             White_P2C =0 , Red_P2C =0;

             delay_ms(100);

             Led_LP;

             delay_ms(200);

             LCD_DrawImage(0);
         }

        if(Typ == 1)   // ON ==> Delay
         {
             LCD_DrawImage(5) , Status();

             if(N2)   Red_N2 =1 ;   else   White_N2 =1 ;

             if(N3)   Red_N3 =1 ;   else   White_N3 =1 ;

             //if(N4)   Red_N4 =1 ;   else   White_N4 =1 ;

             delay_ms(100);

             White_L1 =1  , White_L2  =1;

             White_L3 =1  , White_L4  =1;

             delay_ms(500);

             White_P1O =1 , White_P1C =1;

             White_P2O =1 , White_P2C =1;

             delay_ms(100);

             Led_LP;
         }

        if(Typ == 2)   // ON ==> NO Delay
         {
             LCD_DrawImage(5) , Status();

             if(N2)   Red_N2 =1 ;   else   White_N2 =1 ;

             if(N3)   Red_N3 =1 ;   else   White_N3 =1 ;

             //if(N4)   Red_N4 =1 ;   else   White_N4 =1 ;


             White_L1 =1  , White_L2  =1;

             White_L3 =1  , White_L4  =1;

             White_P1O =1 , White_P1C =1;

             White_P2O =1 , White_P2C =1;


             Led_LP;
         }
     }


//---------------------------Function  Oled----------------------------------


    void Status(void)
     {
        unsigned char buff[50];
        unsigned char v =0;


        //LCD_DrawImage(5);


        if(Red_L1 == 1)   LCD_Goto2X(36 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(36 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L2 == 1)   LCD_Goto2X(20 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(20 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L3 == 1)   LCD_Goto2X(36 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(36 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L4 == 1)   LCD_Goto2X(20 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(20 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
     }
