#include <io.h>
#include <delay.h>
#include <stdio.h>
#include <string.h>
#include <eeprom.h>


//---------------------------OLED----------------------------------


#include <stdio.h>
#include <i2c.h>
#include "ssd1306.c"


//---------------------------BIN1----------------------------------


#define BIN10   PINA.3
#define BIN11   PINA.2
#define BIN12   PINA.1
#define BIN13   PINA.0 ==0


//---------------------------BIN2----------------------------------


#define BIN20   PINA.7
#define BIN21   PINA.6
#define BIN22   PINA.5
#define BIN23   PINA.4 ==0

#define Touch (BIN13 || BIN23)


//---------------------------Touch1----------------------------------


#define Touch_R    BIN13 && BIN12 ==1 && BIN11 ==1 && BIN10 ==0
#define Touch_L    BIN13 && BIN12 ==1 && BIN11 ==0 && BIN10 ==1

#define Touch_1    BIN13 && BIN12 ==0 && BIN11 ==1 && BIN10 ==1
#define Touch_2    BIN13 && BIN12 ==1 && BIN11 ==0 && BIN10 ==0
#define Touch_3    BIN13 && BIN12 ==1 && BIN11 ==1 && BIN10 ==1
#define Touch_4    BIN13 && BIN12 ==0 && BIN11 ==1 && BIN10 ==0
#define Touch_5    BIN13 && BIN12 ==0 && BIN11 ==0 && BIN10 ==1
#define Touch_6    BIN13 && BIN12 ==0 && BIN11 ==0 && BIN10 ==0


//---------------------------Touch2----------------------------------


#define Touch_0    BIN23 && BIN22 ==0 && BIN21 ==1 && BIN20 ==0
#define Touch_7    BIN23 && BIN22 ==1 && BIN21 ==0 && BIN20 ==1
#define Touch_8    BIN23 && BIN22 ==1 && BIN21 ==1 && BIN20 ==0
#define Touch_9    BIN23 && BIN22 ==1 && BIN21 ==1 && BIN20 ==1

#define Touch_C    BIN23 && BIN22 ==0 && BIN21 ==1 && BIN20 ==1

#define Touch_OK   BIN23 && BIN22 ==0 && BIN21 ==0 && BIN20 ==0

#define Touch_D    BIN23 && BIN22 ==0 && BIN21 ==0 && BIN20 ==1

#define Touch_P    //Touch_R



//---------------------------Variable RF----------------------------------


const unsigned long int Bit_Shift = 0x00000001;

unsigned long int  EV_Code = 0;

int Revice_Flag = 0;

unsigned char RF_Z =0;

//---------------------------remut var----------------------------------


#define    Learn        (Touch_OK && !Red_Zoon_1 && !Red_Zoon_2 && !Red_Zoon_3)
#define    Format       (Touch_C  && !Red_Zoon_1 && !Red_Zoon_2 && !Red_Zoon_3)

#define    Led_Learn_ON     White_Zoon_1 =1
#define    Led_Learn_OFF    White_Zoon_1 =0

#define    Led_Format_ON    White_Zoon_2 =1
#define    Led_Format_OFF   White_Zoon_2 =0

#define    RF_PIN     PINE.4     // INT4


//---------------------------Function RF----------------------------------


    #define EE_Total_Rec 5

    eeprom unsigned long int g_u32eeprom[EE_Total_Rec];

    void EE_Format (void);

    void EE_StoreCode (unsigned long int Code);

    char EE_ISValidCode (unsigned long int Code);

    void Ralay_Control (char Rkey);


//---------------------------remut var----------------------------------


interrupt [EXT_INT4] void ext_int4_isr(void)
{
// Place your code here
#asm("cli")
    static unsigned long int    Time_Falling=0;
    static unsigned long int    Time_Rising=0;
    static unsigned int         Start_Sync = 0;
    static unsigned char        Bit_Index = 0;
    static unsigned long int    Receive_Code = 0;

    if(!Revice_Flag)
      {
            if(RF_PIN) // Rising Edge
              {
                TCCR1B=0x00;
                Time_Falling = TCNT1*2;
                TCCR1A=0x00 , TCCR1B=0x02;
                TCNT1H=0x00 , TCNT1L=0x00;
                ICR1H=0x00  , ICR1L=0x00;
                OCR1AH=0x00 , OCR1AL=0x00;
                OCR1BH=0x00 , OCR1BL=0x00;


                if(Time_Falling > (Time_Rising * 20) && Time_Falling < (Time_Rising * 40))
                 {
                    Start_Sync = 1;
                    Bit_Index = 0;
                    Receive_Code = 0;

                 }
                else
                 {
                    if(Start_Sync)    // Start Sended
                     {
                        if(Bit_Index <= 23)
                         {
                            if(Time_Falling > (Time_Rising*2) && Time_Falling < (Time_Rising*4))
                             {
                                Bit_Index++;
                             }
                            else if(Time_Rising > (Time_Falling*2) && Time_Rising < (Time_Falling*4))
                             {
                                Receive_Code |= Bit_Shift << (23-Bit_Index);
                                Bit_Index++;
                             }
                            else
                             {
                                Start_Sync = 0;
                                Bit_Index = 0;
                             }

                            if(Bit_Index > 23&&Start_Sync)
                             {
                                // All Bit Recive
                                Bit_Index = 0;
                                Start_Sync = 0;
                                EV_Code = Receive_Code;
                                Revice_Flag = 1;
                             }
                         }
                     }    // End of Start Sync Send
                 }


              }
            else    //Falling Edge
            {
                TCCR1B=0x00;
                Time_Rising = TCNT1*2;
                TCCR1A=0x00 , TCCR1B=0x02;
                TCNT1H=0x00 , TCNT1L=0x00;
                ICR1H=0x00  , ICR1L=0x00;
                OCR1AH=0x00 , OCR1AL=0x00;
                OCR1BH=0x00 , OCR1BL=0x00;

            }
      }

#asm("sei")
}


//---------------------------Output----------------------------------


unsigned char  Alarm_On_1 =0 , Alarm_Cunter_1 =0 , Alarm_On_2 =0 , Alarm_Cunter_2 =0 , Alarm_On_3 =0 , Alarm_Cunter_3 =0;

unsigned char  pass[13];

eeprom char    o , Z1 , Z2 , Z3 , Memory_pass[5];

eeprom char    SMS_Number_1[13] , SMS_Number_2[13] , SMS_Number_3[13] , SMS_N1 , SMS_N2 , SMS_N3;

eeprom char    Call_Number[13]  , Call_N1;

bit            E2 , SMS_Phone_Number_1 =0 , SMS_Phone_Number_2 =0 , SMS_Phone_Number_3 =0 , Red_Antenna =0 , GSM_Activ =0;


#define Buzzer            PORTB.5 =~ PORTB.5 , delay_ms(3) , PORTB.5 =~ PORTB.5

#define Led_Zoon_1        PORTB.6 =~ PORTB.6  , PORTB.7 =~ PORTB.7
#define White_Zoon_1      PORTB.6
#define Red_Zoon_1        PORTB.7

#define Led_Zoon_2        PORTD.1 =~ PORTD.1  , PORTD.2 =~ PORTD.2
#define White_Zoon_2      PORTD.1
#define Red_Zoon_2        PORTD.2

#define Led_Zoon_3        PORTD.3 =~ PORTD.3  , PORTD.4 =~ PORTD.4
#define White_Zoon_3      PORTD.3
#define Red_Zoon_3        PORTD.4

#define Input_Sensur_4    PINC.7
#define Input_Sensur_2    PINC.6
#define Input_Sensur_3    PINC.5
#define Input_Sensur_1    PINC.4

#define Alarm_Buzzer_3    PORTC.3 //=~ PORTC.3
#define Buzzer_3          PORTC.3

#define Alarm_Buzzer_2    PORTC.2 //=~ PORTC.2
#define Buzzer_2          PORTC.2

#define Alarm_Buzzer_1    PORTC.1 //=~ PORTC.1
#define Buzzer_1          PORTC.1

#define Led_N_OFF         PORTC.0 =0 , OUT_Stand_by
#define Led_N_ON          PORTC.0 =1 , OUT_Stand_by

#define Led_D             PORTE.3 =~ PORTE.3 , PORTE.2 =~ PORTE.2 , E2 =! E2
#define White_D           PORTE.3
#define Red_D             E2

#define Led_P             Led_Zoon_2
#define White_P           White_Zoon_2
#define Red_P             Red_Zoon_2

#define Led_Antenna_OUT   PORTB.1 =0 , delay_ms(10) , PORTB.1 =1 , Red_Antenna =! Red_Antenna
#define Led_Signal        Led_Antenna_OUT , delay_ms(300) , Led_Antenna_OUT

#define Exit_Stand_by    (Red_D && (Alarm_On_1 ==1 || Alarm_On_2 ==1 || Alarm_On_3 ==1) && (Input_Sensur_1 || Input_Sensur_2 || Input_Sensur_3))


//-----------------------------Touch M64-4 & M64 Alarm--------------------------


    bit     WiFi_Alarm =0;


    #define OUT              delay_ms(30) , PORTE.5 =1 , PORTE.6 =1 , PORTE.7 =1 , PORTB.0 =1 , delay_ms(10)

    #define OUT_S1           PORTE.5 =1 , PORTE.6 =1 , PORTE.7 =1 , PORTB.0 =0 , OUT
    #define OUT_S2           PORTE.5 =1 , PORTE.6 =1 , PORTE.7 =0 , PORTB.0 =1 , OUT
    #define OUT_S3           PORTE.5 =1 , PORTE.6 =1 , PORTE.7 =0 , PORTB.0 =0 , OUT
    #define OUT_S4           PORTE.5 =1 , PORTE.6 =0 , PORTE.7 =1 , PORTB.0 =1 , OUT
    #define OUT_S5           PORTE.5 =1 , PORTE.6 =0 , PORTE.7 =1 , PORTB.0 =0 , OUT

    #define OUT_Alarm_ON     PORTE.5 =1 , PORTE.6 =0 , PORTE.7 =0 , PORTB.0 =1 , OUT
    #define OUT_Alarm_OFF    PORTE.5 =1 , PORTE.6 =0 , PORTE.7 =0 , PORTB.0 =0 , OUT

    #define OUT_Stand_by     PORTE.5 =0 , PORTE.6 =1 , PORTE.7 =1 , PORTB.0 =1 , OUT

    #define OUT_K1_O         PORTE.5 =0 , PORTE.6 =1 , PORTE.7 =1 , PORTB.0 =0 , OUT
    #define OUT_K1_F         PORTE.5 =0 , PORTE.6 =1 , PORTE.7 =0 , PORTB.0 =1 , OUT
    #define OUT_K2_O         PORTE.5 =0 , PORTE.6 =1 , PORTE.7 =0 , PORTB.0 =0 , OUT
    #define OUT_K2_F         PORTE.5 =0 , PORTE.6 =0 , PORTE.7 =1 , PORTB.0 =1 , OUT
    #define OUT_K3_O         PORTE.5 =0 , PORTE.6 =0 , PORTE.7 =1 , PORTB.0 =0 , OUT
    #define OUT_K3_F         PORTE.5 =0 , PORTE.6 =0 , PORTE.7 =0 , PORTB.0 =1 , OUT


    #define Alarm_Feed       if(Red_D)       OUT_Alarm_ON ;   else    OUT_Alarm_OFF
    #define Alarm_Order      WiFi_Alarm =1 , OLED_ON_OFF(4) , WiFi_Alarm =0


  //---------------------------Touch Input M64-------------------------------


    bit     Lock =1;


    #define Touch_IN                (PINB.2 == 0 || PINB.3 == 0 || PINB.4 == 0)

    #define Touch_IN_Lock           (PINB.2 == 1 && PINB.3 == 1 && PINB.4 == 0)

    #define Touch_IN_Alarm_Order    (PINB.2 == 1 && PINB.3 == 0 && PINB.4 == 1)
    #define Touch_IN_Alarm_Feed     (PINB.2 == 1 && PINB.3 == 0 && PINB.4 == 0)

    #define Touch_Stand_by          (PINB.2 == 0 && PINB.3 == 1 && PINB.4 == 1)


//---------------------------Function OLED------------------------------------


bit             Zoon_Number =0 , Rotation_LCD =0;

unsigned char   num_OLED =5 , num =0 , Button_Number =0;

unsigned char   Rotation_Next , Rotation_OnOff , Rotation_Pass , Rotation_SMS =0 , Rotation_Call;



#define Rotation_RL    (!Rotation_OnOff && !Rotation_Pass && !Rotation_SMS && !Rotation_Call)


void OLED_ON_OFF (char Show1);

void OLED_Pass   (char Show2);

void OLED_SMS    (char Show3);

void OLED_Call   (char Show4);

void Button      (char Add);

void OLED_Clean  (void);


#define Status_Time      Status_Countr >= 60000


//---------------------------Variable GSM----------------------------------


unsigned char       data[252] , str[252];

unsigned char       i =0 , j =0 , Add_Signal =0;

eeprom   char       o;


#define   Rset_GSM               PORTD.0 =~ PORTD.0 , delay_ms(100) , PORTD.0 =~ PORTD.0

#define   Check_SMS_Number_1    (!SMS_N1 && data[j] == SMS_Number_1[2] && data[j+1] == SMS_Number_1[3] && data[j+2] == SMS_Number_1[4] && data[j+3] == SMS_Number_1[5] && data[j+4] == SMS_Number_1[6] && data[j+5] == SMS_Number_1[7] && data[j+6] == SMS_Number_1[8] && data[j+7] == SMS_Number_1[9] && data[j+8] == SMS_Number_1[10] && data[j+9] == SMS_Number_1[11])

#define   Check_SMS_Number_2    (!SMS_N2 && data[j] == SMS_Number_2[2] && data[j+1] == SMS_Number_2[3] && data[j+2] == SMS_Number_2[4] && data[j+3] == SMS_Number_2[5] && data[j+4] == SMS_Number_2[6] && data[j+5] == SMS_Number_2[7] && data[j+6] == SMS_Number_2[8] && data[j+7] == SMS_Number_2[9] && data[j+8] == SMS_Number_2[10] && data[j+9] == SMS_Number_2[11])

#define   Check_SMS_Number_3    (!SMS_N3 && data[j] == SMS_Number_3[2] && data[j+1] == SMS_Number_3[3] && data[j+2] == SMS_Number_3[4] && data[j+3] == SMS_Number_3[5] && data[j+4] == SMS_Number_3[6] && data[j+5] == SMS_Number_3[7] && data[j+6] == SMS_Number_3[8] && data[j+7] == SMS_Number_3[9] && data[j+8] == SMS_Number_3[10] && data[j+9] == SMS_Number_3[11])


//---------------------------Stand_by--------------------------------


  void Stand_by (char Typ);


//---------------------------Function Wifi----------------------------------


  void GSM             (char Part);

  void Data_Clean      (void);


//---------------------------Function USART----------------------------------


    interrupt [USART0_RXC] void usart0_rx_isr(void)
     {
         data[i] = UDR0;

         i++;

         data[i] =0;

         if(i >= 250) i =0;
     }


//---------------------------Function Scenario----------------------------------


  void Alarm        (char Active);


//---------------------------Function TIMER0 25 ms----------------------------------


unsigned int    OLED_Time    =0 , Button_Time  =1 , Antenna_Time =0 , Signal_Time =0;

unsigned int    Alarm_Time_1 =0 , Alarm_Time_2 =0 , Alarm_Time_3 =0;


  void TIMER0_ON  (void)
      {
          ASSR=0<<AS0;
          TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (1<<CS01) | (1<<CS00);
          TCNT0=0x3D;
          OCR0=0x00;
      }


  void TIMER0_OFF (void)
      {
          ASSR=0<<AS0;
          TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (0<<CS01) | (0<<CS00);
          TCNT0=0x3D;
          OCR0=0x00;
      }


    interrupt [TIM0_OVF] void timer0_ovf_isr(void)      // Timer 24.96 ms
     {
          TCNT0 = 0x3D;

          if(Button_Time  >= 1)    Button_Time  ++;      // Number

          if(OLED_Time    >= 1)    OLED_Time    ++;      // OLED


          if(Alarm_Time_1 >= 1)   Alarm_Time_1 ++;       // Alarm_1

          if(Alarm_Time_2 >= 1)   Alarm_Time_2 ++;       // Alarm_2

          if(Alarm_Time_3 >= 1)   Alarm_Time_3 ++;       // Alarm_3


          if(Antenna_Time >= 1)    Antenna_Time ++;      // Antenna GSM

          if(Signal_Time  >= 1)    Signal_Time  ++;      // Signal Antenna
     }


//---------------------------Function Main----------------------------------


void main(void)
 {

    long unsigned int  chek =0 , Learn_Time =0;

    unsigned int       time_chek =5000;

    bit                L =1 , L_IN =1 , LFormat =1 , LLearn =1 , Nurmal_Mode =0 , Learn_Mode =1 , Work_Mode =0;


    delay_ms(300);


    DDRA  = 0b00000000;
    PORTA = 0b11111111;

    DDRB  = 0b11100011;
    PORTB = 0b01011111;

    DDRC  = 0b00001111;
    PORTC = 0b11110001;

    DDRD  = 0b11111111;
    PORTD = 0b00001011;

    DDRE  = 0b11101110;
    PORTE = 0b11111000;

    DDRF  = 0b11111111;
    PORTF = 0b00000000;

    DDRG  = 0b11111111;
    PORTG = 0b00000000;

    delay_ms(300);

 if(o)
  {
      Memory_pass[1]='1' , Memory_pass[2]='2' , Memory_pass[3]='3' , Memory_pass[4]='4';

      delay_ms(10);

      for(j = 0 ; j < 12 ; j++)   Call_Number[j] = ' ';

delay_ms(10);

      for(j = 0 ; j < 12 ; j++)   SMS_Number_1[j] = ' ';

delay_ms(10);

      for(j = 0 ; j < 12 ; j++)   SMS_Number_2[j] = ' ';

delay_ms(10);

      for(j = 0 ; j < 12 ; j++)   SMS_Number_3[j] = ' ';

delay_ms(10);

      o =0 , Z1 =0 , Z2 =0 , Z3 =0;

      delay_ms(10);
  }


 if(Z1 || Z2 || Z3)    Led_D;

 if(Z1)   Led_Zoon_1 , Alarm_On_1 =1;
 if(Z2)   Led_Zoon_2 , Alarm_On_2 =1;
 if(Z3)   Led_Zoon_3 , Alarm_On_3 =1;

 delay_ms(300);


 //---------------------------Timer/Counter 1------------------------------------------


        // Timer/Counter 1 initialization
        // Clock source: System Clock
        // Clock value: Timer1 Stopped
        // Mode: Normal top=0xFFFF
        // OC1A output: Disconnected
        // OC1B output: Disconnected
        // OC1C output: Disconnected
        // Noise Canceler: Off
        // Input Capture on Falling Edge
        // Timer1 Overflow Interrupt: Off
        // Input Capture Interrupt: Off
        // Compare A Match Interrupt: Off
        // Compare B Match Interrupt: Off
        // Compare C Match Interrupt: Off
        TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<COM1C1) | (0<<COM1C0) | (0<<WGM11) | (0<<WGM10);
        TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
        TCNT1H=0x00;
        TCNT1L=0x00;
        ICR1H=0x00;
        ICR1L=0x00;
        OCR1AH=0x00;
        OCR1AL=0x00;
        OCR1BH=0x00;
        OCR1BL=0x00;
        OCR1CH=0x00;
        OCR1CL=0x00;


        // Timer(s)/Counter(s) Interrupt(s) initialization
        TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);
        ETIMSK=(0<<TICIE3) | (0<<OCIE3A) | (0<<OCIE3B) | (0<<TOIE3) | (0<<OCIE3C) | (0<<OCIE1C);


 //---------------------------Interrupt------------------------------------------


        // External Interrupt(s) initialization
        // INT0: Off
        // INT1: Off
        // INT2: Off
        // INT3: Off
        // INT4: On
        // INT4 Mode: Any change
        // INT5: Off
        // INT6: Off
        // INT7: Off
        EICRA=(0<<ISC31) | (0<<ISC30) | (0<<ISC21) | (0<<ISC20) | (0<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
        EICRB=(0<<ISC71) | (0<<ISC70) | (0<<ISC61) | (0<<ISC60) | (0<<ISC51) | (0<<ISC50) | (0<<ISC41) | (1<<ISC40);
        EIMSK=(0<<INT7) | (0<<INT6) | (0<<INT5) | (1<<INT4) | (0<<INT3) | (0<<INT2) | (0<<INT1) | (0<<INT0);
        EIFR=(0<<INTF7) | (0<<INTF6) | (0<<INTF5) | (1<<INTF4) | (0<<INTF3) | (0<<INTF2) | (0<<INTF1) | (0<<INTF0);


 //---------------------------USART------------------------------------------


        // USART0 initialization
        // Communication Parameters: 8 Data, 1 Stop, No Parity
        // USART0 Receiver: On
        // USART0 Transmitter: On
        // USART0 Mode: Asynchronous
        // USART0 Baud Rate: 9600
        UCSR0A=(0<<RXC0) | (0<<TXC0) | (0<<UDRE0) | (0<<FE0) | (0<<DOR0) | (0<<UPE0) | (0<<U2X0) | (0<<MPCM0);
        UCSR0B=(1<<RXCIE0) | (0<<TXCIE0) | (0<<UDRIE0) | (1<<RXEN0) | (1<<TXEN0) | (0<<UCSZ02) | (0<<RXB80) | (0<<TXB80);
        UCSR0C=(0<<UMSEL0) | (0<<UPM01) | (0<<UPM00) | (0<<USBS0) | (1<<UCSZ01) | (1<<UCSZ00) | (0<<UCPOL0);
        UBRR0H=0x00;
        UBRR0L=0x33;

        // USART1 initialization
        // USART1 disabled
        UCSR1B=(0<<RXCIE1) | (0<<TXCIE1) | (0<<UDRIE1) | (0<<RXEN1) | (0<<TXEN1) | (0<<UCSZ12) | (0<<RXB81) | (0<<TXB81);


 //---------------------------TIMER------------------------------------------


        // Timer/Counter 0 initialization
        // Clock source: System Clock
        // Clock value: 7.813 kHz
        // Mode: Normal top=0xFF
        // OC0 output: Disconnected
        // Timer Period: 24.96 ms
        ASSR=0<<AS0;
        TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (1<<CS01) | (1<<CS00);
        TCNT0=0x3D;
        OCR0=0x00;

        // Timer(s)/Counter(s) Interrupt(s) initialization
        TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);
        ETIMSK=(0<<TICIE3) | (0<<OCIE3A) | (0<<OCIE3B) | (0<<TOIE3) | (0<<OCIE3C) | (0<<OCIE1C);


 //---------------------------OLED------------------------------------------


        i2c_init();
        LCD_init();
        LCD_Contrast(255);
        LCD_Mode(0);


 //-------------------------------------------------------------------------------------------------------


     OLED_ON_OFF(10);

     Data_Clean();

     #asm("sei")

     GSM(0);

     LCD_DrawImage(1);

     Buzzer;

    while(1)
     {
          if(Touch)
            {
                while(Touch && L && Lock)
                  {
                      if(chek >= time_chek)
                        {
                            if(Touch_D)        Buzzer , Led_N_ON , OLED_ON_OFF(0);

                            if(Zoon_Number)    OLED_ON_OFF (1);

                            if(Button_Number)  Button (Button_Number);


                            if(Touch_R && !Red_D)
                              {
                                   if(Rotation_RL)
                                      {
                                           Buzzer , Led_N_ON , Rotation_Next ++;

                                           if(Rotation_Next >= 4)  OLED_ON_OFF (9);

                                           if(Rotation_Next == 1)  LCD_DrawImage(0) , OLED_Pass(0);

                                           if(Rotation_Next == 2)  OLED_SMS    (0);

                                           if(Rotation_Next == 3)  OLED_Call   (0);


                                      }

                                   if(Rotation_OnOff == 1)  Buzzer , OLED_ON_OFF(9);

                                   if(Rotation_OnOff == 2)  Buzzer , OLED_ON_OFF(0);

                                   if(Rotation_Pass  == 1)  Buzzer , OLED_Pass(0);

                                   if(Rotation_Pass  == 2)  Buzzer , OLED_Pass(1);

                                   if(Rotation_SMS   == 1)  Buzzer , OLED_SMS(0);

                                   if(Rotation_SMS   == 2)  Buzzer , OLED_SMS(1);

                                   if(Rotation_SMS   == 3)  Buzzer , OLED_SMS(2);

                                   if(Rotation_Call  == 1)  Buzzer , OLED_Call(0);

                                   if(Rotation_Call  == 2)  Buzzer , OLED_Call(1);
                              }

                            if(Touch_L && !Red_D)
                              {
                                   if(Rotation_RL)
                                      {
                                           Buzzer , Led_N_ON;

                                           if(Rotation_Next >= 1)  Rotation_Next --;

                                                else   LCD_DrawImage(0) , Rotation_Next =3;

                                           if(Rotation_Next == 0)  OLED_ON_OFF (9);

                                           if(Rotation_Next == 1)  OLED_Pass   (0);

                                           if(Rotation_Next == 2)  OLED_SMS    (0);

                                           if(Rotation_Next == 3)  OLED_Call   (0);


                                      }

                                   if(Rotation_OnOff == 1)  Buzzer , OLED_ON_OFF(9);

                                   if(Rotation_OnOff == 2)  Buzzer , OLED_ON_OFF(0);

                                   if(Rotation_Pass  == 1)  Buzzer , OLED_Pass(0);

                                   if(Rotation_Pass  == 2)  Buzzer , OLED_Pass(1);

                                   if(Rotation_SMS   == 1)  Buzzer , OLED_SMS(0);

                                   if(Rotation_SMS   == 2)  Buzzer , OLED_SMS(1);

                                   if(Rotation_SMS   == 3)  Buzzer , OLED_SMS(2);

                                   if(Rotation_Call  == 1)  Buzzer , OLED_Call(0);

                                   if(Rotation_Call  == 2)  Buzzer , OLED_Call(1);
                              }

                            OUT_Stand_by;

                            L =0;
                        }

                      chek++;
                  }
                        chek =0;


            //---------------------------RF-------------------------------------


                while(Learn && LLearn)
                  {
                       if(chek>=200000)
                         {
                              Led_Learn_OFF;

                              Work_Mode = Learn_Mode;

                              Learn_Time=1;

                              LLearn=0 , chek=0;
                         }

                       chek++;
                  }
                   chek =0;

                while(Format && LFormat)
                  {
                       if(chek>=200000)
                         {
                              #asm("cli")

                              Led_Format_OFF;

                              delay_ms(300);

                              EE_Format();

                              Led_Format_ON;

                              LFormat =0 , chek =0;

                              delay_ms(1000);

                              #asm("sei")
                         }

                       chek++;
                  }

              chek =0;

            }

             if(!L && !Touch)    L =1;

             if(!Format && !LFormat)    LFormat =1;


     //---------------------------Touch_IN ==> Mega64_4------------------


          if(Touch_IN && L_IN)
            {
                 delay_ms(15);

                 L_IN =0;

                 if(Touch_IN_Lock)          Lock =! Lock;

                 if(Touch_Stand_by)         Stand_by(0) , L_IN =1;

                 if(Touch_IN_Alarm_Feed)    Alarm_Feed;

                 if(Touch_IN_Alarm_Order)   Alarm_Order;
            }

             if(!Touch_IN && !L_IN)    L_IN =1;


     //---------------------------RF-----------------------------------


          if(Revice_Flag)
            {
                 if(Work_Mode == Nurmal_Mode)
                   {
                        if(EE_ISValidCode(EV_Code & 0xFFFFFFF0)) Ralay_Control (EV_Code & 0x0F); /*If Valid Code*/

                        delay_ms(100);
                   }

                 else if(Work_Mode == Learn_Mode)
                    {

                        if(!EE_ISValidCode(EV_Code & 0xFFFFFFF0)) /*If Not Have Code*/
                            {
                                EE_StoreCode(EV_Code & 0xFFFFFFF0);

                                Work_Mode = Nurmal_Mode;

                                Learn_Time=0 , LLearn=1;

                                Led_Learn_ON;
                            }
                    }


                 EV_Code =0;

                 Revice_Flag =0;
            }

         if(Learn_Time >= 1)     Learn_Time ++ ;

         if(Learn_Time >= 100000)
             {
                 Work_Mode = Nurmal_Mode;

                 Learn_Time=0 , LLearn=1;

                 Led_Learn_ON;
             }


     //---------------------------Alarm----------------------------------


           if(Red_D)
             {

             //---------------------------Alarm_1----------------------------------


                   if(Alarm_On_1 ==0 && Red_Zoon_1 && Alarm_Time_1 >= 1600)
                     {
                          Alarm_Time_1 =0 , Alarm_On_1 ++;

                          Alarm_Buzzer_1 =1 , delay_ms(30) , Alarm_Buzzer_1 =0;

                          OUT_Stand_by;

                          GSM(2);
                     }

                   while(Alarm_On_1 ==1 && Red_Zoon_1 && Input_Sensur_1)
                        {
                            if(chek >= time_chek)
                              {
                                  OUT_Stand_by , chek =0 , Alarm_Time_1 =1 , Alarm_On_1 ++ , Led_N_ON;
                              }

                             chek++;
                        }
                        chek=0;

                   if(Alarm_On_1 ==2 && Red_Zoon_1 && Alarm_Time_1 >= 1200)
                     {
                          Alarm_Buzzer_1 =1;

                          Alarm_Time_1 =1 , Alarm_On_1 ++ , Led_N_ON;

                          OLED_ON_OFF(3);

                          OUT_Stand_by;

                          GSM(3);

                          GSM_Activ =1;
                     }

                   if(Alarm_On_1 ==3 && Red_Zoon_1 && Alarm_Time_1 >= 12000)
                     {
                          Alarm_Buzzer_1 =0;

                          Alarm_Time_1 =0 , Alarm_On_1 =1 , Led_N_OFF;

                          Alarm_Cunter_1++;

                          if(Alarm_Cunter_1 >= 3) Led_Zoon_1;

                          OUT_Stand_by;

                          Alarm (11);
                     }


             //---------------------------Alarm_2----------------------------------


                   if(Alarm_On_2 ==0 && Red_Zoon_2 && Alarm_Time_2 >= 1600)
                     {
                          Alarm_Time_2 =0 , Alarm_On_2 ++;

                          Alarm_Buzzer_2 =1 , delay_ms(30) , Alarm_Buzzer_2 =0;

                          OUT_Stand_by;

                          GSM(2);
                     }

                   while(Alarm_On_2 ==1 && Red_Zoon_2 && Input_Sensur_2)
                        {
                            if(chek >= time_chek)
                              {
                                  OUT_Stand_by , chek =0 , Alarm_Time_2 =1 , Alarm_On_2 ++ , Led_N_ON;
                              }

                             chek++;
                        }
                        chek=0;

                   if(Alarm_On_2 ==2 && Red_Zoon_2 && Alarm_Time_2 >= 1200)
                     {
                          Alarm_Buzzer_2 =1;

                          Alarm_Time_2 =1 , Alarm_On_2 ++ , Led_N_ON;

                          OLED_ON_OFF(3);

                          OUT_Stand_by;

                          GSM(3);

                          GSM_Activ =1;
                     }

                   if(Alarm_On_2 ==3 && Red_Zoon_2 && Alarm_Time_2 >= 12000)
                     {
                          Alarm_Buzzer_2 =0;

                          Alarm_Time_2 =0 , Alarm_On_2 =1 , Led_N_OFF;

                          Alarm_Cunter_2++;

                          if(Alarm_Cunter_2 >= 3) Led_Zoon_2;

                          OUT_Stand_by;

                          Alarm (12);
                     }


             //---------------------------Alarm_3----------------------------------


                   if(Alarm_On_3 ==0 && Red_Zoon_3 && Alarm_Time_3 >= 1600)
                     {
                          Alarm_Time_3 =0 , Alarm_On_3 ++;

                          Alarm_Buzzer_3 =1 , delay_ms(30) , Alarm_Buzzer_3 =0;

                          OUT_Stand_by;

                          GSM(2);
                     }

                   while(Alarm_On_3 ==1 && Red_Zoon_3 && Input_Sensur_3)
                        {
                            if(chek >= time_chek)
                              {
                                  OUT_Stand_by , chek =0 , Alarm_Time_3 =1 , Alarm_On_3 ++ , Led_N_ON;
                              }

                             chek++;
                        }
                        chek=0;

                   if(Alarm_On_3 ==2 && Red_Zoon_3 && Alarm_Time_3 >= 1200)
                     {
                          Alarm_Buzzer_3 =1;

                          Alarm_Time_3 =1 , Alarm_On_3 ++ , Led_N_ON;

                          OLED_ON_OFF(3);

                          OUT_Stand_by;

                          GSM(3);

                          GSM_Activ =1;
                     }

                   if(Alarm_On_3 ==3 && Red_Zoon_3 && Alarm_Time_3 >= 12000)
                     {
                          Alarm_Buzzer_3 =0;

                          Alarm_Time_3 =0 , Alarm_On_3 =1 , Led_N_OFF;

                          Alarm_Cunter_3++;

                          if(Alarm_Cunter_3 >= 3) Led_Zoon_3;

                          OUT_Stand_by;

                          Alarm (13);
                     }
             }


     //---------------------------GSM----------------------------------


          if(Antenna_Time >= 600)                                  // The presence of a SIM card
            {
                sprintf(str , "AT+CPIN?%c" , 13);    // The presence of a SIM card

                puts(str);

                Antenna_Time =1;
            }


          if(strstr(data , "+"))
            {
                  delay_ms(40);

                  if(strstr(data , "+CMTI"))    OUT_Stand_by , GSM(1);     //GSM Config

                      else                      GSM(4);                    //Signal SIM Card
            }


          if(Add_Signal == 1 && Signal_Time >= 80)   Led_Signal , Signal_Time =1;

          if(Add_Signal == 2 && Signal_Time >= 200)  Led_Signal , Signal_Time =1;


     //---------------------------OLED----------------------------------


          if(OLED_Time   >= 400)    OLED_ON_OFF(9);

          if(Button_Time >= 400)
            {
                if(Red_D)   OLED_ON_OFF(3);

                   else     Button_Time =0 , Button_Number =0 , Led_N_OFF;
            }
     }
 }


//---------------------------Function  Stand_by------------------------------


    void Stand_by (char Typ)
     {
        TIMER0_OFF();

        Led_N_OFF;

        White_Zoon_1 =0 , White_Zoon_2 =0 , White_Zoon_3 =0;

        White_D =0;

        if(!Red_D)   LCD_DrawImage(0);

        delay_ms(30);

        while(Typ == 0)   // OFF
         {
             if(Touch_Stand_by)
               {
                    if(!Red_D)        White_D =1 , LCD_DrawImage(1);

                    if(!Red_Zoon_1)   White_Zoon_1 =1;

                    if(!Red_Zoon_2)   White_Zoon_2 =1;

                    if(!Red_Zoon_3)   White_Zoon_3 =1;

                    Led_N_ON , Typ =1;

                    TIMER0_ON();
               }


             if(Touch || strstr(data , "+CMTI") || Exit_Stand_by)
               {
                    OUT_Stand_by;

                    if(!Red_D)        White_D =1 , LCD_DrawImage(1);

                    if(!Red_Zoon_1)   White_Zoon_1 =1;

                    if(!Red_Zoon_2)   White_Zoon_2 =1;

                    if(!Red_Zoon_3)   White_Zoon_3 =1;

                    Led_N_ON , Typ =1;

                    delay_ms(1000);

                    TIMER0_ON();
               }
         }
     }


//---------------------------Function OLED----------------------------------


    void OLED_ON_OFF (char Show1)
     {
        static unsigned char   num1 =0 , num2 =0 , num3 =0;

        unsigned char          buff[50] , v =0;


        if(Show1 == 0)       //Zoon
         {
             OLED_Clean ();

             num1 =0 , num2 =0 , num3 =0;

             LCD_Goto2X(1 , 0) , sprintf(buff , "1 ==>   Z1"  , v) , LCD_Printf(buff , 0);

              if(Z1)  num1 =1 , LCD_Goto2X(35 , 0) , sprintf(buff , "#" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 2) , sprintf(buff , "2 ==>   Z2"  , v) , LCD_Printf(buff , 0);

              if(Z2)  num2 =1 , LCD_Goto2X(35 , 2) , sprintf(buff , "#" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 4) , sprintf(buff , "3 ==>   Z3"  , v) , LCD_Printf(buff , 0);

              if(Z3)  num3 =1 , LCD_Goto2X(35 , 4) , sprintf(buff , "#" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 7) , sprintf(buff , "Next ==> OK" , v) , LCD_Printf(buff , 0);

             OLED_Time =1 , Button_Time =1 , Zoon_Number =1 , Button_Number =0;

             Rotation_Next =0 , Rotation_Pass =0 , Rotation_SMS =0 , Rotation_Call =0;

             num_OLED =5 , num =0 , Rotation_OnOff =1;
         }


        if(Show1 == 1)       //Button Zoon Number
         {
            if(Touch_1)
              {
                  Buzzer;

                  if(!num1) num1 =1 , LCD_Goto2X(35 , 0) , sprintf(buff , "#" , v) , LCD_Printf(buff , 0);

                      else  num1 =0 , LCD_Goto2X(35 , 0) , sprintf(buff , " " , v) , LCD_Printf(buff , 0);
              }

            if(Touch_2)
              {
                  Buzzer;

                  if(!num2) num2 =1 , LCD_Goto2X(35 , 2) , sprintf(buff , "#" , v) , LCD_Printf(buff , 0);

                      else  num2 =0 , LCD_Goto2X(35 , 2) , sprintf(buff , " " , v) , LCD_Printf(buff , 0);
              }

            if(Touch_3)
              {
                  Buzzer;

                  if(!num3) num3 =1 , LCD_Goto2X(35 , 4) , sprintf(buff , "#" , v) , LCD_Printf(buff , 0);

                      else  num3 =0 , LCD_Goto2X(35 , 4) , sprintf(buff , " " , v) , LCD_Printf(buff , 0);
              }

            if(Touch_OK)
              {
                  Show1 =2 , Buzzer;

                  for(j =0 ; j < 5 ; j++) pass[j] = ' ';

num_OLED =5 , num =0;

                  Zoon_Number =0 , Button_Number =1;
              }

               /*
            if(Touch_C)
              {
                  Buzzer;

                  LCD_Goto2X(35 , 0) , sprintf(buff , " " , v) , LCD_Printf(buff , 0);

                  LCD_Goto2X(35 , 2) , sprintf(buff , " " , v) , LCD_Printf(buff , 0);

                  LCD_Goto2X(35 , 4) , sprintf(buff , " " , v) , LCD_Printf(buff , 0);

                  num1 =0 , num2 =0 , num3 =0;
              }
           */

            OLED_Time =1 , Button_Time =1;
         }


        if(Show1 == 2)       //Button Number
         {
             OLED_Clean ();

             LCD_Goto2X(1  , 0) , sprintf(buff , "Enter Password :" , v) , LCD_Printf(buff , 0);

             Button_Number =1 , Button_Time =1 , Rotation_OnOff =2;

             if(!Red_D)  OLED_Time =1;
         }


        if(Show1 == 3)       //Page Alarm ON/Activ
         {
             OLED_Clean ();

             if(Buzzer_1 || Buzzer_2 || Buzzer_3)
               {
                    LCD_Goto2X(0 , 3) , sprintf(buff , "Alarm Activ"  , v) , LCD_Printf(buff , 1);

                    if(Buzzer_1)  LCD_Goto2X(6  , 5) , sprintf(buff , "Z1"  , v) , LCD_Printf(buff , 1);

                    if(Buzzer_2)  LCD_Goto2X(25 , 5) , sprintf(buff , "Z2"  , v) , LCD_Printf(buff , 1);

                    if(Buzzer_3)  LCD_Goto2X(45 , 5) , sprintf(buff , "Z3"  , v) , LCD_Printf(buff , 1);
               }

                else
                 {
                      LCD_Goto2X(10 , 3) , sprintf(buff , "Alarm ON"  , v) , LCD_Printf(buff , 1);

                      if(Z1)  LCD_Goto2X(6  , 5) , sprintf(buff , "Z1"  , v) , LCD_Printf(buff , 1);

                      if(Z2)  LCD_Goto2X(25 , 5) , sprintf(buff , "Z2"  , v) , LCD_Printf(buff , 1);

                      if(Z3)  LCD_Goto2X(45 , 5) , sprintf(buff , "Z3"  , v) , LCD_Printf(buff , 1);
                 }

             Button_Time =0 , Led_N_OFF;

             for(j = 1 ; j < 5 ; j++) pass[j] = ' ';

num_OLED =5 , num =0 , OLED_Time =0 , Button_Number =0;
         }


        if(Show1 == 4)       //Check Password For --> Alarm ON/OFF
         {
            if(!WiFi_Alarm)    delay_ms(500);

            num_OLED =5;

            if(WiFi_Alarm || (Memory_pass[1] == pass[1] && Memory_pass[2] == pass[2] && Memory_pass[3] == pass[3] && Memory_pass[4] == pass[4]))
              {
                   OLED_Clean ();

                   if(!RF_Z)   Z1 =0 , Z2 =0 , Z3 =0 , delay_ms(10);

                   if(num1) Z1 =1; if(num2) Z2 =1; if(num3) Z3 =1;

                   num1 =0 , num2 =0 , num3 =0;

                   if(Z1 || Z2 || Z3)
                     {
                         LCD_Goto2X(10 , 2) , sprintf(buff , "Alarm ON"  , v) , LCD_Printf(buff , 1);

                         if(Z1)  LCD_Goto2X(6  , 5) , sprintf(buff , "Z1"  , v) , LCD_Printf(buff , 1);

                            else LCD_Goto2X(6  , 5) , sprintf(buff , "  "  , v) , LCD_Printf(buff , 1);

                         if(Z2)  LCD_Goto2X(25 , 5) , sprintf(buff , "Z2"  , v) , LCD_Printf(buff , 1);

                            else LCD_Goto2X(25  , 5) , sprintf(buff , "  "  , v) , LCD_Printf(buff , 1);

                         if(Z3)  LCD_Goto2X(45 , 5) , sprintf(buff , "Z3"  , v) , LCD_Printf(buff , 1);

                            else LCD_Goto2X(45  , 5) , sprintf(buff , "  "  , v) , LCD_Printf(buff , 1);

                         Button_Time =0 , Led_N_OFF;

                         for(j = 1 ; j < 5 ; j++) pass[j] = ' ';

num_OLED =5 , num =0 , OLED_Time =0 , Button_Number =0;

                         Rotation_OnOff =0;
                     }

                      else
                        {
                            if(Buzzer_1 || Buzzer_2 || Buzzer_3)     OLED_Clean ();

                            LCD_Goto2X(9 , 3) , sprintf(buff , "Alarm OFF" , v) , LCD_Printf(buff , 1);

                            delay_ms(500);

                            Show1 =9;
                        }


                   Alarm (1);

                   GSM_Activ =0;
              }

                else
                  {
                       num_OLED =5 , num =0 , Button_Time =1;

                       if(!Red_D)  OLED_Time =1;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "          " , v) , LCD_Printf(buff , 1);

                       LCD_Goto2X(10 , 6) , sprintf(buff , "wrong password"  , v) , LCD_Printf(buff , 0);

                       for(j = 1 ; j < 5 ; j++) pass[j] = ' ';

delay_ms(2000);

                       LCD_Goto2X(10 , 6) , sprintf(buff , "              "  , v) , LCD_Printf(buff , 0);
                  }
         }


        if(Show1 == 5)       //GSM --> Alarm ON/OFF
         {
              if(Z1 || Z2 || Z3)
                {
                     OLED_Clean ();

                     LCD_Goto2X(10 , 2) , sprintf(buff , "Alarm ON"  , v) , LCD_Printf(buff , 1);

                     if(Z1)  LCD_Goto2X(6  , 5) , sprintf(buff , "Z1"  , v) , LCD_Printf(buff , 1);

                        else LCD_Goto2X(6  , 5) , sprintf(buff , "  "  , v) , LCD_Printf(buff , 1);

                     if(Z2)  LCD_Goto2X(25 , 5) , sprintf(buff , "Z2"  , v) , LCD_Printf(buff , 1);

                        else LCD_Goto2X(25  , 5) , sprintf(buff , "  "  , v) , LCD_Printf(buff , 1);

                     if(Z3)  LCD_Goto2X(45 , 5) , sprintf(buff , "Z3"  , v) , LCD_Printf(buff , 1);

                        else LCD_Goto2X(45  , 5) , sprintf(buff , "  "  , v) , LCD_Printf(buff , 1);

                     Button_Time =0 , Led_N_OFF;

                     for(j = 1 ; j < 5 ; j++) pass[j] = ' ';

num_OLED =5 , num =0 , OLED_Time =0 , Button_Number =0;

                     Rotation_OnOff =0;
                }

                  else
                    {
                        if(Buzzer_1 || Buzzer_2 || Buzzer_3)     OLED_Clean ();

                        LCD_Goto2X(9 , 3) , sprintf(buff , "Alarm OFF" , v) , LCD_Printf(buff , 1);

                        delay_ms(500);

                        Show1 =9;
                    }


              Alarm (2);
         }


        if(Show1 == 9)       //Home Page
         {
             LCD_DrawImage(1);

             OLED_Time =1 , Zoon_Number =0 , Button_Number =0;

             for(j = 1 ; j < 5 ; j++) pass[j] = ' ';

num_OLED =5 , num =0;

             Rotation_Next  =0 , Rotation_LCD =0;

             Rotation_OnOff =0 , Rotation_Pass  =0 , Rotation_SMS   =0 , Rotation_Call  =0;
         }


        if(Show1 == 10)       //start
          {
             LCD_Goto2X(15 , 1) , sprintf(buff , "please wait"  , v) , LCD_Printf(buff , 0);

             for(j = 0 ; j < 50 ; j++)      buff[j] =0X00;

buff[0] =0X31 , buff[1] =0X36;

             OUT_Stand_by;

             for(j = 0 ; j < 16 ; j++)
                {
                     LCD_Goto2X(25 , 4);

                     buff[1] -= 0X01;    //15

                     if(j == 6)   buff[0] =0X30 , buff[1] =0X39;    //09

                     LCD_Printf(buff , 1);

                     if(j < 15)   delay_ms(1000);
                }
          }
     }


    void OLED_Pass   (char Show2)
     {
        unsigned char          buff[50] , v =0;


        if(Show2 == 0)       //Enter page
         {
             OLED_Clean ();

             LCD_Goto2X(3  , 0) , sprintf(buff , "**Change Password**" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6)  , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =21 , Rotation_Pass  =0 , num_OLED =5 , num =0;
         }

        if(Show2 == 1)       //Enter Password
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Enter Password :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =11 , Rotation_Pass  =1 , num_OLED =5 , num =0;
         }

        if(Show2 == 2)       //Repet Password
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Repet Password :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =12 , Rotation_Pass  =2 , num_OLED =5 , num =0;
         }

        if(Show2 == 3)       //OK Change Password & go to Enter page
         {
             OLED_Clean ();

             LCD_Goto2X(4 , 3) , sprintf(buff , "OK Change Password" , v) , LCD_Printf(buff , 0);

             delay_ms(2000);

             LCD_Goto2X(4 , 3) , sprintf(buff , "                  " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(3  , 0) , sprintf(buff , "**Change Password**" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6)  , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =21 , Rotation_Pass  =0 , num_OLED =5 , num =0;
         }

        if(Show2 == 4)       //OK Change Password & go to Enter Password
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 3) , sprintf(buff , "Wrong Change Password" , v) , LCD_Printf(buff , 0);

             delay_ms(2000);

             LCD_Goto2X(1 , 3) , sprintf(buff , "                     " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 0) , sprintf(buff , "Enter Password :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =11 , Rotation_Pass  =1 , num_OLED =5 , num =0;
         }


        OLED_Time =1 , Button_Time =1;
     }


    void OLED_SMS    (char Show3)
     {
        unsigned char          buff[50] , v =0 , s =0;


        if(Show3 == 0)       //Button Number
         {
             OLED_Clean ();

             LCD_Goto2X(11 , 0) , sprintf(buff , "**SMS Number**" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =22 , Rotation_SMS  =0 , num =0;
         }

        if(Show3 == 1)       //Selection Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 2) , sprintf(buff , "1 ==>   N1 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 4) , sprintf(buff , "2 ==>   N2 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "3 ==>   N3 : " , v) , LCD_Printf(buff , 0);

             SMS_Phone_Number_1 =0 , SMS_Phone_Number_2 =0 , SMS_Phone_Number_3 =0;

             Button_Number =41 , Rotation_SMS  =1 , num =0;
         }

        if(Show3 == 2)       //Enter Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             if(SMS_Phone_Number_1)
               {
                    if(!SMS_N1)
                       {
                             LCD_Goto2X(1 , 2) , sprintf(buff , "N1 :         ****" , v);

                             s =5;

                                 for(j = 1 ; j < 8  ; j++) { s++ , buff[s] = SMS_Number_1[j]; }

                             LCD_Printf(buff , 0);
                       }

                      else   LCD_Goto2X(1 , 2) , sprintf(buff , "N1 : " , v) , LCD_Printf(buff , 0);
               }

             if(SMS_Phone_Number_2)
               {
                    if(!SMS_N2)
                       {
                             LCD_Goto2X(1 , 2) , sprintf(buff , "N2 :         ****" , v);

                             s =5;

                             for(j = 1 ; j < 8  ; j++) { s++ , buff[s] = SMS_Number_2[j]; }

                             LCD_Printf(buff , 0);
                       }

                      else   LCD_Goto2X(1 , 2) , sprintf(buff , "N2 : " , v) , LCD_Printf(buff , 0);
               }

             if(SMS_Phone_Number_3)
               {
                    if(!SMS_N3)
                       {
                             LCD_Goto2X(1 , 2) , sprintf(buff , "N3 :         ****" , v);

                             s =5;

                             for(j = 1 ; j < 8  ; j++) { s++ , buff[s] = SMS_Number_3[j]; }

                             LCD_Printf(buff , 0);
                       }

                      else   LCD_Goto2X(1 , 2) , sprintf(buff , "N3 : " , v) , LCD_Printf(buff , 0);
               }

             LCD_Goto2X(1 , 5) , sprintf(buff , "OK ==> Enter Number" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 7) , sprintf(buff , "C  ==> Clean Number" , v) , LCD_Printf(buff , 0);

             Button_Number =41 , Rotation_SMS  =2 , num =0;
         }

        if(Show3 == 3)       //Clean Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(10 , 3) , sprintf(buff , "OK Clean Number" , v) , LCD_Printf(buff , 0);

             delay_ms(2000);

             LCD_Goto2X(10 , 3) , sprintf(buff , "               " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 2) , sprintf(buff , "1 ==>   N1 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 4) , sprintf(buff , "2 ==>   N2 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "3 ==>   N3 : " , v) , LCD_Printf(buff , 0);

             Button_Number =41 , Rotation_SMS  =1 , num =0;
         }

        if(Show3 == 4)       //Enter Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Enter Phone Number :" , v) , LCD_Printf(buff , 0);

             if(SMS_Phone_Number_1) LCD_Goto2X(1 , 4) , sprintf(buff , "N1 : " , v) , LCD_Printf(buff , 0);

             if(SMS_Phone_Number_2) LCD_Goto2X(1 , 4) , sprintf(buff , "N2 : " , v) , LCD_Printf(buff , 0);

             if(SMS_Phone_Number_3) LCD_Goto2X(1 , 4) , sprintf(buff , "N3 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =31 , Rotation_SMS  =3 , num_OLED =11 , num =0;
         }

        if(Show3 == 5)       //OK Enter SMS Number & Selection Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(2 , 3) , sprintf(buff , "OK Enter SMS Number" , v) , LCD_Printf(buff , 0);

             delay_ms(2000);

             LCD_Goto2X(2 , 3) , sprintf(buff , "                   " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 2) , sprintf(buff , "1 ==>   N1 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 4) , sprintf(buff , "2 ==>   N2 : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "3 ==>   N3 : " , v) , LCD_Printf(buff , 0);

             Button_Number =41 , Rotation_SMS  =1 , num =0;
         }


        OLED_Time =1 , Button_Time =1;
     }


    void OLED_Call   (char Show4)
     {
        unsigned char          buff[50] , v =0 , s =0;


        if(Show4 == 0)       //Enter page
         {
             OLED_Clean ();

             LCD_Goto2X(10 , 0) , sprintf(buff , "**Call Number**" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =23 , Rotation_Call  =0 , num =0;
         }

        if(Show4 == 1)       //Enter Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             if(!Call_N1)
               {
                     LCD_Goto2X(1 , 2) , sprintf(buff , "N :         ****" , v);

                     s =4;

                     for(j = 1 ; j < 8  ; j++) { s++ , buff[s] = Call_Number[j]; }

                     LCD_Printf(buff , 0);
               }

                else   LCD_Goto2X(1 , 2) , sprintf(buff , "N : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 5) , sprintf(buff , "OK ==> Enter Number" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 7) , sprintf(buff , "C  ==> Clean Number" , v) , LCD_Printf(buff , 0);

             Button_Number =42 , Rotation_Call  =1 , num =0;
         }

        if(Show4 == 2)       //Clean Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(10 , 3) , sprintf(buff , "OK Clean Number" , v) , LCD_Printf(buff , 0);

             delay_ms(2000);

             LCD_Goto2X(10 , 3) , sprintf(buff , "               " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 2) , sprintf(buff , "N : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 5) , sprintf(buff , "OK ==> Enter Number" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 7) , sprintf(buff , "C  ==> Clean Number" , v) , LCD_Printf(buff , 0);

             Button_Number =42 , Rotation_Call  =1 , num =0;
         }

        if(Show4 == 3)       //Enter Phone Number
         {
             OLED_Clean ();

             LCD_Goto2X(1 , 0) , sprintf(buff , "Enter Phone Number :" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 4) , sprintf(buff , "N : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 6) , sprintf(buff , "Next ==> OK"  , v) , LCD_Printf(buff , 0);

             Button_Number =32 , Rotation_Call  =2 , num_OLED =9 , num =0;
         }

        if(Show4 == 4)       //OK Enter Call Number
         {
             OLED_Clean ();

             LCD_Goto2X(2 , 3) , sprintf(buff , "OK Enter Call Number" , v) , LCD_Printf(buff , 0);

             delay_ms(2000);

             LCD_Goto2X(2 , 3) , sprintf(buff , "                    " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 0) , sprintf(buff , "Phone Number :" , v) , LCD_Printf(buff , 0);

             if(!Call_N1)
               {
                     LCD_Goto2X(1 , 2) , sprintf(buff , "N :         ****" , v);

                     s =4;

                     for(j = 1 ; j < 8  ; j++) { s++ , buff[s] = Call_Number[j]; }

                     LCD_Printf(buff , 0);
               }

                else   LCD_Goto2X(1 , 2) , sprintf(buff , "N : " , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 5) , sprintf(buff , "OK ==> Enter Number" , v) , LCD_Printf(buff , 0);

             LCD_Goto2X(1 , 7) , sprintf(buff , "C  ==> Clean Number" , v) , LCD_Printf(buff , 0);

             Button_Number =42 , Rotation_Call  =0 , num =0;
         }


        OLED_Time =1 , Button_Time =1;
     }


    void Button (char Add)
     {
         static unsigned char   Cheng_pass[5];

         unsigned char          buff[50] , v =0;


         Button_Time =1;

         if(Add == 1 || Add == 11 || Add == 12)    //Number Password => ON/OFF | Change Password
           {
                 if(Touch_0 && num <= 3)
                   {
                       num++ , pass[num] = '0' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_1 && num <= 3)
                   {
                       num++ , pass[num] = '1' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_2 && num <= 3)
                   {
                       num++ , pass[num] = '2' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_3 && num <= 3)
                   {
                       num++ , pass[num] = '3' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_4 && num <= 3)
                   {
                       num++ , pass[num] = '4' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_5 && num <= 3)
                   {
                       num++ , pass[num] = '5' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_6 && num <= 3)
                   {
                       num++ , pass[num] = '6' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_7 && num <= 3)
                   {
                       num++ , pass[num] = '7' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_8 && num <= 3)
                   {
                       num++ , pass[num] = '8' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }

                 if(Touch_9 && num <= 3)
                   {
                       num++ , pass[num] = '9' , num_OLED += 10 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "*" , v) , LCD_Printf(buff , 1);
                   }


                 if(Touch_C)
                   {
                       num_OLED =5 , num =0 , Buzzer;

                       for(j = 1 ; j < 5 ; j++) pass[j] = ' ';

LCD_Goto2X(num_OLED  , 4) , sprintf(buff , "          " , v) , LCD_Printf(buff , 1);
                   }


                 if(Touch_OK && num == 4)
                   {
                       Buzzer;

                       if(Add == 11)
                         {
                             for(j = 1 ; j < 5 ; j++) Cheng_pass[j] = pass[j];

OLED_Pass(2);
                         }

                       if(Add == 12)
                         {
                             if(Cheng_pass[1] == pass[1] && Cheng_pass[2] == pass[2] && Cheng_pass[3] == pass[3] && Cheng_pass[4] == pass[4])
                               {
                                    for(j = 1 ; j < 5 ; j++) Memory_pass[j] = pass[j] , delay_ms(10);

OLED_Pass(3);
                               }

                                else     OLED_Pass(4);
                         }

                       for(j =0 ; j < 5 ; j++) pass[j] = ' ';

num_OLED =5 , num =0;
                   }


                 if(num == 4)
                   {
                       if(Add == 1)   OLED_ON_OFF(4);
                   }

                 if(Button_Number == 11 || Button_Number == 12)     OLED_Time =1;
           }

         if(Add == 21 || Add == 22 || Add == 23)   //OK page => Pass & SMS & CALL
           {
                 if(Touch_OK)
                   {
                       Buzzer;

                       if(Add == 21)    OLED_Pass(1);

                       if(Add == 22)    OLED_SMS (1);

                       if(Add == 23)    OLED_Call(1);
                   }

                 OLED_Time =1;
           }

         if(Add == 31 || Add == 32)                //Phone Number => SMS & CALL
           {
                 if(Touch_0 && num <= 10)
                   {
                       num++ , pass[num] = '0' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "0" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_1 && num <= 10)
                   {
                       num++ , pass[num] = '1' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "1" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_2 && num <= 10)
                   {
                       num++ , pass[num] = '2' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "2" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_3 && num <= 10)
                   {
                       num++ , pass[num] = '3' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "3" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_4 && num <= 10)
                   {
                       num++ , pass[num] = '4' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "4" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_5 && num <= 10)
                   {
                       num++ , pass[num] = '5' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "5" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_6 && num <= 10)
                   {
                       num++ , pass[num] = '6' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "6" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_7 && num <= 10)
                   {
                       num++ , pass[num] = '7' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "7" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_8 && num <= 10)
                   {
                       num++ , pass[num] = '8' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "8" , v) , LCD_Printf(buff , 0);
                   }

                 if(Touch_9 && num <= 10)
                   {
                       num++ , pass[num] = '9' , num_OLED += 4 , Buzzer;

                       LCD_Goto2X(num_OLED , 4) , sprintf(buff , "9" , v) , LCD_Printf(buff , 0);
                   }


                 if(Touch_C)
                   {
                       Buzzer;

                       for(j = 1 ; j < 12 ; j++) pass[j] = ' ';

LCD_Goto2X(12 , 4) , sprintf(buff , "                " , v) , LCD_Printf(buff , 0);

                       num_OLED =11 , num =0;
                   }


                 if(Touch_OK && num == 11)
                   {
                       Buzzer;

                       if(Add == 31)      //SMS Number
                         {
                             if(SMS_Phone_Number_1)
                               {
                                    for(j = 1 ; j < 12 ; j++)   SMS_Number_1[j] = pass[j] , delay_ms(5);

SMS_N1 =0 , SMS_Phone_Number_1 =0;
                               }

                             if(SMS_Phone_Number_2)
                               {
                                    for(j = 1 ; j < 12 ; j++)   SMS_Number_2[j] = pass[j] , delay_ms(5);

SMS_N2 =0 , SMS_Phone_Number_2 =0;
                               }

                             if(SMS_Phone_Number_3)
                               {
                                    for(j = 1 ; j < 12 ; j++)   SMS_Number_3[j] = pass[j] , delay_ms(5);

SMS_N3 =0 , SMS_Phone_Number_3 =0;
                               }

                             num_OLED =11;

                             OLED_SMS(5);
                         }

                       if(Add == 32)      //Call Number
                         {
                             for(j = 1 ; j < 12 ; j++)   Call_Number[j] = pass[j] , delay_ms(5);

num_OLED =9 , Call_N1 =0;

                             OLED_Call(4);
                         }

                       for(j =0 ; j < 12 ; j++) pass[j] = ' ';

num_OLED =9 , num =0;
                   }

                 OLED_Time =1;
           }

         if(Add == 41 || Add == 42)                //Button Phone Number => SMS & CALL
           {
                 if(Touch_1)
                   {
                       if(Add == 41 && !SMS_Phone_Number_1 && !SMS_Phone_Number_2  && !SMS_Phone_Number_3)    Buzzer , SMS_Phone_Number_1 =1 , SMS_Phone_Number_2 =0 , SMS_Phone_Number_3 =0 , OLED_SMS (2);
                   }

                 if(Touch_2)
                   {
                       if(Add == 41 && !SMS_Phone_Number_1 && !SMS_Phone_Number_2  && !SMS_Phone_Number_3)    Buzzer , SMS_Phone_Number_1 =0 , SMS_Phone_Number_2 =1 , SMS_Phone_Number_3 =0 , OLED_SMS (2);
                   }

                 if(Touch_3)
                   {
                       if(Add == 41 && !SMS_Phone_Number_1 && !SMS_Phone_Number_2  && !SMS_Phone_Number_3)    Buzzer , SMS_Phone_Number_1 =0 , SMS_Phone_Number_2 =0 , SMS_Phone_Number_3 =1 , OLED_SMS (2);
                   }

                 if(Touch_C)
                   {
                       Buzzer;

                       if(Add == 41)
                         {
                               if(SMS_Phone_Number_1)
                                 {
                                     for(j = 1 ; j < 12 ; j++)   SMS_Number_1[j] = ' ' , delay_ms(5);

SMS_N1 =1;

                                 }

                               if(SMS_Phone_Number_2)
                                 {
                                     for(j = 1 ; j < 12 ; j++)   SMS_Number_2[j] = ' ' , delay_ms(5);

SMS_N2 =1;

                                 }

                               if(SMS_Phone_Number_3)
                                 {
                                     for(j = 1 ; j < 12 ; j++)   SMS_Number_3[j] = ' ' , delay_ms(5);

SMS_N3 =1;

                                 }

                               SMS_Phone_Number_1 =0 , SMS_Phone_Number_2 =0 , SMS_Phone_Number_3 =0;

                               OLED_SMS (3);
                         }

                       if(Add == 42)
                         {
                               for(j = 1 ; j < 12 ; j++)   Call_Number[j] = ' ' , delay_ms(5);

Call_N1 =1;

                               OLED_Call (2);
                         }
                   }

                 if(Touch_OK)
                   {
                       Buzzer;

                       if(Add == 41)     OLED_SMS  (4);

                       if(Add == 42)     OLED_Call (3);
                    }

                 OLED_Time =1;
           }
     }


    void OLED_Clean (void)
     {
          //unsigned char    buff[50];

          //for(j = 0 ; j < 21 ; j++)    buff[j] = ' ';

          //for(i = 0 ; i < 8  ; i++)    LCD_Goto2X(0 , i) , LCD_Printf(buff , 0);

          LCD_DrawImage(0);
     }


//---------------------------Function Alarm----------------------------------


    void Alarm (char Active)
     {
        if(Active == 1)         //Alarm_1 & Alarm_2 & Alarm_3  ==>  ON/OFF
         {
              if(!Red_D)  Led_D;

              if(!Z1 && !Z2 && !Z3) Led_D;

              if(!Red_Zoon_1 && Z1) Led_Zoon_1 , Alarm_Time_1 =1 , Alarm_On_1 =0 , Alarm_Cunter_1 =0;

                   else if(Red_Zoon_1 && !Z1) Led_Zoon_1 , Alarm_Time_1 =0 , Alarm_On_1 =0 , Alarm_Cunter_1 =0;


              if(!Red_Zoon_2 && Z2) Led_Zoon_2 , Alarm_Time_2 =1 , Alarm_On_2 =0 , Alarm_Cunter_2 =0;

                   else if(Red_Zoon_2 && !Z2) Led_Zoon_2 , Alarm_Time_2 =0 , Alarm_On_2 =0 , Alarm_Cunter_2 =0;


              if(!Red_Zoon_3 && Z3) Led_Zoon_3 , Alarm_Time_3 =1 , Alarm_On_3 =0 , Alarm_Cunter_3 =0;

                   else if(Red_Zoon_3 && !Z3) Led_Zoon_3 , Alarm_Time_3 =0 , Alarm_On_3 =0 , Alarm_Cunter_3 =0;


              if(Buzzer_1)      Alarm_Buzzer_1 =0;
              if(Buzzer_2)      Alarm_Buzzer_2 =0;
              if(Buzzer_3)      Alarm_Buzzer_3 =0;

              if(GSM_Activ || Alarm_On_1 || Alarm_On_2 || Alarm_On_3)    GSM(2);
         }


        if(Active == 2)         //GSM  ==>  Alarm_1 & Alarm_2 & Alarm_3  ==>  ON/OFF
         {
              if(!Red_D)  Led_D;

              if(!Z1 && !Z2 && !Z3) Led_D;

              if(!Red_Zoon_1 && Z1) Led_Zoon_1 , Alarm_Time_1 =2000 , Alarm_On_1 =0 , Alarm_Cunter_1 =0;

                   else if(Red_Zoon_1 && !Z1) Led_Zoon_1 , Alarm_Time_1 =0 , Alarm_On_1 =0 , Alarm_Cunter_1 =0;


              if(!Red_Zoon_2 && Z2) Led_Zoon_2 , Alarm_Time_2 =2000 , Alarm_On_2 =0 , Alarm_Cunter_2 =0;

                   else if(Red_Zoon_2 && !Z2) Led_Zoon_2 , Alarm_Time_2 =0 , Alarm_On_2 =0 , Alarm_Cunter_2 =0;


              if(!Red_Zoon_3 && Z3) Led_Zoon_3 , Alarm_Time_3 =2000 , Alarm_On_3 =0 , Alarm_Cunter_3 =0;

                   else if(Red_Zoon_3 && !Z3) Led_Zoon_3 , Alarm_Time_3 =0 , Alarm_On_3 =0 , Alarm_Cunter_3 =0;


              if(Buzzer_1)      Alarm_Buzzer_1 =0;
              if(Buzzer_2)      Alarm_Buzzer_2 =0;
              if(Buzzer_3)      Alarm_Buzzer_3 =0;
         }


        Alarm_Feed;
     }


//---------------------------Function GSM----------------------------------


    void GSM (char Part)
     {
        unsigned char   s  =0;

        bit             DY =0 , Senario =0 , Key =0;

        char            *str_Antenna , Add_Antenna , Key1 =0 , Key2 =0 , Key3 =0;


        if(Part == 0)       //GSM Config
         {
             #asm("cli")

             OUT_Stand_by;

             sprintf(str , "AT+CMGF=1%c" , 13);

             puts(str);

             delay_ms(2000);

             Data_Clean();

             sprintf(str , "AT+CMGDA=%cDEL ALL%c%c" ,34,34,13);

             puts(str);

             delay_ms(1000);

             Data_Clean();

             #asm("sei")
         }


        if(Part == 1)       //Receive SMS
         {
             delay_ms(500);

             #asm("cli")

             for(s = 0 ; s < 250 ; s++) if(data[s] == ',') break;

             sprintf(str , "AT+CMGR=  %c" , 13);

             str[8] = data[s +1];

             str[9] = data[s +2];

             puts(str);

             Data_Clean();

             #asm("sei")

             delay_ms(500);

             for(j = 0 ; j < 250 ; j++) { if(data[j] == ',') break;}

             j += 5;

             if(Check_SMS_Number_1 || Check_SMS_Number_2 || Check_SMS_Number_3)
               {
                     #asm("cli")


                     if(strstr(data , "Z"))
                       {
                             if(strstr(data , "Z1on" ))   { if(!Z1)  Z1 =1 , OLED_ON_OFF(5) , Part =2; }
                             if(strstr(data , "Z1off"))   { if(Z1)   Z1 =0 , OLED_ON_OFF(5) , Part =2; }

                             if(strstr(data , "Z2on" ))   { if(!Z2)  Z2 =1 , OLED_ON_OFF(5) , Part =2; }
                             if(strstr(data , "Z2off"))   { if(Z2)   Z2 =0 , OLED_ON_OFF(5) , Part =2; }

                             if(strstr(data , "Z3on" ))   { if(!Z3)  Z3 =1 , OLED_ON_OFF(5) , Part =2; }
                             if(strstr(data , "Z3off"))   { if(Z3)   Z3 =0 , OLED_ON_OFF(5) , Part =2; }

                             if(strstr(data , "Zon" ))    { if(!Z1 || !Z2 || !Z3)  Z1 =1 , Z2 =1 , Z3 =1 , OLED_ON_OFF(5) , Part =2; }
                             if(strstr(data , "Zoff"))    { if(Z1  || Z2  || Z3)   Z1 =0 , Z2 =0 , Z3 =0 , OLED_ON_OFF(5) , Part =2; }
                       }


               //------------------------senario--------------------------


                     if(strstr(data , "S"))
                       {
                             if(strstr(data , "S1on"))    Senario =1 , OUT_S1 , Part =2;

                             if(strstr(data , "S2on"))    Senario =1 , OUT_S2 , Part =2;

                             if(strstr(data , "S3on"))    Senario =1 , OUT_S3 , Part =2;

                             if(strstr(data , "S4on"))    Senario =1 , OUT_S4 , Part =2;
                       }


               //------------------------Key------------------------------


                     if(strstr(data , "K"))
                        {
                             if(strstr(data , "K1on" ))   Key =1 , Key1 =1 , OUT_K3_O , Part =2;

                             if(strstr(data , "K1off"))   Key =1 , Key1 =2 , OUT_K3_F , Part =2;


                             if(strstr(data , "K2on" ))   Key =1 , Key2 =1 , OUT_K2_O , Part =2;

                             //if(strstr(data , "K2off"))   Key =1 , Key2 =2 , OUT_K2_F , Part =2;


                             if(strstr(data , "K3on" ))   Key =1 , Key3 =1 , OUT_K1_O , Part =2;

                             //if(strstr(data , "K3off"))   Key =1 , Key3 =2 , OUT_K1_F , Part =2;

                        }
               }


             Data_Clean();

             sprintf(str , "AT+CMGDA=%cDEL ALL%c%c" ,34,34,13);

             puts(str);

             delay_ms(1000);

             Data_Clean();
         }


        if(Part == 2)       //Send SMS ==> ON/OFF
         {
             #asm("cli")

             if(!Call_N1)
               {
                     sprintf(str , "ATH" , 13);

                     puts(str);

                     Data_Clean();

                     delay_ms(1000);
               }

             if(!SMS_N1)
               {
                     sprintf(str , "AT+CMGS=%c           %c%c" ,34,34,13);

                     s =8;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = SMS_Number_1[j]; }

                     puts(str);

                     Data_Clean();

                     #asm("sei")

                     delay_ms(500);

                     #asm("cli")

                     if(strstr(data , ">" ))
                       {
                                if( (Z1 || Z2 || Z3) && !Senario && !Key)
                                  {
                                       strcpy(str, "Alarm ON\r\n");

                                       if(Z1)    strcat(str , "Z1 ON\r\n");
                                          else   strcat(str , "Z1 OFF\r\n");

                                       if(Z2)    strcat(str , "Z2 ON\r\n");
                                          else   strcat(str , "Z2 OFF\r\n");


                                       if(Z3)    strcat(str , "Z3 ON\r\n");
                                          else   strcat(str , "Z3 OFF\r\n");
                                  }

                           else if( (!Z1 && !Z2 && !Z3) && !Senario && !Key)
                                  {
                                     sprintf(str , "Alarm OFF\r\n" "Z1 OFF\r\n" "Z2 OFF\r\n" "Z3 OFF");
                                  }


                           else if(Key && !Senario)
                                  {
                                             if(Key1 == 1)   sprintf(str , "K1 ON%c" , 13);

                                        else if(Key1 == 2)   sprintf(str , "K1 OFF%c" , 13);


                                        else if(Key2 == 1)   sprintf(str , "K2 ON%c" , 13);

                                        else if(Key2 == 2)   sprintf(str , "K2 OFF%c" , 13);


                                        else if(Key3 == 1)   sprintf(str , "K3 ON%c" , 13);

                                        else if(Key3 == 2)   sprintf(str , "K3 OFF%c" , 13);
                                  }


                           else      sprintf(str , "Senario OK%c" , 13);

                           puts(str);

                           putchar(0X1A);
                       }

                     Data_Clean();

                     delay_ms(5000);
               }

             if(!SMS_N2)
               {
                     sprintf(str , "AT+CMGS=%c           %c%c" ,34,34,13);

                     s =8;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = SMS_Number_2[j]; }

                     puts(str);

                     Data_Clean();

                     #asm("sei")

                     delay_ms(500);

                     #asm("cli")

                     if(strstr(data , ">" ))
                       {
                                if( (Z1 || Z2 || Z3) && !Senario && !Key)
                                  {
                                       strcpy(str, "Alarm ON\r\n");

                                       if(Z1)    strcat(str , "Z1 ON\r\n");
                                          else   strcat(str , "Z1 OFF\r\n");

                                       if(Z2)    strcat(str , "Z2 ON\r\n");
                                          else   strcat(str , "Z2 OFF\r\n");


                                       if(Z3)    strcat(str , "Z3 ON\r\n");
                                          else   strcat(str , "Z3 OFF\r\n");
                                  }

                           else if( (!Z1 && !Z2 && !Z3) && !Senario && !Key)
                                  {
                                     sprintf(str , "Alarm OFF\r\n" "Z1 OFF\r\n" "Z2 OFF\r\n" "Z3 OFF");
                                  }


                           else if(Key && !Senario)
                                  {
                                             if(Key1 == 1)   sprintf(str , "K1 ON%c" , 13);

                                        else if(Key1 == 2)   sprintf(str , "K1 OFF%c" , 13);


                                        else if(Key2 == 1)   sprintf(str , "K2 ON%c" , 13);

                                        else if(Key2 == 2)   sprintf(str , "K2 OFF%c" , 13);


                                        else if(Key3 == 1)   sprintf(str , "K3 ON%c" , 13);

                                        else if(Key3 == 2)   sprintf(str , "K3 OFF%c" , 13);
                                  }


                           else      sprintf(str , "Senario OK%c" , 13);

                           puts(str);

                           putchar(0X1A);
                       }

                     Data_Clean();

                     delay_ms(5000);
               }

             if(!SMS_N3)
               {
                     sprintf(str , "AT+CMGS=%c           %c%c" ,34,34,13);

                     s =8;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = SMS_Number_3[j]; }

                     puts(str);

                     Data_Clean();

                     #asm("sei")

                     delay_ms(500);

                     #asm("cli")

                     if(strstr(data , ">" ))
                       {
                                if( (Z1 || Z2 || Z3) && !Senario && !Key)
                                  {
                                       strcpy(str, "Alarm ON\r\n");

                                       if(Z1)    strcat(str , "Z1 ON\r\n");
                                          else   strcat(str , "Z1 OFF\r\n");

                                       if(Z2)    strcat(str , "Z2 ON\r\n");
                                          else   strcat(str , "Z2 OFF\r\n");


                                       if(Z3)    strcat(str , "Z3 ON\r\n");
                                          else   strcat(str , "Z3 OFF\r\n");
                                  }

                           else if( (!Z1 && !Z2 && !Z3) && !Senario && !Key)
                                  {
                                     sprintf(str , "Alarm OFF\r\n" "Z1 OFF\r\n" "Z2 OFF\r\n" "Z3 OFF");
                                  }


                           else if(Key && !Senario)
                                  {
                                             if(Key1 == 1)   sprintf(str , "K1 ON%c" , 13);

                                        else if(Key1 == 2)   sprintf(str , "K1 OFF%c" , 13);


                                        else if(Key2 == 1)   sprintf(str , "K2 ON%c" , 13);

                                        else if(Key2 == 2)   sprintf(str , "K2 OFF%c" , 13);


                                        else if(Key3 == 1)   sprintf(str , "K3 ON%c" , 13);

                                        else if(Key3 == 2)   sprintf(str , "K3 OFF%c" , 13);
                                  }


                           else     sprintf(str , "Senario OK%c" , 13);

                           puts(str);

                           putchar(0X1A);
                       }

                     Data_Clean();

                     delay_ms(5000);
               }
         }


        if(Part == 3)       //Send SMS & CALL ==> Active
         {
             #asm("cli")

             if(!SMS_N1)
               {
                     sprintf(str , "AT+CMGS=%c           %c%c" ,34,34,13);

                     s =8;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = SMS_Number_1[j]; }

                     puts(str);

                     Data_Clean();

                     #asm("sei")

                     delay_ms(500);

                     #asm("cli")

                     if(strstr(data , ">" ))
                       {
                           strcpy(str , "Alarm Active\r\n");

                           if(Buzzer_1)  strcat(str, "Z1 Active\r\n");

                           if(Buzzer_2)  strcat(str, "Z2 Active\r\n");

                           if(Buzzer_3)  strcat(str, "Z3 Active\r\n");

                           puts(str);

                           putchar(0X1A);
                       }

                     Data_Clean();

                     delay_ms(5000);
               }

             if(!SMS_N2)
               {
                     sprintf(str , "AT+CMGS=%c           %c%c" ,34,34,13);

                     s =8;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = SMS_Number_2[j]; }

                     puts(str);

                     Data_Clean();

                     #asm("sei")

                     delay_ms(500);

                     #asm("cli")

                     if(strstr(data , ">" ))
                       {
                           strcpy(str , "Alarm Active\r\n");

                           if(Buzzer_1)  strcat(str, "Z1 Active\r\n");

                           if(Buzzer_2)  strcat(str, "Z2 Active\r\n");

                           if(Buzzer_3)  strcat(str, "Z3 Active\r\n");

                           puts(str);

                           putchar(0X1A);
                       }

                     Data_Clean();

                     delay_ms(5000);
               }

             if(!SMS_N3)
               {
                     sprintf(str , "AT+CMGS=%c           %c%c" ,34,34,13);

                     s =8;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = SMS_Number_3[j]; }

                     puts(str);

                     Data_Clean();

                     #asm("sei")

                     delay_ms(500);

                     #asm("cli")

                     if(strstr(data , ">" ))
                       {
                           strcpy(str , "Alarm Active\r\n");

                           if(Buzzer_1)  strcat(str, "Z1 Active\r\n");

                           if(Buzzer_2)  strcat(str, "Z2 Active\r\n");

                           if(Buzzer_3)  strcat(str, "Z3 Active\r\n");

                           puts(str);

                           putchar(0X1A);
                       }

                     Data_Clean();

                     delay_ms(5000);
               }

             Data_Clean();

             if(!Call_N1)
               {
                     sprintf(str , "ATD           ;" ,13);

                     s =2;

                     for(j = 1 ; j < 12  ; j++) { s++ , str[s] = Call_Number[j]; }

                     puts(str);

                     Data_Clean();

                     delay_ms(1000);
               }
         }


        if(Part == 4)       //Signal SIM Card
          {
              if(strstr(data , "READY"))                                            // Having a SIM card
                {
                    sprintf(str , "AT+CREG?%c" , 13);         // Call and SMS network SIM card

                    puts(str);

                    Antenna_Time =1;

                    Data_Clean();
                }

              else if(strstr(data , "+CREG: 0,1") || strstr(data , "+CREG: 0,5"))   // Call and SMS network SIM card
                {
                    sprintf(str , "AT+CSQ%c" , 13);           // Antenna power

                    puts(str);

                    Antenna_Time =1;

                    Data_Clean();
                }

              else if((str_Antenna = strstr(data ,"+CSQ:")) != NULL)                // Antenna power
                {
                    sscanf(str_Antenna,"+CSQ: %d" , &Add_Antenna);


                    if(!Red_Antenna)                           Led_Antenna_OUT;

                    if(Add_Antenna >= 10 && Add_Antenna < 15)  Add_Signal =2; //Weak antenna => 5s

                    else if(Add_Antenna >= 15)                 Add_Signal =0; //Medium or Strong antenna => ON

                    else                                       Add_Signal =1; //No antenna   => 2s

                    Data_Clean();
                }

              else                            //No SIM card
                {
                    if(Red_Antenna)   Led_Antenna_OUT;

                    Add_Signal =0;    // => OFF

                    Data_Clean();
                }
          }


        Antenna_Time =1;

        #asm("sei")
     }


    void Data_Clean (void)
     {
        i =0;

        for( j = 0 ; j < 245 ; j++) data[j] ='\0';

for( j = 0 ; j < 245 ; j++) str[j] ='\0';
}



//---------------------------Function RF-------------------------------------



    void EE_Format (void)
    {
        int j;

        unsigned long int Temp = 0xFFFFFFFF;

        for(j = 0 ; j < EE_Total_Rec ; j++)
        {
            eeprom_write_dword(&g_u32eeprom[j] , Temp);

            delay_ms(5);
        }
    }


    char EE_FindFreeIndex (void)
    {
        int j;

        unsigned long int Temp;

        for(j = 0 ; j < EE_Total_Rec ; j++)
        {
            Temp = eeprom_read_dword(&g_u32eeprom[j]);

            if(Temp == 0xFFFFFFFF) return j;
        }

        return -1;
    }


    void EE_StoreCode (unsigned long int Code)
    {
        char Index;

        Index = EE_FindFreeIndex();

        if(Index != -1)
        {
            eeprom_write_dword(&g_u32eeprom[Index] , Code);

            delay_ms(5);
        }
    }


    char EE_ISValidCode (unsigned long int Code)
    {
        int j;

        unsigned long int Temp;

        for(j = 0 ; j < EE_Total_Rec ; j++)
        {
            Temp = eeprom_read_dword(&g_u32eeprom[j]);

            if(Temp == Code)

            return 1;
        }
        return 0;
    }


    void Ralay_Control (char Rkey)
    {
             if(Rkey == 0B00000001)
               {
                    RF_Z =1;

                    Z1 =! Z1 , delay_ms(10);

                    WiFi_Alarm =1 , OLED_ON_OFF(4) , WiFi_Alarm =0;

                    if(Z1)   Alarm_Time_1 =2000;

                       else
                        {
                            Alarm_Buzzer_1 =1 , delay_ms(30) , Alarm_Buzzer_1 =0;

                            delay_ms(30);

                            Alarm_Buzzer_1 =1 , delay_ms(30) , Alarm_Buzzer_1 =0;
                        }

                    RF_Z =0;
               }


        else if(Rkey == 0B00000010)
               {
                    RF_Z =1;

                    Z2 =! Z2 , delay_ms(10);

                    WiFi_Alarm =1 , OLED_ON_OFF(4) , WiFi_Alarm =0;

                    if(Z2)   Alarm_Time_2 =2000;

                       else
                        {
                            Alarm_Buzzer_2 =1 , delay_ms(30) , Alarm_Buzzer_2 =0;

                            delay_ms(30);

                            Alarm_Buzzer_2 =1 , delay_ms(30) , Alarm_Buzzer_2 =0;
                        }

                    RF_Z =0;
               }

        else if(Rkey == 0B00000100)
               {
                    RF_Z =1;

                    Z3 =! Z3 , delay_ms(10);

                    WiFi_Alarm =1 , OLED_ON_OFF(4) , WiFi_Alarm =0;

                    if(Z3)   Alarm_Time_3 =2000;

                       else
                        {
                            Alarm_Buzzer_3 =1 , delay_ms(30) , Alarm_Buzzer_3 =0;

                            delay_ms(30);

                            Alarm_Buzzer_3 =1 , delay_ms(30) , Alarm_Buzzer_3 =0;
                        }

                    RF_Z =0;
               }

        //else if(Rkey == 0B00001000)  Led4;
    }
