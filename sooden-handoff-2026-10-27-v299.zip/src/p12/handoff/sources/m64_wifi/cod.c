#include <io.h>
#include <delay.h>
#include <stdio.h>
#include <string.h>
#include <eeprom.h>


//---------------------------Definition----------------------------------


                                                               //  -> 35 - 76 = 41  <-
                                                               //  |                  |
unsigned char   POL_Variable[] = "#T*A1/Uaiadbdbbbbeeddcc*H1/Ucvvd+#X1*Z1++" , POL_j =41;

unsigned char   KeysCount =16 , Scenario_Count_Local_1 =16 , KeysCount_2 =4 , Scenario_Count_Local_2 =4;

unsigned char   w[5] , Scenario_Count =20;


//---------------------------BIN1----------------------------------


#define BIN10   PINA.7
#define BIN11   PINA.6
#define BIN12   PINA.5
#define BIN13   PINA.4 ==0


//---------------------------BIN2----------------------------------


#define BIN20   PIND.7
#define BIN21   PINC.4
#define BIN22   PINC.5
#define BIN23   PINC.6 ==0


//---------------------------BIN3----------------------------------


#define BIN30   PINC.3
#define BIN31   PINC.2
#define BIN32   PINC.1
#define BIN33   PINC.0 ==0


//---------------------------BIN4----------------------------------


#define BIN40   PINA.0
#define BIN41   PINA.1
#define BIN42   PINA.2
#define BIN43   PINA.3 ==0


#define Touch     (BIN13 || BIN23 || BIN33 || BIN43)

#define Touch_1    BIN13

#define Touch_2    BIN23

#define Touch_3    BIN33

#define Touch_4    BIN43


//---------------------------Touch1----------------------------------


#define Touch_L1    BIN13 && BIN12 ==1 && BIN11 ==0 && BIN10 ==0
#define Touch_L2    BIN13 && BIN12 ==0 && BIN11 ==1 && BIN10 ==1
#define Touch_L3    BIN13 && BIN12 ==1 && BIN11 ==0 && BIN10 ==1
#define Touch_L4    BIN13 && BIN12 ==0 && BIN11 ==1 && BIN10 ==0

#define Touch_L5    BIN13 && BIN12 ==1 && BIN11 ==1 && BIN10 ==0
#define Touch_L6    BIN13 && BIN12 ==0 && BIN11 ==0 && BIN10 ==1
#define Touch_L7    BIN13 && BIN12 ==1 && BIN11 ==1 && BIN10 ==1
#define Touch_L8    BIN13 && BIN12 ==0 && BIN11 ==0 && BIN10 ==0


//---------------------------Touch2----------------------------------


#define Touch_L9    BIN23 && BIN22 ==1 && BIN21 ==0 && BIN20 ==0
#define Touch_L10   BIN23 && BIN22 ==0 && BIN21 ==1 && BIN20 ==1
#define Touch_L11   BIN23 && BIN22 ==1 && BIN21 ==0 && BIN20 ==1
#define Touch_L12   BIN23 && BIN22 ==0 && BIN21 ==1 && BIN20 ==0

#define Touch_S1    BIN23 && BIN22 ==1 && BIN21 ==1 && BIN20 ==0
#define Touch_S2    BIN23 && BIN22 ==1 && BIN21 ==1 && BIN20 ==1
#define Touch_S3    BIN23 && BIN22 ==0 && BIN21 ==0 && BIN20 ==0
#define Touch_S4    BIN23 && BIN22 ==0 && BIN21 ==0 && BIN20 ==1


//---------------------------Touch3----------------------------------


#define Touch_S5    BIN33 && BIN32 ==0 && BIN31 ==0 && BIN30 ==0
#define Touch_S6    BIN33 && BIN32 ==0 && BIN31 ==0 && BIN30 ==1

#define Touch_K1    BIN33 && BIN32 ==1 && BIN31 ==0 && BIN30 ==1
#define Touch_K2    BIN33 && BIN32 ==1 && BIN31 ==0 && BIN30 ==0
#define Touch_K3    BIN33 && BIN32 ==0 && BIN31 ==1 && BIN30 ==1

#define Touch_M     BIN33 && BIN32 ==0 && BIN31 ==1 && BIN30 ==0

#define Touch_7D    BIN33 && BIN32 ==1 && BIN31 ==1 && BIN30 ==0


//---------------------------Touch4----------------------------------


#define Touch_7U    BIN43 && BIN42 ==0 && BIN41 ==0 && BIN40 ==1
#define Touch_7F    BIN43 && BIN42 ==0 && BIN41 ==0 && BIN40 ==0
#define Touch_7N    BIN43 && BIN42 ==0 && BIN41 ==1 && BIN40 ==0

#define Touch_EL    BIN43 && BIN42 ==1 && BIN41 ==0 && BIN40 ==1

#define Touch_P1O   BIN43 && BIN42 ==1 && BIN41 ==0 && BIN40 ==0
#define Touch_P1C   BIN43 && BIN42 ==1 && BIN41 ==1 && BIN40 ==0

#define Touch_P2O   BIN43 && BIN42 ==0 && BIN41 ==1 && BIN40 ==1
#define Touch_P2C   BIN43 && BIN42 ==1 && BIN41 ==1 && BIN40 ==1


//---------------------------Touch Output----------------------------------


#define Buzzer   PORTG ^= 0b00001000 , delay_ms(3) , PORTG ^= 0b00001000

#define OUT      delay_ms(40) , PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =1 , delay_ms(10)


  //---------------------------Touch Output M32-1----------------------------------


    bit     Red_L1 =0 , Red_L2 =0 , Red_L3 =0 , Red_L4 =0 , Red_Par_11 =0 , Red_Par_12 =0 , Red_Par_21 =0 , Red_Par_22 =0;


    #define OUT_N2     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =1 , OUT
    #define OUT_N3     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =0 , OUT
    #define OUT_N4     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =1 , OUT

    #define OUT_L1     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =0 , OUT , Red_L1 =! Red_L1
    #define OUT_L2     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =1 , OUT , Red_L2 =! Red_L2
    #define OUT_L3     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =0 , OUT , Red_L3 =! Red_L3
    #define OUT_L4     PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =1 , OUT , Red_L4 =! Red_L4

    #define OUT_P1O    PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =1 , OUT , Red_Par_11 =! Red_Par_11
    #define OUT_P1C    PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =0 , OUT , Red_Par_12 =! Red_Par_12

    #define OUT_P2O    PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =1 , OUT , Red_Par_21 =! Red_Par_21
    #define OUT_P2C    PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =0 , OUT , Red_Par_22 =! Red_Par_22

    #define OUT_LP     PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =0 , OUT


  //---------------------------Touch Output M8-2-----------------------------------


    bit     Red_L5 =0 , Red_L6 =0 , Red_L7 =0 , Red_L8 =0;


    #define OUT_N1     PORTD.6 =1 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =0 , OUT

    #define OUT_L5     PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =0 , OUT , Red_L5 =! Red_L5
    #define OUT_L6     PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =1 , OUT , Red_L6 =! Red_L6
    #define OUT_L7     PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =0 , OUT , Red_L7 =! Red_L7
    #define OUT_L8     PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =1 , OUT , Red_L8 =! Red_L8


  //---------------------------Touch Output M32-3----------------------------------


    unsigned int       Red_L9 =0 , Red_L10 =0 , Red_L11 =0 , Red_L12 =0 , Red_EL =0;

    bit     Red_K3;


    #define OUT_S1     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =0 , OUT
    #define OUT_S2     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =1 , OUT
    #define OUT_S3     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =0 , PORTD.0 =0 , OUT
    #define OUT_S4     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =1 , OUT
    #define OUT_S5     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =0 , OUT
    #define OUT_S6     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =1 , OUT

    #define OUT_K3     PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =0 , OUT  // , Red_K3  =! Red_K3

    #define OUT_L9     PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =0 , OUT , Red_L9  =! Red_L9
    #define OUT_L10    PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =1 , OUT , Red_L10 =! Red_L10
    #define OUT_L11    PORTD.6 =1 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =0 , OUT , Red_L11 =! Red_L11
    #define OUT_L12    PORTD.6 =0 , PORTD.5 =1 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =1 , OUT , Red_L12 =! Red_L12

    #define OUT_EL     PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =1 , PORTD.1 =1 , PORTD.0 =1 , OUT , Red_EL  =! Red_EL


  //---------------------------Touch Output M64-4----------------------------------


    bit    Red_K1 , Red_K2;


    #define OUT_K1     PORTG ^= 0b00000100 , PORTG ^= 0b00010000 , Red_K1 =! Red_K1
    #define White_K1   PORTG ^= 0b00000100

    #define OUT_K2     PORTG ^= 0b00000010 , PORTG ^= 0b00000001  // , Red_K2 =! Red_K2
    #define White_K2   PORTG ^= 0b00000010


//-----------------------------Touch M64-4 & M64 Alarm--------------------------


    bit     Red_Lock =0;


    #define OUT_M64            delay_ms(30) , PORTB.2 =1 , PORTB.0 =1 , PORTE.7 =1 , delay_ms(10)

    #define OUT_Lock           PORTB.2 =1 , PORTB.0 =1 , PORTE.7 =0 , OUT_M64 , Red_Lock =! Red_Lock

    #define OUT_Alarm_Order    PORTB.2 =1 , PORTB.0 =0 , PORTE.7 =1 , OUT_M64
    #define OUT_Alarm_Feed     PORTB.2 =1 , PORTB.0 =0 , PORTE.7 =0 , OUT_M64


    #define Touch_Lock         Touch_S6
    #define Led_Lock           OUT_S6


    #define OUT_Stand_by_1_d   PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =0 , PORTD.0 =1 , OUT
    #define OUT_Stand_by_1     PORTD.6 =0 , PORTD.5 =0 , PORTD.4 =0 , PORTD.1 =1 , PORTD.0 =0 , OUT

    #define OUT_Stand_by_2     PORTB.2 =0 , PORTB.0 =1 , PORTE.7 =1 , OUT_M64

    #define Stand_by           Stand_by_Countr >= 2000 && Red_L1 == 0 && Red_L2 == 0 && Red_L3 == 0 && Red_L4 == 0 && Red_L5 == 0 && Red_L6 == 0 && Red_L7 == 0 && Red_L8 == 0 && Red_L9 == 0 && Red_L10 == 0 && Red_L11 == 0 && Red_L12 == 0 && Red_Par_11 == 0 && Red_Par_12 == 0 && Red_Par_21 == 0 && Red_Par_22 == 0   // [restored from compiled code: listing line was truncated]


  //---------------------------Touch Input M64-4-----------------------------


    #define Touch_IN_S           (PINB.7 == 0 || PINB.6 == 0 || PINB.5 == 0 || PINB.4 == 0)

    #define Touch_IN_S1          (PINB.7 == 1 && PINB.6 == 1 && PINB.5 == 1 && PINB.4 == 0)
    #define Touch_IN_S2          (PINB.7 == 1 && PINB.6 == 1 && PINB.5 == 0 && PINB.4 == 1)
    #define Touch_IN_S3          (PINB.7 == 1 && PINB.6 == 1 && PINB.5 == 0 && PINB.4 == 0)
    #define Touch_IN_S4          (PINB.7 == 1 && PINB.6 == 0 && PINB.5 == 1 && PINB.4 == 1)
    #define Touch_IN_S5          (PINB.7 == 1 && PINB.6 == 0 && PINB.5 == 1 && PINB.4 == 0)

    #define Touch_IN_Alarm_ON    (PINB.7 == 1 && PINB.6 == 0 && PINB.5 == 0 && PINB.4 == 1)
    #define Touch_IN_Alarm_OFF   (PINB.7 == 1 && PINB.6 == 0 && PINB.5 == 0 && PINB.4 == 0)

    #define Touch_IN_Stand_by    (PINB.7 == 0 && PINB.6 == 1 && PINB.5 == 1 && PINB.4 == 1)

    #define Touch_IN_K1_O        (PINB.7 == 0 && PINB.6 == 0 && PINB.5 == 1 && PINB.4 == 0)
    #define Touch_IN_K1_F        (PINB.7 == 0 && PINB.6 == 0 && PINB.5 == 0 && PINB.4 == 1)
    #define Touch_IN_K2_O        (PINB.7 == 0 && PINB.6 == 1 && PINB.5 == 0 && PINB.4 == 0)
    #define Touch_IN_K2_F        (PINB.7 == 0 && PINB.6 == 0 && PINB.5 == 1 && PINB.4 == 1)
    #define Touch_IN_K3_O        (PINB.7 == 0 && PINB.6 == 1 && PINB.5 == 1 && PINB.4 == 0)
    #define Touch_IN_K3_F        (PINB.7 == 0 && PINB.6 == 1 && PINB.5 == 0 && PINB.4 == 1)


//---------------------------Function Scenario----------------------------------


eeprom unsigned char  S1_1 , S1_2 , S1_3 , S1_4 , S1_5 , S1_6 , S1_7 , S1_8 , S1_9 , S1_10 , S1_11 , S1_12 , S1_13 , S1_14 , S1_15 , S1_16;

eeprom unsigned char  S2_1 , S2_2 , S2_3 , S2_4 , S2_5 , S2_6 , S2_7 , S2_8 , S2_9 , S2_10 , S2_11 , S2_12 , S2_13 , S2_14 , S2_15 , S2_16;

eeprom unsigned char  S3_1 , S3_2 , S3_3 , S3_4 , S3_5 , S3_6 , S3_7 , S3_8 , S3_9 , S3_10 , S3_11 , S3_12 , S3_13 , S3_14 , S3_15 , S3_16;

eeprom unsigned char  S4_1 , S4_2 , S4_3 , S4_4 , S4_5 , S4_6 , S4_7 , S4_8 , S4_9 , S4_10 , S4_11 , S4_12 , S4_13 , S4_14 , S4_15 , S4_16;


#define Led_M   Red_L1 ==0 || Red_L2 ==0 || Red_L3 ==0 || Red_L4 ==0 || Red_L5 ==0 || Red_L6 ==0 || Red_L7 ==0 || Red_L8 ==0 || Red_L9 ==0 || Red_L10 ==0 || Red_L11 ==0 || Red_L12 ==0 || Red_Par_21 ==0 || Red_Par_22 ==0   // [restored from compiled code: listing line was truncated]

#define Led_E   OUT_S5 , delay_ms(15000) , OUT_S5


  void White        (char Typ);

  void Scenario_M   (void);

  void Scenario_E   (void);

  void Scenario_1   (char S_1);

  void Scenario_2   (char S_2);

  void Scenario_3   (char S_3);

  void Scenario_4   (char S_4);


//---------------------------Variable RF----------------------------------


const unsigned long int Bit_Shift = 0x00000001;

unsigned long int  EV_Code = 0;

int Revice_Flag = 0;


//---------------------------remut var----------------------------------


#define	Learn	       (Touch_K1)
#define	Format	       (Touch_K2)

#define	Led_Learn_ON	PORTG &= 0b11101011 , Red_K1 =0 , w[0] &= 0b11011111    //OUT_K1  G2 , G4
#define	Led_Learn_OFF	PORTG |= 0b00000100 , w[0] &= 0b11011111                //OUT_K1  G2

#define	Led_Format_ON	PORTG &= 0b11111100 , Red_K2 =0 , w[2] &= 0b10111111    //OUT_K2  G1 , G0
#define	Led_Format_OFF	PORTG |= 0b00000010 , w[2] &= 0b10111111                //OUT_K2  G1

#define RF_PIN          PINE.6     // INT6


//---------------------------Function RF----------------------------------


    #define EE_Total_Rec 5

    eeprom unsigned long int g_u32eeprom[EE_Total_Rec];

    void EE_Format      (void);

    void EE_StoreCode   (unsigned long int Code);

    char EE_ISValidCode (unsigned long int Code);

    void Ralay_Control  (char Rkey);


//---------------------------remut var----------------------------------


    interrupt [EXT_INT6] void ext_int6_isr(void)
    {
    // Place your code here
    #asm("cli")
        static unsigned long int    Time_Falling =0;
        static unsigned long int    Time_Rising =0;
        static unsigned int         Start_Sync =0;
        static unsigned char        Bit_Index =0;
        static unsigned long int    Receive_Code =0;

        if(!Revice_Flag)
          {
                if(RF_PIN) // Rising Edge
                  {
                    TCCR1B =0x00;
                    Time_Falling = TCNT1*2;
                    TCCR1A =0x00 , TCCR1B =0x02;
                    TCNT1H =0x00 , TCNT1L =0x00;
                    ICR1H  =0x00  , ICR1L  =0x00;
                    OCR1AH =0x00 , OCR1AL =0x00;
                    OCR1BH =0x00 , OCR1BL =0x00;
                    OCR1CH =0x00 , OCR1CL =0x00;



                    if(Time_Falling > (Time_Rising * 20) && Time_Falling < (Time_Rising * 40))
                     {
                        Start_Sync =1;
                        Bit_Index =0;
                        Receive_Code =0;

                     }
                    else
                     {
                        if(Start_Sync)    // Start Sended
                         {
                            if(Bit_Index <= 23)
                             {
                                if(Time_Falling > (Time_Rising * 2) && Time_Falling < (Time_Rising * 4))
                                 {
                                    Bit_Index ++;
                                 }
                                else if(Time_Rising > (Time_Falling * 2) && Time_Rising < (Time_Falling * 4))
                                 {
                                    Receive_Code |= Bit_Shift << (23 - Bit_Index);
                                    Bit_Index ++;
                                 }
                                else
                                 {
                                    Start_Sync =0;
                                    Bit_Index =0;
                                 }

                                if(Bit_Index > 23&&Start_Sync)
                                 {
                                    // All Bit Recive
                                    Bit_Index =0;
                                    Start_Sync =0;
                                    EV_Code = Receive_Code;
                                    Revice_Flag =1;
                                 }
                             }
                         }	// End of Start Sync Send
                     }


                  }
                else	//Falling Edge
                {
                    TCCR1B=0x00;
                    Time_Rising = TCNT1*2;
                    TCCR1A =0x00 , TCCR1B =0x02;
                    TCNT1H =0x00 , TCNT1L =0x00;
                    ICR1H  =0x00 , ICR1L  =0x00;
                    OCR1AH =0x00 , OCR1AL =0x00;
                    OCR1BH =0x00 , OCR1BL =0x00;
                    OCR1CH =0x00 , OCR1CL =0x00;
                }
          }

    #asm("sei")
    }


//---------------------------Variable Wifi----------------------------------


unsigned char   data[252] , str[82] , Data_connected[252] , Mac_Ip[19] , Static_Ip[18];

unsigned char   i =0 , j =0 , Read_Ip =2;

eeprom char     o , Wifi_ON , Usere[22] , POL_Eeprom_Variable[];

unsigned char   Connected_0 =0 , Connected_1 =0 , Id_S1 =0;


//---------------------------Led Wifi----------------------------------


#define Led_W                   OUT_N3 , PORTF ^= 0b10000000

#define Led_Remove_Wifi_Pass    OUT_N3


//---------------------------Function Wifi----------------------------------


  void WiFi            (char Part);

  void Send_Fead_Back  (char Fead_Back);

  void Send_Data       (char Id , unsigned char Cunter);

  void Data_Clean      (void);


//---------------------------Function USART----------------------------------


    interrupt [USART0_RXC] void usart0_rx_isr(void)
     {
         data[i] = UDR0;

         i++;

         data[i] =0;

         if(i >= 250) i =0;
     }


//---------------------------Function TIMER0 25 ms----------------------------------


unsigned int  Stand_by_Countr , Screen_Countr_1 , Learn_Time;


  void TIMER0_ON  (void)
      {
          ASSR=0<<AS0;
          TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (1<<CS01) | (1<<CS00);
          TCNT0=0x3D;
          OCR0=0x00;
      }


  void TIMER0_OFF (void)
      {
          ASSR=0<<AS0;
          TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (0<<CS01) | (0<<CS00);
          TCNT0=0x3D;
          OCR0=0x00;
      }


    interrupt [TIM0_OVF] void timer0_ovf_isr(void)
     {
          TCNT0 = 0x3D;

          Stand_by_Countr ++;                              // Stand_by

          if(Screen_Countr_1 >= 1)  Screen_Countr_1 ++;    // Screen_1

          if(Learn_Time >= 1)       Learn_Time ++ ;        // RF
     }


//---------------------------Function  Main----------------------------------


void main(void)
 {

    unsigned int      Wifi_Countr =0 , chek =0 , time_chek =5000;

    unsigned char     L_W =0 , L_S =0 , Scenario_Countr =0;

    bit               L =1 , L_IN_S =1 , L_Lock =1 , L_M =0;

    unsigned char     LFormat =1  , LLearn =1 , Learn_Mode =1 , Nurmal_Mode =0 , Work_Mode =0;


    delay_ms(300);

    DDRA  = 0b00000000;
    PORTA = 0b11111111;

    DDRB  = 0b00001101;
    PORTB = 0b11110111;

    DDRC  = 0b10000000;
    PORTC = 0b01111111;

    DDRD  = 0b01111011;
    PORTD = 0b11110011;

    DDRE  = 0b10111110;
    PORTE = 0b11000000;

    DDRF  = 0b11111111;
    PORTF = 0b00000000;

    DDRG  = 0b11111111;
    PORTG = 0b00000110;

    delay_ms(300);


 //---------------------------TIMER/Counter 0------------------------------------------


        // Timer/Counter 0 initialization
        // Clock source: System Clock
        // Clock value: 7.813 kHz
        // Mode: Normal top=0xFF
        // OC0 output: Disconnected
        // Timer Period: 24.96 ms
        ASSR=0<<AS0;
        TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (1<<CS01) | (1<<CS00);
        TCNT0=0x3D;
        OCR0=0x00;


 //---------------------------Timer/Counter 1------------------------------------------


        // Timer/Counter 1 initialization
        // Clock source: System Clock
        // Clock value: Timer1 Stopped
        // Mode: Normal top=0xFFFF
        // OC1A output: Disconnected
        // OC1B output: Disconnected
        // OC1C output: Disconnected
        // Noise Canceler: Off
        // Input Capture on Falling Edge
        // Timer1 Overflow Interrupt: Off
        // Input Capture Interrupt: Off
        // Compare A Match Interrupt: Off
        // Compare B Match Interrupt: Off
        // Compare C Match Interrupt: Off
        TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<COM1C1) | (0<<COM1C0) | (0<<WGM11) | (0<<WGM10);
        TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (0<<CS10);
        TCNT1H=0x00;
        TCNT1L=0x00;
        ICR1H=0x00;
        ICR1L=0x00;
        OCR1AH=0x00;
        OCR1AL=0x00;
        OCR1BH=0x00;
        OCR1BL=0x00;
        OCR1CH=0x00;
        OCR1CL=0x00;


        // Timer(s)/Counter(s) Interrupt(s) initialization
        TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);
        ETIMSK=(0<<TICIE3) | (0<<OCIE3A) | (0<<OCIE3B) | (0<<TOIE3) | (0<<OCIE3C) | (0<<OCIE1C);


 //---------------------------Interrupt------------------------------------------


        // External Interrupt(s) initialization
        // INT0: Off
        // INT1: Off
        // INT2: Off
        // INT3: Off
        // INT4: Off
        // INT5: Off
        // INT6: On
        // INT6 Mode: Any change
        // INT7: Off
        EICRA=(0<<ISC31) | (0<<ISC30) | (0<<ISC21) | (0<<ISC20) | (0<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
        EICRB=(0<<ISC71) | (0<<ISC70) | (0<<ISC61) | (1<<ISC60) | (0<<ISC51) | (0<<ISC50) | (0<<ISC41) | (0<<ISC40);
        EIMSK=(0<<INT7) | (1<<INT6) | (0<<INT5) | (0<<INT4) | (0<<INT3) | (0<<INT2) | (0<<INT1) | (0<<INT0);
        EIFR=(0<<INTF7) | (1<<INTF6) | (0<<INTF5) | (0<<INTF4) | (0<<INTF3) | (0<<INTF2) | (0<<INTF1) | (0<<INTF0);


 //---------------------------USART------------------------------------------


        // USART0 initialization
        // Communication Parameters: 8 Data, 1 Stop, No Parity
        // USART0 Receiver: On
        // USART0 Transmitter: On
        // USART0 Mode: Asynchronous
        // USART0 Baud Rate: 9600
        UCSR0A=(0<<RXC0) | (0<<TXC0) | (0<<UDRE0) | (0<<FE0) | (0<<DOR0) | (0<<UPE0) | (0<<U2X0) | (0<<MPCM0);
        UCSR0B=(1<<RXCIE0) | (0<<TXCIE0) | (0<<UDRIE0) | (1<<RXEN0) | (1<<TXEN0) | (0<<UCSZ02) | (0<<RXB80) | (0<<TXB80);
        UCSR0C=(0<<UMSEL0) | (0<<UPM01) | (0<<UPM00) | (0<<USBS0) | (1<<UCSZ01) | (1<<UCSZ00) | (0<<UCPOL0);
        UBRR0H=0x00;
        UBRR0L=0x33;

        // USART1 initialization
        // USART1 disabled
        UCSR1B=(0<<RXCIE1) | (0<<TXCIE1) | (0<<UDRIE1) | (0<<RXEN1) | (0<<TXEN1) | (0<<UCSZ12) | (0<<RXB81) | (0<<TXB81);


 //-------------------------------------------------------------------------------------------------------


     if(o)
       {
            for( j = 0 ; j < POL_j ; j++) POL_Eeprom_Variable[j] = POL_Variable[j] , delay_ms(5);

for( j = 0 ; j < 20 ; j++) Usere[j] ='\0';

o =0;
       }


     for( j = 0 ; j < 17 ; j++) Mac_Ip[j] ='\0';

for( j = 0 ; j < 16 ; j++) Static_Ip[j] ='\0';

for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';


w[0] =0X00 ,  w[1] =0X00 ,  w[2] =0X00 ,  w[3] =0X00;

     Data_Clean();

     #asm("sei")

     delay_ms(4000);

     if(!Wifi_ON) delay_ms(4000) , WiFi(0);


    while(1)
     {


          if(Stand_by)
            {
                TIMER0_OFF();

                White (0);

                Data_Clean();

                while(Stand_by_Countr >= 600)
                    {
                        if(Touch)
                            {
                                White (0);

                                Stand_by_Countr =0 , L =1;
                            }

                        if(Touch_IN_S)
                            {
                                White (1);

                                Stand_by_Countr =0 , L =1;
                            }

                        if(strstr(data , "IPD") || strstr(data , "CONNECT") || Revice_Flag)
                            {
                                White (2);

                                Stand_by_Countr =0 , L =1;
                            }
                    }

                delay_ms(1000);

                TIMER0_ON();
            }


     //---------------------------Touch--------------------------------


          if(!Red_Lock && Touch)
            {
                  while(Touch && L)
                      {
                          if(chek >= time_chek)
                            {
                                Data_connected[4] ='U';

                                if(Touch_1)
                                  {
                                      if(Touch_L1)   OUT_L1 , w[0] ^=0X40 , Send_Fead_Back (1) ;

                                      if(Touch_L2)   OUT_L2 , w[0] ^=0X80 , Send_Fead_Back (1) ;

                                      if(Touch_L3)   OUT_L3 , w[0] ^=0X10 , Send_Fead_Back (1) ;

                                      if(Touch_L4)   OUT_L4 , w[0] ^=0X20 , Send_Fead_Back (1) ;

                                      if(Touch_L5)   OUT_L5 , w[0] ^=0X04 , Send_Fead_Back (1) ;

                                      if(Touch_L6)   OUT_L6 , w[0] ^=0X08 , Send_Fead_Back (1) ;

                                      if(Touch_L7)   OUT_L7 , w[0] ^=0X01 , Send_Fead_Back (1) ;

                                      if(Touch_L8)   OUT_L8 , w[0] ^=0X02 , Send_Fead_Back (1) ;
                                  }

                                if(Touch_2)
                                  {
                                      if(Touch_L9)   OUT_L9  , w[1] ^=0X40 , Send_Fead_Back (1) ;

                                      if(Touch_L10)  OUT_L10 , w[1] ^=0X80 , Send_Fead_Back (1) ;

                                      if(Touch_L11)  OUT_L11 , w[1] ^=0X10 , Send_Fead_Back (1) ;

                                      if(Touch_L12)  OUT_L12 , w[1] ^=0X20 , Send_Fead_Back (1) ;



                                  //------------------Touch ==> Scenario---------------------


                                      L_S =0 , chek =0 , Scenario_Countr =0;

                                      while(Touch_S1 && L_S < 2)                 // Scenario_1
                                           {
                                               if(chek >= time_chek)   L_S =1 , Scenario_Countr ++ , delay_ms(30);

                                               if(Scenario_Countr >= 100)   L_S =2 , Scenario_1(1);

                                               chek++;
                                           }

                                      if(L_S == 1)   L_S =0 , Scenario_1(0);



                                      L_S =0 , chek =0 , Scenario_Countr =0;

                                      while(Touch_S2 && L_S < 2)                 // Scenario_2
                                           {
                                               if(chek >= time_chek)   L_S =1 , Scenario_Countr ++ , delay_ms(30);

                                               if(Scenario_Countr >= 100)   L_S =2 , Scenario_2(1);

                                               chek++;
                                           }

                                      if(L_S == 1)   L_S =0 , Scenario_2(0);



                                      L_S =0 , chek =0 , Scenario_Countr =0;

                                      while(Touch_S3 && L_S < 2)                 // Scenario_3
                                           {
                                               if(chek >= time_chek)   L_S =1 , Scenario_Countr ++ , delay_ms(30);

                                               if(Scenario_Countr >= 100)   L_S =2 , Scenario_3(1);

                                               chek++;
                                           }

                                      if(L_S == 1)   L_S =0 , Scenario_3(0);



                                      L_S =0 , chek =0 , Scenario_Countr =0;

                                      while(Touch_S4 && L_S < 2)                 // Scenario_4
                                           {
                                               if(chek >= time_chek)   L_S =1 , Scenario_Countr ++ , delay_ms(30);

                                               if(Scenario_Countr >= 100)   L_S =2 , Scenario_4(1);

                                               chek++;
                                           }

                                      if(L_S == 1)   L_S =0 , Scenario_4(0);
                                  }

                                if(Touch_3)
                                  {
                                      if(Touch_S5)   Scenario_E();

                                      //if(Touch_S6)   ;


                                      if(Touch_K1)   OUT_K1 , w[2] ^=0X80 , Send_Fead_Back (3) ;

                                      if(Touch_K2)   OUT_K2 , delay_ms(2000) , OUT_K2  ; //  , w[2] ^=0X40 , Send_Fead_B  (comment truncated in listing)

                                      if(Touch_K3)   OUT_K3 , delay_ms(2000) , OUT_K3 ; // w[2] ^=0X20 , Send_Fead_Back  (comment truncated in listing)

                                      //if(Touch_7D)   OUT_7D ;


                                  //------------------Touch ==> Master & Wifi---------------------


                                      L_M =0 , L_W =0 , chek =0 , Wifi_Countr =0;

                                      while(Touch_M && L_W < 2)
                                           {
                                               if(Wifi_Countr >= 100 && !L_W)  L_W =1 , Wifi_ON =! Wifi_ON , WiFi(0);  (comment truncated in listing)

                                               if(Wifi_Countr >= 300)        { L_W =2 ; if(!Wifi_ON)  WiFi(9); }    //Re  (comment truncated in listing)


                                               if(chek >= time_chek)
                                                 {
                                                     if(!L_M)  L_M =1 , Scenario_M();

                                                     Wifi_Countr ++ , delay_ms(30);
                                                 }

                                               chek++;
                                           }
                                  }

                                if(Touch_4)
                                  {
                                      //if(Touch_7U)   OUT_7U ;

                                      //if(Touch_7F)   OUT_7F ;

                                      //if(Touch_7N)   OUT_7N ;


                                      if(Touch_EL)   OUT_EL  , w[2] ^=0X10 , Send_Fead_Back (3) ;


                                      if(Touch_P1O)  OUT_P1O , w[1] ^=0X08 , Send_Fead_Back (1) ;

                                      if(Touch_P1C)  OUT_P1C , w[1] ^=0X04 , Send_Fead_Back (1) ;


                                      if(Touch_P2O)  OUT_P2O , w[1] ^=0X02 , Send_Fead_Back (1) ;

                                      if(Touch_P2C)  OUT_P2C , w[1] ^=0X01 , Send_Fead_Back (1) ;
                                  }

                                L =0;
                            }

                          chek++;
                      }
                            chek =0;


            //---------------------------RF-------------------------------------


                  while(Learn && LLearn)
                     {
                        if(chek>=100)
                            {
                                 Led_Learn_ON;

                                 Work_Mode = Learn_Mode;

                                 Learn_Time =1;

                                 LLearn =0 , chek =0;
                            }

                        delay_ms(30);

                        chek++;
                     }
                           chek =0;

                  while(Format && LFormat)
                     {
                        if(chek>=100)
                            {
                                 #asm("cli")

                                 Led_Format_ON;

                                 delay_ms(300);

                                 EE_Format();

                                 Led_Format_OFF;

                                 LFormat=0,chek=0;

                                 delay_ms(1000);

                                 #asm("sei")
                            }

                        delay_ms(30);

                        chek++;
                     }
                     if(!Format && !LFormat)    LFormat =1;

                  chek =0 , Stand_by_Countr =0;
            }

          if(!L && !Touch)    L =1;


     //---------------------------Lock---------------------------------


          while(Touch_Lock && L_Lock)
               {
                    if(chek >= 100)    L_Lock =0 , chek =0 , Led_Lock , OUT_Lock;

                    delay_ms(30);

                    chek++ , Stand_by_Countr =0;
               }
                   chek =0;

          if(!L_Lock && !Touch)    L_Lock =1;


     //---------------------------Touch Input M64-4--------------------


          if(Touch_IN_S && L_IN_S)
            {
                delay_ms(15);

                if(Touch_IN_S1)   Scenario_1(0);

                if(Touch_IN_S2)   Scenario_2(0);

                if(Touch_IN_S3)   Scenario_3(0);

                if(Touch_IN_S4)   Scenario_4(0);

                if(Touch_IN_S5)   Scenario_E();


                if(Touch_IN_Alarm_OFF)   WiFi(13);

                if(Touch_IN_Alarm_ON)    WiFi(14);


                if(Touch_IN_K1_O && !Red_K1)    OUT_K1;

                if(Touch_IN_K1_F &&  Red_K1)    OUT_K1;

                if(Touch_IN_K2_O && !Red_K2)    OUT_K2 , delay_ms(2000) , OUT_K2;

                //if(Touch_IN_K2_F &&  Red_K2)    OUT_K2;

                if(Touch_IN_K3_O && !Red_K3)    OUT_K3 , delay_ms(2000) , OUT_K3;

                //if(Touch_IN_K3_F &&  Red_K3)    OUT_K3;


                L_IN_S =0 , Stand_by_Countr =0;
            }

          if(!Touch_IN_S && !L_IN_S)    L_IN_S =1;


      //---------------------------RF-----------------------------------


          if(Revice_Flag)
            {
                 if(Work_Mode == Nurmal_Mode)
                   {
                        if(EE_ISValidCode(EV_Code & 0xFFFFFFF0)) Ralay_Control (EV_Code & 0x0F); /*If Valid Code*/

                        delay_ms(100);
                   }

                 else if(Work_Mode == Learn_Mode)
                    {

                        if(!EE_ISValidCode(EV_Code & 0xFFFFFFF0)) /*If Not Have Code*/
                            {
                                EE_StoreCode(EV_Code & 0xFFFFFFF0);

                                Work_Mode = Nurmal_Mode;

                                Learn_Time=0 , LLearn=1;

                                Led_Learn_ON , Led_Learn_OFF;
                            }
                    }


                 EV_Code =0;

                 Stand_by_Countr =0;

                 Revice_Flag =0;
            }


          if(Learn_Time >= 200)
             {
                 Work_Mode = Nurmal_Mode;

                 Learn_Time=0 , LLearn=1;

                 Led_Learn_ON , Led_Learn_OFF;
             }


     //---------------------------WiFi-----------------------------------


          if(strstr(data , "WIFI GOT IP"))   Stand_by_Countr =0 , WiFi(1);

          if(Read_Ip < 2)                    Stand_by_Countr =0 , WiFi(2);

          if(strstr(data , "FAIL"))          Stand_by_Countr =0 , WiFi(3);

          if(strstr(data , "0,CONNECT"))     Id_S1 =0 , Stand_by_Countr =0 , Connected_0 =1 , Data_Clean();
          if(strstr(data , "1,CONNECT"))     Id_S1 =1 , Stand_by_Countr =0 , Connected_1 =1 , Data_Clean();

          if(strstr(data , "+IPD,0"))        Id_S1 =0 , Stand_by_Countr =0 , WiFi(4) , Data_Clean();
          if(strstr(data , "+IPD,1"))        Id_S1 =1 , Stand_by_Countr =0 , WiFi(4) , Data_Clean();

          if(strstr(data , "0,CLOSED"))                 Stand_by_Countr =0 , Connected_0 =0 , Data_Clean();
          if(strstr(data , "1,CLOSED"))      Id_S1 =0 , Stand_by_Countr =0 , Connected_1 =0 , Data_Clean();
     }
 }


//---------------------------Function----------------------------------


    void White (char Typ)
     {
        if(Typ == 2)
         {
              OUT_Stand_by_1;

             if(!Red_K1) White_K1;

             if(!Red_K2) White_K2;

              OUT_Stand_by_2;
         }

            else if(Typ == 1)
             {
                  OUT_Stand_by_1_d;

                  delay_ms(500);

                 if(!Red_K1) White_K1;

                 if(!Red_K2) White_K2;

                 delay_ms(300);

                 //OUT_Stand_by_2;

                 delay_ms(100);
             }

                else
                 {
                      OUT_Stand_by_1_d;

                      delay_ms(500);

                     if(!Red_K1) White_K1;

                     if(!Red_K2) White_K2;

                     delay_ms(300);

                     OUT_Stand_by_2;

                     delay_ms(100);
                 }
     }


    void Scenario_M (void)
     {
        bit   DY =0;

        #asm("cli")

        if(Led_M)
         {
             if(!Red_L1 ) DY =1 , OUT_L1;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L2 ) DY =1 , OUT_L2;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L3 ) DY =1 , OUT_L3;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L4 ) DY =1 , OUT_L4;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L5 ) DY =1 , OUT_L5;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L6 ) DY =1 , OUT_L6;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L7 ) DY =1 , OUT_L7;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L8 ) DY =1 , OUT_L8;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L9 ) DY =1 , OUT_L9;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L10) DY =1 , OUT_L10;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L11) DY =1 , OUT_L11;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_L12) DY =1 , OUT_L12;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_Par_11) DY =1 , OUT_P1O;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_Par_12) OUT_P1C;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_Par_21) DY =1 , OUT_P2O;

             if(DY    ) DY =0 , delay_ms(50);

             if(!Red_Par_22) OUT_P2C;

             w[0] =0XFF , w[1] =0XFF;
         }

        else
         {
            OUT_L1;

            delay_ms(50);

            OUT_L2;

            delay_ms(50);

            OUT_L3;

            delay_ms(50);

            OUT_L4;

            delay_ms(50);

            OUT_L5;

            delay_ms(50);

            OUT_L6;

            delay_ms(50);

            OUT_L7;

            delay_ms(50);

            OUT_L8;

            delay_ms(50);

            OUT_L9;

            delay_ms(50);

            OUT_L10;

            delay_ms(50);

            OUT_L11;

            delay_ms(50);

            OUT_L12;

            delay_ms(50);

            OUT_P1O;

            delay_ms(50);

            OUT_P1C;

            delay_ms(50);

            OUT_P2O;

            delay_ms(50);

            OUT_P2C;

            w[0] =0X00 , w[1] =0X00;
         }


        Send_Fead_Back (1);

        #asm("sei")
     }


    void Scenario_E (void)
     {
         bit   DY =0;

         Led_E;

         if(Red_L1 ) DY =1 , OUT_L1;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L2 ) DY =1 , OUT_L2;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L3 ) DY =1 , OUT_L3;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L4 ) DY =1 , OUT_L4;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L5 ) DY =1 , OUT_L5;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L6 ) DY =1 , OUT_L6;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L7 ) DY =1 , OUT_L7;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L8 ) DY =1 , OUT_L8;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L9 ) DY =1 , OUT_L9;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L10) DY =1 , OUT_L10;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L11) DY =1 , OUT_L11;

         if(DY    ) DY =0 , delay_ms(50);

         if(Red_L12) DY =1 , OUT_L12;

         if(DY    ) DY =0 , delay_ms(50);

        if(Red_Par_11) OUT_P1O;

         if(DY    ) DY =0 , delay_ms(50);

        if(Red_Par_12) OUT_P1C;

         if(DY    ) DY =0 , delay_ms(50);

        if(Red_Par_21) OUT_P2O;

         if(DY    ) DY =0 , delay_ms(50);

        if(Red_Par_22) OUT_P2C;


         w[0] =0X00 , w[1] =0X00;

         Send_Fead_Back (1);

         delay_ms(100);
     }


    void Scenario_1 (char S_1)
     {
         bit   DY =0;

         if(S_1)
           {
               OUT_N1;

                 if(Red_L1 )   S1_1  =0;    else   S1_1  =1;   delay_ms(10);

                 if(Red_L2 )   S1_2  =0;    else   S1_2  =1;   delay_ms(10);

                 if(Red_L3 )   S1_3  =0;    else   S1_3  =1;   delay_ms(10);

                 if(Red_L4 )   S1_4  =0;    else   S1_4  =1;   delay_ms(10);

                 if(Red_L5 )   S1_5  =0;    else   S1_5  =1;   delay_ms(10);

                 if(Red_L6 )   S1_6  =0;    else   S1_6  =1;   delay_ms(10);

                 if(Red_L7 )   S1_7  =0;    else   S1_7  =1;   delay_ms(10);

                 if(Red_L8 )   S1_8  =0;    else   S1_8  =1;   delay_ms(10);

                 if(Red_L9 )   S1_9  =0;    else   S1_9  =1;   delay_ms(10);

                 if(Red_L10)   S1_10 =0;    else   S1_10 =1;   delay_ms(10);

                 if(Red_L11)   S1_11 =0;    else   S1_11 =1;   delay_ms(10);

                 if(Red_L12)   S1_12 =0;    else   S1_12 =1;   delay_ms(10);


           //---------------------------Screen 1----------------------------------


                if(Red_Par_11) S1_13 =0;    else   S1_13 =1;   delay_ms(10);

                if(Red_Par_12) S1_14 =0;    else   S1_14 =1;   delay_ms(10);


           //---------------------------Screen 2----------------------------------


                if(Red_Par_21) S1_15 =0;    else   S1_15 =1;   delay_ms(10);

                if(Red_Par_22) S1_16 =0;    else   S1_16 =1;   delay_ms(10);

               delay_ms(1000);

               OUT_N1;
           }

            else
             {
                 if(!S1_1 && !Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                        else if(S1_1 && Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S1_2 && !Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                        else if(S1_2 && Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S1_3 && !Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                        else if(S1_3 && Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S1_4 && !Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                        else if(S1_4 && Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_5 && !Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                        else if(S1_5 && Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_6 && !Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                        else if(S1_6 && Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_7 && !Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                        else if(S1_7 && Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_8 && !Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                        else if(S1_8 && Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_9 && !Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                        else if(S1_9 && Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_10 && !Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                        else if(S1_10 && Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_11 && !Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                        else if(S1_11 && Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_12 && !Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                        else if(S1_12 && Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_13 && !Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                        else if(S1_13 && Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_14 && !Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                        else if(S1_14 && Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_15 && !Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                        else if(S1_15 && Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S1_16 && !Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                        else if(S1_16 && Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);


                 Send_Fead_Back (1);
            }
     }


    void Scenario_2 (char S_2)
     {
         bit   DY =0;

         if(S_2)
           {
               OUT_N1;

                 if(Red_L1 )   S2_1  =0;    else   S2_1  =1;   delay_ms(10);

                 if(Red_L2 )   S2_2  =0;    else   S2_2  =1;   delay_ms(10);

                 if(Red_L3 )   S2_3  =0;    else   S2_3  =1;   delay_ms(10);

                 if(Red_L4 )   S2_4  =0;    else   S2_4  =1;   delay_ms(10);

                 if(Red_L5 )   S2_5  =0;    else   S2_5  =1;   delay_ms(10);

                 if(Red_L6 )   S2_6  =0;    else   S2_6  =1;   delay_ms(10);

                 if(Red_L7 )   S2_7  =0;    else   S2_7  =1;   delay_ms(10);

                 if(Red_L8 )   S2_8  =0;    else   S2_8  =1;   delay_ms(10);

                 if(Red_L9 )   S2_9  =0;    else   S2_9  =1;   delay_ms(10);

                 if(Red_L10)   S2_10 =0;    else   S2_10 =1;   delay_ms(10);

                 if(Red_L11)   S2_11 =0;    else   S2_11 =1;   delay_ms(10);

                 if(Red_L12)   S2_12 =0;    else   S2_12 =1;   delay_ms(10);


           //---------------------------Screen 1----------------------------------


                if(Red_Par_11) S2_13 =0;    else   S2_13 =1;   delay_ms(10);

                if(Red_Par_12) S2_14 =0;    else   S2_14 =1;   delay_ms(10);


           //---------------------------Screen 2----------------------------------


                if(Red_Par_21) S2_15 =0;    else   S2_15 =1;   delay_ms(10);

                if(Red_Par_22) S2_16 =0;    else   S2_16 =1;   delay_ms(10);

               delay_ms(1000);

               OUT_N1;
           }

            else
             {
                 if(!S2_1 && !Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                        else if(S2_1 && Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S2_2 && !Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                        else if(S2_2 && Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S2_3 && !Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                        else if(S2_3 && Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S2_4 && !Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                        else if(S2_4 && Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_5 && !Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                        else if(S2_5 && Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_6 && !Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                        else if(S2_6 && Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_7 && !Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                        else if(S2_7 && Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_8 && !Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                        else if(S2_8 && Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_9 && !Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                        else if(S2_9 && Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_10 && !Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                        else if(S2_10 && Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_11 && !Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                        else if(S2_11 && Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_12 && !Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                        else if(S2_12 && Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_13 && !Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                        else if(S2_13 && Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_14 && !Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                        else if(S2_14 && Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_15 && !Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                        else if(S2_15 && Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S2_16 && !Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                        else if(S2_16 && Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);


                 Send_Fead_Back (1);
             }
     }


    void Scenario_3 (char S_3)
     {
         bit   DY =0;

         if(S_3)
           {
               OUT_N1;

                 if(Red_L1 )   S3_1  =0;    else   S3_1  =1;   delay_ms(10);

                 if(Red_L2 )   S3_2  =0;    else   S3_2  =1;   delay_ms(10);

                 if(Red_L3 )   S3_3  =0;    else   S3_3  =1;   delay_ms(10);

                 if(Red_L4 )   S3_4  =0;    else   S3_4  =1;   delay_ms(10);

                 if(Red_L5 )   S3_5  =0;    else   S3_5  =1;   delay_ms(10);

                 if(Red_L6 )   S3_6  =0;    else   S3_6  =1;   delay_ms(10);

                 if(Red_L7 )   S3_7  =0;    else   S3_7  =1;   delay_ms(10);

                 if(Red_L8 )   S3_8  =0;    else   S3_8  =1;   delay_ms(10);

                 if(Red_L9 )   S3_9  =0;    else   S3_9  =1;   delay_ms(10);

                 if(Red_L10)   S3_10 =0;    else   S3_10 =1;   delay_ms(10);

                 if(Red_L11)   S3_11 =0;    else   S3_11 =1;   delay_ms(10);

                 if(Red_L12)   S3_12 =0;    else   S3_12 =1;   delay_ms(10);


           //---------------------------Screen 1----------------------------------


                if(Red_Par_11) S3_13 =0;    else   S3_13 =1;   delay_ms(10);

                if(Red_Par_12) S3_14 =0;    else   S3_14 =1;   delay_ms(10);


           //---------------------------Screen 2----------------------------------


                if(Red_Par_21) S3_15 =0;    else   S3_15 =1;   delay_ms(10);

                if(Red_Par_22) S3_16 =0;    else   S3_16 =1;   delay_ms(10);

               delay_ms(1000);

               OUT_N1;
           }

            else
             {
                 if(!S3_1 && !Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                        else if(S3_1 && Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S3_2 && !Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                        else if(S3_2 && Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S3_3 && !Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                        else if(S3_3 && Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S3_4 && !Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                        else if(S3_4 && Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_5 && !Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                        else if(S3_5 && Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_6 && !Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                        else if(S3_6 && Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_7 && !Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                        else if(S3_7 && Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_8 && !Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                        else if(S3_8 && Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_9 && !Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                        else if(S3_9 && Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_10 && !Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                        else if(S3_10 && Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_11 && !Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                        else if(S3_11 && Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_12 && !Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                        else if(S3_12 && Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_13 && !Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                        else if(S3_13 && Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_14 && !Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                        else if(S3_14 && Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_15 && !Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                        else if(S3_15 && Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S3_16 && !Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                        else if(S3_16 && Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);


                 Send_Fead_Back (1);
             }
     }


    void Scenario_4 (char S_4)
     {
         bit   DY =0;

         if(S_4)
           {
               OUT_N1;

                 if(Red_L1 )   S4_1  =0;    else   S4_1  =1;   delay_ms(10);

                 if(Red_L2 )   S4_2  =0;    else   S4_2  =1;   delay_ms(10);

                 if(Red_L3 )   S4_3  =0;    else   S4_3  =1;   delay_ms(10);

                 if(Red_L4 )   S4_4  =0;    else   S4_4  =1;   delay_ms(10);

                 if(Red_L5 )   S4_5  =0;    else   S4_5  =1;   delay_ms(10);

                 if(Red_L6 )   S4_6  =0;    else   S4_6  =1;   delay_ms(10);

                 if(Red_L7 )   S4_7  =0;    else   S4_7  =1;   delay_ms(10);

                 if(Red_L8 )   S4_8  =0;    else   S4_8  =1;   delay_ms(10);

                 if(Red_L9 )   S4_9  =0;    else   S4_9  =1;   delay_ms(10);

                 if(Red_L10)   S4_10 =0;    else   S4_10 =1;   delay_ms(10);

                 if(Red_L11)   S4_11 =0;    else   S4_11 =1;   delay_ms(10);

                 if(Red_L12)   S4_12 =0;    else   S4_12 =1;   delay_ms(10);


           //---------------------------Screen 1----------------------------------


                if(Red_Par_11) S4_13 =0;    else   S4_13 =1;   delay_ms(10);

                if(Red_Par_12) S4_14 =0;    else   S4_14 =1;   delay_ms(10);


           //---------------------------Screen 2----------------------------------


                if(Red_Par_21) S4_15 =0;    else   S4_15 =1;   delay_ms(10);

                if(Red_Par_22) S4_16 =0;    else   S4_16 =1;   delay_ms(10);

               delay_ms(1000);

               OUT_N1;
           }

            else
             {
                 if(!S4_1 && !Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                        else if(S4_1 && Red_L1) DY =1 , OUT_L1 , w[0] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S4_2 && !Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                        else if(S4_2 && Red_L2) DY =1 , OUT_L2 , w[0] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S4_3 && !Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                        else if(S4_3 && Red_L3) DY =1 , OUT_L3 , w[0] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);


                 if(!S4_4 && !Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                        else if(S4_4 && Red_L4) DY =1 , OUT_L4 , w[0] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_5 && !Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                        else if(S4_5 && Red_L5) DY =1 , OUT_L5 , w[0] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_6 && !Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                        else if(S4_6 && Red_L6) DY =1 , OUT_L6 , w[0] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_7 && !Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                        else if(S4_7 && Red_L7) DY =1 , OUT_L7 , w[0] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_8 && !Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                        else if(S4_8 && Red_L8) DY =1 , OUT_L8 , w[0] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_9 && !Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                        else if(S4_9 && Red_L9) DY =1 , OUT_L9 , w[1] ^=0X40;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_10 && !Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                        else if(S4_10 && Red_L10) DY =1 , OUT_L10 , w[1] ^=0X80;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_11 && !Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                        else if(S4_11 && Red_L11) DY =1 , OUT_L11 , w[1] ^=0X10;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_12 && !Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                        else if(S4_12 && Red_L12) DY =1 , OUT_L12 , w[1] ^=0X20;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_13 && !Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                        else if(S4_13 && Red_Par_11) DY =1 , OUT_P1O , w[1] ^=0X08;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_14 && !Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                        else if(S4_14 && Red_Par_12) DY =1 , OUT_P1C , w[1] ^=0X04;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_15 && !Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                        else if(S4_15 && Red_Par_21) DY =1 , OUT_P2O , w[1] ^=0X02;

                    if(DY) DY =0 , delay_ms(50);



                 if(!S4_16 && !Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                        else if(S4_16 && Red_Par_22) DY =1 , OUT_P2C , w[1] ^=0X01;

                    if(DY) DY =0 , delay_ms(50);


                 Send_Fead_Back (1);
             }
     }



//---------------------------Function RF-------------------------------------



    void EE_Format (void)
    {
        unsigned long int Temp = 0xFFFFFFFF;

        for(j = 0 ; j < EE_Total_Rec ; j++)
        {
            eeprom_write_dword(&g_u32eeprom[j] , Temp);

            delay_ms(5);
        }
    }


    char EE_FindFreeIndex (void)
    {
        unsigned long int Temp;

        for(j = 0 ; j < EE_Total_Rec ; j++)
        {
            Temp = eeprom_read_dword(&g_u32eeprom[j]);

            if(Temp == 0xFFFFFFFF) return j;
        }

        return -1;
    }


    void EE_StoreCode (unsigned long int Code)
    {
        char Index;

        Index = EE_FindFreeIndex();

        if(Index != -1)
        {
            eeprom_write_dword(&g_u32eeprom[Index] , Code);

            delay_ms(5);
        }
    }


    char EE_ISValidCode (unsigned long int Code)
    {
        unsigned long int Temp;

        for(j = 0 ; j < EE_Total_Rec ; j++)
        {
            Temp = eeprom_read_dword(&g_u32eeprom[j]);

            if(Temp == Code)

            return 1;
        }
        return 0;
    }


    void Ralay_Control (char Rkey)
    {
        Data_connected[4] ='U';


             if(Rkey == 0B00000001) { OUT_L2  , w[0] ^=0X80 , Send_Fead_Back (1); }

        else if(Rkey == 0B00000010) { OUT_L1  , w[0] ^=0X40 , Send_Fead_Back (1); }

        else if(Rkey == 0B00001000) { OUT_L4  , w[0] ^=0X20 , Send_Fead_Back (1); }

        else if(Rkey == 0B00000100) { OUT_L3  , w[0] ^=0X10 , Send_Fead_Back (1); }

        else if(Rkey == 0B00000101) { OUT_L6  , w[0] ^=0X08 , Send_Fead_Back (1); }

        else if(Rkey == 0B00001110) { OUT_L5  , w[0] ^=0X04 , Send_Fead_Back (1); }

        else if(Rkey == 0B00001001) { OUT_L8  , w[0] ^=0X02 , Send_Fead_Back (1); }

        else if(Rkey == 0B00001010) { OUT_L7  , w[0] ^=0X01 , Send_Fead_Back (1); }

        else if(Rkey == 0B00000110) { OUT_L10 , w[1] ^=0X80 , Send_Fead_Back (1); }

        else if(Rkey == 0B00000111) { OUT_L9  , w[1] ^=0X40 , Send_Fead_Back (1); }

        else if(Rkey == 0B00001011) { OUT_L12 , w[1] ^=0X40 , Send_Fead_Back (1); }

        else if(Rkey == 0B00001101) { OUT_L11 , w[1] ^=0X40 , Send_Fead_Back (1); }
    }



//---------------------------Function WiFi----------------------------------



    void WiFi (char Part)
     {
        unsigned char  *ret , s =0 , r =0 , x[20] , Bit =0 , StartBytedata =0 , StartBitdata =0 , StartBytew =0 , StartBitw =0;
        bit     DY =0;


       for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';


if(Part == 0)
         {
            Led_W , Connected_0 =0 , Connected_1 =0;

            #asm("cli")

            if(!Wifi_ON)
             {
                delay_ms(300);

                sprintf(str , "AT+CWMODE=3%c" , 13);

                puts(str);

                delay_ms(300);

                Data_Clean();


                sprintf(str , "AT+CIPMUX=1%c" , 13);

                puts(str);

                delay_ms(300);

                Data_Clean();


                sprintf(str , "AT+CIPSERVER=1,6269%c" , 13);

                puts(str);

                delay_ms(300);

                Data_Clean();


                delay_ms(3000);

                sprintf(str , "AT+CIFSR%c" , 13);

                puts(str);

                #asm("sei")

                Read_Ip =0;
             }
         }


        if(Part == 1)       //Check IP
         {
            delay_ms(2000);

            #asm("cli")

            Data_Clean();

            sprintf(str , "AT+CIFSR%c" , 13);

            puts(str);

            Data_Clean();

            #asm("sei")

            Read_Ip =1;
         }


        if(Part == 2)       //Writ IP
         {
            if(Read_Ip == 0 && strstr(data , "STAMAC"))
             {
                delay_ms(300);

                #asm("cli")

                for( j = 0 ; j < 17 ; j++) Mac_Ip[j] =' ';

ret = strstr(data , "STAMAC");

                s = ret - data;

                s = s + 7;

                for(j = 0 ; j < 17 ; j++) { s++; if(data[s] == '"') break; Mac_Ip[j] = data[s]; }

                Read_Ip =1;
             }

            if(Read_Ip == 1 && strstr(data , "STAIP"))
             {
                delay_ms(300);

                #asm("cli")

                if(strstr(data , "0.0.0.0"))
                 {
                    sprintf(Data_connected , "@M_S=Repeat\n");

                         if(Connected_0 && !Id_S1) Send_Data (0 , 12);

                    else if(Connected_1 && Id_S1)  Send_Data (1 , 12);

                    for( j = 0 ; j < 16 ; j++)  Static_Ip[j] =' ';
}

                else
                 {
                    for( j = 0 ; j < 16 ; j++) Static_Ip[j] =' ';

ret = strstr(data , "STAIP");

                    s = ret - data;

                    s = s + 6;

                    Data_connected[0] ='@' , Data_connected[1] ='M' , Data_connected[2] ='_' , Data_connected[3] ='S' , Data_connected[4] ='=';

                    r =4;

                    for(j = 0 ; j < 16 ; j++)
                     {
                        s++ , r++;

                        if(data[s] == '"') break;

                        Static_Ip[j] = data[s];

                        Data_connected[r] = Static_Ip[j];
                     }

                         if(Connected_0 && !Id_S1) Send_Data (0 , 21);

                    else if(Connected_1 && Id_S1)  Send_Data (1 , 21);
                 }

                Data_Clean();

                Read_Ip =2;
             }
         }


        if(Part == 3)       //Fail IP
         {
             #asm("cli")

             sprintf(Data_connected , "@M_S=Error\n");

                  if(Connected_0 && !Id_S1) Send_Data (0 , 11);

             else if(Connected_1 && Id_S1)  Send_Data (1 , 11);
         }


        if(Part == 4)       //+IPD
         {
             delay_ms(60);

             #asm("cli")

         //---------------------------Config-------------------------------------


             if(strstr(data , "@M_IP"))   Part =5;

             if(strstr(data , "@M_F_C"))  Part =5;

             if(strstr(data , "@M_F_T"))  Part =5;


         //---------------------------POL-------------------------------------


             if(strstr(data , "@TA1U"))  Data_connected[4] ='U' , Send_Fead_Back (1);

             if(strstr(data , "&TA1U"))  Part =6;


             if(strstr(data , "@TH1U"))  Data_connected[4] ='U' , Send_Fead_Back (3);

             if(strstr(data , "&TH1U"))  Part =12;


         //---------------------------Scenario--------------------------------


             if(strstr(data , "!"))  Part =10;


         //---------------------------Alarm--------------------------------


             if(strstr(data , "&X1Z1"))  OUT_Alarm_Order;

             if(strstr(data , "@X1Z"))   OUT_Alarm_Feed;


         //---------------------------Chang Password & Wifi Router-----------------------------


             if(strstr(data , ":*AT")) Part =7;

             if(strstr(data , ":#AT")) Part =8;


         //---------------------------Definition Head Line-----------------------------


             if(strstr(data , "Line#")) Part =11;
         }


        if(Part == 5)       //Config
         {
            if(strstr(data , "@M_IP"))
             {
                 Data_Clean();

                 s =0;

                 Data_connected[s] = '%' , s++;

                 for( j = 0 ; j < 17 ; j++) Data_connected[s] = Mac_Ip[j] , s++;


Data_connected[s] = '+' , s++;


                 for( j = 0 ; j < 16 ; j++) Data_connected[s] = Static_Ip[j] , s++;


Data_connected[s] = '+' , s++;


                 for( j = 0 ; j < 20 ; j++) Data_connected[s] = Usere[j] , s++;


Data_connected[s] = '%' , s++;


                      if(Connected_0 && !Id_S1) Send_Data (0 , s);

                 else if(Connected_1 &&  Id_S1) Send_Data (1 , s);
             }


            if(strstr(data , "@M_F_C"))
             {
                 Data_Clean();

                 sprintf(Data_connected , "#T");


                      if(Connected_0 && !Id_S1) Send_Data (0 , 2);

                 else if(Connected_1 &&  Id_S1) Send_Data (1 , 2);
             }


            if(strstr(data , "@M_F_T"))
             {
                 for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';

s =0;
                 for( j = 0 ; j < POL_j ; j++) Data_connected[s] = POL_Eeprom_Variable[j] , s++;     //POL PAR


if(Connected_0 && !Id_S1) Send_Data (0 , s);

                 else if(Connected_1 &&  Id_S1) Send_Data (1 , s);
             }
         }


        if(Part == 6)       //POL 1
         {
                for(s = 0 ; s < 250 ; s++) { if(data[s] == 'U') break;}

                s++;
                StartBytedata = s;


                for(j = 0 ; j < KeysCount ; j++)
                 {
                    Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                    w[StartBytew] ^= (Bit << (7 - StartBitw));


                    x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;

                    StartBitdata++;
                    if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                    StartBitw++;
                    if(StartBitw == 8) StartBitw =0 , StartBytew++;
                 }



                if(x[1] == 1) { if(!Red_L1) OUT_L1 , DY =1; }

                else if (Red_L1) OUT_L1 , DY =1;


                if(x[0] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L2) OUT_L2 , DY =1;
                 }

                else if(Red_L2)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L2 , DY =1;
                 }


                if(x[3] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L3) OUT_L3 , DY =1;
                 }

                else if(Red_L3)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L3 , DY =1;
                 }


                if(x[2] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L4) OUT_L4 , DY =1;
                 }

                else if(Red_L4)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L4 , DY =1;
                 }


                if(x[5] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L5) OUT_L5 , DY =1;
                 }

                else if(Red_L5)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L5 , DY =1;
                 }


                if(x[4] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L6) OUT_L6 , DY =1;
                 }

                else if(Red_L6)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L6 , DY =1;
                 }


                if(x[7] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L7) OUT_L7 , DY =1;
                 }

                else if(Red_L7)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L7 , DY =1;
                 }


                if(x[6] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L8) OUT_L8 , DY =1;
                 }

                else if(Red_L8)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L8 , DY =1;
                 }


                if(x[9] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L9) OUT_L9 , DY =1;
                 }

                else if(Red_L9)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L9 , DY =1;
                 }


                if(x[8] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L10) OUT_L10;
                 }

                else if(Red_L10)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L10;
                 }


                if(x[11] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L11) OUT_L11;
                 }

                else if(Red_L11)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L11;
                 }


                if(x[10] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_L12) OUT_L12;
                 }

                else if(Red_L12)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_L12;
                 }


                if(x[12] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_Par_11) OUT_P1O;
                 }

                else if(Red_Par_11)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_P1O;
                 }


                if(x[13] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_Par_12) OUT_P1C;
                 }

                else if(Red_Par_12)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_P1C;
                 }



                if(x[14] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_Par_21) OUT_P2O;
                 }

                else if(Red_Par_21)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_P2O;
                 }


                if(x[15] == 1)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    if(!Red_Par_22) OUT_P2C;
                 }

                else if(Red_Par_22)
                 {
                    if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                    OUT_P2C;
                 }


                Data_connected[4] ='U';

                Send_Fead_Back (1);
         }


        if(Part == 7)       //Chang Password
         {
             delay_ms(200);

             #asm("cli")

             for(s = 0 ; s < 250 ; s++) if(data[s] == '*') break;

             for(j = 0 ; j < 80  ; j++) { s++ ; if(data[s] == '*') break ; str[j] = data[s]; }

             str[j] = '\r';

             puts(str);

             delay_ms(5000);

             Data_Clean();
         }


        if(Part == 8)       //Wifi Router
         {
             delay_ms(200);

             #asm("cli")

             for(s = 0 ; s < 250 ; s++) if(data[s] == '#') break;

             for(j = 0 ; j < 80  ; j++) { s++ ; if(data[s] == '#') break ; str[j] = data[s]; }

             str[j] = '\r';


             for(s = 0 ; s < 250 ; s++) if(data[s] == '#') break;

             s = s + 10;

             for( j = 0 ; j < 20 ; j++) Usere[j] ='\0';

for(j = 0 ; j < 20  ; j++) { s++ ; if(data[s] == '"') break ; Usere[j] = data[s]; }

             puts(str);

             delay_ms(300);

             Data_Clean();
         }


        if(Part == 9)       //Remove Password
         {
            #asm("cli")

            Led_Remove_Wifi_Pass;

            Data_Clean();

            sprintf(str,"AT+CWSAP=%cSUNTOUCH%c,%c%c,1,0%c" ,34,34,34,34,13);

            puts(str);

            delay_ms(1000);

            Led_Remove_Wifi_Pass;

            Data_Clean();
         }


        if(Part == 10)      //Scenario
         {

                if(strstr(data , "!&"))        //General
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == '&') break;}

                    s++;
                    StartBytedata = s;

                    StartBitdata = 0;

                    w[0] =0X00 , w[1] =0X00 , w[2] =0X00;

                    for(j = 0 ; j < Scenario_Count ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                        w[StartBytew] |= (Bit << (7 - StartBitw));


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;
                        if(j == 17 || j == 18)   w[StartBytew] ^= (Bit << (7 - StartBitw));

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }


                    w[2] =0X00;

                    StartBytedata = s + 1;
                    StartBitdata  = 6;

                    StartBytew = 2;
                    StartBitw  = 0;

                    for(j = 0 ; j < KeysCount_2 ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                        w[StartBytew] ^= (Bit << (7 - StartBitw));


                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }


                 //---------------------------POL 1----------------------------------


                    if(x[1] == 1) { if(!Red_L1) OUT_L1 , DY =1; }

                    else if (Red_L1) OUT_L1 , DY =1;


                    if(x[0] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L2) OUT_L2 , DY =1;
                     }

                    else if(Red_L2)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L2 , DY =1;
                     }


                    if(x[3] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L3) OUT_L3 , DY =1;
                     }

                    else if(Red_L3)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L3 , DY =1;
                     }


                    if(x[2] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L4) OUT_L4 , DY =1;
                     }

                    else if(Red_L4)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L4 , DY =1;
                     }


                    if(x[5] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L5) OUT_L5 , DY =1;
                     }

                    else if(Red_L5)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L5 , DY =1;
                     }


                    if(x[4] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L6) OUT_L6 , DY =1;
                     }

                    else if(Red_L6)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L6 , DY =1;
                     }


                    if(x[7] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L7) OUT_L7 , DY =1;
                     }

                    else if(Red_L7)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L7 , DY =1;
                     }


                    if(x[6] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L8) OUT_L8 , DY =1;
                     }

                    else if(Red_L8)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L8 , DY =1;
                     }


                    if(x[9] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L9) OUT_L9 , DY =1;
                     }

                    else if(Red_L9)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L9 , DY =1;
                     }


                    if(x[8] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L10) OUT_L10 , DY =1;
                     }

                    else if(Red_L10)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L10 , DY =1;
                     }


                    if(x[11] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L11) OUT_L11 , DY =1;
                     }

                    else if(Red_L11)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L11 , DY =1;
                     }


                    if(x[10] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L12) OUT_L12 , DY =1;
                     }

                    else if(Red_L12)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L12 , DY =1;
                     }


                    if(x[12] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_11) OUT_P1O;
                     }

                    else if(Red_Par_11)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P1O;
                     }


                    if(x[13] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_12) OUT_P1C;
                     }

                    else if(Red_Par_12)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P1C;
                     }



                    if(x[14] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_21) OUT_P2O;
                     }

                    else if(Red_Par_21)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P2O;
                     }


                    if(x[15] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_22) OUT_P2C;
                     }

                    else if(Red_Par_22)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P2C;
                     }


                 //---------------------------POL 2----------------------------------


                    if(x[16] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_K1) OUT_K1 , DY =1;
                     }

                    else if(Red_K1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_K1 , DY =1;
                     }


                    if(x[17] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_K2) OUT_K2 , delay_ms(2000) , OUT_K2 , DY =1;
                     }

                    //else if(Red_K2)
                     //{
                        //if(DY == 1) delay_ms(110) , DY =0;

                        //OUT_K2 , DY =1;
                     //}


                    if(x[18] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_K3) OUT_K3 , delay_ms(2000) , OUT_K3 , DY =1;
                     }

                    //else if(Red_K3)
                     //{
                        //if(DY == 1) delay_ms(110) , DY =0;

                        //OUT_K3 , DY =1;
                     //}


                    if(x[19] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_EL) OUT_EL , DY =1;
                     }

                    else if(Red_EL)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        OUT_EL , DY =1;
                     }


                    Data_Clean();
                 }


                if(strstr(data , "!^T"))       //Floor
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == 'T') break;}

                    s++;
                    StartBytedata = s;

                    StartBitdata = 0;

                    w[0] =0X00 , w[1] =0X00 , w[2] =0X00;

                    for(j = 0 ; j < Scenario_Count ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                        w[StartBytew] |= (Bit << (7 - StartBitw));


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;
                        if(j == 17 || j == 18)   w[StartBytew] ^= (Bit << (7 - StartBitw));

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }


                    w[2] =0X00;

                    StartBytedata = s + 1;
                    StartBitdata  = 6;

                    StartBytew = 2;
                    StartBitw  = 0;

                    for(j = 0 ; j < KeysCount_2 ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                        w[StartBytew] ^= (Bit << (7 - StartBitw));


                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }


                 //---------------------------POL 1----------------------------------


                    if(x[1] == 1) { if(!Red_L1) OUT_L1 , DY =1; }

                    else if (Red_L1) OUT_L1 , DY =1;


                    if(x[0] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L2) OUT_L2 , DY =1;
                     }

                    else if(Red_L2)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L2 , DY =1;
                     }


                    if(x[3] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L3) OUT_L3 , DY =1;
                     }

                    else if(Red_L3)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L3 , DY =1;
                     }


                    if(x[2] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L4) OUT_L4 , DY =1;
                     }

                    else if(Red_L4)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L4 , DY =1;
                     }


                    if(x[5] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L5) OUT_L5 , DY =1;
                     }

                    else if(Red_L5)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L5 , DY =1;
                     }


                    if(x[4] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L6) OUT_L6 , DY =1;
                     }

                    else if(Red_L6)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L6 , DY =1;
                     }


                    if(x[7] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L7) OUT_L7 , DY =1;
                     }

                    else if(Red_L7)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L7 , DY =1;
                     }


                    if(x[6] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L8) OUT_L8 , DY =1;
                     }

                    else if(Red_L8)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L8 , DY =1;
                     }


                    if(x[9] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L9) OUT_L9 , DY =1;
                     }

                    else if(Red_L9)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L9 , DY =1;
                     }


                    if(x[8] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L10) OUT_L10 , DY =1;
                     }

                    else if(Red_L10)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L10 , DY =1;
                     }


                    if(x[11] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L11) OUT_L11 , DY =1;
                     }

                    else if(Red_L11)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L11 , DY =1;
                     }


                    if(x[10] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L12) OUT_L12 , DY =1;
                     }

                    else if(Red_L12)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L12 , DY =1;
                     }


                    if(x[12] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_11) OUT_P1O;
                     }

                    else if(Red_Par_11)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P1O;
                     }


                    if(x[13] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_12) OUT_P1C;
                     }

                    else if(Red_Par_12)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P1C;
                     }



                    if(x[14] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_21) OUT_P2O;
                     }

                    else if(Red_Par_21)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P2O;
                     }


                    if(x[15] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_22) OUT_P2C;
                     }

                    else if(Red_Par_22)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P2C;
                     }


                 //---------------------------POL 2----------------------------------


                    if(x[16] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_K1) OUT_K1 , DY =1;
                     }

                    else if(Red_K1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_K1 , DY =1;
                     }


                    if(x[17] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_K2) OUT_K2 , delay_ms(2000) , OUT_K2 , DY =1;
                     }

                    //else if(Red_K2)
                     //{
                        //if(DY == 1) delay_ms(110) , DY =0;

                        //OUT_K2 , DY =1;
                     //}


                    if(x[18] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_K3) OUT_K3 , delay_ms(2000) , OUT_K3 , DY =1;
                     }

                    //else if(Red_K3)
                     //{
                        //if(DY == 1) delay_ms(110) , DY =0;

                        //OUT_K3 , DY =1;
                     //}


                    if(x[19] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_EL) OUT_EL , DY =1;
                     }

                    else if(Red_EL)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        OUT_EL , DY =1;
                     }


                    Data_Clean();
                 }


                if(strstr(data , "!~TA1"))     //Local 1
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == 'A') break;}

                    s = s + 2;
                    StartBytedata = s;

                    StartBitdata = 0;

                    w[0] =0X00 , w[1] =0X00;

                    for(j = 0 ; j < Scenario_Count_Local_1 ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                        w[StartBytew] |= (Bit << (7 - StartBitw));


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }



                    if(x[1] == 1) { if(!Red_L1) OUT_L1 , DY =1; }

                    else if (Red_L1) OUT_L1 , DY =1;


                    if(x[0] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L2) OUT_L2 , DY =1;
                     }

                    else if(Red_L2)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L2 , DY =1;
                     }


                    if(x[3] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L3) OUT_L3 , DY =1;
                     }

                    else if(Red_L3)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L3 , DY =1;
                     }


                    if(x[2] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L4) OUT_L4 , DY =1;
                     }

                    else if(Red_L4)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L4 , DY =1;
                     }


                    if(x[5] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L5) OUT_L5 , DY =1;
                     }

                    else if(Red_L5)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L5 , DY =1;
                     }


                    if(x[4] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L6) OUT_L6 , DY =1;
                     }

                    else if(Red_L6)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L6 , DY =1;
                     }


                    if(x[7] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L7) OUT_L7 , DY =1;
                     }

                    else if(Red_L7)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L7 , DY =1;
                     }


                    if(x[6] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L8) OUT_L8 , DY =1;
                     }

                    else if(Red_L8)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L8 , DY =1;
                     }


                    if(x[9] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L9) OUT_L9 , DY =1;
                     }

                    else if(Red_L9)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L9 , DY =1;
                     }


                    if(x[8] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L10) OUT_L10 , DY =1;
                     }

                    else if(Red_L10)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L10 , DY =1;
                     }


                    if(x[11] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L11) OUT_L11 , DY =1;
                     }

                    else if(Red_L11)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L11 , DY =1;
                     }


                    if(x[10] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_L12) OUT_L12 , DY =1;
                     }

                    else if(Red_L12)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        OUT_L12 , DY =1;
                     }


                    if(x[12] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_11) OUT_P1O;
                     }

                    else if(Red_Par_11)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P1O;
                     }


                    if(x[13] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_12) OUT_P1C;
                     }

                    else if(Red_Par_12)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P1C;
                     }



                    if(x[14] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_21) OUT_P2O;
                     }

                    else if(Red_Par_21)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P2O;
                     }


                    if(x[15] == 1)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        if(!Red_Par_22) OUT_P2C;
                     }

                    else if(Red_Par_22)
                     {
                        if(DY == 1) DY =0 , delay_ms(50) , DY =0;

                        OUT_P2C;
                     }

                    Data_Clean();
                 }


                if(strstr(data , "!~TH1"))     //Local 2
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == 'H') break;}

                    s = s + 2;
                    StartBytedata = s;

                    StartBytew = 2;

                    w[2] =0X00;

                    for(j = 0 ; j < Scenario_Count_Local_2 ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                        w[StartBytew] |= (Bit << (7 - StartBitw));


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;
                        if(j == 1 || j == 2)   w[StartBytew] ^= (Bit << (7 - StartBitw));

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }



                    if(x[0] == 1) { if(!Red_K1) OUT_K1 , DY =1; }

                    else if (Red_K1) OUT_K1 , DY =1;


                    if(x[1] == 1)
                     {
                        if(DY == 1) delay_ms(50) , DY =0;

                        if(!Red_K2) OUT_K2 , delay_ms(2000) , OUT_K2 , DY =1;
                     }

                    //else if(Red_K2)
                     //{
                        //if(DY == 1) delay_ms(50) , DY =0;

                        //OUT_K2 , DY =1;
                     //}


                    if(x[2] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_K3) OUT_K3 , delay_ms(2000) , OUT_K3 , DY =1;
                     }

                    //else if(Red_K3)
                     //{
                        //if(DY == 1) delay_ms(110) , DY =0;

                        //OUT_K3 , DY =1;
                     //}


                    if(x[3] == 1)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        if(!Red_EL) OUT_EL , DY =1;
                     }

                    else if(Red_EL)
                     {
                        if(DY == 1) delay_ms(110) , DY =0;

                        OUT_EL , DY =1;
                     }


                    Data_Clean();
                 }
         }


        if(Part == 11)      //Head Line
         {
             for(s = 0 ; s < 250 ; s++) if(data[s] == '#') break;

             for(j = 7 ; j < (KeysCount + 7)  ; j++) { s++ , POL_Eeprom_Variable[j] = data[s] , delay_ms(5); }


             sprintf(Data_connected , "ok\n");

             Send_Data (0 , 3);

             delay_ms(10);

             Data_Clean();
         }


        if(Part == 12)      //POL 2
         {
                for(s = 0 ; s < 250 ; s++) { if(data[s] == 'U') break;}

                s++;
                StartBytedata = s;

                StartBytew = 2;


                for(j = 0 ; j < KeysCount_2 ; j++)
                 {
                    Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;
                    w[StartBytew] ^= (Bit << (7 - StartBitw));


                    x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;
                    if(j == 1 || j == 2)   w[StartBytew] ^= (Bit << (7 - StartBitw));

                    StartBitdata++;
                    if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                    StartBitw++;
                    if(StartBitw == 8) StartBitw =0 , StartBytew++;
                 }



                if(x[0] == 1) { if(!Red_K1) OUT_K1 , DY =1; }

                else if (Red_K1) OUT_K1 , DY =1;


                if(x[1] == 1)
                 {
                    if(DY == 1) delay_ms(110) , DY =0;

                    if(!Red_K2) OUT_K2 , delay_ms(2000) , OUT_K2 , DY =1;
                 }

                //else if(Red_K2)
                 //{
                    //if(DY == 1) delay_ms(110) , DY =0;

                    //OUT_K2 , DY =1;
                 //}


                if(x[2] == 1)
                 {
                    if(DY == 1) delay_ms(110) , DY =0;

                    if(!Red_K3) OUT_K3 , delay_ms(2000) , OUT_K3 , DY =1;
                 }

                //else if(Red_K3)
                 //{
                    //if(DY == 1) delay_ms(110) , DY =0;

                    //OUT_K3 , DY =1;
                 //}


                if(x[3] == 1)
                 {
                    if(DY == 1) delay_ms(110) , DY =0;

                    if(!Red_EL) OUT_EL , DY =1;
                 }

                else if(Red_EL)
                 {
                    if(DY == 1) delay_ms(110) , DY =0;

                    OUT_EL , DY =1;
                 }



                Data_connected[4] ='U';

                Send_Fead_Back (3);
         }


        if(Part == 13 || Part == 14)      //Alarm ==> Active/RActive
          {
              sprintf(Data_connected , "@X1Z1of");

              if(Part == 14)  Data_connected[6] ='n';

              if(Id_S1)
                {
                    if(Connected_1) Send_Data (1 , 7);

                    if(Connected_0) delay_ms(1000) , Send_Data (0 , 7);

                    Id_S1 =0;
                }

                  else
                    {
                        if(Connected_0) Send_Data (0 , 7);

                        if(Connected_1) delay_ms(1000) , Send_Data (1 , 7);
                    }
          }


        #asm("sei")
     }


    void Send_Fead_Back  (char Fead_Back)
     {
        unsigned char Cunter;

        #asm("cli")

        Data_connected[0] ='@' , Data_connected[1] ='T' , Data_connected[2] ='A' , Data_connected[3] ='1';

        if(Fead_Back == 1)  Data_connected[5] = w[0]    , Data_connected[6] = w[1] , Cunter =7;


        if(Fead_Back == 3)  Data_connected[2] ='H'    , Data_connected[5] = w[2] , Cunter =6;


        if(Id_S1)
          {
               if(Connected_1) Send_Data (1 , Cunter);

               if(Connected_0) delay_ms(300) , Send_Data (0 , Cunter);

               Id_S1 =0;
          }

            else
              {
                   if(Connected_0) Send_Data (0 , Cunter);

                   if(Connected_1) delay_ms(300) , Send_Data (1 , Cunter);
              }


        #asm("sei")
     }


    void Send_Data  (char Id , unsigned char Cunter)
     {

        #asm("cli")

        Data_Clean();

        sprintf(str , "AT+CIPSEND=%d,%d%c" , Id , Cunter , 13);

        puts(str);

        delay_ms(100);

        Data_Clean();

        for(j = 0 ; j < Cunter ; j++) putchar (Data_connected [j]);

Data_Clean();

        #asm("sei")
     }


    void Data_Clean (void)
     {
        #asm("cli")

        i =0;

        for( j = 0 ; j < 250 ; j++) data[j] ='\0';

for( j = 0 ; j < 80 ; j++) str[j] ='\0';

#asm("sei")
     }
