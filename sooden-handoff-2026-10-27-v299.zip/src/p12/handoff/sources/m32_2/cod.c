#include <io.h>
#include <delay.h>


//---------------------------OLED----------------------------------


#include <stdio.h>
#include <i2c.h>
#include "ssd1306.c"


//---------------------------Touch----------------------------------


#define Touch      (PINA.0 ==0 || PINA.1 ==0 || PINA.2 ==0 || PINA.3 ==0 || PINA.4 ==0)

#define Touch_N1    PINA.0 ==1 && PINA.1 ==1 && PINA.2 ==1 && PINA.3 ==1 && PINA.4 ==0

#define Touch_L5    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==1 && PINA.3 ==1 && PINA.4 ==0
#define Touch_L6    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==1 && PINA.3 ==0 && PINA.4 ==1
#define Touch_L7    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==1 && PINA.3 ==0 && PINA.4 ==0
#define Touch_L8    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==0 && PINA.3 ==1 && PINA.4 ==1

#define Touch_Ss    PINA.0 ==0 && PINA.1 ==0 && PINA.2 ==0 && PINA.3 ==0 && PINA.4 ==1
#define Touch_Sd    PINA.0 ==0 && PINA.1 ==0 && PINA.2 ==0 && PINA.3 ==1 && PINA.4 ==0


//---------------------------Led----------------------------------


bit     N1 =0;


#define Led_N1        PORTC.0 =~ PORTC.0  , PORTC.1 =~ PORTC.1 , N1 =! N1
#define White_N1      PORTC.0
#define Red_N1        PORTC.1


#define Led_L5        PORTC.2 =~ PORTC.2  , PORTC.3 =~ PORTC.3 //, LCD_DrawImage(2)
#define White_L5      PORTC.2
#define Red_L5        PORTC.3

#define Led_L6        PORTB.4 =~ PORTB.4  , PORTB.3 =~ PORTB.3 //, LCD_DrawImage(0)
#define White_L6      PORTB.4
#define Red_L6        PORTB.3

#define Led_L7        PORTA.7 =~ PORTA.7  , PORTA.6 =~ PORTA.6 //, LCD_DrawImage(3)
#define White_L7      PORTA.7
#define Red_L7        PORTA.6

#define Led_L8        PORTB.2 =~ PORTB.2  , PORTB.1 =~ PORTB.1 //, LCD_DrawImage(1)
#define White_L8      PORTB.2
#define Red_L8        PORTB.1


//---------------------------Stand_by--------------------------------


  void Stand_by (char Typ);


//---------------------------Status----------------------------------


void Status(void);

#define Status_Time   Status_Countr >= 60000


//---------------------------Function  Main----------------------------------


void main(void)
 {

 //long unsigned int Status_Countr =0;

 bit L =1 , S_by =0;


 delay_ms(300);


    DDRA  = 0b11100000;
    PORTA = 0b10011111;

    DDRB  = 0b01111111;
    PORTB = 0b10010100;

    DDRC  = 0b11111111;
    PORTC = 0b00000101;

    DDRD  = 0b11111111;
    PORTD = 0b00000000;


    i2c_init();
    LCD_init();
    LCD_Contrast(255);
    LCD_Mode(0);

    delay_ms(300);

    LCD_DrawImage(5);

    Status();

    delay_ms(300);

 while(1)
  {
      //if(Status_Time) Status() , Status_Countr =0;


      if(Touch && L)
        {
            delay_ms(20);

            if(Touch_N1)  Led_N1;


            if(Touch_L5)  Led_L5 , Status(); //Status_Countr =1;

            if(Touch_L6)  Led_L6 , Status(); //Status_Countr =1;

            if(Touch_L7)  Led_L7 , Status(); //Status_Countr =1;

            if(Touch_L8)  Led_L8 , Status(); //Status_Countr =1;


            if(Touch_Ss)   { if(S_by) S_by =0 , Stand_by(1) ; else  S_by =1 , Stand_by(0) ; }

            if(Touch_Sd)     S_by =0 , Stand_by(2) ;


        //------------------------------------------------------------------

            L =0;
        }

      if(!Touch && !L)    L =1;


      //if(Status_Countr >= 1) Status_Countr ++;
  }

 }


//---------------------------Function  Stand_by------------------------------


    void Stand_by (char Typ)
     {
        if(Typ == 0)   // OFF
         {
             White_N1 =0  , Red_N1  =0;

             delay_ms(200);

             White_L5 =0  , Red_L5  =0;

             White_L6 =0  , Red_L6  =0;

             White_L7 =0  , Red_L7  =0;

             White_L8 =0  , Red_L8  =0;

             delay_ms(700);

             LCD_DrawImage(0);
         }

        if(Typ == 1)   // ON ==> Delay
         {
             LCD_DrawImage(5) , Status();

             if(N1)   Red_N1 =1 ;   else   White_N1 =1 ;

             delay_ms(200);

             White_L5 =1  , White_L6  =1;

             White_L7 =1  , White_L8  =1;
         }

        if(Typ == 2)   // ON ==> NO Delay
         {
             LCD_DrawImage(5) , Status();

             if(N1)   Red_N1 =1 ;   else   White_N1 =1 ;


             White_L5 =1  , White_L6  =1;

             White_L7 =1  , White_L8  =1;
         }
     }


//---------------------------Function  Oled----------------------------------


    void Status(void)
     {
        unsigned char buff[50];
        unsigned char v =0;


        //LCD_DrawImage(5);


        if(Red_L5 == 1)   LCD_Goto2X(36 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(36 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L6 == 1)   LCD_Goto2X(20 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(20 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L7 == 1)   LCD_Goto2X(36 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(36 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L8 == 1)   LCD_Goto2X(20 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(20 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
     }
