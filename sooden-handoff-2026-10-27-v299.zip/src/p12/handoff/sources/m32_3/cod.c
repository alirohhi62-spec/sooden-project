#include <io.h>
#include <delay.h>


//---------------------------OLED----------------------------------


#include <stdio.h>
#include <i2c.h>
#include "ssd1306.c"


//---------------------------Touch----------------------------------


#define Touch      (PIND.2 ==0 || PIND.3 ==0 || PIND.4 ==0 || PIND.7 ==0 || PINC.0 ==0)

#define Touch_S1    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==1 && PIND.7 ==1 && PINC.0 ==0
#define Touch_S2    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==1 && PIND.7 ==0 && PINC.0 ==1
#define Touch_S3    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==1 && PIND.7 ==0 && PINC.0 ==0
#define Touch_S4    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==0 && PIND.7 ==1 && PINC.0 ==1
#define Touch_S5    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==0 && PIND.7 ==1 && PINC.0 ==0
#define Touch_S6    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==0 && PIND.7 ==0 && PINC.0 ==1

#define Touch_K1    PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==0 && PIND.7 ==0 && PINC.0 ==0

#define Touch_L9    PIND.2 ==1 && PIND.3 ==0 && PIND.4 ==0 && PIND.7 ==1 && PINC.0 ==0
#define Touch_L10   PIND.2 ==1 && PIND.3 ==0 && PIND.4 ==0 && PIND.7 ==0 && PINC.0 ==1
#define Touch_L11   PIND.2 ==1 && PIND.3 ==0 && PIND.4 ==0 && PIND.7 ==0 && PINC.0 ==0
#define Touch_L12   PIND.2 ==0 && PIND.3 ==1 && PIND.4 ==1 && PIND.7 ==1 && PINC.0 ==1

#define Touch_EL    PIND.2 ==0 && PIND.3 ==0 && PIND.4 ==1 && PIND.7 ==1 && PINC.0 ==1

#define Touch_Ss    PIND.2 ==0 && PIND.3 ==0 && PIND.4 ==0 && PIND.7 ==0 && PINC.0 ==1
#define Touch_Sd    PIND.2 ==0 && PIND.3 ==0 && PIND.4 ==0 && PIND.7 ==1 && PINC.0 ==0


//---------------------------Led----------------------------------


bit     S1 =0 , S2 =0 , S3 =0 , S4 =0 , S5 =0 , S6 =0;


#define Led_S1        PORTC.6 =~ PORTC.6  , PORTC.5 =~ PORTC.5 , S1 =! S1
#define White_S1      PORTC.6
#define Red_S1        PORTC.5

#define Led_S2        PORTA.7 =~ PORTA.7  , PORTC.7 =~ PORTC.7 , S2 =! S2
#define White_S2      PORTA.7
#define Red_S2        PORTC.7

#define Led_S3        PORTA.5 =~ PORTA.5  , PORTA.6 =~ PORTA.6 , S3 =! S3
#define White_S3      PORTA.5
#define Red_S3        PORTA.6

#define Led_S4        PORTA.3 =~ PORTA.3  , PORTA.4 =~ PORTA.4 , S4 =! S4
#define White_S4      PORTA.3
#define Red_S4        PORTA.4

#define Led_S5        PORTA.1 =~ PORTA.1  , PORTA.2 =~ PORTA.2 , S5 =! S5
#define White_S5      PORTA.1
#define Red_S5        PORTA.2

#define Led_S6        PORTB.0 =~ PORTB.0  , PORTA.0 =~ PORTA.0 , S6 =! S6
#define White_S6      PORTB.0
#define Red_S6        PORTA.0


#define Led_K1        PORTB.2 =~ PORTB.2  , PORTB.1 =~ PORTB.1
#define White_K1      PORTB.2
#define Red_K1        PORTB.1


#define Led_L9        PORTC.1 =~ PORTC.1  , PORTC.2 =~ PORTC.2
#define White_L9      PORTC.1
#define Red_L9        PORTC.2

#define Led_L10       PORTD.1 =~ PORTD.1  , PORTD.0 =~ PORTD.0
#define White_L10     PORTD.1
#define Red_L10       PORTD.0

#define Led_L11       PORTC.4 =~ PORTC.4  , PORTC.3 =~ PORTC.3
#define White_L11     PORTC.4
#define Red_L11       PORTC.3

#define Led_L12       PORTB.4 =~ PORTB.4  , PORTB.3 =~ PORTB.3
#define White_L12     PORTB.4
#define Red_L12       PORTB.3


#define ELEVATOR      PORTB.5 =~ PORTB.5  // , delay_ms(1000) , PORTB.5 =~ PORTB.5


//---------------------------Stand_by--------------------------------


  void Stand_by (char Typ);


//---------------------------Status----------------------------------


void Status(void);

#define Status_Time   Status_Countr >= 60000


//---------------------------Function  Main----------------------------------


void main(void)
 {

 //long unsigned int Status_Countr =0;

 bit L =1 , S_by =0;


 delay_ms(300);


    DDRA  = 0b11111111;
    PORTA = 0b10101010;

    DDRB  = 0b00111111;
    PORTB = 0b10010101;

    DDRC  = 0b11111110;
    PORTC = 0b01010011;

    DDRD  = 0b01100011;
    PORTD = 0b10011110;

    i2c_init();
    LCD_init();
    LCD_Contrast(255);
    LCD_Mode(0);

    delay_ms(300);

    LCD_DrawImage(5);

    Status();

    delay_ms(300);

 while(1)
  {
      //if(Status_Time) Status() , Status_Countr =0;


      if(Touch && L)
        {
            delay_ms(20);

            if(Touch_S1)  Led_S1;

            if(Touch_S2)  Led_S2;

            if(Touch_S3)  Led_S3;

            if(Touch_S4)  Led_S4;

            if(Touch_S5)  Led_S5;

            if(Touch_S6)  Led_S6;


            if(Touch_K1)  Led_K1;


            if(Touch_L9)  Led_L9 , Status();

            if(Touch_L10) Led_L10 , Status();

            if(Touch_L11) Led_L11 , Status();

            if(Touch_L12) Led_L12 , Status();


            if(Touch_EL)  ELEVATOR;


            if(Touch_Ss)   { if(S_by) S_by =0 , Stand_by(1) ; else  S_by =1 , Stand_by(0) ; }

            if(Touch_Sd)     S_by =0 , Stand_by(2) ;


        //------------------------------------------------------------------

            L =0;
        }

      if(!Touch && !L)    L =1;


      //if(Status_Countr >= 1) Status_Countr ++;
  }

 }


//---------------------------Function  Stand_by------------------------------


    void Stand_by (char Typ)
     {
        if(Typ == 0)   // OFF
         {
             delay_ms(300);

             White_L9  =0 ; Red_L9  =0;

             White_L10 =0 ; Red_L10 =0;

             White_L11 =0 ; Red_L11 =0;

             White_L12 =0 ; Red_L12 =0;

             delay_ms(100);

             White_S1 =0 ; Red_S1 =0;

             White_S2 =0 ; Red_S2 =0;

             White_S3 =0 ; Red_S3 =0;

             White_S4 =0 ; Red_S4 =0;

             White_S5 =0 ; Red_S5 =0;

             White_S6 =0 ; Red_S6 =0;

             delay_ms(100);

             White_K1 =0;

             delay_ms(400);

             LCD_DrawImage(0);
         }

        if(Typ == 1)   // ON ==> Delay
         {
             LCD_DrawImage(5) , Status();

             delay_ms(300);

             White_L9  =1 ; White_L10 =1;

             White_L11 =1 ; White_L12 =1;

             delay_ms(100);

             if(S1)   Red_S1 =1 ;   else   White_S1 =1 ;

             if(S2)   Red_S2 =1 ;   else   White_S2 =1 ;

             if(S3)   Red_S3 =1 ;   else   White_S3 =1 ;

             if(S4)   Red_S4 =1 ;   else   White_S4 =1 ;

             if(S5)   Red_S5 =1 ;   else   White_S5 =1 ;

             if(S6)   Red_S6 =1 ;   else   White_S6 =1 ;

             delay_ms(100);

             if(!Red_K1)   White_K1 =1;
         }

        if(Typ == 2)   // ON ==> NO Delay
         {
             LCD_DrawImage(5) , Status();

             White_L9  =1 ; White_L10 =1;

             White_L11 =1 ; White_L12 =1;


             if(S1)   Red_S1 =1 ;   else   White_S1 =1 ;

             if(S2)   Red_S2 =1 ;   else   White_S2 =1 ;

             if(S3)   Red_S3 =1 ;   else   White_S3 =1 ;

             if(S4)   Red_S4 =1 ;   else   White_S4 =1 ;

             if(S5)   Red_S5 =1 ;   else   White_S5 =1 ;

             if(S6)   Red_S6 =1 ;   else   White_S6 =1 ;


             if(!Red_K1)   White_K1 =1;
         }
     }


//---------------------------Function  Oled----------------------------------


    void Status(void)
     {
        unsigned char buff[50];
        unsigned char v =0;


        //LCD_DrawImage(5);


        if(Red_L9 == 1)   LCD_Goto2X(36 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(36 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L10 == 1)  LCD_Goto2X(20 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(20 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L11 == 1)  LCD_Goto2X(36 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(36 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);


        if(Red_L12 == 1)  LCD_Goto2X(20 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);

          else            LCD_Goto2X(20 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
     }
