const { chromium } = require('playwright');
const words = [['W_PARDE1','پرده ۱',24],['W_PARDE2','پرده ۲',24],['W_BAZ','باز',26],['W_BASTE','بسته',26],['W_EST','توقف',26],['W_LOGO','suden home',18]];
(async()=>{const b=await chromium.launch();const p=await b.newPage();
 const out=await p.evaluate((words)=>{return words.map(([n,t,sz])=>{const c=document.createElement('canvas');c.width=128;c.height=32;const x=c.getContext('2d');
  x.fillStyle='#000';x.fillRect(0,0,128,32);x.fillStyle='#fff';x.font='bold '+sz+'px "DejaVu Sans"';x.textBaseline='middle';x.textAlign='center';x.direction=/[a-z]/.test(t)?'ltr':'rtl';x.fillText(t,64,17);
  const d=x.getImageData(0,0,128,32).data;let x0=128,x1=-1,y0=32,y1=-1;const on=(i,j)=>d[(j*128+i)*4]>120;
  for(let j=0;j<32;j++)for(let i=0;i<128;i++)if(on(i,j)){x0=Math.min(x0,i);x1=Math.max(x1,i);y0=Math.min(y0,j);y1=Math.max(y1,j);}
  const w=x1-x0+1,h=y1-y0+1,pages=Math.ceil(h/8),bytes=[];
  for(let pg=0;pg<pages;pg++)for(let i=0;i<w;i++){let v=0;for(let k=0;k<8;k++){const j=y0+pg*8+k;if(j<=y1&&on(x0+i,j))v|=1<<k;}bytes.push(v);}
  return {n,w,h,pages,bytes};});},words);
 let s='/* Persian words for the OLEDs (bold DejaVu Sans, made by genbmp.js): width, pages (8 rows each), columns page by page */\n';
 for(const o of out){s+=`static const uint8_t ${o.n}[] PROGMEM = { ${o.w}, ${o.pages},\n  ${o.bytes.map(v=>'0x'+v.toString(16).padStart(2,'0')).join(',')} };\n`; console.log(o.n,o.w,o.h);}
 require('fs').writeFileSync('words.h',s);await b.close();})();
