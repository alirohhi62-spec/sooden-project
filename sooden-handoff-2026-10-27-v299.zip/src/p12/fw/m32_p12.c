/* Sooden 12-pole SIM panel - M1 / M2 / M3 (ATmega32A, 8 MHz crystal): build with -DBOARD=1, 2 or 3
   - every key output (white LED + red LED / relay) follows bus A (bus.h)
   - OLED: the state of the board's 4 poles (lamp drawing, number, ON/OFF), idle picture,
     curtain view (OLED 1: which curtain, OLED 2: opening / closing / stopped, OLED 3: the curtain moving)
   - power-up motion "scanner" when M4 says so (target 0 value 3) */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include "bus.h"
#define OLED_SH1106 1                    /* OLED 1..3 are 1.3" (SH1106, 132 columns) */
#include "gfx.h"
#include "words2.h"
#if BOARD == 1
#include "rooms.h"                       /* the 7-segment room names (the programmer rewrites them at 0x7000) */
#endif

typedef struct { uint8_t tg, wp, wb, rp, rb; int16_t mOn, mOff, mBack; } Item;   /* motion: ms of the white */
#define NO 0xFF
enum { A, B, C, D };
#define KEEP 0x80        /* outputs not driven by bus values (indicators B C, keypad light): white once the power-up motion ends */
#if BOARD == 1
static const Item IT[] = {
    { 1, A,5, A,4,   50, 150, 1325}, { 2, D,1, D,0,  200, 325, 1150}, { 3, A,3, A,2,   50, 150, 1325}, { 4, B,4, B,3,  200, 325, 1150},
    {16, D,7, D,4,  600, 700,  775}, {15, C,0, C,1,  525, 625,  850}, {18, D,3, D,2,  600, 700,  775}, {17, C,2, C,3,  525, 625,  850},   /* left key = open (rule) */
    {26|KEEP, A,7, A,6, 100, 200, -1}, {27, C,6, C,7, 150, 275, -1}, {28, C,4, C,5, 225, 325, -1},   /* B: white at the end of the motion; C: Wi-Fi (a phone app connected) and D: the SIM state, from M4 */
    {29|KEEP, B,5, NO,0, -1, -1, -1} };
#define INIT() do { DDRA = 0xFC; PORTA = 0xAB; DDRB = 0x38; PORTB = 0xB7; DDRC = 0xFF; PORTC = 0x55; DDRD = 0xFF; PORTD = 0x8A; } while (0)
#define BUSRD() ((uint8_t)(((PINA >> 1) & 1) << 4 | (PINA & 1) << 3 | (PINB & 1) << 2 | ((PINB >> 1) & 1) << 1 | ((PINB >> 2) & 1)))
#elif BOARD == 2
static const Item IT[] = {
    { 5, C,2, C,3,   50, 150, 1325}, { 6, B,4, B,3,  200, 325, 1150}, { 7, A,7, A,6,   50, 150, 1325}, { 8, B,2, B,1,  200, 325, 1150},
    {25, C,0, C,1,   50, 150, 1325} };
#define INIT() do { DDRA = 0xE0; PORTA = 0x9F; DDRB = 0x7F; PORTB = 0x94; DDRC = 0xFF; PORTC = 0x05; DDRD = 0xFF; PORTD = 0x00; } while (0)
#define BUSRD() ((uint8_t)((PINA & 1) << 4 | ((PINA >> 1) & 1) << 3 | ((PINA >> 2) & 1) << 2 | ((PINA >> 3) & 1) << 1 | ((PINA >> 4) & 1)))
#elif BOARD == 3
static const Item IT[] = {
    { 9, C,1, C,2,   50, 150, 1325}, {10, D,1, D,0,  200, 325, 1150}, {11, C,4, C,3,   50, 150, 1325}, {12, B,4, B,3,  200, 325, 1150},
    {19, C,6, C,5,   25, 125, 1350}, {20, A,7, C,7,   75, 175, 1300}, {21, A,5, A,6,  125, 250, 1225}, {22, A,3, A,4,  200, 300, 1175},
    {23, A,1, A,2,  250, 350, 1125}, {24, B,0, A,0,  300, 400, 1075}, {13, B,2, B,1,  575, 700,  775}, {14, NO,0, B,5, -1, -1, -1} };
#define INIT() do { DDRA = 0xFF; PORTA = 0xAA; DDRB = 0x3F; PORTB = 0x95; DDRC = 0xFE; PORTC = 0x53; DDRD = 0x63; PORTD = 0x9E; } while (0)
#define BUSRD() ((uint8_t)(((PIND >> 2) & 1) << 4 | ((PIND >> 3) & 1) << 3 | ((PIND >> 4) & 1) << 2 | ((PIND >> 7) & 1) << 1 | (PINC & 1)))
#else
#error "build with -DBOARD=1, 2 or 3"
#endif
#define NIT (sizeof IT / sizeof IT[0])
#define FIRST ((BOARD - 1) * 4 + 1)        /* the 4 poles on this OLED: FIRST .. FIRST+3 */

static volatile uint8_t *const PORT[4] = { &PORTA, &PORTB, &PORTC, &PORTD };
static void pin(uint8_t p, uint8_t b, uint8_t v) { if (p == NO) return; uint8_t s = SREG; cli(); if (v) *PORT[p] |= _BV(b); else *PORT[p] &= (uint8_t)~_BV(b); SREG = s; }   /* atomic: the 1 ms interrupt sets pole outputs too */
static void fast_out(uint8_t tg, uint8_t v);

/* ---------------- bus A receiver (1 ms timer interrupt) ---------------- */
static volatile uint16_t ms;
static uint8_t bLast = BUS_IDLE, bCnt, bIdle = 20, bN, bSym[5];
#define RQ 16
static volatile uint8_t rqT[RQ], rqH, rqN;             /* target, or 0x80 | register */
static volatile uint16_t rqV[RQ];
ISR(TIMER0_COMP_vect)
{
    ms++;
    uint8_t c = BUSRD();
    if (c == bLast) { if (bCnt < 255) bCnt++; } else { bLast = c; bCnt = 1; }
    if (c == BUS_IDLE) {
        if (bCnt >= 3 && bIdle < 255) bIdle = bCnt;
        if (bCnt > 12) bN = 0;                                  /* a long pause: a half frame is dropped */
        return;
    }
    if (bCnt == 3 && bIdle >= 3) {                              /* a new symbol, steady 3 ms after an idle */
        bIdle = 0;
        bSym[bN++] = c;
        uint8_t need = (bN >= 2 && bSym[0] == TG_SYS && bSym[1] >= R_FIRST) ? 5 : 3;   /* data frame: 5 symbols */
        if (bN == need) {
            bN = 0;
            if (rqN >= RQ) return;
            uint8_t i = (uint8_t)((rqH + rqN) % RQ);
            if (need == 3 && (uint8_t)((bSym[0] + bSym[1]) % 31) == bSym[2]) { rqT[i] = bSym[0]; rqV[i] = bSym[1]; rqN++; fast_out(bSym[0], bSym[1]); }
            else if (need == 5 && (uint8_t)((bSym[1] + bSym[2] + bSym[3]) % 31) == bSym[4]) { rqT[i] = (uint8_t)(0x80 | bSym[1]); rqV[i] = (uint16_t)(bSym[2] * 31 + bSym[3]); rqN++; }
        }
    }
}
static uint16_t now(void) { uint16_t v; cli(); v = ms; sei(); return v; }

/* ---------------- outputs ---------------- */
static uint8_t val[NIT];
static uint8_t stby, kSave[NIT];                                    /* standby; KEEP outputs as they were before it */
static volatile uint8_t *const PIN_[4] = { &PORTA, &PORTB, &PORTC, &PORTD };
static uint8_t rdp(uint8_t p, uint8_t b) { return p == NO ? 0 : (uint8_t)((*PIN_[p] >> b) & 1); }
static void pin(uint8_t p, uint8_t b, uint8_t v);
static void keep_dark(uint8_t on)                                  /* indicators B C D, keypad light: dark in standby, back after */
{
    for (uint8_t i = 0; i < NIT; i++) {
        const Item *it = &IT[i];
        if (!(it->tg & KEEP)) continue;
        if (on) { kSave[i] = (uint8_t)(rdp(it->wp, it->wb) | rdp(it->rp, it->rb) << 1); pin(it->wp, it->wb, 0); pin(it->rp, it->rb, 0); }
        else { pin(it->wp, it->wb, kSave[i] & 1); pin(it->rp, it->rb, kSave[i] >> 1); }
    }
}
static uint8_t motion;                 /* 1 while the power-up motion runs */
static uint8_t kPend; static uint16_t kAt;   /* shared whites to light once the motion ends */
static uint16_t mAt, aBlinkAt;
static uint8_t aBlink;
static void outputs(void)
{
    uint16_t t = (uint16_t)(now() - mAt);
    for (uint8_t i = 0; i < NIT; i++) {
        const Item *it = &IT[i];
        if (motion) {
            uint8_t w = (it->mOn >= 0 && t >= (uint16_t)it->mOn && t < (uint16_t)it->mOff) || (it->mBack >= 0 && t >= (uint16_t)it->mBack);
            pin(it->wp, it->wb, w);
            if (!(it->tg & KEEP)) pin(it->rp, it->rb, 0);
            continue;
        }
        if (it->tg & KEEP) continue;                               /* standby: handled in keep_dark() */
        uint8_t v = val[i];
        if (stby) v = V_DARK;                                      /* standby: A dark too (the keys are dark already) */
        if (it->tg == TG_A && aBlink) {                            /* A: 3 red blinks, then as before */
            uint8_t ph = (uint8_t)((uint16_t)(now() - aBlinkAt) / 170);
            if (ph >= 6) aBlink = 0; else { pin(it->wp, it->wb, 0); pin(it->rp, it->rb, !(ph & 1)); continue; }
        }
        if (v == V_BLINK) { pin(it->wp, it->wb, 0); pin(it->rp, it->rb, ((uint16_t)now() / 1000) & 1 ? 0 : 1); continue; }   /* 1 s red, 1 s dark */
        cli();
        if (!rqN) { pin(it->wp, it->wb, v == V_OFF); pin(it->rp, it->rb, v == V_ON); }   /* a frame just came (fast_out set it): val[] is old until the queue is read */
        sei();
    }
}
static int8_t find(uint8_t tg);
/* a pole / key frame: its relay and LED change here at once (the main loop may be busy drawing the OLED), so the master steps keep an even rhythm */
static void fast_out(uint8_t tg, uint8_t v)
{
    if (tg == TG_SYS || tg == TG_DISP || tg == TG_A || motion || stby || v > V_DARK) return;
    int8_t i = find(tg);
    if (i < 0 || (IT[i].tg & KEEP)) return;
    pin(IT[i].wp, IT[i].wb, v == V_OFF); pin(IT[i].rp, IT[i].rb, v == V_ON);
}
static int8_t find(uint8_t tg) { for (uint8_t i = 0; i < NIT; i++) if ((IT[i].tg & 0x7F) == tg) return (int8_t)i; return -1; }

/* ---------------- OLED ---------------- */
static uint8_t disp = 0xFF, shown[4], anim[4], dispNew = 1;
static uint16_t lastDraw, dispAt;
static uint8_t poleOn(uint8_t k) { int8_t i = find((uint8_t)(FIRST + k)); return i >= 0 && val[i] == V_ON; }
/* key state screen, design "A": lamp fills from the middle and shines, number, ON / OFF.
   odd poles on the right (as on the glass), even ones on the left */
static void draw_states(void)
{
    clr();
    vline(63, 2, 61); hline(2, 125, 31);
    for (uint8_t k = 0; k < 4; k++) {
        int16_t x = (k & 1) ? 0 : 64, y = (k & 2) ? 32 : 0;
        uint8_t on = shown[k], a = anim[k];                       /* a = 0..4 steps of the change, 4 = done */
        uint8_t fillR = on ? (uint8_t)(a * 7 / 4) : (uint8_t)((4 - a) * 7 / 4);
        int16_t cx = x + 13, cy = y + 15;
        circle(cx, cy, 8, 0);
        if (fillR) circle(cx, cy, (int8_t)fillR, 1);
        rect(cx - 3, cy + 9, 7, 3);
        if (on && a >= 3) {                                       /* rays */
            static const int8_t R[8][2] = { {0,-1},{1,-1},{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1} };
            for (uint8_t r = 0; r < 8; r++) if (R[r][1] < 1) line(cx + R[r][0] * 10, cy + R[r][1] * 10, cx + R[r][0] * 12, cy + R[r][1] * 12);
        }
        char n[3]; uint8_t num = (uint8_t)(FIRST + k);
        if (num >= 10) { n[0] = (char)('0' + num / 10); n[1] = (char)('0' + num % 10); n[2] = 0; } else { n[0] = (char)('0' + num); n[1] = 0; }
        str(x + 28, y + 6, n, 2);
        str(x + 28, y + 23, (on ? a >= 2 : a < 2) ? "ON" : "OFF", 1);
    }
}
static uint16_t reg[R_N];
#define REG(r) reg[(r) - R_FIRST]
static const uint8_t *gp(const uint8_t *const *t, uint8_t i) { return (const uint8_t *)pgm_read_word(&t[i]); }
static uint8_t gw(const uint8_t *g) { return pgm_read_byte(&g[0]); }
__attribute__((unused)) static void word_inv(const uint8_t *w, int16_t x, int16_t y)    /* a word cleared out of a lit box */
{
    uint8_t wd = pgm_read_byte(&w[0]), pg = pgm_read_byte(&w[1]);
    rect(x - 4, y - 3, wd + 8, pg * 8 + 4);
    for (uint8_t p = 0; p < pg; p++) for (uint8_t i = 0; i < wd; i++) {
        uint8_t v = pgm_read_byte(&w[2 + p * wd + i]);
        for (uint8_t k = 0; k < 8; k++) if (v & (1 << k)) { int16_t xx = x + i, yy = y + p * 8 + k; if (xx >= 0 && xx < 128 && yy >= 0 && yy < 64) fb[yy >> 3][xx] &= (uint8_t)~(1 << (yy & 7)); }
    }
}
/* a row of glyphs (index list), left to right, 2 px apart */
__attribute__((unused)) static uint8_t gl_w(const uint8_t *const *t, const uint8_t *ix, uint8_t n) { uint8_t w = 0; for (uint8_t i = 0; i < n; i++) w = (uint8_t)(w + gw(gp(t, ix[i])) + (i ? 3 : 0)); return w; }
__attribute__((unused)) static void gl_row(const uint8_t *const *t, const uint8_t *ix, uint8_t n, int16_t x, int16_t y) { for (uint8_t i = 0; i < n; i++) { const uint8_t *g = gp(t, ix[i]); word(g, x, y); x += gw(g) + 3; } }
__attribute__((unused)) static uint8_t num_ix(uint8_t *ix, uint16_t v, uint8_t digits) { uint8_t n = 0; char b[5]; do { b[n++] = (char)(v % 10); v /= 10; } while (v || n < digits); for (uint8_t i = 0; i < n; i++) ix[i] = (uint8_t)b[n - 1 - i]; return n; }

/* idle / standby: OLED 1 weekday, OLED 2 Jalali date, OLED 3 HH:MM (colon blinks); a few points away every minute: no burn-in */
static void draw_clock(uint16_t t)
{
    clr();
    uint8_t m = (uint8_t)REG(R_MIN);
    int16_t dx = (int16_t)(m % 7) * 2 - 6, dy = (int16_t)(m % 5) - 2;
    uint8_t ix[12], n = 0;
#if BOARD == 1
    uint8_t wd = (uint8_t)REG(R_WDAY); if (wd > 6) wd = 0;
    const uint8_t *g = gp(W_DAY, wd);
    word(g, 64 - gw(g) / 2 + dx, 32 - pgm_read_byte(&g[1]) * 4 + dy); (void)n; (void)ix; (void)t;
#elif BOARD == 2
    n = num_ix(ix, (uint16_t)(1300 + REG(R_YEAR)), 4); ix[n++] = 10;
    n = (uint8_t)(n + num_ix(ix + n, REG(R_MON), 2)); ix[n++] = 10;
    n = (uint8_t)(n + num_ix(ix + n, REG(R_DAY), 2));
    gl_row(G_FA, ix, n, 64 - gl_w(G_FA, ix, n) / 2 + dx, 22 + dy); (void)t;
#else
    n = num_ix(ix, REG(R_HOUR), 2); ix[n++] = 10;
    n = (uint8_t)(n + num_ix(ix + n, REG(R_MIN), 2));
    int16_t x = 64 - gl_w(G_CK, ix, n) / 2 + dx * 2 / 3, y = 17 + dy;        /* stays inside the screen while it drifts */
    if (x < 2) x = 2;
    for (uint8_t i = 0; i < n; i++) { const uint8_t *g = gp(G_CK, ix[i]); if (i != 2 || (t / 500) % 2 == 0) word(g, x, y); x += gw(g) + 3; }
#endif
}
/* curtain view: OLED 1 curtain 1, OLED 2 curtain 2: name on top, below what it does ("opening" / "closing" / "stopped")
   with running arrows (two bars when stopped); OLED 3: the curtain in view in front of a window, open by its real % */
__attribute__((unused)) static void crect(int16_t x, int16_t y, int16_t w, int16_t h)    /* clear a rectangle */
{
    for (int16_t j = y; j < y + h; j++) for (int16_t i = x; i < x + w; i++) if (i >= 0 && i < 128 && j >= 0 && j < 64) fb[j >> 3][i] &= (uint8_t)~(1 << (j & 7));
}
static void draw_curtain(uint8_t d, uint16_t t)
{
    clr();
    uint8_t mv = (uint8_t)REG(R_MOV); (void)mv;
#if BOARD == 1 || BOARD == 2
    uint8_t c = BOARD - 1, dir = ((mv >> (2 * c)) & 1) ? 1 : ((mv >> (2 * c + 1)) & 1) ? 2 : 0;
    const uint8_t *nm = c ? W_N2 : W_N1;
    word(nm, 64 - gw(nm) / 2, 5);
    hline(14, 113, 27);
    const uint8_t *st = dir == 1 ? W_OPENING : dir == 2 ? W_CLOSING : W_STOPS;
    int16_t sx = dir ? 127 - gw(st) : 72 - gw(st) / 2;
    word(st, sx, 39);
    if (dir) {                                                    /* three arrows, one gap running along */
        uint8_t ph = (uint8_t)((t / 120) % 3);
        for (uint8_t a = 0; a < 3; a++) {
            if (a == ph) continue;
            int16_t x0 = 1 + (dir == 1 ? a : 2 - a) * 4;
            if (dir == 1) { line(x0, 42, x0 + 3, 46); line(x0 + 3, 46, x0, 50); }
            else { line(x0 + 3, 42, x0, 46); line(x0, 46, x0 + 3, 50); }
        }
    } else { rect(5, 42, 2, 9); rect(10, 42, 2, 9); }
    (void)d;
#else
    uint8_t c = (uint8_t)((d - D_CUR) / 2);
    uint16_t p = REG(c ? R_POS2 : R_POS1); if (p > 100) p = 100;
    const int16_t L = 10, R = 118, top = 6, bot = 60;
    hline(L, R, top); hline(L, R, bot); vline(L, top, bot); vline(R, top, bot);     /* window */
    vline((L + R) / 2, top, bot); hline(L, R, (top + bot) / 2);
    circle(92, 22, 6, 1);                                         /* sun */
    for (uint8_t a = 0; a < 8; a++) { static const int8_t RX[8] = { 9, 6, 0, -6, -9, -6, 0, 6 }, RY[8] = { 0, 6, 9, 6, 0, -6, -9, -6 }; px(92 + RX[a], 22 + RY[a]); }
    int16_t half = (R - L) / 2, w = (int16_t)(half * (100 - p) / 100);
    if (w > 0) {
        crect(L, top, w, bot - top + 1); crect(R - w + 1, top, w, bot - top + 1);
        for (uint8_t f = 0; f < 6; f++) { vline(L + w * f / 6, top, bot); vline(R - w * f / 6, top, bot); }
        vline(L + w, top, bot); vline(R - w, top, bot);
    }
    (void)t;
#endif
}

int main(void)
{
    INIT();
    for (uint8_t i = 0; i < NIT; i++) { pin(IT[i].wp, IT[i].wb, 0); if (!(IT[i].tg & KEEP)) pin(IT[i].rp, IT[i].rb, 0); val[i] = V_OFF; }
    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS01) | _BV(CS00);       /* 1 ms */
    TIMSK |= _BV(OCIE0);
    wdt_enable(WDTO_1S);
    sei();
    ol_init();
    uint8_t started = 0, gsm = (PINB >> 7) & 1;
    uint16_t boot = now();
    (void)gsm;
    for (;;) {
        wdt_reset();
        while (rqN) {
            uint8_t tg; uint16_t v;
            cli(); tg = rqT[rqH]; v = rqV[rqH]; rqH = (uint8_t)((rqH + 1) % RQ); rqN--; sei();
            if (tg & 0x80) { uint8_t r = tg & 0x7F; if (r >= R_FIRST && r <= R_LAST && reg[r - R_FIRST] != v) { reg[r - R_FIRST] = v; dispNew = 1; } }
            else if (tg == TG_SYS && v == SYS_MOTION) {
                motion = 1; started = 1; mAt = now();
                for (uint8_t i = 0; i < NIT; i++) if (val[i] == V_DARK) val[i] = V_OFF;   /* standby ends: every white comes back */
            }
            else if (tg == TG_DISP) {
                if (v != disp) {
                    uint8_t s2 = v == D_STANDBY;
                    if (s2 != stby) { stby = s2; if (s2) { if (!motion) keep_dark(1); } else { kPend = 1; kAt = now(); } }   /* out of standby: the shared whites wait for the wake motion to end */
                    disp = (uint8_t)v; dispNew = 1; dispAt = now();
                }
            }
            else {
                int8_t i = find(tg);
                if (i >= 0 && !(IT[i].tg & KEEP)) {
                    if (tg == TG_A && v == A_BLINK) { aBlink = 1; aBlinkAt = now(); }
                    else if (v <= V_DARK || v == V_BLINK) val[i] = (uint8_t)v;
                }
            }
        }
        if (!started && (uint16_t)(now() - boot) > 3000) started = 1;   /* no word from M4: plain start */
        if (motion && (uint16_t)(now() - mAt) >= 1400) {
            motion = 0; kPend = 1; kAt = (uint16_t)(now() - 2000);   /* the motion is over: every shared white (B C, keypad light) on together */
        }
        if (kPend && !motion && !stby && (uint16_t)(now() - kAt) >= 1600) {   /* (1.6 s fallback when no motion comes after standby) */
            kPend = 0;
            for (uint8_t i = 0; i < NIT; i++) if (IT[i].tg & KEEP) pin(IT[i].wp, IT[i].wb, 1);
        }
        if (started) outputs();
#if BOARD == 1
        { uint8_t g = (PINB >> 7) & 1; if (gsm && !g) { cli(); PORTC ^= _BV(4) | _BV(5); sei(); } gsm = g; }   /* GSM line: as the current firmware */
#endif
        /* OLED, at most every 70 ms */
        uint16_t t = now();
        if (!started || motion || (uint16_t)(t - lastDraw) < 70) continue;
        lastDraw = t;
        uint8_t d = disp == 0xFF ? 0 : disp;
#if BOARD == 1
        if (d == D_ROOM) {                                         /* 7-segment room: its name, then on / off / no answer */
            clr();
            uint8_t r = (uint8_t)REG(R_ROOM), res = (uint8_t)REG(R_RRES);
            if (r >= 1 && r <= 9 && pgm_read_byte(&ROOMNAME[r - 1][0]) <= 128 && pgm_read_byte(&ROOMNAME[r - 1][1]) <= 3) word(ROOMNAME[r - 1], 64 - gw(ROOMNAME[r - 1]) / 2, 6);
            const uint8_t *w = res == 1 ? W_RON : res == 0 ? W_ROFF : W_RNA;
            word(w, 64 - gw(w) / 2, 38);
            fb_push(); dispNew = 1; continue;
        }
        if (d == D_EXIT) {                                         /* exit scenario: "exit scenario" and the seconds left */
            clr(); word(W_EXIT, 64 - gw(W_EXIT) / 2, 0);
            uint8_t n = (uint8_t)(REG(R_CNT) > 99 ? 99 : REG(R_CNT));
            if (n >= 10) { const uint8_t *a = gp(G_CK, (uint8_t)(n / 10)), *b = gp(G_CK, (uint8_t)(n % 10)); int16_t w = gw(a) + 3 + gw(b), x = 64 - w / 2; word(a, x, 22); word(b, x + gw(a) + 3, 22); }
            else { const uint8_t *g = gp(G_CK, n); word(g, 64 - gw(g) / 2, 22); }
            fb_push(); dispNew = 1; continue;
        }
        if (d == D_SCNHOLD || d == D_SCNOK) {                      /* scenario key held: countdown 5..0, then "stored" */
            clr();
            if (d == D_SCNOK) word(W_SCNOK, 64 - gw(W_SCNOK) / 2, 24);
            else { word(W_SCNT, 64 - gw(W_SCNT) / 2, 0); const uint8_t *g = gp(G_CK, (uint8_t)(REG(R_CNT) > 9 ? 9 : REG(R_CNT))); word(g, 64 - gw(g) / 2, 22); }
            fb_push(); dispNew = 1; continue;
        }
#else
        if (d == D_SCNHOLD || d == D_SCNOK || d == D_EXIT || d == D_ROOM) d = D_STATES;
#endif
        if (d == D_STATES) {
            uint8_t busy = 0;
            for (uint8_t k = 0; k < 4; k++) {
                uint8_t o = poleOn(k);
                if (o != shown[k]) { shown[k] = o; anim[k] = 0; }
                if (anim[k] < 4) { anim[k]++; busy = 1; }
            }
            if (busy || dispNew) { draw_states(); fb_push(); }
        } else if (d == D_CLOCK || d == D_STANDBY) { draw_clock(t); fb_push(); }
        else if (d >= D_CUR && d < D_CUR + 4) { draw_curtain(d, t); fb_push(); }
        dispNew = 0;
    }
}
