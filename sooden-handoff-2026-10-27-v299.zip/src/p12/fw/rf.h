/* 433 MHz EV1527 decoder (the same as the Sooden panels); RF_PIN() = receiver level, Timer1 = 1 us ticks */
static uint16_t rfLast, rfHi, rfT;
static uint8_t rfBits, rfOn;
static uint32_t rfAcc, rfPrev;
static volatile uint32_t rfCode;
static volatile uint8_t rfNew;
static void rf_edge(void)
{
    uint16_t t = TCNT1, dt = t - rfLast;
    rfLast = t;
    if (!RF_PIN()) { rfHi = dt; return; }
    uint16_t hi = rfHi, lo = dt;
    if (hi >= 100 && hi <= 1200 && lo >= hi * 18u && lo <= hi * 45u && lo >= 3000) { rfT = lo / 31; rfBits = 0; rfAcc = 0; rfOn = 1; return; }
    if (!rfOn) return;
    uint16_t T = rfT, sh, lg; uint8_t bv;
    if (hi > lo) { bv = 1; sh = lo; lg = hi; } else { bv = 0; sh = hi; lg = lo; }
    if (sh < T / 2 || sh > T * 2 || lg < T * 2 || lg > T * 5) { rfOn = 0; return; }
    rfAcc = (rfAcc << 1) | bv;
    if (++rfBits == 24) { rfOn = 0; if (rfAcc == rfPrev) { rfCode = rfAcc; rfNew = 1; } rfPrev = rfAcc; }
}
