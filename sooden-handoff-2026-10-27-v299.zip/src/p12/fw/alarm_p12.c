/* Sooden 12-pole SIM panel - alarm MCU (ATmega64A, 8 MHz crystal, fuses Low 3F, High C1, Extended FF)
   3 zones (sensor 1..3), input 4 = magnet (backup: a message, sirens if set), 3 sirens, keypad, own 433 MHz remotes (5),
   OLED 4 in Persian. SMS / app messages: the events are marked msg_*(), sent once the GSM / Wi-Fi stage is done.
   pins: keypad IC1 valid PA0 code PA1 PA2 PA3, IC2 valid PA4 code PA5 PA6 PA7
         sensors S1 PC4, S2 PC6, S3 PC5, S4 PC7 (pull-up; high = open = alarm, a cut wire alarms too)
         sirens PC1 PC2 PC3 (high = on), Led_N PC0, buzzer PB5
         zone LEDs white/red: 1 PB6/PB7, 2 PD1/PD2, 3 PD3/PD4, ON/OFF key PE3/PE2
         433 MHz PE4 (INT4), OLED SCL PD6 SDA PD5, GSM reset PD0, bus B out PE5 PE6 PE7 PB0, bus C in PB2 PB3 PB4
   safety: the armed zones and the password are kept in 2 EEPROM copies with a check byte, written only when they change;
   a bad copy is healed from the good one, both bad = alarm off. Sensors are ignored 60 s after power-up. */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <string.h>
#include "bus.h"
#pragma GCC diagnostic ignored "-Wunused-function"
#include "gfx.h"
#include "words2.h"
#include "words3.h"

/* ---------------- settings (the programmer will write this block; erased = defaults) ---------------- */
typedef struct {
    uint8_t magic;          /* 0xA5 */
    uint8_t zoneOn;         /* bit 1..2: zones 2 / 3 in use (zone 1 always) */
    uint8_t sir[3];         /* per zone: sirens (bit 0..2) */
    uint8_t mag;            /* bit 0: input 4 in use, bit 1: a message also while the alarm is off, bit 2: curtains by SMS */
    uint8_t magSir;         /* sirens for input 4 */
    uint8_t rem[4];         /* remote buttons: R_NONE, R_OFF, R_TOG, or R_ARM | zone bits */
    uint8_t exitS, entryS;  /* seconds */
    uint16_t sirenS;
} ACfg;
#define R_NONE 0
#define R_OFF  0x40
#define R_TOG  0x80
#define R_ARM  0x10        /* | zone bits 0..2 */
#define R_FAST 0x08        /* with R_ARM / R_TOG: no exit time */
const uint8_t alcfg_flash[32] __attribute__((section(".alcfg"), used)) = { [0 ... 31] = 0xFF };
static ACfg C;
static void cfg_load(void)
{
    for (uint8_t i = 0; i < sizeof C; i++) ((uint8_t *)&C)[i] = pgm_read_byte(&alcfg_flash[i]);
    if (C.magic == 0xA5) return;
    static const ACfg D = { 0xA5, 0, { 1, 2, 4 }, 0, 0, { R_ARM | 1, R_OFF, R_NONE, R_NONE }, 40, 30, 180 };
    C = D;
}

/* ---------------- time, I/O ---------------- */
static volatile uint32_t ms;
static void busB_step(void); static void bc_sample(void);
ISR(TIMER0_COMP_vect) { ms++; bc_sample(); busB_step(); }   /* both buses timed here: the main loop can be slow while an OLED is drawn */
static uint32_t now(void) { uint32_t v; cli(); v = ms; sei(); return v; }
#define RF_PIN() (PINE & _BV(4))
#include "rf.h"
ISR(INT4_vect) { rf_edge(); }

static uint8_t busC(void) { return (uint8_t)(((PINB >> 2) & 1) << 2 | ((PINB >> 3) & 1) << 1 | ((PINB >> 4) & 1)); }
/* bus C symbols (held 30 ms, 10 ms idle between): found in the 1 ms interrupt, handled in the main loop */
static volatile uint8_t cq[16], cqh, cqt;
static uint8_t cLast = 7, cMs, cIdl = 1;
static void bc_sample(void)
{
    uint8_t c = busC();
    if (c == cLast) { if (cMs < 255) cMs++; } else { cLast = c; cMs = 0; }
    if (c == BC_IDLE) { if (cMs >= 5) cIdl = 1; if (cMs == 200) { cq[cqh & 15] = 0xFF; cqh++; } }   /* 0xFF: long idle, a frame is over */
    else if (cMs == 15 && cIdl) { cIdl = 0; if ((uint8_t)(cqh - cqt) < 16) { cq[cqh & 15] = c; cqh++; } }
}
static void busB(uint8_t c)
{
    PORTE = (uint8_t)((PORTE & (uint8_t)~0xE0) | ((c & 8) ? _BV(5) : 0) | ((c & 4) ? _BV(6) : 0) | ((c & 2) ? _BV(7) : 0));
    if (c & 1) PORTB |= _BV(0); else PORTB &= (uint8_t)~_BV(0);
}
static uint8_t sensors(void) { uint8_t c = PINC; return (uint8_t)(((c >> 4) & 1) | ((c >> 6) & 1) << 1 | ((c >> 5) & 1) << 2 | ((c >> 7) & 1) << 3); }
static void sirens(uint8_t m) { PORTC = (uint8_t)((PORTC & (uint8_t)~0x0E) | ((m & 7) << 1)); }
static volatile uint8_t *const WP[4] = { &PORTB, &PORTD, &PORTD, &PORTE };
static const uint8_t WB[4] = { 6, 1, 3, 3 }, RB[4] = { 7, 2, 4, 2 };
static void led(uint8_t i, uint8_t w, uint8_t r)
{
    uint8_t s = SREG; cli();                                /* PORTB / PORTE also carry bus B, written in the 1 ms interrupt */
    if (w) *WP[i] |= _BV(WB[i]); else *WP[i] &= (uint8_t)~_BV(WB[i]);
    if (r) *WP[i] |= _BV(RB[i]); else *WP[i] &= (uint8_t)~_BV(RB[i]);
    SREG = s;
}
/* keypad: 0 none, else the key character */
static const char K1[8] = { '6', '5', '4', '1', '2', 'L', 'R', '3' }, K2[8] = { 'K', 'D', '0', 'C', 0, '7', '8', '9' };   /* K = OK */
static char keypad(void)
{
    if (!(PINA & _BV(0))) return K1[((PINA >> 1) & 1) << 2 | ((PINA >> 2) & 1) << 1 | ((PINA >> 3) & 1)];
    if (!(PINA & _BV(4))) return K2[((PINA >> 5) & 1) << 2 | ((PINA >> 6) & 1) << 1 | ((PINA >> 7) & 1)];
    return 0;
}

/* ---------------- safe EEPROM records: [magic][data...][check], two copies ---------------- */
static uint8_t ck(const uint8_t *p, uint8_t n) { uint8_t c = 0x5A; while (n--) c = (uint8_t)((c << 1 | c >> 7) ^ *p++); return c; }
static uint8_t rec_load(uint16_t a, uint16_t b, uint8_t mg, uint8_t *d, uint8_t n)   /* n data bytes */
{
    uint8_t x[100], y[100], okx, oky;
    eeprom_read_block(x, (const void *)a, n + 2); eeprom_read_block(y, (const void *)b, n + 2);
    okx = x[0] == mg && x[n + 1] == ck(x, (uint8_t)(n + 1));
    oky = y[0] == mg && y[n + 1] == ck(y, (uint8_t)(n + 1));
    if (okx) { memcpy(d, x + 1, n); if (!oky || memcmp(x, y, n + 2)) eeprom_update_block(x, (void *)b, n + 2); return 1; }
    if (oky) { memcpy(d, y + 1, n); eeprom_update_block(y, (void *)a, n + 2); return 1; }
    return 0;
}
static void rec_save(uint16_t a, uint16_t b, uint8_t mg, const uint8_t *d, uint8_t n)  /* copy A, then B: one is always whole */
{
    uint8_t x[100]; x[0] = mg; memcpy(x + 1, d, n); x[n + 1] = ck(x, (uint8_t)(n + 1));
    eeprom_update_block(x, (void *)a, n + 2); wdt_reset();
    eeprom_update_block(x, (void *)b, n + 2);
}
#define EE_STA 0x10
#define EE_STB 0x20
#define EE_RMA 0x40
#define EE_RMB 0x60
#define MG_ST  0x3C
#define MG_RM  0xC3
static uint16_t pin = 0x1234;      /* 4 digits, one per nibble */
static uint8_t armed;              /* zone bits */
static uint32_t rmt[5];            /* remote ids (code without the button nibble), 0 = free */
static void st_save(void) { uint8_t d[3] = { (uint8_t)(pin >> 8), (uint8_t)pin, armed }; rec_save(EE_STA, EE_STB, MG_ST, d, 3); }
static void rm_save(void)
{
    uint8_t d[15];
    for (uint8_t i = 0; i < 5; i++) { d[i * 3] = (uint8_t)(rmt[i] >> 16); d[i * 3 + 1] = (uint8_t)(rmt[i] >> 8); d[i * 3 + 2] = (uint8_t)rmt[i]; }
    rec_save(EE_RMA, EE_RMB, MG_RM, d, 15);
}
static void ee_init(void)
{
    uint8_t d[15];
    if (rec_load(EE_STA, EE_STB, MG_ST, d, 3)) { pin = (uint16_t)(d[0] << 8 | d[1]); armed = d[2] & 7; } else { pin = 0x1234; armed = 0; }
    if (rec_load(EE_RMA, EE_RMB, MG_RM, d, 15)) for (uint8_t i = 0; i < 5; i++) rmt[i] = (uint32_t)d[i * 3] << 16 | (uint16_t)(d[i * 3 + 1] << 8) | d[i * 3 + 2];
    else memset(rmt, 0, sizeof rmt);
}

/* ---------------- alarm ---------------- */
enum { S_OFF, S_EXIT, S_ARMED, S_ENTRY, S_SIREN };
enum { U_HOME, U_SEL, U_PASS, U_MENU, U_MPASS, U_NEW1, U_NEW2, U_LEARN, U_NUMLIST, U_NUMEDIT };
static uint8_t st = S_OFF, ui = U_HOME, sel, trig = 0xFF, cnt[3], nbuf, page, sirOn, stby, locked, bootDark = 1;   /* locked: 1 child lock, 2 exit scenario */
static uint16_t buf, newPin;
static uint32_t T, until, msgUntil, quietUntil, uiUntil, beepUntil, nextBeep;
static const uint8_t *msgW;
static void beep(uint16_t m) { beepUntil = T + m; }
static void flash(const uint8_t *w) { msgW = w; msgUntil = T + 2500; }
static uint8_t zones_ok(uint8_t m) { return (uint8_t)(m & (1 | (C.zoneOn & 6))); }
static void wake_panel(void); static void act_ping(void);
static void busB_send(uint8_t c, uint8_t a);
#include "gsm.h"
static void arm_by(uint8_t m, uint8_t src, uint8_t user)
{
    uint8_t fast = m & R_FAST;                           /* remote button set to "quick": armed at once, no exit time */
    m = zones_ok(m & 7);
    if (!m) return;
    armed = m; st = S_EXIT; until = T + (fast ? 0 : (uint32_t)C.exitS * 1000); memset(cnt, 0, 3); ui = U_HOME;
    st_save(); flash(A_ARMED); beep(120); ev((uint8_t)(1 + src));
    if (src == SRC_SMS) answer(user, T_ON, m, 0, 1); else notify_all(src == SRC_KEY ? T_KEYON : src == SRC_REMOTE ? T_REMON : T_ON, m, 0);
}
static void disarm_by(uint8_t m, uint8_t src, uint8_t user)    /* m: the zones to turn off (7 = all) */
{
    armed &= (uint8_t)~m;
    if (!armed) { st = S_OFF; sirOn = 0; trig = 0xFF; gsm_cancel_alarm(); flash(A_DISARMED); }
    else if (trig < 3 && !((armed >> trig) & 1)) { sirOn = 0; trig = 0xFF; st = S_ARMED; }
    ui = U_HOME; st_save(); beep(120); ev((uint8_t)(5 + src));
    if (src == SRC_SMS) { if (!armed) answer(user, T_OFF, 0, 0, 1); else answer(user, T_ZOFF, m, armed, 1); }
    else notify_all(src == SRC_KEY ? T_KEYOFF : src == SRC_REMOTE ? T_REMOFF : T_OFF, 0, 0);
}
static uint8_t mpage, nslot, nlen; static char nbufS[NLEN];
static void check_pass(void)
{
    uint8_t ok = buf == pin;
    if (ui == U_MPASS) { if (ok) { if (mpage == 0) { ui = U_NEW1; nbuf = 0; buf = 0; } else ui = U_NUMLIST; } else { flash(A_WRONG); ui = U_HOME; } return; }
    if (!ok) { flash(A_WRONG); ui = U_HOME; beep(400); return; }
    if (st == S_OFF) arm_by(sel, SRC_KEY, 0); else disarm_by(7, SRC_KEY, 0);
}
static void digit(uint8_t d)
{
    buf = (uint16_t)(buf << 4 | d);
    if (++nbuf < 4) return;
    nbuf = 0;
    if (ui == U_NEW1) { newPin = buf; buf = 0; ui = U_NEW2; return; }
    if (ui == U_NEW2) { if (buf == newPin) { pin = buf; st_save(); flash(A_PWOK); } else flash(A_PWBAD); ui = U_HOME; return; }
    check_pass(); buf = 0;
}
static void ui_timeout(void); static void key2(char k, uint8_t d, uint8_t isd);
static void key(char k)
{
    uint8_t d = (uint8_t)(k - '0'), isd = k >= '0' && k <= '9';
    /* settings: left / right = one step back, down to the page of the three options */
    if ((k == 'L' || k == 'R') && (ui == U_MPASS || ui == U_NEW1 || ui == U_NEW2 || ui == U_NUMLIST || ui == U_NUMEDIT)) {
        if (ui == U_NUMEDIT) ui = U_NUMLIST; else { ui = U_MENU; page = mpage; }
        buf = 0; nbuf = 0; ui_timeout(); return;
    }
    key2(k, d, isd);
    ui_timeout();
}
static void ui_timeout(void)   /* first step (zone choice, the three options) 5 s; after the first OK 30 s with no key */
{
    uiUntil = T + ((ui == U_SEL || ui == U_MENU) ? 5000 : 30000);
}
static void key2(char k, uint8_t d, uint8_t isd)
{
    if (ui == U_PASS || ui == U_MPASS || ui == U_NEW1 || ui == U_NEW2) {
        if (isd) digit(d); else if (k == 'C') { buf = 0; nbuf = 0; } else if (k == 'D') { ui = U_HOME; buf = 0; nbuf = 0; }
        return;
    }
    if (ui == U_SEL) {
        if (k >= '1' && k <= '3') { uint8_t b = (uint8_t)(1 << (k - '1')); if (zones_ok(b)) sel ^= b; }
        else if (k == 'K') { if (sel) { ui = U_PASS; buf = 0; nbuf = 0; } }
        else if (k == 'D' || k == 'C') ui = U_HOME;
        return;
    }
    if (ui == U_MENU) {
        if (k == 'L') page = (uint8_t)((page + 2) % 3); else if (k == 'R') page = (uint8_t)((page + 1) % 3);
        else if (k == 'K') { mpage = page; ui = U_MPASS; buf = 0; nbuf = 0; }
        else if (k == 'D' || k == 'C') ui = U_HOME;
        return;
    }
    if (ui == U_LEARN) { if (k == 'D' || k == 'C') ui = U_HOME; return; }
    if (ui == U_NUMLIST) {                                /* 1..3: the number to edit */
        if (k >= '1' && k <= '3') { nslot = (uint8_t)(k - '1'); char *n = mpage == 1 ? N.sms[nslot] : N.call[nslot]; strcpy(nbufS, n); nlen = (uint8_t)strlen(nbufS); ui = U_NUMEDIT; }
        else if (k == 'D' || k == 'C') ui = U_HOME;
        return;
    }
    if (ui == U_NUMEDIT) {                                /* digits, C = one back, OK = save, ON/OFF = cancel */
        if (isd && nlen < NLEN - 1) { nbufS[nlen++] = k; nbufS[nlen] = 0; }
        else if (k == 'C') { if (nlen) nbufS[--nlen] = 0; }
        else if (k == 'K') { strcpy(mpage == 1 ? N.sms[nslot] : N.call[nslot], nbufS); nums_save(); flash(A_SAVED); ui = U_NUMLIST; }
        else if (k == 'D') ui = U_NUMLIST;
        return;
    }
    /* home */
    if (k == 'D') { if (st == S_OFF) { ui = U_SEL; sel = 1; } else { ui = U_PASS; buf = 0; nbuf = 0; } return; }
    if ((k == 'L' || k == 'R') && st == S_OFF) { ui = U_MENU; page = 0; return; }
    if (isd && st != S_OFF) { ui = U_PASS; buf = d; nbuf = 1; }
}
static void remote(uint32_t code)
{
    uint32_t id = code & 0xFFFFF0UL; uint8_t b = code & 0x0F;
    if (ui == U_LEARN) {
        for (uint8_t i = 0; i < 5; i++) if (rmt[i] == id) { flash(A_ROK); ui = U_HOME; return; }
        for (uint8_t i = 0; i < 5; i++) if (!rmt[i]) { rmt[i] = id; rm_save(); flash(A_ROK); beep(200); ui = U_HOME; return; }
        flash(A_RFULL); ui = U_HOME; return;
    }
    uint8_t known = 0;
    for (uint8_t i = 0; i < 5; i++) if (rmt[i] && rmt[i] == id) known = 1;
    if (!known || locked == 1) return;                  /* child lock: no; exit scenario (2): the alarm remote still works */
    uint8_t n = b == 1 ? 0 : b == 2 ? 1 : b == 4 ? 2 : b == 8 ? 3 : 0xFF;
    if (n == 0xFF) return;
    uint8_t a = C.rem[n];
    if (stby) wake_panel(); else act_ping();
    if (a == R_NONE) { flash(A_NOACT); return; }
    if (a == R_OFF) { if (st != S_OFF) disarm_by(7, SRC_REMOTE, 0); return; }
    if ((a & 0xF7) == R_TOG) { if (st == S_OFF) arm_by((uint8_t)(1 | (a & R_FAST)), SRC_REMOTE, 0); else disarm_by(7, SRC_REMOTE, 0); return; }
    if ((a & R_ARM) && st == S_OFF) arm_by(a & (7 | R_FAST), SRC_REMOTE, 0);
}

/* ---------------- OLED ---------------- */
static uint8_t gwd(const uint8_t *g) { return pgm_read_byte(&g[0]); }
static uint8_t gpg(const uint8_t *g) { return pgm_read_byte(&g[1]); }
static void wc(const uint8_t *w, int16_t cy) { word(w, 64 - gwd(w) / 2, cy - gpg(w) * 4); }
static const uint8_t *fa(uint8_t d) { return (const uint8_t *)pgm_read_word(&G_FA[d]); }
static uint8_t num_w(uint16_t v) { uint8_t w = 0; do { w = (uint8_t)(w + gwd(fa((uint8_t)(v % 10))) + 3); v /= 10; } while (v); return (uint8_t)(w - 3); }
static void num(uint16_t v, int16_t x, int16_t y)                 /* x = left edge */
{
    uint8_t d[5], n = 0; do { d[n++] = (uint8_t)(v % 10); v /= 10; } while (v);
    while (n--) { word(fa(d[n]), x, y); x += gwd(fa(d[n])) + 3; }
}
static void secs(uint16_t s, int16_t cy)                          /* "45 ثانیه": number on the right */
{
    uint8_t nw = num_w(s), w = (uint8_t)(nw + 6 + gwd(A_SEC));
    int16_t x = 64 - w / 2;
    word(A_SEC, x, cy - 4); num(s, x + gwd(A_SEC) + 6, cy - 9);
}
static void crect(int16_t x, int16_t y, int16_t w, int16_t h)
{
    for (int16_t j = y; j < y + h; j++) for (int16_t i = x; i < x + w; i++) if (i >= 0 && i < 128 && j >= 0 && j < 64) fb[j >> 3][i] &= (uint8_t)~(1 << (j & 7));
}
static uint16_t left_s(void) { return until > T ? (uint16_t)((until - T + 999) / 1000) : 0; }
static void draw(void)
{
    clr();
    if (msgUntil > T) { wc(msgW, 32); return; }
    switch (ui) {
    case U_SEL:
        wc(A_SEL, 9);
        for (uint8_t i = 0; i < 3; i++) {
            int16_t cx = 24 + i * 40; uint8_t on = (sel >> i) & 1, ok = zones_ok((uint8_t)(1 << i)) != 0;
            hline(cx - 14, cx + 14, 20); hline(cx - 14, cx + 14, 43); vline(cx - 14, 20, 43); vline(cx + 14, 20, 43);
            if (on) rect(cx - 12, 22, 25, 20);
            if (!ok) hline(cx - 5, cx + 5, 32);
            else { const uint8_t *g = fa((uint8_t)(i + 1)); word(g, cx - gwd(g) / 2, 23); if (on) { crect(cx - 12, 22, 25, 20); rect(cx - 12, 22, 25, 20);
                    for (uint8_t p = 0; p < gpg(g); p++) for (uint8_t c = 0; c < gwd(g); c++) { uint8_t v = pgm_read_byte(&g[2 + p * gwd(g) + c]);
                        for (uint8_t k = 0; k < 8; k++) if (v & (1 << k)) { int16_t xx = cx - gwd(g) / 2 + c, yy = 23 + p * 8 + k; if (yy < 64) fb[yy >> 3][xx] &= (uint8_t)~(1 << (yy & 7)); } } } }
        }
        wc(A_OKNEXT, 56);
        return;
    case U_PASS: case U_MPASS: case U_NEW1: case U_NEW2:
        wc(ui == U_NEW1 ? A_PNEW : ui == U_NEW2 ? A_PREP2 : ui == U_MPASS ? A_PCUR : A_PASS, 10);
        for (uint8_t i = 0; i < 4; i++) { int16_t cx = 34 + i * 20; if (i < nbuf) circle(cx, 36, 4, 1); else rect(cx - 5, 42, 10, 2); }
        if (st == S_ENTRY && ui == U_PASS) secs(left_s(), 56);
        return;
    case U_MENU:
        wc(A_SET, 8); hline(20, 108, 17);
        wc(page == 0 ? A_CHPW : page == 1 ? A_SMS : A_CALLS, 35);
        wc(A_OKIN, 56);
        return;
    case U_LEARN: wc(A_RLEARN, 32); return;
    case U_NUMLIST:
        wc(mpage == 1 ? A_SMS : A_CALLS, 8);
        for (uint8_t i = 0; i < 3; i++) {
            char b[18]; b[0] = (char)('1' + i); b[1] = ':'; b[2] = ' '; strcpy(b + 3, mpage == 1 ? N.sms[i] : N.call[i]);
            str(8, 22 + i * 14, b, 1);
            if (!(mpage == 1 ? N.sms[i] : N.call[i])[0]) word(A_EMPTY, 30, 22 + i * 14);
        }
        return;
    case U_NUMEDIT: {
        wc(mpage == 1 ? A_SMS : A_CALLS, 8);
        char b[4] = { (char)('1' + nslot), ':', 0, 0 }; str(2, 26, b, 1);
        uint8_t sc = nlen <= 9 ? 2 : 1; int16_t x = 18;
        str(x, sc == 2 ? 22 : 26, nbufS, sc);
        if ((T / 400) & 1) rect(x + nlen * 6 * sc, sc == 2 ? 36 : 34, 5 * sc, 2);   /* cursor */
        wc(A_OKSAVE, 56);
        return; }
    }
    if (gOk) for (uint8_t i = 0; i < 5; i++) { uint8_t h = (uint8_t)(2 + i * 2); if (i < gCsq) rect(i * 4, 11 - h, 3, h); else rect(i * 4, 10, 3, 1); }   /* signal: 5 bars, 3 px wide, up to 10 px (the titles start at row 12) */
    switch (st) {
    case S_OFF:
        wc(A_OFF, 20);
        if (quietUntil > T) { wc(A_PREP, 38); uint16_t q = (uint16_t)((quietUntil - T + 999) / 1000); num(q, 64 - num_w(q) / 2, 46); }
        else wc(A_HINT, 48);
        break;
    case S_EXIT: wc(A_EXIT, 14); secs(left_s(), 44); break;
    case S_ARMED: {
        wc(A_ON, 16);
        uint8_t w = (uint8_t)gwd(A_ZONE), n = 0;
        for (uint8_t i = 0; i < 3; i++) if ((armed >> i) & 1) n++;
        int16_t x = 64 - (w + 6 + n * 14) / 2;
        for (int8_t i = 2; i >= 0; i--) if ((armed >> i) & 1) { word(fa((uint8_t)(i + 1)), x, 36); x += 14; }
        word(A_ZONE, x + 4, 40);
        break; }
    case S_ENTRY: wc(A_PASS, 14); secs(left_s(), 44); break;
    case S_SIREN:
        wc(A_ALERT, 20);
        if (trig == 3) wc(A_MAG, 47);
        else { uint8_t w = gwd(A_ZONE); int16_t x = 64 - (w + 20) / 2; word(fa((uint8_t)(trig + 1)), x, 38); word(A_ZONE, x + 18, 42); }
        if ((T / 400) & 1) for (uint8_t p = 0; p < 8; p++) for (uint8_t i = 0; i < 128; i++) fb[p][i] ^= 0xFF;   /* blinking */
        break;
    }
}

/* ---------------- panel link ---------------- */
/* bus B frames to M4: [command][argument][check = (c + a) mod 15], 4-bit symbols, idle 1111, held 8 ms, 4 ms apart */
static uint8_t bbQ[24][2], bbN, bbSym[3], bbI, bbPh, bbLeft;
static void busB_send(uint8_t c, uint8_t a) { uint8_t s = SREG; cli(); if (bbN < 24) { bbQ[bbN][0] = c; bbQ[bbN][1] = a; bbN++; } SREG = s; }
static void busB_step(void)
{
    if (bbLeft) { bbLeft--; return; }
    if (bbPh == 1) { busB(BB_IDLE); bbPh = 2; bbLeft = 3; if (++bbI == 3) { bbPh = 0; bbLeft = 19; } return; }
    if (bbPh == 2) { busB(bbSym[bbI]); bbPh = 1; bbLeft = 7; return; }
    if (!bbN) return;
    bbSym[0] = bbQ[0][0]; bbSym[1] = bbQ[0][1]; bbSym[2] = (uint8_t)((bbSym[0] + bbSym[1]) % 15);
    bbN--; memmove(bbQ[0], bbQ[1], bbN * 2);
    bbI = 0; busB(bbSym[0]); bbPh = 1; bbLeft = 7;
}
static void wake_panel(void) { busB_send(BB_C_WAKE, 0); }
/* ---------------- for the phone app (Wi-Fi, through M4) ---------------- */
static uint8_t al_view(void) { return st == S_EXIT ? 1 : st == S_ARMED ? 2 : st == S_ENTRY ? 3 : st == S_SIREN ? 4 : 0; }
static void bb_pole(uint8_t d, uint8_t on)        /* poles 1..11: K arguments 4..14, pole 12: misc 8 / 9 */
{
    if (d <= 11) busB_send(on ? BB_C_KON : BB_C_KOFF, (uint8_t)(d + 3)); else busB_send(BB_C_MISC, on ? 8 : 9);
    if (on) poleMask |= (uint16_t)(1 << (d - 1)); else poleMask &= (uint16_t)~(1 << (d - 1));   /* the answer shows it now; M4's next pole frame corrects it */
}
static void bb_credit(void)
{
    if (!cred[0]) { busB_send(BB_C_CRD, 12); return; }
    busB_send(BB_C_CRD, 10);
    for (uint8_t i = 0; cred[i]; i++) busB_send(BB_C_CRD, (uint8_t)(cred[i] - '0'));
    busB_send(BB_C_CRD, 11);
}
#ifdef NO_APPREPORT
static void ev(uint8_t code) { (void)code; }
#else
static void ev(uint8_t code) { busB_send(BB_C_EV, code); }
#endif
/* the states the app shows, only while a phone is connected: M4 asks (app frame 5) every 30 s; for 60 s after that a
   changed state goes to M4, at most one frame a second (a busy bus B made this board restart); quiet otherwise */
static uint32_t rptUntil;
static void bb_report(uint8_t all)
{
    static uint8_t lA = 0xFF, lZ = 0xFF, lO = 0xFF, lG = 0xFF, lP = 0xFF, crdSent; static uint32_t at;
    if (all) { lA = lZ = lO = lG = lP = 0xFF; rptUntil = T + 60000; if (!crdSent) { crdSent = 1; bb_credit(); } return; }
    if (T >= rptUntil || T - at < 1000 || bbN) return;
    uint8_t a = al_view(), z = armed, o = sensOpen, g = (uint8_t)(gCsq | (gOk ? 8 : 0)), p = gOp;
    if (a != lA) { lA = a; busB_send(BB_C_AL, a); }
    else if (z != lZ) { lZ = z; busB_send(BB_C_ZN, z); }
    else if (o != lO) { lO = o; busB_send(BB_C_OPEN, o); }
    else if (g != lG) { lG = g; busB_send(BB_C_GSM, g); }
    else if (p != lP) { lP = p; busB_send(BB_C_MISC, (uint8_t)(4 + (p & 3))); }
    else return;
    at = T;
}
/* ---------------- alarm settings from the app (installer, Wi-Fi through M4) ----------------
   times changed from the app: EEPROM 0x200 / 0x210 = the programmed times they replace, then the new ones;
   a new programming (other times in flash) drops them */
#define EE_TMA 0x200
#define EE_TMB 0x210
#define MG_TM  0x7A
static void tm_save(uint8_t e, uint8_t n, uint16_t sr)
{
    ACfg f; for (uint8_t i = 0; i < sizeof f; i++) ((uint8_t *)&f)[i] = pgm_read_byte(&alcfg_flash[i]);
    if (f.magic != 0xA5) { f.exitS = 40; f.entryS = 30; f.sirenS = 180; }
    uint8_t d[8] = { f.exitS, f.entryS, (uint8_t)(f.sirenS >> 8), (uint8_t)f.sirenS, e, n, (uint8_t)(sr >> 8), (uint8_t)sr };
    rec_save(EE_TMA, EE_TMB, MG_TM, d, 8);
    C.exitS = e; C.entryS = n; C.sirenS = sr;
}
static void tm_load(void)
{
    uint8_t d[8];
    if (rec_load(EE_TMA, EE_TMB, MG_TM, d, 8) && d[0] == C.exitS && d[1] == C.entryS && (uint16_t)(d[2] << 8 | d[3]) == C.sirenS) {
        C.exitS = d[4]; C.entryS = d[5]; C.sirenS = (uint16_t)(d[6] << 8 | d[7]);
    }
}
/* the settings for M4 on bus B: MISC 10, then CRD symbols: digits 0..9, 12 '+', 10 between fields, 11 at the end:
   exit s, entry s, siren s, code (4 digits), SMS 1..3, call 1..3 */
static char dmp[100]; static uint8_t dmpN, dmpI;
static void d_num(uint16_t v) { char b[6]; utoa(v, b, 10); for (uint8_t i = 0; b[i] && dmpN < sizeof dmp - 2; i++) dmp[dmpN++] = b[i]; }
static void d_sep(void) { if (dmpN < sizeof dmp - 1) dmp[dmpN++] = ','; }
static void dump_start(void)
{
    dmpN = 0;
    d_num(C.exitS); d_sep(); d_num(C.entryS); d_sep(); d_num(C.sirenS); d_sep();
    for (int8_t k = 12; k >= 0; k -= 4) dmp[dmpN++] = (char)('0' + ((pin >> k) & 15));
    for (uint8_t i = 0; i < 6; i++) { d_sep(); const char *n = i < 3 ? N.sms[i] : N.call[i - 3]; for (uint8_t j = 0; n[j] && dmpN < sizeof dmp - 4; j++) dmp[dmpN++] = n[j]; }
    uint16_t sum = 0;                              /* check: the sum of the symbols (digit, ',' 10, '+' 12) mod 100, two digits */
    for (uint8_t i = 0; i < dmpN; i++) sum += dmp[i] == ',' ? 10 : dmp[i] == '+' ? 12 : (uint8_t)(dmp[i] - '0');
    dmp[dmpN++] = (char)('0' + sum % 100 / 10); dmp[dmpN++] = (char)('0' + sum % 10);
    dmp[dmpN++] = '.';
    dmpI = 0xFF;                                   /* first MISC 10 */
}
static void dump_step(void)                        /* main loop: fills the bus B queue (the 1 ms interrupt sends it), so a slow
                                                      main loop (an OLED being drawn) does not slow the dump down */
{
    while (dmpI != 0xFE && bbN < 20) {
        if (dmpI == 0xFF) { busB_send(BB_C_MISC, 10); dmpI = 0; continue; }
        char c = dmp[dmpI++];
        busB_send(BB_C_CRD, c == ',' ? 10 : c == '.' ? 11 : c == '+' ? 12 : (uint8_t)(c - '0'));
        if (c == '.') dmpI = 0xFE;
    }
}
static char nset[NLEN]; static uint8_t nsetN;
/* act 6: sub 0 send the settings, 1 exit s, 2 entry s, 3 siren s, 4 code (4 nibbles), 5 number digits (4 nibbles: 0..9, A '+', F none;
   FFFF = start a number), 6 store the number in slot code (0..2 SMS, 3..5 call); answer MISC 11 saved / 12 refused */
static void app_set(uint8_t sub, uint16_t v)
{
    uint8_t ok = 1;
    if (sub == 0) { dump_start(); return; }
    if (sub == 5) {
        if (v == 0xFFFF) { nsetN = 0; nset[0] = 0; return; }
        for (int8_t k = 12; k >= 0; k -= 4) { uint8_t d = (uint8_t)((v >> k) & 15); if (d <= 10 && nsetN < NLEN - 1) { nset[nsetN++] = d == 10 ? '+' : (char)('0' + d); nset[nsetN] = 0; } }
        return;
    }
    if (sub == 1) { if (v > 255) ok = 0; else tm_save((uint8_t)v, C.entryS, C.sirenS); }
    else if (sub == 2) { if (!v || v > 255) ok = 0; else tm_save(C.exitS, (uint8_t)v, C.sirenS); }
    else if (sub == 3) { if (!v) ok = 0; else tm_save(C.exitS, C.entryS, v); }
    else if (sub == 4) { for (int8_t k = 12; k >= 0; k -= 4) if (((v >> k) & 15) > 9) ok = 0; if (ok) { pin = v; st_save(); } }
    else if (sub == 6) { if (v > 5) ok = 0; else { strcpy(v < 3 ? N.sms[v] : N.call[v - 3], nset); nums_save(); } }
    else ok = 0;
    busB_send(BB_C_MISC, ok ? 11 : 12);
}
/* an app command (bus C frame): code = 4 digits one per nibble, like the keypad */
static void app_cmd(uint8_t act, uint8_t zones, uint16_t code)
{
    if (act == 6) { app_set((uint8_t)(zones - 1), code); return; }
    if (act == 5) { bb_report(1); return; }
    if (act == 4) { if (!jqueued(J_USSD, 0xFF) && cur.type != J_USSD) { Job j = { J_USSD, 0xFF, 0, 0, 0, 0, 0, 0 }; jpush(j, 0, 0); busB_send(BB_C_CRD, 13); } return; }
    if (act < 1 || act > 3) return;
    if (locked == 2) { busB_send(BB_C_MISC, 3); return; }      /* exit scenario: wait */
    if (code != pin) { busB_send(BB_C_MISC, 2); return; }
    if (act == 3) { if (armed) disarm_by(7, SRC_APP, 0); }
    else { uint8_t m = zones_ok(zones); if (m && (armed & m) != m) arm_by((uint8_t)((armed | m) | (act == 2 ? R_FAST : 0)), SRC_APP, 0); }
    busB_send(BB_C_MISC, 1);
}
static uint32_t actAt; static uint8_t actOnce;
static void act_ping(void)                      /* a keypad / remote touch: the panel's 1-minute standby count starts again (at most every 2 s) */
{
    if (actOnce && T - actAt < 2000) return;
    actOnce = 1; actAt = T; busB_send(BB_C_WAKE, 0);
}

int main(void)
{
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0xE3; PORTB = 0x1F;          /* zone 1 LEDs off, buzzer off, bus B idle, bus C pull-ups */
    DDRC = 0x0F; PORTC = 0xF0;          /* sirens off, sensor pull-ups */
    DDRD = 0xFF; PORTD = 0x01;          /* GSM reset line high (idle) */
    DDRE = 0xEE; PORTE = 0xF0;
    DDRF = 0xFF; PORTF = 0x00;
    DDRG = 0xFF; PORTG = 0x00;
    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS02);       /* 1 ms */
    TIMSK |= _BV(OCIE0);
    TCCR1A = 0; TCCR1B = _BV(CS11);                   /* 1 us for the remote */
    EICRB = _BV(ISC40); EIFR = _BV(INTF4); EIMSK |= _BV(INT4);
    wdt_enable(WDTO_1S);
    sei();
    cfg_load();
    ol_init();
    T = now();
    while (now() - T < 300) wdt_reset();              /* supply settles before any EEPROM read */
    ee_init();
    tm_load();
    dmpI = 0xFE;
    gsm_init();
    T = now();
    quietUntil = T + 60000;                           /* PIR sensors settle after power-up */
    st = armed ? S_ARMED : S_OFF;                     /* the last state stays */
    uint32_t boot = T, lastT = T, oledAt = T, fullAt = T, initAt = T, learnHold = 0, clrHold = 0;
    uint8_t cFr = 0, cBuf[7], gBusyWas = 0, aFr = 0, aBuf[9];
    uint8_t kLast = 0, kCnt = 0, kDone = 0, wasSens = 0;
    char held = 0;
    for (;;) {
        wdt_reset();
        T = now();
        if (T == lastT) continue;
        uint16_t dt = (uint16_t)(T - lastT); lastT = T;
        /* bus C from M4 */
        while (cqt != cqh) {
            uint8_t c = cq[cqt & 15]; cqt++;
            if (c == 0xFF) { cFr = 0; aFr = 0; continue; }
            if (T - boot <= 1000) continue;
            uint8_t inFr = cFr | aFr;
            if (aFr) {                                    /* app frame: action, zones - 1, 6 base-7 digits of the code, check */
                aBuf[aFr - 1] = c;
                if (++aFr == 10) {
                    aFr = 0; uint8_t sum = 0; uint32_t v = 0;
                    for (uint8_t i = 0; i < 8; i++) sum = (uint8_t)(sum + aBuf[i]);
                    for (uint8_t i = 2; i < 8; i++) v = v * 7 + aBuf[i];
                    if (sum % 7 == aBuf[8] && v <= 0xFFFF) app_cmd(aBuf[0], (uint8_t)(aBuf[1] + 1), (uint16_t)v);
                }
            }
            else if (cFr) {                                    /* pole frame: 6 base-7 digits + check */
                cBuf[cFr - 1] = c;
                if (++cFr == 8) { cFr = 0; uint8_t sum = 0; uint32_t v = 0; for (uint8_t i = 0; i < 6; i++) { sum = (uint8_t)(sum + cBuf[i]); v = v * 7 + cBuf[i]; } if (sum % 7 == cBuf[6]) poleMask = (uint16_t)v; }
            }
            else if (c == 0) cFr = 1;
            else if (c == BC_APP) aFr = 1;
            else if (c == BC_STANDBY && !stby) { stby = 1; ol_cmd(0xAE); }
            else if (c == BC_AWAKE && stby) { stby = 0; ol_cmd(0xAF); fbAll = 1; }
            else if (c == BC_LOCKED) locked = 1;
            else if (c == BC_EXITLK) locked = 2;
            else if (c == BC_UNLOCKED) locked = 0;
            if (!inFr && (c == BC_AWAKE || c == BC_STANDBY)) bootDark = 0;   /* a state (not a pole-frame digit): the panel's power-up motion is over, our whites come on with the panel's */
        }
        gsm_tick();
        { uint8_t b = gsm_busy(); if (b != gBusyWas) { gBusyWas = b; busB_send(BB_C_BUSY, b); } }
        { static uint8_t simWas = 0xFF; static uint32_t simAt; uint8_t v = sim_state(); if (v != simWas || T - simAt >= 10000) { simWas = v; simAt = T; busB_send(BB_C_SIM, v); } }   /* indicator D on the panel */   /* touches on the panel wait while the module transmits */
        /* keypad: a key counts once steady 20 ms; OK held 3 s = learn a remote, C held 5 s = erase the remotes */
        char k = keypad();
        if (k == kLast) { if (kCnt < 255) kCnt++; } else { kLast = (uint8_t)k; kCnt = 0; kDone = 0; }
        if (k && kCnt == 20 && !kDone) {
            kDone = 1;
            if (stby) { stby = 0; ol_cmd(0xAF); fbAll = 1; wake_panel(); }   /* the first touch only wakes */
            else if (!locked) { act_ping(); beep(40); key(k); held = k; learnHold = T; clrHold = T; }
        }
        if (!k) held = 0;
        if (held == 'K' && st == S_OFF && ui == U_HOME && T - learnHold >= 3000) { held = 0; ui = U_LEARN; uiUntil = T + 15000; beep(200); }
        if (held == 'C' && st == S_OFF && ui == U_HOME && T - clrHold >= 5000) { held = 0; memset(rmt, 0, sizeof rmt); rm_save(); flash(A_RCLR); beep(400); }
        if (ui != U_HOME && T > uiUntil) ui = U_HOME;
        if (rfNew) { rfNew = 0; remote(rfCode); }
        /* sensors (ignored in the first minute) */
        uint8_t s = T < quietUntil ? 0 : sensors();
        if ((C.mag & 1) && (s & 8) && !(wasSens & 8)) {           /* input 4: magnet */
            if (armed) { notify_all(T_MAG, 0, 1); flash(A_MAGOPEN); ev(13); if (C.magSir && st != S_SIREN) { st = S_SIREN; trig = 3; sirOn = C.magSir; until = T + (uint32_t)C.sirenS * 1000; wake_panel(); } }
            else if (C.mag & 2) notify_all(T_DOOR, 0, 0);
        }
        wasSens = s; sensOpen = (uint8_t)(s & 7 & (1 | (C.zoneOn & 6)));
#ifndef NO_APPREPORT
        bb_report(0);
        dump_step();
#endif
        switch (st) {
        case S_EXIT: if (T >= until) st = S_ARMED; break;
        case S_ARMED:
            for (uint8_t i = 0; i < 3; i++) if (((armed >> i) & 1) && ((s >> i) & 1)) {
                st = S_ENTRY; trig = i; until = T + (uint32_t)C.entryS * 1000; nextBeep = T; wake_panel(); break; }
            break;
        case S_ENTRY:
            if (T >= nextBeep) { nextBeep = T + 1000; beep(60); }
            if (T >= until) { st = S_SIREN; sirOn = C.sir[trig]; until = T + (uint32_t)C.sirenS * 1000; cnt[trig]++; wake_panel(); ev((uint8_t)(9 + trig)); notify_all(T_SIREN, (uint8_t)(1 << trig), 1); }
            break;
        case S_SIREN:
            if (T >= until) {
                sirOn = 0;
                if (trig < 3 && cnt[trig] >= 3) { armed &= (uint8_t)~(1 << trig); st_save(); notify_all(T_AUTO, (uint8_t)(1 << trig), 0); }
                st = armed ? S_ARMED : S_OFF; trig = 0xFF;
            }
            break;
        }
        sirens(sirOn);
        if (T < beepUntil) PORTB |= _BV(5); else PORTB &= (uint8_t)~_BV(5);
        /* LEDs: white = zone off, red = armed; leaving: slow blink, set off: fast blink */
        if (bootDark && T - boot > 5000) bootDark = 0;
        uint8_t dk = stby || bootDark;
        uint8_t slow = (T / 500) & 1, fast = (T / 200) & 1;
        for (uint8_t i = 0; i < 3; i++) {
            uint8_t a = (armed >> i) & 1, r = a;
            if (a && st == S_EXIT) r = slow;
            if (i == trig && (st == S_ENTRY || st == S_SIREN)) r = fast;
            if (dk) led(i, 0, r && a); else led(i, !a, r);
        }
        if (dk) { led(3, 0, armed != 0); PORTC &= (uint8_t)~_BV(0); }
        else { led(3, !armed, armed != 0); PORTC |= _BV(0); }
        /* OLED: every 100 ms; every page again every 5 s and a fresh start every 5 min (a noise hit does not stay) */
        if (!stby && T - oledAt >= 100) {
            oledAt = T;
            if (T - initAt >= 300000UL) { initAt = T; ol_init(); }
            if (T - fullAt >= 5000) { fullAt = T; fbAll = 1; }
            draw(); fb_push();
        }
    }
}
