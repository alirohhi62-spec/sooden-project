/* SIM800 on USART0 (9600): SMS commands and messages, alarm calls, credit check, signal.
   Never waits: a ring buffer takes every byte in the interrupt, one job runs at a time and every step has a time limit.
   Every message waiting in the SIM is read, done and deleted by its own index (never "delete all"), and the SIM is
   listed again every minute, so nothing that arrives while the module is busy is lost.
   Texts are UCS2 (Persian and English), the command words come from sms_text.h (later: editable from the software). */
#include <stdlib.h>
#include "sms_text.h"

/* ---------------- numbers (3 SMS, 3 call), language per SMS number ---------------- */
#define NLEN 14
typedef struct { char sms[3][NLEN]; char call[3][NLEN]; uint8_t en; } Nums;   /* en: bit i = number i in English */
static Nums N;
#define EE_NUMA 0x100
#define EE_NUMB 0x180
#define MG_NUM  0x5E
static void nums_save(void) { rec_save(EE_NUMA, EE_NUMB, MG_NUM, (const uint8_t *)&N, sizeof N); }
static void nums_load(void) { if (!rec_load(EE_NUMA, EE_NUMB, MG_NUM, (uint8_t *)&N, sizeof N)) memset(&N, 0, sizeof N); }
static uint8_t num_same(const char *a, const char *b)            /* the last 10 digits */
{
    uint8_t la = (uint8_t)strlen(a), lb = (uint8_t)strlen(b);
    if (la < 10 || lb < 10) return 0;
    return !memcmp(a + la - 10, b + lb - 10, 10);
}

/* ---------------- UART ---------------- */
static volatile uint8_t rxb[256], rxh, rxt, txb[256], txh, txt;
ISR(USART0_RX_vect) { rxb[rxh++] = UDR0; }
ISR(USART0_UDRE_vect) { if (txh != txt) UDR0 = txb[txt++]; else UCSR0B &= (uint8_t)~_BV(UDRIE0); }
static void tx(uint8_t c) { while ((uint8_t)(txh + 1) == txt) wdt_reset(); txb[txh++] = c; UCSR0B |= _BV(UDRIE0); }
static void txs(const char *s) { while (*s) tx((uint8_t)*s++); }
static void txp(const char *p) { char c; while ((c = (char)pgm_read_byte(p++))) tx((uint8_t)c); }
static void txhex4(uint16_t u) { static const char H[] = "0123456789ABCDEF"; for (int8_t s = 12; s >= 0; s -= 4) tx((uint8_t)H[(u >> s) & 15]); }
static void txnum_ucs2(const char *n) { while (*n) txhex4((uint8_t)*n++); }
static uint8_t hexv(uint8_t c) { return c <= '9' ? (uint8_t)(c - '0') : (uint8_t)((c | 0x20) - 'a' + 10); }

/* ---------------- state ---------------- */
static uint8_t gMode;                                 /* answer to AT+CMGF?: 1 = PDU (settings lost), 2 = text, 0 = none */
static uint8_t gOk, gReg, gCsq, gOp;                /* module answered, registered, signal 0..5, operator 1 MCI 2 Irancell 3 Rightel */
static uint8_t fOK, fERR, fPrompt, fSent, fAns, fEnd, fRing, fCusd;
static char rdNum[NLEN + 2];
static uint16_t rdBody[48]; static uint8_t rdLen;
static uint16_t cus[70]; static uint8_t cusLen;      /* credit answer */
static uint8_t gl[250], ln, body, bodyN; static uint16_t bodyU;
static uint8_t imsiWait, fCmgr;
/* jobs */
enum { J_NONE, J_INIT, J_LIST, J_CSQ, J_READ, J_SMS, J_CALL, J_USSD, J_DEL, J_AT };
typedef struct { uint8_t type, to, tm, a1, a2, by, alarm, tries; } Job;   /* SMS: to = number, tm = text, a1 a2 = arguments, by = user+1 */
#define JQ 20
static Job jq[JQ]; static uint8_t jn;
static uint32_t smsHold;
static Job cur; static uint8_t step; static uint32_t dl, busyUntil, nextList, nextCsq, initAt;
static uint8_t callAns, callRound, chunk, nFail, nRestart;
static uint16_t msg[160]; static uint8_t msgLen;
#define TM_CREDIT 0xFE
#define TM_MACHINE 0xFD                                /* for the phone app: #SD,s,z,o,pppp,b,c# */
static uint8_t smsMach;                              /* the command came from the app (starts with #): its answer is TM_MACHINE */
static char cred[12];                                /* last credit (digits), "" = not known */
static uint8_t al_view(void);                        /* 0 off, 1 exit time, 2 armed, 3 entry time, 4 siren */
static uint8_t sensOpen;
static void bb_pole(uint8_t d, uint8_t on); static void ev(uint8_t code);                             /* zones whose sensor is open now (bit 0..2) */
static void jpush(Job j, uint8_t front, uint8_t at)  /* at: position from the front when front = 1 */
{
    if (jn >= JQ) return;
    if (!front) { jq[jn++] = j; return; }
    if (at > jn) at = jn;
    memmove(&jq[at + 1], &jq[at], (jn - at) * sizeof(Job)); jq[at] = j; jn++;
}
static uint8_t jqueued(uint8_t type, uint8_t to) { for (uint8_t i = 0; i < jn; i++) if (jq[i].type == type && jq[i].to == to) return 1; return 0; }
static void gsm_cancel_alarm(void)                   /* alarm off: the alarm messages / calls still waiting are dropped */
{
    uint8_t k = 0;
    for (uint8_t i = 0; i < jn; i++) if (!jq[i].alarm) jq[k++] = jq[i];
    jn = k;
    if (cur.type == J_CALL && cur.alarm) { txp(PSTR("ATH\r")); cur.type = J_NONE; }
}

/* ---------------- gl handling ---------------- */
static uint8_t starts(const char *p) { uint8_t i = 0; char c; while ((c = (char)pgm_read_byte(p + i))) { if (i >= ln || gl[i] != (uint8_t)c) return 0; i++; } return 1; }
static uint8_t num_after(uint8_t i) { uint8_t v = 0; while (i < ln && (gl[i] < '0' || gl[i] > '9')) i++; while (i < ln && gl[i] >= '0' && gl[i] <= '9') v = (uint8_t)(v * 10 + gl[i++] - '0'); return v; }
static void quoted_ucs2(uint8_t nth, char *out, uint8_t max)   /* the nth "..." of the gl, UCS2 hex -> ASCII */
{
    uint8_t i = 0, q = 0, n = 0;
    while (i < ln && q < nth * 2 - 1) { if (gl[i] == '"') q++; i++; }
    while (i + 3 < ln && gl[i] != '"' && n < max - 1) { uint16_t u = (uint16_t)(hexv(gl[i]) << 12 | hexv(gl[i + 1]) << 8 | hexv(gl[i + 2]) << 4 | hexv(gl[i + 3])); i += 4; if (u < 128) out[n++] = (char)u; }
    out[n] = 0;
}
static void on_line(void)
{
    if (!ln) return;
    if (starts(PSTR("OK"))) fOK = 1;
    else if (starts(PSTR("ERROR")) || starts(PSTR("+CMS ERROR")) || starts(PSTR("+CME ERROR"))) fERR = 1;
    else if (starts(PSTR("+CMTI:"))) { busyUntil = T + 2000; uint8_t i = 0; while (i < ln && gl[i] != ',') i++; uint8_t idx = num_after(i); if (!jqueued(J_READ, idx)) { Job j = { J_READ, idx, 0, 0, 0, 0, 0 }; jpush(j, 0, 0); } }
    else if (starts(PSTR("+CMGL:"))) { uint8_t idx = num_after(6); if (!jqueued(J_READ, idx) && !jqueued(J_DEL, idx) && !((cur.type == J_READ || cur.type == J_DEL) && cur.to == idx)) { Job j = { J_READ, idx, 0, 0, 0, 0, 0 }; jpush(j, 0, 0); } }
    else if (starts(PSTR("+CMGR:"))) { fCmgr = 1; quoted_ucs2(2, rdNum, sizeof rdNum); body = 1; bodyN = 0; bodyU = 0; rdLen = 0; ln = 0; return; }
    else if (starts(PSTR("+CMGS:"))) fSent = 1;
    else if (starts(PSTR("+COLP:"))) fAns = 1;
    else if (starts(PSTR("NO CARRIER")) || starts(PSTR("BUSY")) || starts(PSTR("NO ANSWER")) || starts(PSTR("NO DIALTONE"))) fEnd = 1;
    else if (starts(PSTR("RDY")) || starts(PSTR("SMS Ready")) || starts(PSTR("Call Ready")) || starts(PSTR("+CPIN: NOT"))) {
        if (gOk && cur.type != J_INIT) { gOk = 0; initAt = T + 1500; cur.type = J_NONE; nRestart++; }   /* the module restarted (supply dip): its settings are gone, set it up again */
    }
    else if (starts(PSTR("RING"))) { fRing = 1; busyUntil = T + 2000; }
    else if (starts(PSTR("+CMGF:"))) gMode = (uint8_t)(num_after(6) + 1);
    else if (starts(PSTR("+CSQ:"))) { uint8_t v = num_after(5); gCsq = v == 99 || v == 0 ? 0 : v < 10 ? 1 : v < 15 ? 2 : v < 20 ? 3 : v < 25 ? 4 : 5; }
    else if (starts(PSTR("+CREG:"))) { uint8_t i = 0; while (i < ln && gl[i] != ',') i++; uint8_t s = num_after(i); gReg = s == 1 || s == 5; }
    else if (starts(PSTR("+CUSD:"))) {
        uint8_t i = 0, q = 0; cusLen = 0;
        while (i < ln && !q) { if (gl[i] == '"') q = 1; i++; }
        while (i + 3 < ln && gl[i] != '"' && cusLen < 70) { cus[cusLen++] = (uint16_t)(hexv(gl[i]) << 12 | hexv(gl[i + 1]) << 8 | hexv(gl[i + 2]) << 4 | hexv(gl[i + 3])); i += 4; }
        fCusd = 1;
    }
    else if (imsiWait && ln >= 5 && gl[0] == '4' && gl[1] == '3' && gl[2] == '2') {
        uint8_t m = (uint8_t)((gl[3] - '0') * 10 + gl[4] - '0');
        gOp = m == 11 ? 1 : m == 35 ? 2 : m == 20 ? 3 : 0; imsiWait = 0;
    }
    ln = 0;
}
static void gsm_rx(void)
{
    while (rxt != rxh) {
        uint8_t c = rxb[rxt++];
        if (body) {                                         /* the SMS text: UCS2 hex, decoded on the fly */
            if (c == '\n') { body = 0; continue; }
            if (c == '\r') continue;
            bodyU = (uint16_t)(bodyU << 4 | hexv(c));
            if (++bodyN == 4) { bodyN = 0; if (rdLen < sizeof rdBody / 2) rdBody[rdLen++] = bodyU; bodyU = 0; }
            continue;
        }
        if (c == '>' && ln == 0) { fPrompt = 1; continue; }
        if (c == '\r') continue;
        if (c == '\n') { on_line(); ln = 0; continue; }
        if (ln < sizeof gl) gl[ln++] = c;
    }
}

/* ---------------- texts ---------------- */
static uint8_t is_en(uint8_t to) { return (N.en >> to) & 1; }
static void mput(uint16_t u) { if (msgLen < sizeof msg / 2) msg[msgLen++] = u; }
static void mnum(uint8_t v, uint8_t en) { if (v >= 10) mnum((uint8_t)(v / 10), en); mput((uint16_t)((en ? '0' : 0x06F0) + v % 10)); }
static void mzones(uint8_t m, uint8_t en) { uint8_t f = 1; for (uint8_t i = 0; i < 3; i++) if ((m >> i) & 1) { if (!f) mput(en ? ',' : 0x060C); mnum((uint8_t)(i + 1), en); f = 0; } }
static uint16_t poleMask;                               /* from M4 over bus C */
static void mtext(uint8_t tm, uint8_t en, uint8_t a1, uint8_t a2);
static void marg(uint8_t tm, uint8_t which, uint8_t a, uint8_t en)
{
    if (tm == T_STATUS) {
        if (which == 0) { if (armed) mtext(T_ST_ON, en, armed, 0); else mtext(T_ST_OFF, en, 0, 0); }
        else if (which == 1) { if (!poleMask) mtext(T_NONE, en, 0, 0); else { uint8_t f = 1; for (uint8_t i = 0; i < 15; i++) if ((poleMask >> i) & 1) { if (!f) mput(en ? ',' : 0x060C); mnum((uint8_t)(i + 1), en); f = 0; } } }
        else mnum(gCsq, en);
        return;
    }
    if (tm == T_ON || tm == T_ST_ON || tm == T_ZOFF || tm == T_KEYON || tm == T_REMON || tm == T_SIREN || tm == T_AUTO) mzones(a, en);
    else mnum(a, en);
}
static void mtext(uint8_t tm, uint8_t en, uint8_t a1, uint8_t a2)
{
    const uint16_t *p = (const uint16_t *)pgm_read_word(&TXT[tm][en]);
    uint16_t u;
    while ((u = pgm_read_word(p++))) {
        if (u == '#') marg(tm, 0, a1, en); else if (u == '%') marg(tm, 1, a2, en); else if (u == '&') marg(tm, 2, 0, en); else mput(u);
    }
}
static void compose(const Job *j)
{
    uint8_t en = is_en(j->to);
    msgLen = 0;
    if (j->tm == TM_MACHINE) {
        static const char H[] = "0123456789ABCDEF";
        mput('#'); mput('S'); mput('D'); mput(',');
        mnum(al_view(), 1); mput(','); mnum(armed, 1); mput(','); mnum(sensOpen, 1); mput(',');
        for (int8_t sh = 12; sh >= 0; sh -= 4) mput((uint16_t)H[(poleMask >> sh) & 15]);
        mput(','); mnum(gCsq, 1); mput(',');
        if (cred[0]) for (uint8_t i = 0; cred[i]; i++) mput((uint16_t)cred[i]); else mput('-');
        mput('#');
        return;
    }
    if (j->tm == TM_CREDIT) { if (cusLen) for (uint8_t i = 0; i < cusLen; i++) mput(cus[i]); else mtext(T_NOCRED, en, 0, 0); return; }
    mtext(j->tm, en, j->a1, j->a2);
    if (j->by) mtext(T_BY, en, j->by, 0);
}

/* ---------------- what the panel tells the users ---------------- */
static uint8_t has_sms(uint8_t i) { return N.sms[i][0] != 0; }
static void sms_to(uint8_t to, uint8_t tm, uint8_t a1, uint8_t a2, uint8_t by, uint8_t front, uint8_t at, uint8_t alarm)
{
    if (!has_sms(to)) return;
    Job j = { J_SMS, to, tm, a1, a2, by, alarm, 0 };
    jpush(j, front, at);
}
static void notify_all(uint8_t tm, uint8_t a1, uint8_t calls)   /* an event: every SMS number, then the calls */
{
    for (uint8_t i = 0; i < 3; i++) sms_to(i, tm, a1, 0, 0, 0, 0, calls);
    if (calls) { callAns = 0; callRound = 0; for (uint8_t i = 0; i < 3; i++) if (N.call[i][0]) { Job j = { J_CALL, i, 0, 0, 0, 0, 1 }; jpush(j, 0, 0); } }
}
/* the answer to the user first, then the others ("by user N") right after it */
static void answer(uint8_t user, uint8_t tm, uint8_t a1, uint8_t a2, uint8_t share)
{
    sms_to(user, smsMach ? TM_MACHINE : tm, a1, a2, 0, 1, 0, 0);
    if (!share) return;
    uint8_t at = 1;
    for (uint8_t i = 0; i < 3; i++) if (i != user && has_sms(i)) { sms_to(i, tm, a1, a2, (uint8_t)(user + 1), 1, at, 0); at++; }
}

/* ---------------- SMS commands ---------------- */
/* command words: from the EEPROM table when the software has written one (later), else the defaults */
static uint16_t wch(uint8_t w, uint8_t alt, uint8_t k) { const uint16_t *p = (const uint16_t *)pgm_read_word(&WORD_DEF[w][alt]); return pgm_read_word(p + k); }
static uint8_t cmdLen, cmdPos; static uint16_t cmd[48];
static uint8_t mword(uint8_t w)                          /* the word at cmdPos (English or Persian): moves on, 1 = found */
{
    for (uint8_t alt = 0; alt < 2; alt++) {
        uint8_t k = 0; uint16_t u;
        while ((u = wch(w, alt, k)) && cmdPos + k < cmdLen && cmd[cmdPos + k] == u) k++;
        if (!u && k) { cmdPos = (uint8_t)(cmdPos + k); return 1; }
    }
    return 0;
}
static uint8_t at_end(void) { return cmdPos == cmdLen; }
static void normalise(void)
{
    cmdLen = 0;
    for (uint8_t i = 0; i < rdLen; i++) {
        uint16_t u = rdBody[i];
        if (u >= 0x06F0 && u <= 0x06F9) u = (uint16_t)('0' + u - 0x06F0);       /* Persian digits */
        else if (u >= 0x0660 && u <= 0x0669) u = (uint16_t)('0' + u - 0x0660);  /* Arabic digits */
        else if (u == 0x064A || u == 0x0649) u = 0x06CC;                        /* ي ى -> ی */
        else if (u == 0x0643) u = 0x06A9;                                        /* ك -> ک */
        else if (u >= 'a' && u <= 'z') u = (uint16_t)(u - 32);
        if (u == ' ' || u == 0x200C || u == 0x200F || u == 0x200E || u == '\n' || u == '\r' || u == '\t' || u == 0xA0) continue;
        if (cmdLen < sizeof cmd / 2) cmd[cmdLen++] = u;
    }
}
static void busB_send(uint8_t c, uint8_t a);
static void arm_by(uint8_t m, uint8_t src, uint8_t user);
static void disarm_by(uint8_t m, uint8_t src, uint8_t user);
enum { SRC_KEY, SRC_REMOTE, SRC_SMS, SRC_APP };
static uint8_t curSms(void) { return (C.mag & 4) != 0; }        /* settings: curtains by SMS (off by default) */
static void sms_cmd2(uint8_t user, uint8_t cb);
static void sms_command(uint8_t user)
{
    normalise();
    uint8_t cb = 0;
    smsMach = cmdLen && cmd[0] == '#';                 /* the phone app: "#..." and a machine answer */
    if (smsMach) smsHold = T + 1500;                   /* its answer waits for M4's new pole states (bus C) */
    if (smsMach) cb = 1;
    if (locked == 2) answer(user, T_LOCKED, 0, 0, 0);   /* the exit scenario runs: the panel takes no command now */
    else sms_cmd2(user, cb);
    smsMach = 0;
}
static void sms_cmd2(uint8_t user, uint8_t cb)
{
    cmdPos = cb;
    uint8_t z = 0, d = 0, nd = 0;
    while (cmdPos < cmdLen && cmd[cmdPos] >= '1' && cmd[cmdPos] <= '3') { z |= (uint8_t)(1 << (cmd[cmdPos] - '1')); cmdPos++; nd = 1; }
    uint8_t p0 = cmdPos;
    if (mword(W_ON) && at_end()) { uint8_t m = zones_ok(nd ? z : 7); if (!m || (armed & m) == m) answer(user, T_ALREADY, 0, 0, 0); else arm_by((uint8_t)(armed | m), SRC_SMS, user); return; }
    cmdPos = p0;
    if (mword(W_OFF) && at_end()) { disarm_by(nd ? z : 7, SRC_SMS, user); return; }
    if (nd) { answer(user, T_BAD, 0, 0, 0); return; }
    cmdPos = cb;
    if (mword(W_FAST) && at_end()) { uint8_t m = zones_ok(7); if ((armed & m) == m) answer(user, T_ALREADY, 0, 0, 0); else arm_by((uint8_t)(m | R_FAST), SRC_SMS, user); return; }
    cmdPos = cb;
    if (mword(W_SCN) && mword(W_OFF) && at_end()) { busB_send(2, 5); answer(user, T_SCNALL, 0, 0, 1); return; }   /* SOFF: every scenario off */
    cmdPos = cb;
    if (mword(W_SCN) && cmdPos < cmdLen && (d = (uint8_t)(cmd[cmdPos] - '0')) >= 1 && d <= 4) {
        cmdPos++; uint8_t p = cmdPos;
        if (mword(W_ON) && at_end()) { busB_send(1, d); answer(user, T_SCNON, d, 0, 1); return; }
        cmdPos = p;
        if (mword(W_OFF) && at_end()) { busB_send(2, d); answer(user, T_SCNOFF, d, 0, 1); return; }
    }
    cmdPos = cb;
    if (mword(W_KEY) && cmdPos < cmdLen && (d = (uint8_t)(cmd[cmdPos] - '0')) >= 1 && d <= 3) {
        cmdPos++; uint8_t p = cmdPos;
        if (mword(W_ON) && at_end()) { busB_send(3, d); poleMask |= (uint16_t)(1 << (d + 11)); answer(user, T_KON, d, 0, 1); return; }
        cmdPos = p;
        if (mword(W_OFF) && at_end()) { busB_send(4, d); poleMask &= (uint16_t)~(1 << (d + 11)); answer(user, T_KOFF, d, 0, 1); return; }
    }
    cmdPos = cb;
    if (mword(W_POLE) && cmdPos < cmdLen && cmd[cmdPos] >= '0' && cmd[cmdPos] <= '9') {   /* poles 1..12: L5ON, L12OFF */
        d = (uint8_t)(cmd[cmdPos++] - '0');
        if (cmdPos < cmdLen && cmd[cmdPos] >= '0' && cmd[cmdPos] <= '9') d = (uint8_t)(d * 10 + cmd[cmdPos++] - '0');
        if (d >= 1 && d <= 12) {
            uint8_t p = cmdPos;
            if (mword(W_ON) && at_end()) { bb_pole(d, 1); answer(user, T_PON, d, 0, 1); return; }
            cmdPos = p;
            if (mword(W_OFF) && at_end()) { bb_pole(d, 0); answer(user, T_POFF, d, 0, 1); return; }
        }
    }
    cmdPos = cb;
    if ((curSms() || smsMach) && mword(W_CUR) && cmdPos < cmdLen && (d = (uint8_t)(cmd[cmdPos] - '0')) >= 1 && d <= 2) {
        cmdPos++; uint8_t p = cmdPos, base = (uint8_t)((d - 1) * 3);
        if (mword(W_OPEN) && at_end()) { busB_send(5, (uint8_t)(base + 1)); answer(user, T_COPEN, d, 0, 1); return; }
        cmdPos = p;
        if (mword(W_CLOSE) && at_end()) { busB_send(5, (uint8_t)(base + 2)); answer(user, T_CCLOSE, d, 0, 1); return; }
        cmdPos = p;
        if (mword(W_STOP) && at_end()) { busB_send(5, (uint8_t)(base + 3)); answer(user, T_CSTOP, d, 0, 1); return; }
    }
    cmdPos = cb; if (mword(W_STATUS) && at_end()) { answer(user, T_STATUS, 0, 0, 0); return; }
    cmdPos = cb; if (mword(W_CREDIT) && at_end()) { Job j = { J_USSD, user, 0, smsMach, 0, 0, 0, 0 }; jpush(j, 1, 0); return; }
    cmdPos = cb; if (mword(W_FA) && at_end()) { N.en &= (uint8_t)~(1 << user); nums_save(); answer(user, T_LANG, 0, 0, 0); return; }
    cmdPos = cb; if (mword(W_EN) && at_end()) { N.en |= (uint8_t)(1 << user); nums_save(); answer(user, T_LANG, 0, 0, 0); return; }
    answer(user, T_BAD, 0, 0, 0);
}

/* ---------------- the job runner ---------------- */
static void cmdp(const char *p, uint16_t ms) { fOK = fERR = 0; txp(p); dl = T + ms; }
static void next(void) { step++; }
static void done(void) { cur.type = J_NONE; }
static uint8_t timed(void) { return T > dl; }
/* the credit in the operator's answer: the first number of 3 digits or more (separators , ٬ . skipped); app told over bus B */
static void bb_credit(void);
static void cred_parse(uint8_t got)
{
    char b[12]; uint8_t n = 0, best = 0;
    if (got) for (uint8_t i = 0; i < cusLen && !best; i++) {
        uint16_t u = cus[i]; int8_t dg = -1;
        if (u >= '0' && u <= '9') dg = (int8_t)(u - '0'); else if (u >= 0x06F0 && u <= 0x06F9) dg = (int8_t)(u - 0x06F0); else if (u >= 0x0660 && u <= 0x0669) dg = (int8_t)(u - 0x0660);
        if (dg >= 0) { if (n < sizeof b - 1) b[n++] = (char)('0' + dg); }
        else if (n && (u == ',' || u == 0x066C || u == 0x060C) && i + 1 < cusLen) continue;
        else { if (n >= 3) best = 1; else n = 0; }
    }
    if (n >= 3) best = 1;
    if (best) { b[n] = 0; strcpy(cred, b); } else cred[0] = 0;
    bb_credit();
}
static void ussd_code(void)
{
    const char *c = gOp == 2 ? PSTR("*141*1#") : gOp == 3 ? PSTR("*140#") : PSTR("*140*11#");
    char ch; while ((ch = (char)pgm_read_byte(c++))) txhex4((uint8_t)ch);
}
static void sms_fail(void)
{
    Job j = cur; done();
    if (!j.tries) { j.tries = 1; jpush(j, 1, 0); }                 /* once more, first in the queue */
    if (++nFail >= 2) { nFail = 0; gOk = 0; initAt = T + 1000; nRestart++; }   /* twice in a row: set the module up again (the retry waits for it) */
}
static void run_job(void)
{
    switch (cur.type) {
    case J_INIT: {
        static const char S0[] PROGMEM = "ATE0\r", S1[] PROGMEM = "AT+CMGF=1\r", S2[] PROGMEM = "AT+CSCS=\"UCS2\"\r", S3[] PROGMEM = "AT+CSMP=17,167,0,8\r",
            S4[] PROGMEM = "AT+CNMI=2,1,0,0,0\r", S5[] PROGMEM = "AT+COLP=1\r", S6[] PROGMEM = "AT+CIMI\r";
        static const char *const S[] PROGMEM = { S0, S1, S2, S3, S4, S5, S6 };
        if (step == 0) { cmdp(PSTR("AT\r"), 1500); step = 1; break; }
        if (fOK) {
            uint8_t k = (uint8_t)(step - 1);
            if (k < 7) { if (k == 6) imsiWait = 1; cmdp((const char *)pgm_read_word(&S[k]), 3000); step++; }
            else { imsiWait = 0; gOk = 1; done(); Job a = { J_LIST, 0, 0, 0, 0, 0, 0 }, b = { J_CSQ, 0, 0, 0, 0, 0, 0 }; jpush(a, 0, 0); jpush(b, 0, 0); }
            break;
        }
        if (fERR || timed()) { gOk = 0; initAt = T + 30000; done(); }   /* no module / no answer: again in 30 s */
        break;
    }
    case J_LIST:      /* every message still in the SIM: "ALL" in UCS2 */
        if (step == 0) { cmdp(PSTR("AT+CMGL=\"0041004C004C\"\r"), 8000); next(); }
        else if (fOK) done();
        else if (fERR || timed()) { done(); Job a = { J_AT, 0, 0, 0, 0, 0, 0, 0 }; jpush(a, 1, 0); }   /* refused / no answer (SIM not ready yet, ...): is the module alive at all? the list again in 60 s */
        break;
    case J_AT:        /* still in text mode (our settings kept): the module is fine, the list again in 60 s; PDU mode / silent: it restarted, set it up again */
        if (step == 0) { gMode = 0; cmdp(PSTR("AT+CMGF?\r"), 2000); next(); }
        else if (fOK && gMode == 2) done();
        else if (fOK || fERR || timed()) { done(); gOk = 0; initAt = T + 1000; nRestart++; }
        break;
    case J_CSQ:
        if (step == 0) { cmdp(PSTR("AT+CSQ\r"), 3000); next(); }
        else if (step == 1) { if (fOK || fERR || timed()) { cmdp(PSTR("AT+CREG?\r"), 3000); next(); } }
        else if (fOK || fERR || timed()) done();
        break;
    case J_READ:
        if (step == 0) { rdNum[0] = 0; rdLen = 0; fOK = fERR = fCmgr = 0; txp(PSTR("AT+CMGR=")); { char b[4]; utoa(cur.to, b, 10); txs(b); } tx('\r'); dl = T + 5000; next(); }
        else if ((fOK && fCmgr) || fERR || timed()) {   /* the message read (an OK left over from before does not count): act and answer first, delete after the answer */
            Job d = { J_DEL, cur.to, 0, 0, 0, 0, 0, 0 };
            done();
            if (rdNum[0]) { for (uint8_t i = 0; i < 3; i++) if (has_sms(i) && num_same(rdNum, N.sms[i])) { sms_command(i); break; } }   /* unknown numbers: read, deleted, no answer */
            jpush(d, 0, 0);
        }
        break;
    case J_DEL:
        if (step == 0) { fOK = fERR = 0; txp(PSTR("AT+CMGD=")); { char b[4]; utoa(cur.to, b, 10); txs(b); } tx('\r'); dl = T + 5000; next(); }
        else if (fOK || fERR || timed()) done();
        break;
    case J_SMS:
        if (step == 0) { compose(&cur); chunk = 0; next(); }
        if (step == 1) { fPrompt = fERR = 0; txp(PSTR("AT+CMGS=\"")); txnum_ucs2(N.sms[cur.to]); txp(PSTR("\"\r")); dl = T + 10000; next(); }
        else if (step == 2) {
            if (fPrompt) { uint8_t e = (uint8_t)(chunk + 67 < msgLen ? chunk + 67 : msgLen); for (uint8_t i = chunk; i < e; i++) txhex4(msg[i]); chunk = e; fOK = fERR = fSent = 0; tx(0x1A); dl = T + 60000; next(); }
            else if (fERR || timed()) { tx(0x1B); sms_fail(); }
        }
        else if (step == 3) { if (fOK) { nFail = 0; if (chunk < msgLen) step = 1; else done(); } else if (fERR || timed()) sms_fail(); }
        break;
    case J_CALL:
        if (step == 0) { if (callAns || !N.call[cur.to][0]) { done(); break; } fOK = fERR = fAns = fEnd = 0; txp(PSTR("ATD")); txs(N.call[cur.to]); txp(PSTR(";\r")); dl = T + 20000; next(); }
        else if (step == 1) {
            if (fAns) { callAns = 1; dl = T + 15000; step = 2; }          /* answered: 15 s of gl, no more calls */
            else if (fEnd || fERR || timed()) { txp(PSTR("ATH\r")); dl = T + 2000; step = 3; }
        }
        else if (step == 2) { if (fEnd || timed()) { txp(PSTR("ATH\r")); dl = T + 2000; step = 3; } }
        else if (timed() || fOK) {
            done();
            uint8_t more = 0; for (uint8_t i = 0; i < jn; i++) if (jq[i].type == J_CALL) more = 1;
            if (!more && !callAns && !callRound && armed) { callRound = 1; for (uint8_t i = 0; i < 3; i++) if (N.call[i][0]) { Job j = { J_CALL, i, 0, 0, 0, 0, 1 }; jpush(j, 0, 0); } }
        }
        break;
    case J_USSD:
        if (step == 0) { cusLen = 0; fCusd = fOK = fERR = 0; txp(PSTR("AT+CUSD=1,\"")); ussd_code(); txp(PSTR("\"\r")); dl = T + 20000; next(); }
        else if (fCusd || fERR || timed()) {
            Job j = cur; done(); cred_parse(fCusd);
            if (j.to < 3) sms_to(j.to, j.a1 ? TM_MACHINE : TM_CREDIT, 0, 0, 0, 1, 0, 0);   /* to = 0xFF: asked by the app over Wi-Fi */
        }
        break;
    default: done();
    }
}
static void gsm_init(void)
{
    UBRR0H = 0; UBRR0L = 51;                              /* 9600 at 8 MHz */
    UCSR0C = _BV(UCSZ01) | _BV(UCSZ00); UCSR0B = _BV(RXEN0) | _BV(TXEN0) | _BV(RXCIE0);
    nums_load();
    initAt = T + 6000;                                    /* the module starts up */
}
static void gsm_tick(void)
{
    gsm_rx();
    if (fRing && cur.type == J_NONE) { fRing = 0; txp(PSTR("ATH\r")); }   /* calls to the panel: hung up */
    if (cur.type == J_NONE) {
        if (!gOk) {   /* two set-ups at least 10 s apart: a module that keeps restarting does not blink the antenna / indicator D fast */
            static uint32_t lastInit; static uint8_t inits;
            if (T >= initAt && (!inits || T - lastInit >= 10000)) { inits = 1; lastInit = T; cur.type = J_INIT; step = 0; initAt = T + 30000; }
            return;
        }
        if (T >= nextList) { nextList = T + 60000; if (!jqueued(J_LIST, 0)) { Job j = { J_LIST, 0, 0, 0, 0, 0, 0 }; jpush(j, 0, 0); } }
        if (T >= nextCsq) { nextCsq = T + 10000; if (!jqueued(J_CSQ, 0)) { Job j = { J_CSQ, 0, 0, 0, 0, 0, 0 }; jpush(j, 0, 0); } }
        if (!jn) return;
        if (jq[0].type == J_SMS && T < smsHold) return;
        cur = jq[0]; jn--; memmove(&jq[0], &jq[1], jn * sizeof(Job)); step = 0;
    }
    if (cur.type >= J_READ && cur.type != J_AT) busyUntil = T + 2000;        /* radio work (an SMS in or out, a call, USSD): touches wait; AT queries do not */
    run_job();
}
/* SIM state for indicator D on the panel: 0 no SIM / no module, 1 weak signal or no network, 2 good (3 bars of 5 or more) */
static uint8_t sim_state(void) { if (!gOk) return 0; return (gReg && gCsq >= 3) ? 2 : 1; }
static uint8_t gsm_busy(void) { return (cur.type >= J_READ && cur.type != J_AT) || T < busyUntil; }
