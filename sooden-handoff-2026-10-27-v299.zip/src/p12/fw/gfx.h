/* SSD1306 128x64 on software I2C (SCL = PD6, SDA = PD5, open drain), with a 1 KB frame buffer:
   draw in RAM, then fb_push() sends the pages that changed. Start-up sequence as the panel's original firmware. */
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <string.h>
#include "font.h"
#include "words.h"
#define OL_ADDR 0x78
#define SCL_LO() (DDRD |= _BV(6))
#define SCL_HI() (DDRD &= (uint8_t)~_BV(6))
#define SDA_LO() (DDRD |= _BV(5))
#define SDA_HI() (DDRD &= (uint8_t)~_BV(5))
static void i2_d(void) { _delay_us(2); }
static void i2_start(void) { SDA_HI(); SCL_HI(); i2_d(); SDA_LO(); i2_d(); SCL_LO(); i2_d(); }
static void i2_stop(void) { SDA_LO(); i2_d(); SCL_HI(); i2_d(); SDA_HI(); i2_d(); }
static void i2_wr(uint8_t b)
{
    for (uint8_t m = 0x80; m; m >>= 1) { if (b & m) SDA_HI(); else SDA_LO(); i2_d(); SCL_HI(); i2_d(); SCL_LO(); }
    SDA_HI(); i2_d(); SCL_HI(); i2_d(); SCL_LO(); i2_d();
}
static void ol_cmd(uint8_t c) { i2_start(); i2_wr(OL_ADDR); i2_wr(0x00); i2_wr(c); i2_stop(); }

static uint8_t fb[8][128];
static uint16_t sentH[8];                  /* hash of each page as last sent */
static uint16_t phash(const uint8_t *p) { uint16_t h = 0x1D0F; for (uint8_t i = 0; i < 128; i++) h = (uint16_t)((h << 5) + (h >> 11) + p[i] + i); return h; }
static uint8_t fbAll;                       /* 1 = send every page */
static void fb_push(void)
{
    for (uint8_t p = 0; p < 8; p++) {
        uint16_t h = phash(fb[p]);
        if (!fbAll && h == sentH[p]) continue;
        ol_cmd((uint8_t)(0xB0 | p)); ol_cmd(0x00); ol_cmd(0x10);
        i2_start(); i2_wr(OL_ADDR); i2_wr(0x40);
#ifdef OLED_SH1106
        /* 1.3" SH1106: 132 columns; the picture goes to columns 2..129 and the 4 unused ones are cleared (no stray line at the edge) */
        i2_wr(0); i2_wr(0);
        for (uint8_t i = 0; i < 128; i++) i2_wr(fb[p][i]);
        i2_wr(0); i2_wr(0);
#else
        for (uint8_t i = 0; i < 128; i++) i2_wr(fb[p][i]);
#endif
        i2_stop();
        sentH[p] = h;
    }
    fbAll = 0;
}
static void ol_init(void)
{
    PORTD &= (uint8_t)~(_BV(5) | _BV(6)); SCL_HI(); SDA_HI();
    _delay_ms(50);
    static const uint8_t seq[] PROGMEM = { 0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40, 0x8D, 0x14, 0x20, 0x02,
        0xA1, 0xC8, 0xDA, 0x12, 0x81, 0xCF, 0xD9, 0xF1, 0xDB, 0x40, 0xA4, 0xA6, 0xAF };
    for (uint8_t i = 0; i < sizeof seq; i++) ol_cmd(pgm_read_byte(&seq[i]));
    memset(fb, 0, sizeof fb); fbAll = 1; fb_push();
}
/* ---- drawing ---- */
static void clr(void) { memset(fb, 0, sizeof fb); }
static void px(int16_t x, int16_t y) { if (x >= 0 && x < 128 && y >= 0 && y < 64) fb[y >> 3][x] |= (uint8_t)(1 << (y & 7)); }
static void hline(int16_t x0, int16_t x1, int16_t y) { for (int16_t x = x0; x <= x1; x++) px(x, y); }
static void vline(int16_t x, int16_t y0, int16_t y1) { for (int16_t y = y0; y <= y1; y++) px(x, y); }
static void rect(int16_t x, int16_t y, int16_t w, int16_t h) { for (int16_t j = 0; j < h; j++) hline(x, x + w - 1, y + j); }
static void circle(int16_t cx, int16_t cy, int8_t r, uint8_t fill)
{
    for (int16_t y = -r; y <= r; y++) for (int16_t x = -r; x <= r; x++) {
        int16_t d = x * x + y * y;
        if (fill ? d <= r * r + r / 2 : (d <= r * r + r && d >= (r - 1) * (r - 1))) px(cx + x, cy + y);
    }
}
static void line(int16_t x0, int16_t y0, int16_t x1, int16_t y1)
{
    int16_t dx = x1 > x0 ? x1 - x0 : x0 - x1, dy = y1 > y0 ? y0 - y1 : y1 - y0, sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, e = dx + dy;
    for (;;) { px(x0, y0); if (x0 == x1 && y0 == y1) break; int16_t e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; } }
}
static void chr(int16_t x, int16_t y, char c, uint8_t sc)       /* 5x7 font, scale sc */
{
    if (c < 32 || c > 126) c = '?';
    for (uint8_t i = 0; i < 5; i++) {
        uint8_t col = pgm_read_byte(&FONT[c - 32][i]);
        for (uint8_t j = 0; j < 8; j++) if (col & (1 << j))
            for (uint8_t a = 0; a < sc; a++) for (uint8_t b = 0; b < sc; b++) px(x + i * sc + a, y + j * sc + b);
    }
}
static void str(int16_t x, int16_t y, const char *s, uint8_t sc) { for (; *s; s++, x += 6 * sc) chr(x, y, *s, sc); }
__attribute__((unused)) static uint8_t strw(const char *s, uint8_t sc) { uint8_t n = 0; while (*s++) n++; return (uint8_t)(n * 6 * sc - sc); }
static void word(const uint8_t *w, int16_t x, int16_t y)       /* a PROGMEM word bitmap at x, y (top left) */
{
    uint8_t wd = pgm_read_byte(&w[0]), pg = pgm_read_byte(&w[1]);
    for (uint8_t p = 0; p < pg; p++) for (uint8_t i = 0; i < wd; i++) {
        uint8_t v = pgm_read_byte(&w[2 + p * wd + i]);
        for (uint8_t k = 0; k < 8; k++) if (v & (1 << k)) px(x + i, y + p * 8 + k);
    }
}
__attribute__((unused)) static void wordc(const uint8_t *w, int16_t cy) { uint8_t wd = pgm_read_byte(&w[0]), pg = pgm_read_byte(&w[1]); word(w, 64 - wd / 2, cy - pg * 4); }
