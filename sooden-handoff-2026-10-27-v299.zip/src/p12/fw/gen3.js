// alarm OLED words (bold DejaVu Sans), each word its own rows
const { chromium } = require('playwright');
const W = [['A_OFF','دزدگیر خاموش',16],['A_ON','دزدگیر روشن',16],['A_HINT','روشن کردن: ON/OFF',11],['A_PREP','آماده‌سازی سنسورها',11],
 ['A_SEL','انتخاب زون‌ها',14],['A_OKNEXT','OK = ادامه',11],['A_PASS','رمز را وارد کنید',14],['A_PCUR','رمز فعلی',14],['A_PNEW','رمز جدید',14],['A_PREP2','تکرار رمز جدید',14],
 ['A_SEC','ثانیه',13],['A_SET','تنظیمات',12],['A_CHPW','تغییر رمز',16],['A_SMS','شماره‌های پیامک',14],['A_CALL','شمارهٔ تماس',15],['A_OKIN','OK = ورود',11],['A_LATER','در مرحلهٔ پیامک',11],
 ['A_EXIT','فرصت خروج',16],['A_ZONE','زون',15],['A_ALERT','هشدار',22],['A_MAG','مگنت',17],['A_ARMED','دزدگیر روشن شد',14],['A_DISARMED','دزدگیر خاموش شد',14],
 ['A_WRONG','رمز اشتباه',16],['A_PWOK','رمز عوض شد',16],['A_PWBAD','تکرار رمز اشتباه',15],['A_MAGOPEN','مگنت باز شد',16],
 ['A_RLEARN','ریموت را بزنید',15],['A_ROK','ریموت ثبت شد',16],['A_RCLR','ریموت‌ها پاک شد',15],['A_RFULL','حافظه ریموت پر',13],['A_NOACT','دکمه بدون کار',14],['A_CALLS','شماره‌های تماس',14],['A_OKSAVE','OK: ذخیره   C: پاک',11],['A_SAVED','ذخیره شد',16],['A_EMPTY','خالی',11]];
(async()=>{const b=await chromium.launch();const p=await b.newPage();
 const out=await p.evaluate((W)=>W.map(([n,t,sz])=>{const c=document.createElement('canvas');c.width=200;c.height=48;const x=c.getContext('2d');
  x.fillStyle='#000';x.fillRect(0,0,200,48);x.fillStyle='#fff';x.font='bold '+sz+'px "DejaVu Sans"';x.textBaseline='middle';x.textAlign='center';x.direction='rtl';x.fillText(t,100,24);
  const d=x.getImageData(0,0,200,48).data;const on=(i,j)=>d[(j*200+i)*4]>80;let x0=200,x1=-1,y0=48,y1=-1;
  for(let j=0;j<48;j++)for(let i=0;i<200;i++)if(on(i,j)){x0=Math.min(x0,i);x1=Math.max(x1,i);y0=Math.min(y0,j);y1=Math.max(y1,j);}
  const w=x1-x0+1,h=y1-y0+1,pages=Math.ceil(h/8),bytes=[];
  for(let pg=0;pg<pages;pg++)for(let i=0;i<w;i++){let v=0;for(let k=0;k<8;k++){const j=y0+pg*8+k;if(j<=y1&&on(x0+i,j))v|=1<<k;}bytes.push(v);}
  return {n,w,h,pages,bytes};}),W);
 let s='/* alarm OLED words (made by gen3.js): width, pages, columns page by page */\n';
 for(const o of out){if(o.w>128)throw o.n+' too wide';s+=`static const uint8_t ${o.n}[] PROGMEM = { ${o.w}, ${o.pages}, ${o.bytes.map(v=>'0x'+v.toString(16).padStart(2,'0')).join(',')} };\n`;console.log(o.n,o.w,o.h);}
 require('fs').writeFileSync('words3.h',s);await b.close();})();
