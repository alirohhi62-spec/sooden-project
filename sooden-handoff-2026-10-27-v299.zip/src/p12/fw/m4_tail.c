/* ---------------- outputs ---------------- */
/* bus target of every key (0 = none) */
static const uint8_t TGT[SW_NP] PROGMEM = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,  13, 0, 0,  19, 20, 21, 22, 23, 24,  0, 14,  15, 16, 17, 18 };
static uint8_t sentV[31];
static uint16_t regV[R_N];
static uint8_t refreshI = 1;
static uint32_t refreshAt;
/* power-up motion of the own whites (keys 14 / 15), the same scanner as M1..M3 */
static void motion_whites(uint16_t t)
{
    uint8_t w14 = (t >= 525 && t < 625) || t >= 850, w15 = (t >= 475 && t < 575) || t >= 900;
    PORTG = (uint8_t)((PORTG & (uint8_t)~(_BV(1) | _BV(2) | _BV(0) | _BV(4))) | (w14 ? _BV(1) : 0) | (w15 ? _BV(2) : 0));
}
static void set_reg(uint8_t r, uint16_t v) { if (regV[r - R_FIRST] != v) { regV[r - R_FIRST] = v; send((uint8_t)(0x80 | r), v, 1); } }

/* ---------------- clock (counted here; starts at Saturday 1405/01/01 00:00 after power-up, the app will set it) ---------------- */
static uint8_t cH, cM, cS, cWd, cMo = 1, cD = 1;
static uint16_t cY = 1405;
static uint8_t leap(uint16_t y) { uint8_t r = (uint8_t)(y % 33); return r == 1 || r == 5 || r == 9 || r == 13 || r == 17 || r == 22 || r == 26 || r == 30; }
static uint8_t mdays(void) { return cMo <= 6 ? 31 : cMo <= 11 ? 30 : leap(cY) ? 30 : 29; }
static void clock_sec(void)
{
    if (++cS < 60) return;
    cS = 0; if (++cM < 60) return;
    cM = 0; if (++cH < 24) return;
    cH = 0; cWd = (uint8_t)((cWd + 1) % 7);
    if (++cD <= mdays()) return;
    cD = 1; if (++cMo <= 12) return;
    cMo = 1; cY++;
}

/* ---------------- curtains: where each one is (0..1000 = closed..open), from the run time ---------------- */
#define EE_POS 0x7F0
static const uint8_t CK[2][2] = { { K_P1O, K_P1C }, { K_P2O, K_P2C } };
static uint16_t pos[2], pacc[2];
static uint32_t runMs[2];

/* ---------------- child lock (S6 held 7 s): touches do nothing, the remote still works ---------------- */
#define T_LOCKHOLD 7000

int main(void)
{
    uint8_t why = MCUCSR;
    MCUCSR |= _BV(JTD); MCUCSR |= _BV(JTD);              /* JTAG off: PF4..PF7 */
    MCUCSR = 0;
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0x0D; PORTB = 0xF7;                            /* bus C idle: PB2 PB0 high */
    DDRC = 0x80; PORTC = 0x7F;
    DDRD = 0x7B; PORTD = 0xF3;                            /* bus A idle 11111 */
    DDRE = 0xBE; PORTE = 0xC0;                            /* bus C: PE7 high */
    DDRF = 0xFF; PORTF = 0x7F;                            /* 7-segment dark (common anode) */
    DDRG = 0xFF; PORTG = 0x00;                            /* everything off until the motion */
    OCR0 = 124; TCCR0 = _BV(WGM01) | _BV(CS02);           /* 1 ms */
    TIMSK |= _BV(OCIE0);
    TCCR1A = 0; TCCR1B = _BV(CS11);                       /* 1 us for the remote */
    EICRB = _BV(ISC60); EIFR = _BV(INTF6); EIMSK |= _BV(INT6);

    for (uint16_t i = 0; i < CFG_SIZE; i++) ((uint8_t *)&S.c)[i] = pgm_read_byte(&cfg_flash[i]);
    if (!sw_cfg_ok(&S.c)) defaults(&S.c);
    S.eer = ee_r; S.eew = ee_w;
    for (uint8_t c = 0; c < 2; c++) { pos[c] = eeprom_read_word((const uint16_t *)(EE_POS + 2 * c)); if (pos[c] > 1000) pos[c] = 0; }
    uint32_t t0 = now_ms();
    sei();
    sw_init(&S, &S.c, t0);
    S.logOn = (why & (_BV(PORF) | _BV(BORF))) != 0;
    wdt_enable(WDTO_1S);
    memset(sentV, V_OFF, sizeof sentV);                   /* the boards start with every key off */
    memset(regV, 0xFF, sizeof regV);

    uint8_t kLast = 0, kCnt = 0, wasDim = 0, disp = 0xFF, motionSent = 0, view = 0, movWas = 0;
    uint8_t locked = 0, s6Hold = 0, s6Ok = 0, s6Done = 0;
    uint16_t red12 = 0, s6Ms = 0, clickMs = 0;
    pm_t keys = 0;
    uint32_t motAt = t0 + 300, lastAct = t0, flashUntil = 0, last = t0, overUntil = 0, clkAt = t0;
    uint8_t flashK = 0xFF;
    for (;;) {
        wdt_reset();
        uint32_t now = now_ms();
        if (now == last) continue;
        uint16_t dt = (uint16_t)(now - last);
        last = now;
        while (now - clkAt >= 1000) { clkAt += 1000; clock_sec(); }
        uint8_t inMotion = !motionSent || (now - motAt) < 1500;
        /* touch: the code steady for 3 ms */
        uint8_t r = touch_raw();
        if (r == kLast) { if (kCnt < 255) kCnt++; } else { kLast = r; kCnt = 0; }
        if (kCnt == 3) {
            uint8_t k = r ? pgm_read_byte(&KEYIDX[r - 1]) : NK;
            keys = k == NK ? 0 : BIT(k);
            if (r && !locked && !S.dimmed && !inMotion) {
                lastAct = now;
                if (k != K_P1O && k != K_P1C && k != K_P2O && k != K_P2C && k != K_S(6)) overUntil = now + 5000;   /* the command touched is shown first */
            }
        }
        /* S6: child lock, held 7 s (a touch that only wakes the panel does not count) */
        if (keys & BIT(K_S(6))) {
            if (!s6Hold) { s6Hold = 1; s6Ms = 0; s6Done = 0; s6Ok = !S.dimmed && !inMotion; }
            else if (s6Ms < 65000) s6Ms += dt;
            if (s6Ok && !s6Done && s6Ms >= T_LOCKHOLD) { s6Done = 1; locked = !locked; clickMs = 150; lastAct = now; }
        } else s6Hold = 0;
        pm_t k2 = keys;
        if (!S.dimmed) k2 &= (pm_t)~BIT(K_S(6));            /* S6 is not a scenario key; in standby it only wakes */
        if (locked) { k2 = 0; S.idleSec = 0; }               /* locked: no touch reaches the panel, and no standby */
        sw_tick(&S, now, k2);
        /* custom scenario: stored -> A blinks; run -> its red for a moment */
        if (S.scnEv == 1) { send(TG_A, A_BLINK, 1); lastAct = now; }
        if (S.scnEv == 2) { flashK = S.scnKey; flashUntil = now + 300; }
        S.scnEv = 0;
        /* curtains: position from the run time */
        uint8_t mov = 0;
        for (uint8_t c = 0; c < 2; c++) {
            uint8_t o = (S.red & BIT(CK[c][0])) != 0, cl = (S.red & BIT(CK[c][1])) != 0;
            uint8_t sec = S.c.sec1[CK[c][cl]]; if (!sec) sec = 45;
            if (o || cl) {
                if (!(movWas & (3 << (2 * c)))) { runMs[c] = 0; pacc[c] = 0; view = (uint8_t)(c + 1); overUntil = 0; }
                runMs[c] += dt; pacc[c] += dt;
                while (pacc[c] >= sec) { pacc[c] -= sec; if (o && pos[c] < 1000) pos[c]++; if (cl && pos[c] > 0) pos[c]--; }
                mov |= (uint8_t)((o ? 1 : 2) << (2 * c));
            } else if (movWas & (3 << (2 * c))) eeprom_update_word((uint16_t *)(EE_POS + 2 * c), pos[c]);
        }
        if (view && !(mov & (3 << (2 * (view - 1))))) {       /* the curtain in view stopped: the other one, or the usual view */
            uint8_t other = view == 1 ? 2 : 1;
            view = (mov & (3 << (2 * (other - 1)))) ? other : 0;
            if (!view) { lastAct = now; overUntil = 0; }
        }
        if (mov) lastAct = now;
        movWas = mov;
        /* the power-up motion (and the same when waking from standby) */
        if (!motionSent && (int32_t)(now - motAt) >= 0) {
            send(TG_SYS, SYS_MOTION, 1); motionSent = 1; motAt = now;
            for (uint8_t i = 0; i < sizeof sentV; i++) if (sentV[i] == V_DARK || sentV[i] == 0xFF) sentV[i] = V_OFF;   /* the boards do the same */
        }
        if (S.dimmed) wasDim = 1;
        else if (wasDim) { wasDim = 0; motionSent = 0; motAt = now; lastAct = now; }
        if (S.dimmed) PORTE &= (uint8_t)~_BV(7); else PORTE |= _BV(7);   /* bus C: standby to the alarm MCU */
        if (inMotion) { motion_whites(motionSent ? (uint16_t)(now - motAt) : 0); PORTG &= (uint8_t)~_BV(3); continue; }
        /* own keys 14 and 15, click relay */
        uint8_t g = PORTG & (uint8_t)~(_BV(0) | _BV(1) | _BV(2) | _BV(3) | _BV(4));
        if (S.white & BIT(K_14)) g |= _BV(1);
        if (S.red & BIT(K_14)) g |= _BV(0);
        if (S.white & BIT(K_15)) g |= _BV(2);
        if (S.red & BIT(K_15)) g |= _BV(4);
        if (clickMs) { clickMs = clickMs > dt ? (uint16_t)(clickMs - dt) : 0; g |= _BV(3); }
        if (S.buzz) g |= _BV(3);
        PORTG = g;
        /* the other keys: over bus A, each time one changes */
        for (uint8_t k = 0; k < SW_NP; k++) {
            uint8_t tg = pgm_read_byte(&TGT[k]);
            if (!tg) continue;
            uint8_t v = (S.red & BIT(k)) ? V_ON : (S.white & BIT(k)) ? V_OFF : V_DARK;
            if (k == flashK && (int32_t)(now - flashUntil) < 0) v = V_ON;
            if (k == K_S(6)) v = locked ? V_ON : v;            /* child lock: S6 red */
            if (v != sentV[tg]) { if (v != V_DARK) lastAct = now; sentV[tg] = v; send(tg, v, 1); }
        }
        if ((int32_t)(now - flashUntil) >= 0) flashK = 0xFF;
        /* a pole 1..12 changed (from anywhere): its state is shown first, for 5 s */
        uint16_t r12 = (uint16_t)(S.red & 0x0FFF);
        if (r12 != red12) { red12 = r12; overUntil = now + 5000; lastAct = now; }
        /* OLED data */
        set_reg(R_HOUR, cH); set_reg(R_MIN, cM); set_reg(R_WDAY, cWd); set_reg(R_YEAR, (uint16_t)(cY - 1300)); set_reg(R_MON, cMo); set_reg(R_DAY, cD);
        set_reg(R_POS1, (uint16_t)((pos[0] + 5) / 10)); set_reg(R_POS2, (uint16_t)((pos[1] + 5) / 10)); set_reg(R_MOV, mov);
        if (view) {
            uint8_t c = (uint8_t)(view - 1), cl = (mov >> (2 * c + 1)) & 1;
            uint8_t sec = S.c.sec1[CK[c][cl]]; if (!sec) sec = 45;
            uint32_t ms2 = (uint32_t)sec * 1000;
            set_reg(R_LEFT, runMs[c] >= ms2 ? 0 : (uint16_t)((ms2 - runMs[c] + 999) / 1000));
        }
        /* OLED view: a pole change / a touched command first (5 s), a moving curtain, the usual view, the clock after 1 minute */
        uint8_t d;
        if (S.dimmed) d = D_STANDBY;
        else if ((int32_t)(now - overUntil) < 0) d = D_STATES;
        else if (view) d = (uint8_t)(D_CUR + 2 * (view - 1) + ((mov >> (2 * (view - 1) + 1)) & 1));
        else d = (now - lastAct >= 60000UL) ? D_CLOCK : D_STATES;
        if (d != disp) { disp = d; send(TG_DISP, d, 1); }
        /* every state again now and then (a lost frame heals), when nothing else waits */
        if (!qN && now - refreshAt >= 250) {
            refreshAt = now;
            if (refreshI == 25) refreshI = TG_DISP;
            if (refreshI == TG_DISP) { send(TG_DISP, disp, 0); refreshI = 32; }
            else if (refreshI >= 32) { uint8_t rg = (uint8_t)(refreshI - 32 + R_FIRST); send((uint8_t)(0x80 | rg), regV[rg - R_FIRST], 0); if (++refreshI >= 32 + R_N) refreshI = 1; }
            else { if (sentV[refreshI] != 0xFF) send(refreshI, sentV[refreshI], 0); refreshI++; }
        }
    }
}
