// second glyph set: weekdays, Persian digits, clock digits, small curtain words (bold DejaVu Sans)
const { chromium } = require('playwright');
// [name, text, px, font, set]  items of one set share the same rows (aligned baseline)
const items = [];
['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'].forEach((t,i)=>items.push(['W_DAY'+i,t,26,'DejaVu Sans','days']));
'۰۱۲۳۴۵۶۷۸۹'.split('').forEach((t,i)=>items.push(['G_FA'+i,t,22,'DejaVu Sans','fa']));
items.push(['G_FASL','/',22,'DejaVu Sans','fa']); items.push(['G_FAPC','٪',22,'DejaVu Sans','fa']);
'0123456789'.split('').forEach((t,i)=>items.push(['G_CK'+i,t,38,'DejaVu Sans','ck'])); items.push(['G_CKCO',':',38,'DejaVu Sans','ck']);
[['W_SCNT','ذخیرهٔ سناریو',14],['W_SCNOK','سناریو ذخیره شد',15],['W_EXIT','سناریو خروج',16],['W_N1','پرده ۱',18],['W_N2','پرده ۲',18],['W_OPENING','در حال باز شدن',14],['W_CLOSING','در حال بستن',14],['W_STOPS','توقف',14]].forEach(([n,t,z])=>items.push([n,t,z,'DejaVu Sans','s_'+n,70]));
[['W_RON','روشن شد',16],['W_ROFF','خاموش شد',16],['W_RNA','پاسخ نداد',16]].forEach(([n,t,z])=>items.push([n,t,z,'DejaVu Sans','s_'+n,70]));
'۱۲۳۴۵۶۷۸۹'.split('').forEach((d,i)=>items.push(['N_R'+(i+1),'اتاق '+d,18,'DejaVu Sans','rname',70]));
[['W_SP1','پرده ۱'],['W_SP2','پرده ۲'],['W_SOPEN','باز می‌شود'],['W_SCLOSE','بسته می‌شود'],['W_SEC','ثانیه']].forEach(([n,t])=>items.push([n,t,16,'DejaVu Sans','s_'+n]));
(async()=>{const b=await chromium.launch();const p=await b.newPage();
 const out=await p.evaluate((items)=>{
  const r=items.map(([n,t,sz,f,set,thr])=>{const c=document.createElement('canvas');c.width=160;c.height=64;const x=c.getContext('2d');
   x.fillStyle='#000';x.fillRect(0,0,160,64);x.fillStyle='#fff';x.font='bold '+sz+'px "'+f+'"';x.textBaseline='alphabetic';x.textAlign='center';x.direction=/[0-9:a-z\/]/.test(t)?'ltr':'rtl';x.fillText(t,80,48);
   const d=x.getImageData(0,0,160,64).data;const on=(i,j)=>d[(j*160+i)*4]>(thr||120);let x0=160,x1=-1,y0=64,y1=-1;
   for(let j=0;j<64;j++)for(let i=0;i<160;i++)if(on(i,j)){x0=Math.min(x0,i);x1=Math.max(x1,i);y0=Math.min(y0,j);y1=Math.max(y1,j);}
   return {n,set,on:Array.from({length:64*160},(_,k)=>on(k%160,Math.floor(k/160))?1:0),x0,x1,y0,y1};});
  const sets={};for(const o of r){const s=sets[o.set]||(sets[o.set]={y0:64,y1:-1});s.y0=Math.min(s.y0,o.y0);s.y1=Math.max(s.y1,o.y1);}
  return r.map(o=>{const s=sets[o.set],w=o.x1-o.x0+1,h=s.y1-s.y0+1,pages=Math.ceil(h/8),bytes=[];
   for(let pg=0;pg<pages;pg++)for(let i=0;i<w;i++){let v=0;for(let k=0;k<8;k++){const j=s.y0+pg*8+k;if(j<=s.y1&&o.on[j*160+o.x0+i])v|=1<<k;}bytes.push(v);}
   return {n:o.n,w,h,pages,bytes};});},items);
 let s='/* glyphs for the OLEDs, part 2 (made by gen2.js): width, pages, columns page by page; a set shares its rows */\n';
const nm=out.filter(o=>o.n.startsWith('N_R'));
 let rn='/* room names for the 7-segment rooms (made by gen2.js: default "اتاق ۱".."اتاق ۹"); 9 x 256 bytes at a fixed place,\n   the programmer writes the customer\'s names here: width, pages, columns page by page (a name at most 126 x 24) */\n';
 rn+='const uint8_t ROOMNAME[9][256] __attribute__((section(".rmname"), used)) = {\n'+nm.map(o=>{const b=[o.w,o.pages,...o.bytes];while(b.length<256)b.push(0xFF);return ' { '+b.map(v=>'0x'+v.toString(16).padStart(2,'0')).join(',')+' }';}).join(',\n')+' };\n';
 require('fs').writeFileSync('rooms.h',rn);
 for(const o of out.filter(o=>!o.n.startsWith('N_R'))){s+=`static const uint8_t ${o.n}[] PROGMEM = { ${o.w}, ${o.pages}, ${o.bytes.map(v=>'0x'+v.toString(16).padStart(2,'0')).join(',')} };\n`; console.log(o.n,o.w,o.h);}
 s+='static const uint8_t *const W_DAY[7] PROGMEM = { W_DAY0, W_DAY1, W_DAY2, W_DAY3, W_DAY4, W_DAY5, W_DAY6 };\n';
 s+='static const uint8_t *const G_FA[12] PROGMEM = { G_FA0, G_FA1, G_FA2, G_FA3, G_FA4, G_FA5, G_FA6, G_FA7, G_FA8, G_FA9, G_FASL, G_FAPC };\n';
 s+='static const uint8_t *const G_CK[11] PROGMEM = { G_CK0, G_CK1, G_CK2, G_CK3, G_CK4, G_CK5, G_CK6, G_CK7, G_CK8, G_CK9, G_CKCO };\n';
 require('fs').writeFileSync('words2.h',s);await b.close();})();
