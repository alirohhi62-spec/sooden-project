# SMS texts and command words -> UTF-16 tables in flash (sms_text.h)
# placeholders in texts: '#' first argument, '%' second, '&' third
T = [  # id, Persian, English
 ('T_ON',      'دزدگیر روشن شد. زون #', 'Alarm ON. Zone #'),
 ('T_OFF',     'دزدگیر خاموش شد', 'Alarm OFF'),
 ('T_ZOFF',    'زون # خاموش شد. روشن: زون %', 'Zone # OFF. Still on: zone %'),
 ('T_ALREADY', 'دزدگیر از قبل روشن است', 'Alarm is already ON'),
 ('T_STATUS',  'دزدگیر: #\nپل‌های روشن: %\nآنتن: & از ۵', 'Alarm: #\nPoles on: %\nSignal: &/5'),
 ('T_ST_ON',   'روشن، زون #', 'ON, zone #'),
 ('T_ST_OFF',  'خاموش', 'OFF'),
 ('T_NONE',    'هیچ', 'none'),
 ('T_SCNON',   'سناریو # روشن شد', 'Scenario # ON'),
 ('T_SCNOFF',  'سناریو # خاموش شد', 'Scenario # OFF'),
 ('T_KON',     'کلید # روشن شد', 'K# ON'),
 ('T_KOFF',    'کلید # خاموش شد', 'K# OFF'),
 ('T_COPEN',   'پرده # در حال باز شدن', 'Curtain # opening'),
 ('T_CCLOSE',  'پرده # در حال بستن', 'Curtain # closing'),
 ('T_CSTOP',   'پرده # متوقف شد', 'Curtain # stopped'),
 ('T_LANG',    'پیام‌ها فارسی شد', 'Messages in English'),
 ('T_BAD',     'فرمان نامعتبر. نمونه:\n۱روشن ۲۳خاموش وضعیت\nسناریو۱ روشن کلید۱ خاموش', 'Unknown command. e.g.\n1ON 23OFF STATUS\nS1ON K1OFF'),
 ('T_BY',      ' (توسط کاربر #)', ' (by user #)'),
 ('T_SIREN',   'هشدار! زون # تحریک شد', 'ALARM! Zone # triggered'),
 ('T_MAG',     'هشدار! مگنت باز شد', 'ALARM! Magnet opened'),
 ('T_DOOR',    'مگنت باز شد (دزدگیر خاموش)', 'Magnet opened (alarm off)'),
 ('T_KEYON',   'دزدگیر با کی‌پد روشن شد. زون #', 'Alarm ON by keypad. Zone #'),
 ('T_KEYOFF',  'دزدگیر با کی‌پد خاموش شد', 'Alarm OFF by keypad'),
 ('T_REMON',   'دزدگیر با ریموت روشن شد. زون #', 'Alarm ON by remote. Zone #'),
 ('T_REMOFF',  'دزدگیر با ریموت خاموش شد', 'Alarm OFF by remote'),
 ('T_AUTO',    'زون # بعد از ۳ بار آژیر خاموش شد', 'Zone # off after 3 sirens'),
 ('T_NOCRED',  'استعلام شارژ انجام نشد', 'Credit check failed'),
 ('T_PON', 'پل # روشن شد', 'Pole # ON'),
 ('T_POFF', 'پل # خاموش شد', 'Pole # OFF'),
 ('T_LOCKED',  'پنل در حال اجرای سناریو خروج است. کمی بعد دوباره بفرستید', 'Panel is running the exit scenario. Try again shortly'),
 ('T_SCNALL',  'همه سناریوها خاموش شد', 'All scenarios OFF'),
]
W = [  # command words: id, English, Persian (normalised: no spaces, upper case)
 ('W_ON', 'ON', 'روشن'), ('W_OFF', 'OFF', 'خاموش'), ('W_SCN', 'S', 'سناریو'), ('W_KEY', 'K', 'کلید'), ('W_CUR', 'P', 'پرده'),
 ('W_OPEN', 'OPEN', 'باز'), ('W_CLOSE', 'CLOSE', 'بسته'), ('W_STOP', 'STOP', 'توقف'), ('W_STATUS', 'STATUS', 'وضعیت'),
 ('W_CREDIT', 'CREDIT', 'شارژ'), ('W_FA', 'FA', 'فارسی'), ('W_EN', 'EN', 'انگلیسی'),
 ('W_POLE', 'L', 'پل'), ('W_FAST', 'FAST', 'سریع'),
]
def arr(s):
    u = [ord(c) for c in s]
    assert all(c < 0x10000 for c in u)
    return u
out = ['/* made by gen_sms.py: SMS texts (UTF-16) and the default command words */']
names = []
for i, fa, en in T:
    for lang, s in (('FA', fa), ('EN', en)):
        u = arr(s)
        assert len([c for c in u if c not in (35, 37, 38)]) <= 70, (i, len(u))
        out.append('static const uint16_t %s_%s[] PROGMEM = { %s, 0 };' % (i, lang, ', '.join('0x%04x' % c for c in u)))
    names.append(i)
out.append('enum { %s, T_N };' % ', '.join(names))
out.append('static const uint16_t *const TXT[T_N][2] PROGMEM = { %s };' % ', '.join('{ %s_FA, %s_EN }' % (n, n) for n in names))
wn = []
for i, en, fa in W:
    out.append('static const uint16_t %s_EN[] PROGMEM = { %s, 0 };' % (i, ', '.join('0x%04x' % c for c in arr(en))))
    out.append('static const uint16_t %s_FA[] PROGMEM = { %s, 0 };' % (i, ', '.join('0x%04x' % c for c in arr(fa))))
    wn.append(i)
out.append('enum { %s, W_N };' % ', '.join(wn))
out.append('static const uint16_t *const WORD_DEF[W_N][2] PROGMEM = { %s };' % ', '.join('{ %s_EN, %s_FA }' % (n, n) for n in wn))
open('sms_text.h', 'w').write('\n'.join(out) + '\n')
print('ok', len(names), 'texts', len(wn), 'words')
