// vacation on the 12-pole SIM panel: pole bits 0..14, curtain bits 15..18 (HEXDIR=g_prog2/)
const S = require('./sim'); const { run, red, check } = S;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const { attachEsp } = require('/home/claude/avrsim/esp');
const u = new AVRUSART(S.M4.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
u.UDRE.constant = true;
let pw; const E = attachEsp({ b: { cpu: S.M4.cpu, usart: u }, a: { D: { addListener: f => pw = f }, cpu: { data: { 0x31: 0x20 } } } });
pw(0x20); run(20000); const ph = E.connect(0); run(300);
const ask = (c, ms) => { ph.rx.length = 0; E.send(0, c); run(ms || 800); return ph.rx.join(''); };
ask('@M_MDL', 1500);
let r = ask('&CLK#09800#1199#50#', 800); console.log(r);
// night 9800: step 1 at 20:00 (1200): pole 1 + pole 3 on, curtain 1 close (bit 16); end 23:00 (1380): curtain 1 open (bit 15)
r = ask('Vac#1#09800#09800#1#1200' + (0x10005).toString(16).toUpperCase().padStart(5, '0') + '#1380' + (0x8000).toString(16).toUpperCase().padStart(5, '0') + '#', 1500);
r = ask('@M_VAC'); console.log(r);
run(15000);
check(red('L1') === 1 && red('L3') === 1 && !red('L2'), 'vacation step: poles 1 and 3 on');
check(red('P1C') === 1, 'vacation step: curtain 1 closes (bit 16 = key 25)');
const res = S.res(); console.log(`${res.n - res.fails}/${res.n} passed`);
