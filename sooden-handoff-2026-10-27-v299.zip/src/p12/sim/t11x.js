// the approved fixes of 27 Mehr: SH1106, motion end whites, elevator, master lock + 100 ms, alarm menu, SIM indicator, exit scenario
const S = require('./sim'); const { run, tap, press, red, white, check, o, M } = S;
require('./nums').putNums(0); S.powerAL(); const O = require('./oled'); const AL = S.AL;
let bl=7, bms=0, bidl=1; const busc=[];
{ const cpu = AL.cpu; const f = () => { const c = (S.o(S.M4,'B',2)<<2)|(S.o(S.M4,'B',0)<<1)|S.o(S.M4,'E',7);
  if (c === bl) { if (bms < 255) bms++; } else { bl = c; bms = 0; }
  if (c === 7) { if (bms >= 5) bidl = 1; } else if (bms === 15 && bidl) { bidl = 0; busc.push(S.T + ':' + c); }
  const qh = cpu.data[0x892]; if (qh !== f.qh) { if (f.qh !== undefined) for (let q = f.qh; q !== qh; q = (q + 1) & 255) busc.push('A' + cpu.data[0x882 + (q & 15)]); f.qh = qh; }
  const lk = cpu.data[0x1de]; if (lk !== f.lk) { busc.push('LOCK' + lk + '@' + S.T); f.lk = lk; }
  cpu.addClockEvent(f, 8000); }; cpu.addClockEvent(f, 8000); }
// motion: shared whites (keypad light M1 B5, B C on board 1) dark during the motion, all on at its end; alarm whites with them
const tr = {}; const W = { kp: () => o(M[1], 'B', 5), iB: () => o(M[1], 'A', 7), iC: () => o(M[1], 'C', 6), z1: () => o(AL, 'B', 6), Dz: () => o(AL, 'E', 3) };
const was = {}; S.setHook(() => { for (const k in W) { const v = W[k](); if (v && !was[k]) tr[k] = S.T; was[k] = v; } });   // the last time each came on
run(4000); S.setHook(null);
console.log('first white at', JSON.stringify(tr));
const shared = ['kp', 'iB', 'iC'].map(k => tr[k]);
check(Math.max(...shared) - Math.min(...shared) <= 5 && Math.min(...shared) >= 1690, 'panel shared whites come on together at the motion end');
check(Math.abs(tr.z1 - tr.kp) <= 120 && Math.abs(tr.Dz - tr.kp) <= 120, 'alarm keypad whites with them (' + (tr.z1 - tr.kp) + ' ms)');
// SH1106: picture at columns 2..129, nothing in 0,1,130,131 -> decoded picture has content and no stray line
const fb = O.scr[1]; let edge = 0; for (let p = 0; p < 8; p++) edge += fb[p][127] ? 1 : 0;
check(edge === 0 && fb.some(r => r.some(v => v)), 'OLED 1 (SH1106): picture shown, right edge clean');
// elevator: a short touch = relay 1 s
let el = []; S.setHook(() => { const v = red('EL'); if (el.length % 2 !== (v ? 1 : 0)) el.push(S.T); });
tap('EL'); run(1500); const shortNo = el.length === 0; press('EL', 1200); run(1500); S.setHook(null);
check(shortNo && el.length === 2 && el[1] - el[0] >= 950 && el[1] - el[0] <= 1100, 'elevator: short touch nothing, held 1 s -> relay ' + (el[1] - el[0]) + ' ms');
// master: 100 ms steps; a second touch while stepping is ignored, then it works
const ev = []; let prev = {}; S.setHook(() => { for (const k of S.POLES) { const v = red(k); if (v !== prev[k]) { if (prev[k] !== undefined) ev.push([S.T, k, v]); prev[k] = v; } } });
run(10); tap('M'); run(400); tap('M'); tap('L1'); run(1500);
const ons = ev.filter(e => e[2]); const gaps = ons.slice(1).map((e, i) => e[0] - ons[i][0]);
check(ons.length === 12 && ev.length === 12, 'master runs to the end: 12 on, the touches during it ignored (' + ev.length + ' changes)');
console.log(ons.map(e=>e[1]+'@'+e[0]).join(' '));
check(Math.max(...gaps) <= 106 && Math.min(...gaps) >= 86, 'master steps 100 ms: ' + Math.min(...gaps) + '..' + Math.max(...gaps));
tap('M'); run(1600); check(S.POLES.every(k => !red(k)), 'after it: master again = all off');
S.setHook(null);
// alarm menu: arrows open the 3 options; 5 s alone -> home; after OK (password) 30 s
const AK = { kR: [0, 6], kL: [0, 5], kOK: [1, 0], k1: [0, 3], k2: [0, 4], k3: [0, 7], k4: [0, 2], kD: [1, 1] };
function key(k) { const [ic, c] = AK[k], b = ic * 4; AL.A.setPin(b + 1, !!(c & 4)); AL.A.setPin(b + 2, !!(c & 2)); AL.A.setPin(b + 3, !!(c & 1)); AL.A.setPin(b, false); run(400); AL.A.setPin(b, true); run(200); }   // (the keypad counts loop rounds: a press must outlast an OLED refresh)
const UI = parseInt(require('child_process').execSync('/root/tc/avr-gcc-14.1.0-x64-linux/bin/avr-nm /home/claude/fw/out/fw_p12_alarm.elf').toString().split('\n').find(l => / ui$/.test(l)).slice(0, 8), 16) & 0xFFFF;
const sym = () => AL.cpu.data[UI];   // ui: 0 home, 3 options, 4 menu password, 8 numbers list
run(500); const home = sym();
{ console.log('BUSC', busc.filter(x=>1).slice(-400).join(' ')); key('kR'); } run(500); const menu = sym(); run(5200); check(menu !== home && sym() === home, 'three options page: back home after 5 s');
