// RS485 line of the 12-pole panel (M4 USART1) with other Sooden panels on it (their real hex files)
const S = require('./sim');
const X = require('/home/claude/avrsim/mix'); const C = X.C;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const CHAR = 8 * 1042;                                   // one byte at 9600 baud, in cycles
function usart1(chip) {
  const u = new AVRUSART(chip.cpu, { rxCompleteInterrupt: 0x3C, dataRegisterEmptyInterrupt: 0x3E, txCompleteInterrupt: 0x40,
    UCSRA: 0x9B, UCSRB: 0x9A, UCSRC: 0x9D, UBRRL: 0x99, UBRRH: 0x98, UDR: 0x9C }, 8000000);
  u.UDRE.constant = true;                                // as the real chip (see sim800.js)
  const h = chip.cpu.writeHooks[0x9A]; chip.cpu.writeHooks[0x9A] = (v, ov) => { const a = chip.cpu.data[0x9B] & 0x80; const r = h(v, ov); if (a) chip.cpu.setInterruptFlag(u.RXC); return r; };
  return u;
}
const nodes = [], wire = [];
function join(cpu, usart, name) {
  const n = { cpu, usart, name, txFree: 0 }; nodes.push(n);
  usart.onByteTransmit = b => {
    n.txFree = Math.max(n.txFree, cpu.cycles) + CHAR;
    wire.push({ from: name, b, t: S.T });
    for (const r of nodes) if (r !== n) { const d = Math.max(1, n.txFree - cpu.cycles); r.cpu.addClockEvent(() => r.usart.writeByte(b, true), d); }
  };
  return n;
}
function p12() { return join(S.M4.cpu, usart1(S.M4), 'p12'); }
// an ATmega8 4-pole panel (v2 network build) that is room r (all its poles are normal lights)
function room4(r, fw) {
  const cfg = { role: 0, npoles: 4, peerpoles: 0, remote: false, type: [1, 1, 1, 1], link: [-1, -1, -1, -1], offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 100 };
  const b = C.buildCfg(cfg); b[126] = r; b[127] = C.crc8(b, 127);
  const n = X.m8(C.patchHex(X.hex(fw || 'fw_4p_px'), b), null, 1);
  S.addChip(n.cpu, 0xFFF);
  join(n.cpu, n.usart, 'room' + r);
  return n;
}
module.exports = { p12, room4, wire, X };
// an ATmega8 4-pole panel paired with the 12-pole panel (two-panel network v2): link[k] = network number of the 12-pole key
function pair4(role, link) {
  const cfg = { role, npoles: 4, peerpoles: 20, remote: false, type: [1, 1, 1, 1], link, offmask: [0, 0, 0, 0], onmask: [0, 0, 0, 0], minutes: [0, 0, 0, 0], dimsec: 0, stagMs: 100 };
  const n = X.m8(C.patchHex(X.hex('fw_4p_px'), C.buildCfg(cfg)), null, 1);
  S.addChip(n.cpu, 0xFFF);
  join(n.cpu, n.usart, 'pair' + role);
  return n;
}
module.exports.pair4 = pair4;
module.exports.join = join;
