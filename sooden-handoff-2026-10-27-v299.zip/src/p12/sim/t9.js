// scenario countdown on OLED 1, master step 100 ms, curtain keys (left = open)
const S = require('./sim'); const { run, tap, press, red, check, POLES } = S;
const { snap } = require('./oled');
run(2600);
tap('L1'); tap('L2');
let cd = []; S.setHook(() => { if (S.T % 1000 === 500) snap('c_' + Math.floor(S.T / 1000)); });
press('S2', 5600); S.setHook(null); run(300); snap('c_saved');
tap('M'); run(2000); if (POLES.some(k => red(k))) { tap('M'); run(2000); }   // all off then
const on = []; S.setHook(() => { POLES.forEach((k, i) => { if (red(k) && on[i] === undefined) on[i] = S.T; }); });
tap('M'); run(4000); S.setHook(null);
const d = on.slice(1).map((t, i) => t - on[i]);
check(d.every(x => x >= 86 && x <= 106) && Math.abs(d.reduce((a, b) => a + b) / d.length - 100) < 3, 'master: each pole ' + d.join(',') + ' ms after the one before');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
