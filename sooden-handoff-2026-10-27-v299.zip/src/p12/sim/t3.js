const S = require('./sim'); const { run, tap, red, white, check, M } = S;
run(2600);
tap('L1'); run(400);
const VAL = parseInt(require('child_process').execSync('/root/tc/avr-gcc-14.1.0-x64-linux/bin/avr-nm /home/claude/fw/out/fw_p12_m1.elf').toString().split('\n').find(l => / val$/.test(l)).slice(0, 8), 16) & 0xFFFF;
M[1].cpu.data[VAL] = 0;            // M1 forgets pole 1 (as if its frame was lost)
run(50); check(red('L1') === 0, 'M1 lost the state of pole 1');
run(8000); check(red('L1') === 1, 'healed by the periodic repeat within 8 s');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
