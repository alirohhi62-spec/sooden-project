// alarm MCU on bus B / C: standby, wake from the alarm keypad, child lock
const S = require('./sim'); const { run, tap, press, check, M4, AL, o, white, red, POLES } = S;
const L = () => [o(AL,'B',6), o(AL,'D',1), o(AL,'D',3), o(AL,'E',3), o(AL,'C',0)].join('');
const key = (ms) => { AL.A.setPin(0, false); run(ms); AL.A.setPin(0, true); };
run(3500); check(L() === '11111', 'after power-up: zone / D whites and Led_N on (' + L() + ')');
run(64000); check(L() === '00000', 'panel standby -> alarm LEDs dark (' + L() + ')');
check(POLES.every(k => !white(k)), 'panel dark');
key(80); run(2500);
check(L() === '11111', 'alarm keypad touched: alarm LEDs back');
check(POLES.every(k => white(k)), 'and the panel woke up (bus B 0111)');
press('S6', 7400); run(3000);
check(red('S6') === 1, 'child lock on');
run(64000); check(L() === '11111', 'locked: no standby, alarm LEDs stay');
press('S6', 7400); run(500);
check(!red('S6'), 'child lock off');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
