// RS485: the 7-segment rooms (two real ATmega8 4-pole panels as room 1 and room 3)
const S = require('./sim'); const { run, tap, check, o, M4 } = S;
const N = require('./net'); N.p12();
const r1 = N.room4(1), r3 = N.room4(3);
const nm = require('child_process').execSync('/root/tc/avr-gcc-14.1.0-x64-linux/bin/avr-nm /home/claude/fw/out/fw_p12_m4.elf').toString();
const REGV = parseInt(nm.match(/^([0-9a-f]+) . regV$/m)[1], 16) & 0xFFFF;   // regV[R - 16], 16 bit
const reg = r => M4.cpu.data[REGV + 2 * (r - 16)] | M4.cpu.data[REGV + 2 * (r - 16) + 1] << 8;
const SEG = { 0x06: 1, 0x6B: 2, 0x4F: 3, 0x1E: 4, 0x5D: 5, 0x7D: 6, 0x07: 7, 0x7F: 8, 0x5F: 9, 0x08: '-', 0x00: ' ' };
const seg = () => SEG[(~M4.cpu.data[0x62]) & 0x7F];
const CODE4 = [7, 0, 3, 4];
function t8(n, pole) { const c = CODE4[pole]; n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); run(80); n.pc.setPin(2, true); n.pc.setPin(3, true); n.pc.setPin(4, true); n.pc.setPin(5, true); run(80); }
const reds4 = n => N.X.r4(n).map(v => v === 1 ? 1 : 0).join('');
run(4000);
check(seg() === '-', '7-segment idle: a dash (' + seg() + ')');
t8(r1, 0); t8(r1, 1); run(500);
check(reds4(r1) === '1100', 'room 1: poles 1 and 2 on by hand (' + reds4(r1) + ')');
tap('SUP'); run(200); check(seg() === 1, 'up: room 1');
let w0 = N.wire.length; tap('SOFF'); run(1500);
check(reds4(r1) === '0000', 'OFF: every pole of room 1 off (' + reds4(r1) + ')');
check(reg(27) === 1 && reg(28) === 0, 'OLED 1: room 1, "off" (' + reg(27) + ',' + reg(28) + ')');
console.log('   line:', N.wire.slice(w0).map(x => x.from + ':' + x.b.toString(16)).join(' ').slice(0, 300));
tap('SUP'); tap('SUP'); run(200); check(seg() === 3, 'up twice: room 3');
tap('SON'); run(2000); check(reds4(r3) === '1111' && reds4(r1) === '0000', 'ON: all 4 poles of room 3 on, room 1 untouched (' + reds4(r3) + ')');
check(reg(28) === 1, 'OLED 1: "on"');
tap('SUP'); tap('SUP'); run(200); check(seg() === 5, 'room 5 (no panel there)');
tap('SON'); run(2000); check(reg(27) === 5 && reg(28) === 2, 'room 5: "no answer" after the tries (' + reg(28) + ')');
tap('SDN'); run(200); check(seg() === 4, 'down: room 4');
run(10500); check(seg() === '-', '10 s alone: dash again');
tap('SOFF'); run(1500); check(reds4(r3) === '1111', 'OFF with the dash (no room chosen): nothing happens');
tap('L1'); run(400); check(S.red('L1') === 1, 'the panel keys still work');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
