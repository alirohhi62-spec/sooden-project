// alarm settings: a piece of the dump lost on bus B -> the M4 asks again, the app gets the right values
const S = require('./sim'); const { run } = S;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const { attachEsp } = require('/home/claude/avrsim/esp');
const { putNums } = require('./nums');
putNums(0); S.powerAL();
const u = new AVRUSART(S.M4.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
u.UDRE.constant = true;
let pw; const E = attachEsp({ b: { cpu: S.M4.cpu, usart: u }, a: { D: { addListener: f => pw = f }, cpu: { data: { 0x31: 0x20 } } } });
pw(0x20); run(20000); const ph = E.connect(0); run(300);
ph.rx.length = 0; E.send(0, '@M_MDL'); run(1500);
const want = '40,30,180,1234,09121111111,09352222222,09193333333,09121111111,09352222222,';
for (const [lo, hi, what] of [[800, 900, 'a digit-sized gap'], [1500, 2000, 'half a second'], [0, 0, 'nothing lost']]) {
  ph.rx.length = 0; E.send(0, '&ACR'); const t0 = S.T;
  S.setHook(() => { const d = S.T - t0; if (d >= lo && d < hi) for (let i = 4; i < 8; i++) S.M4.B.setPin(i, true); });
  let got = null; for (let i = 0; i < 200 && !got; i++) { run(200); got = ph.rx.join('').match(/\$ACF#([^$]*)\$/); }
  S.setHook(null);
  const sec = ((S.T - t0) / 1000).toFixed(1);
  S.check(got && got[1] === want, `bus B dropped for ${what}: right values after ${sec} s ` + (got ? got[1] : 'none'));
  run(3000);
}
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
