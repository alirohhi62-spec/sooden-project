const S = require('./sim'); const { M4, o, run } = S;
let last = -1, out = '', idle = 0;
S.setHook(() => { const a = (o(M4,'D',6)<<4)|(o(M4,'D',5)<<3)|(o(M4,'D',4)<<2)|(o(M4,'D',1)<<1)|o(M4,'D',0);
  if (a === 31) idle++; else { if (idle > 10) out += ' |'; if (a !== last || idle) out += ' ' + a + '(' + (S.T) + ')'; idle = 0; } last = a; });
run(3000); console.log(out);
