// the approved fixes of 27 Mehr: SH1106, motion end whites, elevator, master lock + 100 ms, alarm menu, SIM indicator, exit scenario
const S = require('./sim'); const { run, tap, press, red, white, check, o, M } = S;
require('./nums').putNums(0); S.powerAL(); const O = require('./oled'); const AL = S.AL;
// motion: shared whites (keypad light M1 B5, B C on board 1) dark during the motion, all on at its end; alarm whites with them
const tr = {}; const W = { kp: () => o(M[1], 'B', 5), iB: () => o(M[1], 'A', 7), iC: () => o(M[1], 'C', 6), z1: () => o(AL, 'B', 6), Dz: () => o(AL, 'E', 3) };
const was = {}; S.setHook(() => { for (const k in W) { const v = W[k](); if (v && !was[k]) tr[k] = S.T; was[k] = v; } });   // the last time each came on
run(4000); S.setHook(null);
console.log('first white at', JSON.stringify(tr));
const shared = ['kp', 'iB', 'iC'].map(k => tr[k]);
check(Math.max(...shared) - Math.min(...shared) <= 5 && Math.min(...shared) >= 1690, 'panel shared whites come on together at the motion end');
check(Math.abs(tr.z1 - tr.kp) <= 120 && Math.abs(tr.Dz - tr.kp) <= 120, 'alarm keypad whites with them (' + (tr.z1 - tr.kp) + ' ms)');
// SH1106: picture at columns 2..129, nothing in 0,1,130,131 -> decoded picture has content and no stray line
const fb = O.scr[1]; let edge = 0; for (let p = 0; p < 8; p++) edge += fb[p][127] ? 1 : 0;
check(edge === 0 && fb.some(r => r.some(v => v)), 'OLED 1 (SH1106): picture shown, right edge clean');
// elevator: a short touch = relay 1 s
let el = []; S.setHook(() => { const v = red('EL'); if (el.length % 2 !== (v ? 1 : 0)) el.push(S.T); });
tap('EL'); run(1500); const shortNo = el.length === 0; press('EL', 1200); run(1500); S.setHook(null);
check(shortNo && el.length === 2 && el[1] - el[0] >= 950 && el[1] - el[0] <= 1100, 'elevator: short touch nothing, held 1 s -> relay ' + (el[1] - el[0]) + ' ms');
// master: 100 ms steps; a second touch while stepping is ignored, then it works
const ev = []; let prev = {}; S.setHook(() => { for (const k of S.POLES) { const v = red(k); if (v !== prev[k]) { if (prev[k] !== undefined) ev.push([S.T, k, v]); prev[k] = v; } } });
run(10); tap('M'); run(400); tap('M'); tap('L1'); run(1500);
const ons = ev.filter(e => e[2]); const gaps = ons.slice(1).map((e, i) => e[0] - ons[i][0]);
check(ons.length === 12 && ev.length === 12, 'master runs to the end: 12 on, the touches during it ignored (' + ev.length + ' changes)');
console.log(ons.map(e=>e[1]+'@'+e[0]).join(' '));
check(Math.max(...gaps) <= 106 && Math.min(...gaps) >= 86, 'master steps 100 ms: ' + Math.min(...gaps) + '..' + Math.max(...gaps));
tap('M'); run(1600); check(S.POLES.every(k => !red(k)), 'after it: master again = all off');
S.setHook(null);
// alarm menu: arrows open the 3 options; 5 s alone -> home; after OK (password) 30 s
const AK = { kR: [0, 6], kL: [0, 5], kOK: [1, 0], k1: [0, 3], k2: [0, 4], k3: [0, 7], k4: [0, 2], kD: [1, 1] };
function key(k) { const [ic, c] = AK[k], b = ic * 4; AL.A.setPin(b + 1, !!(c & 4)); AL.A.setPin(b + 2, !!(c & 2)); AL.A.setPin(b + 3, !!(c & 1)); AL.A.setPin(b, false); run(400); AL.A.setPin(b, true); run(200); }   // (the keypad counts loop rounds: a press must outlast an OLED refresh)
const UI = parseInt(require('child_process').execSync('/root/tc/avr-gcc-14.1.0-x64-linux/bin/avr-nm /home/claude/fw/out/fw_p12_alarm.elf').toString().split('\n').find(l => / ui$/.test(l)).slice(0, 8), 16) & 0xFFFF;
const sym = () => AL.cpu.data[UI];   // ui: 0 home, 3 options, 4 menu password, 8 numbers list
run(500); const home = sym();
{ const h = {}; const ot = AL.cpu.tick.bind(AL.cpu); AL.cpu.tick = () => { const p = AL.cpu.pc >> 6; h[p] = (h[p] || 0) + 1; ot(); }; { const u=[]; S.setHook(()=>{ const v=AL.cpu.data[0x1ee]; if(u[u.length-1]!==v) u.push(v, S.T); }); key('kR'); S.setHook(null); console.log('UI', u.join(' ')); } AL.cpu.tick = ot; console.log('PCS', JSON.stringify(Object.entries(h).sort((a, b) => b[1] - a[1]).slice(0, 6).map(e => [(+e[0] * 128).toString(16), e[1]]))); } run(500); const menu = sym(); run(5200); check(menu !== home && sym() === home, 'three options page: back home after 5 s');
key('kR'); key('kR'); run(300); key('kOK'); run(300); const pw = sym(); run(6000); check(sym() === pw, 'after OK (password): no 5 s return');
key('kL'); run(300); key('kL'); run(300); const pg = sym(); check(pg !== pw, 'L in the password step: one step back to the options');
key('kOK'); key('k1'); key('k2'); key('k3'); key('k4'); run(300); const list = sym(); key('kR'); run(300); check(sym() === pg, 'numbers list -> R -> back to the options page');
key('kOK'); run(300); run(31000); check(sym() === home, 'password step left alone: home after 30 s');
// SIM indicator D (board 1 C4 white, C5 red): module with good signal -> red
run(12000); check(o(M[1], 'C', 5) === 1 && o(M[1], 'C', 4) === 0, 'indicator D: good signal = red');
// exit scenario S5
tap('L2'); run(300); S.GSM.answer.clear();
const t0 = S.T; tap('S5'); run(1000);
tap('L3'); run(300); check(!red('L3') && red('S5'), 'exit: S5 red, touches locked');
S.GSM.receive('09121111111', 'k1on'); run(8000);
check(!red('K13') && S.GSM.sent.some(x => x.t > t0 && x.text.startsWith('پنل در حال اجرای سناریو خروج')), 'exit: SMS command refused with a message');
run(20000 - (S.T - t0) + 500);
check(!red('L2') && !red('S5'), 'exit after 20 s: poles off, S5 off');
tap('L3'); run(300); check(red('L3') === 1, 'after the exit the panel works again');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
