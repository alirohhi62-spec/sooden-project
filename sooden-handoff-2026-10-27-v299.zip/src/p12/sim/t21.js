// SIM12 round 3: names of 20 letters (one byte a letter), child lock from the app, curtain percent (HEXDIR=new/)
const S = require('./sim'); const { run, tap, red, check } = S;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const { attachEsp } = require('/home/claude/avrsim/esp');
const u = new AVRUSART(S.M4.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
u.UDRE.constant = true;
let pw; const E = attachEsp({ b: { cpu: S.M4.cpu, usart: u }, a: { D: { addListener: f => pw = f }, cpu: { data: { 0x31: 0x20 } } } });
pw(0x20); run(20000); const ph = E.connect(0); run(300);
const ask = (c, ms) => { ph.rx.length = 0; E.send(0, c); run(ms || 800); return ph.rx.join(''); };
ask('@M_MDL', 1500);
const name = 'لوستر پذیرایی بزرگ'; // 18 letters
let r = ask('Lbl#01#' + name + '#', 1200); r = ask('@M_LBL#01');
check(r.includes('$L01#' + name + '$'), '18 Persian letters kept: ' + r);
const n20 = 'کلید شماره‌ی ۱۲ پارکینگ'; r = ask('Lbl#02#' + n20 + '#', 1200); r = ask('@M_LBL#02');
check(r.includes('$L02#' + [...n20].slice(0, 20).join('') + '$'), 'cut at 20 letters, ZWNJ and Persian digits kept: ' + r);
r = ask('Lbl#03#Hall 3#', 1200); r = ask('@M_LBL#03'); check(r.includes('$L03#Hall 3$'), 'Latin name: ' + r);
r = ask('@M_LBL#05'); check(r.includes('$L05#$'), 'old names dropped once (key 5 empty): ' + r);
// child lock from the app: S6 = key 21
r = ask('&K#21', 1500); check(r.includes('$A#21#1$'), 'app: child lock key answered ' + r);
check(/\$K#[0-9A-F]*\$/.test(r) && (parseInt(r.match(/\$K#([0-9A-F]*)\$/g).pop().slice(3, -1), 16) >> 20 & 1) === 1, 'child lock on: bit 21 red in the app ' + r.match(/\$K#[^$]*\$/g));
tap('L1'); run(500); check(!red('L1'), 'locked: a touch on the panel does nothing');
r = ask('&K#01', 1500); check(red('L1') === 1, 'locked: the app still switches pole 1');
r = ask('&K#21', 1500); check((parseInt(r.match(/\$K#([0-9A-F]*)\$/g).pop().slice(3, -1), 16) >> 20 & 1) === 0, 'app: child lock off');
tap('L2'); run(500); check(red('L2') === 1, 'unlocked: touches work');
// curtain percent
r = ask('@M_POS'); check(/\$POS#\d\d#\d\d\$/.test(r), '@M_POS: ' + r);
const res = S.res(); console.log(`${res.n - res.fails}/${res.n} passed`);
