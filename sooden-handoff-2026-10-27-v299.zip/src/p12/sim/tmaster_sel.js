// SIM12 M4 from the programmer: master without poles 3 and 12
const S = require('./sim'); const { run, tap, red, check, POLES } = S;
run(2600);
tap('L1'); run(300);
tap('M'); run(2500);
const on = POLES.filter(k => red(k));
check(on.length === 10 && !red('L3') && !red('L12'), 'master: all on except 3 and 12 (' + on.join(',') + ')');
tap('M'); run(2500);
check(POLES.every(k => !red(k)), 'master again: all off');
tap('L3'); run(300); tap('M'); run(2500);
check(red('L3') && POLES.filter(k => red(k)).length === 11, 'pole 3 on by hand: master turns the other 10 on, 3 stays');
