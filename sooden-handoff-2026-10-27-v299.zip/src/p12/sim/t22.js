// all scenarios off: Wi-Fi &SOFF and SMS #SOFF (HEXDIR=g_prog/)
const S = require('./sim'); const { run, tap, red, check } = S;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const { attachEsp } = require('/home/claude/avrsim/esp');
const { putNums } = require('./nums');
putNums(0); S.powerAL();
const u = new AVRUSART(S.M4.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
u.UDRE.constant = true;
let pw; const E = attachEsp({ b: { cpu: S.M4.cpu, usart: u }, a: { D: { addListener: f => pw = f }, cpu: { data: { 0x31: 0x20 } } } });
pw(0x20); run(20000); const ph = E.connect(0); run(300);
const ask = (c, ms) => { ph.rx.length = 0; E.send(0, c); run(ms || 800); return ph.rx.join(''); };
ask('@M_MDL', 1500);
console.log(ask('@M_CF#16'), ask('Set#16#O#000005#'), ask('Set#17#O#000018#'), ask('Set#17#F#000001#'));
const cf = []; for (const n of [16, 17, 18, 19]) { const r = ask('@M_CF#' + n); cf.push(parseInt(r.split('#')[6], 16)); }
console.log('S1..S4 on masks', cf.map(x => x.toString(16)));
const mask = (cf[0] | cf[1]) & 0x7FFF;
let r = ask('&K#16', 3000); r += ask('&K#17', 3000); run(3000);
const st = () => parseInt(ask('@K').match(/\$K#([0-9A-F]+)\$/)[1], 16);
let v = st(); check((v & 0x1C) === 0x1C && !(v & 1), 'S1 then S2: poles 3 4 5 on, pole 1 off by S2 (' + v.toString(16) + ')');
r = ask('&SOFF', 3000); check(r.includes('$SOFF#1$'), '&SOFF answered ' + r); run(3000);
v = st(); check((v & mask) === 0, 'all scenario poles off (' + v.toString(16) + ')');
ask('&K#16', 3000); run(3000); v = st(); check((v & cf[0] & 0x7FFF) === (cf[0] & 0x7FFF), 'S1 on again');
const G = S.GSM, t0 = G.now; G.receive('09121111111', '#SOFF'); run(15000);
v = st(); check((v & mask) === 0, 'SMS #SOFF: poles off (' + v.toString(16) + ')');
const ans = G.sent.filter(x => x.to === '09121111111' && x.t > t0).map(x => x.text);
check(ans.some(x => /^#SD,0,0,0,0000,/.test(x)), 'machine answer shows the poles off: ' + ans.join(' | '));
const t1 = G.now; G.receive('09121111111', 'سناریو خاموش'); run(15000);
const a2 = G.sent.filter(x => x.to === '09121111111' && x.t > t1).map(x => x.text);
check(a2.some(x => x.startsWith('همه سناریوها خاموش شد')), 'Persian SMS: «همه سناریوها خاموش شد» ' + a2.join(' | '));
const res = S.res(); console.log(`${res.n - res.fails}/${res.n} passed`);
