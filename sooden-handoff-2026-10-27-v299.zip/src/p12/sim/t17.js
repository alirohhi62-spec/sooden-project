// programmer-made pair (HEXDIR=prog3/): 12-pole A + 4-pole B; links pole 1 <-> B1, curtain 1 open <-> B2, elevator <-> B3; master also switches B4
const S = require('./sim'); const { run, tap, press, red, check } = S;
const N = require('./net'); N.p12();
const P = N.X.m8(require('fs').readFileSync((process.env.BHEX || 'prog3/b.hex'), 'utf8'), null, 1); S.addChip(P.cpu, 0xFFF); N.join(P.cpu, P.usart, 'B');
const CODE4 = [7, 0, 3, 4];
function t8(n, pole) { const c = CODE4[pole]; n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); run(80); n.pc.setPin(2, true); n.pc.setPin(3, true); n.pc.setPin(4, true); n.pc.setPin(5, true); run(80); }
const r4 = () => N.X.r4(P).map(v => v === 1 ? 1 : 0).join('');
run(6000);
tap('L1'); run(1500); check(red('L1') === 1 && r4()[0] === '1', 'A pole 1 on -> B1 on (' + r4() + ')');
t8(P, 0); run(1500); check(!red('L1') && r4()[0] === '0', 'B1 off -> A pole 1 off');
t8(P, 1); run(1500); check(red('P1O') === 1, 'B2 -> A curtain 1 opens');
tap('P1O'); run(1500); check(!red('P1O') && r4()[1] === '0', 'A curtain stopped -> B2 off (' + r4() + ')');
tap('M'); run(3000); check(red('L12') === 1 && r4()[3] === '1', 'A master: all on, B4 on too (' + r4() + ')');
tap('M'); run(3000); check(!red('L12') && r4()[3] === '0', 'A master again: all off, B4 off (' + r4() + ')');
let elev = 0; S.setHook(() => { if (red('EL')) elev++; });
t8(P, 2); run(2500); S.setHook(null); check(elev > 800 && elev < 1300, 'B3 -> A elevator relay once (' + elev + ' ms)'); check(r4()[2] === '0', 'B3 back off with the relay');
let b3 = 0, ea = 0; S.setHook(() => { if (r4()[2] === '1') b3++; if (red('EL')) ea++; }); press('EL', 1300); run(2500); S.setHook(null); check(b3 > 500 && r4()[2] === '0', 'A elevator held 1 s -> B3 on with the relay, then off (' + b3 + ' ms, A relay ' + ea + ')');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
