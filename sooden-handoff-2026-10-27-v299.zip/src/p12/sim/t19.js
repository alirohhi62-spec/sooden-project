// round 28 Mehr: standby touch only wakes, elevator needs 1 s without a break, quick arm from the alarm remote (HEXDIR=prog2/ for the last part)
const S = require('./sim'); const { run, tap, press, red, check } = S;
let elev = 0; S.setHook(() => { if (red('EL')) elev++; });
run(4000);
if (!process.env.HEXDIR) {
  run(62000); const dim = !S.white('L1');
  check(dim, 'standby after 60 s (whites dark)');
  elev = 0; press('EL', 1300); run(1500);
  check(elev === 0, 'standby: holding the elevator only wakes the panel (relay ' + elev + ' ms)');
  run(62000); tap('L1'); run(500); check(!red('L1'), 'standby: a touch on pole 1 only wakes, pole 1 stays off');
  tap('L1'); run(500); check(red('L1') === 1, 'awake: pole 1 on');
  // a broken hold (radio pulses look like this): 600 ms, a 20 ms gap, 600 ms
  elev = 0; press('EL', 600); run(20); press('EL', 600); run(1500);
  check(elev === 0, 'elevator: 600 + 600 ms with a break does not call (' + elev + ' ms)');
  elev = 0; press('EL', 1150); run(1500); check(elev > 800, 'elevator: 1 s without a break calls (' + elev + ' ms)');
} else {
  const AL = S.AL, o = S.o;
  const INT4 = { address: 10, flagRegister: 0x58, flagMask: 0x10, enableRegister: 0x59, enableMask: 0x10 };
  const rf = code => { const T = 350 * 8; let at = AL.cpu.cycles + 1000;
    const ev = l => { const c = at; AL.cpu.addClockEvent(() => { AL.E.setPin(4, !!l); AL.cpu.setInterruptFlag(INT4); }, c - AL.cpu.cycles); };
    for (let r = 0; r < 4; r++) { ev(1); at += T; ev(0); at += 31 * T; for (let b = 23; b >= 0; b--) { const one = (code >> b) & 1; ev(1); at += (one ? 3 : 1) * T; ev(0); at += (one ? 1 : 3) * T; } }
    ev(1); at += T; ev(0); run(Math.ceil((at - AL.cpu.cycles) / 8000) + 50); };
  const AK = { kOK: [1, 0] }; const key = (k, ms) => { const [ic, code] = AK[k], b = ic * 4; AL.A.setPin(b + 1, !!(code & 4)); AL.A.setPin(b + 2, !!(code & 2)); AL.A.setPin(b + 3, !!(code & 1)); AL.A.setPin(b, false); run(ms || 60); AL.A.setPin(b, true); run(150); };
  const red0 = () => o(AL, 'B', 7), wh0 = () => o(AL, 'B', 6);
  key('kOK', 3300); run(200); rf(0xABC120 | 1); run(500);
  rf(0xABC120 | 2); run(400); rf(0xABC120 | 8); run(800);
  let steady = 1; for (let i = 0; i < 20; i++) { run(100); if (!red0() || wh0()) steady = 0; }
  check(steady, 'remote button 4 (quick arm, zone 1): armed at once, red steady, no exit time');
  rf(0xABC120 | 2); run(400); check(wh0() && !red0(), 'button 2: off');
  rf(0xABC120 | 1); run(800); let blink = 0, last = red0(); for (let i = 0; i < 40; i++) { run(100); if (red0() !== last) { blink++; last = red0(); } }
  check(blink >= 2, 'button 1 (normal arm): the exit time still runs (red blinks ' + blink + ')');
}
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
