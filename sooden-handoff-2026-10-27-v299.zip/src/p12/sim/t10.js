// SMS / calls through the SIM800 model
const S = require('./sim'); const { run, tap, press, red, check, o } = S;
const NUMS = ['09121111111', '09352222222', '09193333333'], CALLS = ['09121111111', '09352222222', ''];
// numbers into the alarm EEPROM (2 copies with the check byte, as the firmware writes them)
function ck(b) { let c = 0x5A; for (const x of b) c = (((c << 1) | (c >> 7)) & 0xFF) ^ x; return c; }
function putNums(en) {
  const d = []; const pad = s => { const a = [...s].map(c => c.charCodeAt(0)); while (a.length < 14) a.push(0); return a; };
  NUMS.forEach(n => d.push(...pad(n))); CALLS.forEach(n => d.push(...pad(n))); d.push(en || 0);
  const rec = [0x5E, ...d]; rec.push(ck(rec));
  for (const base of [0x100, 0x180]) rec.forEach((v, i) => S.AL.ee.memory[base + i] = v);
}
putNums(0); S.powerAL();
const G = () => S.GSM;
const sentTo = (n, after) => G().sent.filter(x => x.to === n && x.t > after).map(x => x.text);
run(12000);
check(G().log.includes('AT+CMGF=1') && G().log.includes('AT+CSCS="UCS2"'), 'module set up (text mode, UCS2)');
let t0 = G().now;
G().receive('+989121111111', '123on'); run(9000);
check(sentTo('09121111111', t0).some(x => x.startsWith('دزدگیر روشن شد. زون ۱')), 'user 1: «123on» -> «دزدگیر روشن شد. زون ۱» (only zone 1 is in use)');
check(sentTo('09352222222', t0).some(x => x.includes('(توسط کاربر ۱)')) && sentTo('09193333333', t0).some(x => x.includes('(توسط کاربر ۱)')), 'users 2 and 3: the same, «(توسط کاربر ۱)»');
check(G().store.size === 0, 'the message was deleted after reading');
t0 = G().now;
run(3000); tap('L1'); run(500); const l1 = red('L1');
G().receive('09352222222', 'S1 ON'); run(6000);
check(l1 === 1 && !red('L1'), 'S1ON (scenario 1 = all off by default): pole 1 off through bus B');
check(sentTo('09352222222', t0).some(x => x === 'سناریو ۱ روشن شد'), 'answer «سناریو ۱ روشن شد»');
t0 = G().now;
G().receive('09121111111', 'k1on'); G().receive('09352222222', 'وضعیت'); G().receive('09193333333', 'ﻭﺿﻌﯿﺖ'); run(16000);
check(red('K13') === 1, 'K1ON: key 13 on');
check(sentTo('09352222222', t0).some(x => x.startsWith('دزدگیر: روشن، زون ۱') && x.includes('پل‌های روشن: ۱۳')), 'three messages at once: none lost; status shows zone 1 and pole 13');
check(sentTo('09193333333', t0).some(x => x.startsWith('فرمان نامعتبر')), 'a garbled word gets «فرمان نامعتبر»');
t0 = G().now;
G().receive('09900000000', 'off'); run(4000);
check(G().sent.filter(x => x.t > t0).length === 0, 'unknown number: no answer, nothing done');
G().receive('09193333333', 'EN'); run(5000); t0 = G().now;
G().receive('09193333333', 'status'); run(6000);
check(sentTo('09193333333', t0).some(x => x.startsWith('Alarm: ON, zone 1')), 'EN: answers in English');
t0 = G().now;
G().receive('09121111111', 'CREDIT'); run(9000);
check(G().cusdCode === '*140*11#' && sentTo('09121111111', t0).some(x => x.includes('۱۲۵،۴۰۰')), 'CREDIT: *140*11# (MCI) and the operator answer forwarded');
console.log('alarm: sensor -> siren -> SMS to all, then calls');
run(45000);                                       // quiet minute after power-up has passed, exit time over
G().answer.add('09352222222');
t0 = G().now;
S.AL.C.setPin(4, true); run(400); S.AL.C.setPin(4, false); run(32000 + 30000);
const al = G().sent.filter(x => x.t > t0 && (x.text.startsWith('هشدار') || x.text.startsWith('ALARM')));
check(al.length === 3, 'siren: «هشدار! زون ۱ تحریک شد» to all 3 (' + al.length + ')');
const calls = G().calls.filter(c => c.t > t0);
check(calls.length === 2 && calls[0].to === '09121111111' && calls[1].to === '09352222222' && calls[0].t > Math.max(...al.map(x => x.t)), 'calls after the messages: 1 (no answer, 20 s), then 2 (answered), no more: ' + calls.map(c => c.to).join(','));
t0 = G().now;
G().receive('09121111111', 'خاموش'); run(14000);
check(sentTo('09121111111', t0).includes('دزدگیر خاموش شد') && !o(S.AL, 'C', 1), '«خاموش»: off, siren off');
console.log('while the module works: the elevator waits, the other keys work');
G().receive('09121111111', 'وضعیت'); run(1500);
tap('L2'); run(300); const l2 = red('L2');
let elv = 0; S.setHook(() => { if (red('EL')) elv++; }); press('EL', 1300); run(1500); S.setHook(null);
run(10000); tap('L2'); run(300);
check(l2 === 1 && elv === 0, 'during the GSM work: pole 2 works, the elevator (held 1 s) does not fire');
G().sent.forEach(x=>console.log(x.t,x.to,JSON.stringify(x.text))); console.log(G().log.slice(-40).join(' | '));
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
