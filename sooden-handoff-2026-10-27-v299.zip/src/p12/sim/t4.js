const S = require('./sim'); const { run, tap, M } = S;
const { PNG } = (() => { try { return require('/home/claude/avrsim/node_modules/pngjs'); } catch (e) { return {}; } })();
// decode the software I2C of each board into a 128x64 picture
const scr = [null], st = [null];
for (const b of [1, 2, 3]) {
  const c = M[b].cpu, fbm = Array.from({ length: 8 }, () => new Uint8Array(128)); scr.push(fbm);
  const s = { ps: 1, pc: 1, bits: [], bytes: [], page: 0, col: 0 }; st.push(s);
  const hk = c.writeHooks[0x31];
  c.writeHooks[0x31] = v => { c.data[0x31] = v; const sda = (v >> 5) & 1 ? 0 : 1, scl = (v >> 6) & 1 ? 0 : 1;
    if (s.pc && scl && s.ps && !sda) { s.bits = []; s.bytes = []; }
    else if (s.pc && scl && !s.ps && sda) { const f = s.bytes; if (f[1] === 0) { const x = f[2]; if ((x & 0xF0) === 0xB0) s.page = x & 7; else if (x < 0x10) s.col = (s.col & 0xF0) | x; else if (x < 0x20) s.col = (s.col & 0x0F) | ((x & 15) << 4); }
      else if (f[1] === 0x40) { for (let i = 2; i < f.length; i++) { if (s.col < 128) fbm[s.page][s.col] = f[i]; s.col++; } } }
    else if (!s.pc && scl) { s.bits.push(sda); if (s.bits.length === 9) { s.bytes.push(parseInt(s.bits.slice(0, 8).join(''), 2)); s.bits = []; } }
    s.ps = sda; s.pc = scl; return true; };
}
function snap(name) {
  const W = 3 * 132, H = 66, img = Buffer.alloc(W * H);
  for (let b = 1; b <= 3; b++) for (let p = 0; p < 8; p++) for (let x = 0; x < 128; x++) for (let k = 0; k < 8; k++) if ((scr[b][p][x] >> k) & 1) img[(p * 8 + k + 1) * W + (b - 1) * 132 + x + 2] = 255;
  require('fs').writeFileSync(name + '.pgm', Buffer.concat([Buffer.from(`P5 ${W} ${H} 255\n`), img]));
}
run(3200); tap('L1'); tap('L6'); tap('L12'); run(800); snap('s_states');
tap('P1O'); run(1500); snap('s_curtain'); tap('P1O'); run(1000); snap('s_stopped');
run(4000); tap('L1'); tap('L6'); tap('L12'); run(61500); snap('s_idle');
