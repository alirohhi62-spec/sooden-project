// SMS answers: fast, retried; the module restarting (supply dip) is noticed and set up again
const S = require('./sim'); const { run, red, check } = S;
require('./nums').putNums(0); S.powerAL(); const G = () => S.GSM;
run(12000); G().sendDelay = 3000;                       // a real network: ~3 s per message
let t0 = G().now; G().receive('09121111111', 'k1on'); run(15000);
const s1 = G().sent.filter(x => x.t > t0);
const first = s1.find(x => x.to === '09121111111'); const iRead = G().log.lastIndexOf('AT+CMGR=1'), iDel = G().log.lastIndexOf('AT+CMGD=1'), iSms = G().log.indexOf('AT+CMGS="00300039003100320031003100310031003100310031"', iRead);
check(red('K13') === 1 && first && first.t - t0 < 1500, 'answer to the sender leaves ' + (first && first.t - t0) + ' ms after the SMS came (then ~3 s network)');
check(iSms > iRead && iDel > iSms, 'the message is deleted after the answers');
console.log('module restarts without a word (settings gone)');
G().restart(false); t0 = G().now; G().receive('09121111111', 'k1off'); run(75000);
check(red('K13') === 0 && G().sent.some(x => x.t > t0 && x.text.startsWith('کلید ۱ خاموش')), 'found within a minute: set up again, the waiting SMS done and answered');
console.log('module restarts and says RDY');
G().restart(true); run(6000); t0 = G().now; G().receive('09352222222', 'k2on'); run(8000);
check(red('K14') === 1 && G().sent.some(x => x.t > t0 && x.to === '09352222222'), 'RDY: set up again at once, the next SMS works');
console.log('a message the network refuses goes once more');
G().failNext = 1; t0 = G().now; G().receive('09193333333', 'k2off'); run(20000);
check(G().sent.filter(x => x.t > t0 && x.to === '09193333333').length === 1, 'refused once, sent on the second try');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
