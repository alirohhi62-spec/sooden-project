// how long &ACR takes until $ACF$ arrives (HEXDIR=cur/)
const S = require('./sim'); const { run } = S;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const { attachEsp } = require('/home/claude/avrsim/esp');
const { putNums } = require('./nums');
if (process.argv[2] !== 'none') putNums(+process.argv[2] || 0); S.powerAL();
const u = new AVRUSART(S.M4.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
u.UDRE.constant = true;
let pw; const E = attachEsp({ b: { cpu: S.M4.cpu, usart: u }, a: { D: { addListener: f => pw = f }, cpu: { data: { 0x31: 0x20 } } } });
pw(0x20); run(20000); const ph = E.connect(0); run(300);
ph.rx.length = 0; E.send(0, '@M_MDL'); run(1500);
for (let rep = 0; rep < 2; rep++) {
  ph.rx.length = 0; E.send(0, '&ACR'); const t0 = S.T; let got = null;
  for (let i = 0; i < 150 && !got; i++) { run(200); got = ph.rx.join('').match(/\$(ACF#[^$]*|ACS#[^$]*)\$/); }
  console.log('reply after', ((S.T - t0) / 1000).toFixed(1), 's:', got ? got[0] : 'none');
}
