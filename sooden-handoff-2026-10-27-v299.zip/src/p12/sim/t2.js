const S = require('./sim'); const { run, tap, press, red, white, check, POLES, M, M4, o, INT6 } = S;
// EV1527 frame on PE6 (433 MHz receiver): sync 1T high + 31T low, then 24 bits (0 = 1T/3T, 1 = 3T/1T), T = 350 us
function rfSend(code, times) {
  const T = 350 * 8; let at = M4.cpu.cycles + 1000;
  const ev = (lvl) => { const c = at; M4.cpu.addClockEvent(() => { M4.E.setPin(6, !!lvl); M4.cpu.setInterruptFlag(INT6); }, c - M4.cpu.cycles); };
  for (let r = 0; r < times; r++) {
    ev(1); at += T; ev(0); at += 31 * T;
    for (let b = 23; b >= 0; b--) { const one = (code >> b) & 1; ev(1); at += (one ? 3 : 1) * T; ev(0); at += (one ? 1 : 3) * T; }
  }
  ev(1); at += T; ev(0);
  return Math.ceil((at - M4.cpu.cycles) / 8000) + 5;
}
run(2600);
console.log('remote: hold key 13 for 5 s, then touch pole 3');
let blink = 0, pw = 1; S.setHook(() => { const w = white('K13'); if (w !== pw) blink++; pw = w; });
press('K13', 5300); run(1200); S.setHook(null);
check(blink >= 3 && red('K13') === 0, `key 13 white blinks (${blink} changes), its own pole did not stay on`);
tap('L3'); run(300);
const id = 0x5A3C10;                 // remote id (low 4 bits = button)
run(rfSend(id | 1, 4)); run(500);
check(red('L3') === 0, 'remote stored (pole 3 not switched by the learning press)');
run(1000);
run(rfSend(id | 1, 4)); run(600);
check(red('L3') === 1, 'remote button: pole 3 on');
run(800); run(rfSend(id | 2, 4)); run(600);
check(red('L3') === 0, 'another button of the same remote: pole 3 off');
run(800); run(rfSend(0x123450 | 1, 4)); run(600);
check(red('L3') === 0 && POLES.every(k => !red(k)), 'an unknown remote does nothing');
console.log('erase: hold key 14 for 5 s, then touch it once more');
press('K14', 5300); run(500); tap('K14'); run(2500);
run(rfSend(id | 1, 4)); run(600);
check(red('L3') === 0, 'after erase the remote does nothing');
console.log('a lost frame heals: M1 pole 1 forced on by hand');
const v = M[1]; const valAddr = null;
tap('L1'); run(400); check(red('L1') === 1, 'pole 1 on');
// corrupt: flip M1 PA4/PA5 directly as if a frame was lost
v.cpu.data[0x3B] &= ~0x10; v.cpu.data[0x3B] |= 0x20;
run(9000);
check(red('L1') === 1 && white('L1') === 0, 'M1 output back on after the periodic repeat');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
