// curtain percent while moving (HEXDIR=g_prog2/)
const S = require('./sim'); const { run, tap, red, check } = S;
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const { attachEsp } = require('/home/claude/avrsim/esp');
const u = new AVRUSART(S.M4.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
  UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
u.UDRE.constant = true;
let pw; const E = attachEsp({ b: { cpu: S.M4.cpu, usart: u }, a: { D: { addListener: f => pw = f }, cpu: { data: { 0x31: 0x20 } } } });
pw(0x20); run(20000); const ph = E.connect(0); run(300);
const ask = (c, ms) => { ph.rx.length = 0; E.send(0, c); run(ms || 800); return ph.rx.join(''); };
ask('@M_MDL', 1500); let r = ask('@M_CF#24'); console.log(r);
const sec = parseInt(r.split('#')[3], 16);
ask('&K#24', 400); run(sec * 500); r = ask('@M_POS', 300); const p = +r.match(/POS#(\d\d)/)[1];
check(p >= 40 && p <= 60, 'curtain 1 half way after half its time: ' + p + '% (' + sec + ' s)');
run(sec * 600); r = ask('@M_POS', 300); check(/POS#99/.test(r), 'open at the end: ' + r);
const res = S.res(); console.log(`${res.n - res.fails}/${res.n} passed`);
