// A SIM800 model on the alarm MCU's USART0 (enough of it for the panel firmware): SMS storage, +CMTI, CMGL / CMGR / CMGD,
// CMGS with the "> " prompt, calls (ATD, +COLP when answered), USSD, CSQ / CREG / CIMI. Text mode, UCS2 character set.
const { AVRUSART } = require('/home/claude/avrsim/node_modules/avr8js');
const hex = s => [...s].map(c => c.charCodeAt(0).toString(16).toUpperCase().padStart(4, '0')).join('');
const unhex = h => (h.match(/..../g) || []).map(x => String.fromCharCode(parseInt(x, 16))).join('');
function attach(chip, opts = {}) {
  const u = new AVRUSART(chip.cpu, { rxCompleteInterrupt: 0x24, dataRegisterEmptyInterrupt: 0x26, txCompleteInterrupt: 0x28,
    UCSRA: 0x2B, UCSRB: 0x2A, UCSRC: 0x95, UBRRL: 0x29, UBRRH: 0x90, UDR: 0x2C }, 8000000);
  // real hardware: UDRE stays set until UDR is written (avr8js clears it when the interrupt runs), and writing UCSRB does not drop a received byte
  u.UDRE.constant = true;
  { const h = chip.cpu.writeHooks[0x2A]; chip.cpu.writeHooks[0x2A] = (v, ov) => { const a = chip.cpu.data[0x2B] & 0x80; const r = h(v, ov); if (a) chip.cpu.setInterruptFlag(u.RXC); return r; }; }
  const m = { out: [], cmd: '', inBody: null, store: new Map(), next: 1, sent: [], calls: [], log: [], answer: new Set(), imsi: opts.imsi || '432113000000001',
    ussd: opts.ussd || 'شارژ: ۱۲۵،۴۰۰ ریال', timers: [], now: 0, cusdCode: null, text: 0, ucs2: 0, cnmi: 0, sendDelay: 800, failNext: 0, restarts: 0 };
  const say = s => { for (const c of s) m.out.push(c.charCodeAt(0)); };
  const later = (ms, f) => m.timers.push([m.now + ms, f]);
  u.onByteTransmit = b => {
    if (m.inBody !== null) {                              // SMS text after the "> " prompt
      if (b === 0x1A) { const to = unhex(m.inBody.num), text = unhex(m.inBody.text); m.inBody = null; if (m.failNext) { m.failNext--; later(m.sendDelay, () => say('\r\n+CMS ERROR: 500\r\n')); return; } m.sent.push({ to, text, t: m.now }); if (m.onSms) m.onSms(to, text); later(m.sendDelay, () => say('\r\n+CMGS: 7\r\n\r\nOK\r\n')); }
      else if (b === 0x1B) { m.inBody = null; }
      else m.inBody.text += String.fromCharCode(b);
      return;
    }
    if (b === 13) { const c = m.cmd; m.cmd = ''; m.log.push(c); handle(c); return; }
    if (b !== 10) m.cmd += String.fromCharCode(b);
  };
  function handle(c) {
    let r;
    if (c === 'AT+CMGF=1') m.text = 1; if (c === 'AT+CSCS="UCS2"') m.ucs2 = 1; if (c.startsWith('AT+CNMI=2')) m.cnmi = 1;
    if (c === 'AT+CMGF?') return later(20, () => say('\r\n+CMGF: ' + (m.text ? 1 : 0) + '\r\n\r\nOK\r\n'));
    if (c.startsWith('AT+CMGL=') && m.listErr) return later(20, () => say('\r\n+CMS ERROR: 302\r\n'));   // SIM storage not ready (settings kept)
    if (c === 'AT' || c === 'ATE0' || /^AT\+(CMGF|CSCS|CSMP|CNMI|COLP)=/.test(c)) return later(20, () => say('\r\nOK\r\n'));
    if ((c.startsWith('AT+CMGL=') || c.startsWith('AT+CMGS=')) && !(m.text && m.ucs2)) return later(20, () => say('\r\nERROR\r\n'));   // settings lost (after a restart)
    if (c === 'AT+CIMI') return later(20, () => say('\r\n' + m.imsi + '\r\n\r\nOK\r\n'));
    if (c === 'AT+CSQ') return later(20, () => say('\r\n+CSQ: 18,0\r\n\r\nOK\r\n'));
    if (c === 'AT+CREG?') return later(20, () => say('\r\n+CREG: 0,1\r\n\r\nOK\r\n'));
    if (c.startsWith('AT+CMGL=')) return later(50, () => { let s = ''; for (const [i, x] of m.store) s += '\r\n+CMGL: ' + i + ',"' + hex('REC UNREAD') + '","' + hex(x.from) + '","","' + hex('26/10/19,16:00:00+14') + '"\r\n' + hex(x.text); say(s + '\r\n\r\nOK\r\n'); });
    if ((r = c.match(/^AT\+CMGR=(\d+)$/))) return later(60, () => { const x = m.store.get(+r[1]); if (!x) return say('\r\nOK\r\n'); say('\r\n+CMGR: "' + hex('REC UNREAD') + '","' + hex(x.from) + '","","' + hex('26/10/19,16:00:00+14') + '"\r\n' + hex(x.text) + '\r\n\r\nOK\r\n'); });
    if ((r = c.match(/^AT\+CMGD=(\d+)$/))) { m.store.delete(+r[1]); return later(80, () => say('\r\nOK\r\n')); }
    if ((r = c.match(/^AT\+CMGS="([0-9A-F]+)"$/))) { m.inBody = { num: r[1], text: '' }; return later(200, () => say('\r\n> ')); }
    if ((r = c.match(/^ATD(\+?\d+);$/))) { const num = r[1]; m.calls.push({ to: num, t: m.now, ans: m.answer.has(num) }); m.inCall = num; if (m.onCall) m.onCall(num, 'ring'); if (m.answer.has(num)) later(3000, () => say('\r\n+COLP: "' + num + '",129,"",0,""\r\n\r\nOK\r\n')); return; }
    if (c === 'ATH') { if (m.inCall && m.onCall) m.onCall(m.inCall, 'end'); m.inCall = null; return later(50, () => say('\r\nOK\r\n')); }
    if ((r = c.match(/^AT\+CUSD=1,"([0-9A-F]+)"$/))) { m.cusdCode = unhex(r[1]); later(30, () => say('\r\nOK\r\n')); return later(2500, () => say('\r\n+CUSD: 0,"' + hex(m.ussd) + '",72\r\n')); }
    later(20, () => say('\r\nERROR\r\n'));
  }
  m.pickUp = () => { if (!m.inCall) return; const num = m.inCall; if (m.onCall) m.onCall(num, 'talk'); say('\r\n+COLP: "' + num + '",129,"",0,""\r\n\r\nOK\r\n'); };
  m.hangUp = () => { if (!m.inCall) return; if (m.onCall) m.onCall(m.inCall, 'end'); m.inCall = null; say('\r\nNO CARRIER\r\n'); };
  m.receive = (from, text) => { const i = m.next++; m.store.set(i, { from, text }); if (m.cnmi) later(100, () => say('\r\n+CMTI: "' + hex('SM') + '",' + i + '\r\n')); };
  m.restart = (rdy) => { m.text = m.ucs2 = m.cnmi = 0; m.restarts++; m.inBody = null; m.cmd = ''; if (rdy) later(3000, () => say('\r\nRDY\r\n\r\n+CFUN: 1\r\n\r\n+CPIN: READY\r\n\r\nCall Ready\r\n\r\nSMS Ready\r\n')); };
  m.tick = () => {                                        // every simulated ms: timers, then one byte to the MCU (9600 baud)
    m.now++;
    const due = m.timers.filter(x => x[0] <= m.now); if (due.length) { m.timers = m.timers.filter(x => x[0] > m.now); due.forEach(x => x[1]()); }
    if (m.out.length && !u.rxBusy && u.writeByte(m.out[0])) m.out.shift();
  };
  m.usart = u;
  return m;
}
module.exports = { attach, hex, unhex };
