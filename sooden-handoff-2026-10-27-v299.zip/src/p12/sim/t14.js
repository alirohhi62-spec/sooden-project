// RS485: the 12-pole panel paired with a 4-pole panel (poles, curtain key) and, on the same line, a room of the 7-segment
const S = require('./sim'); const { run, tap, press, red, check } = S;
const N = require('./net'); N.p12();
const P = N.pair4(1, [0, 15, 19, -1]);                  // its keys 1..3 <-> 12-pole pole 1, curtain 1 open, elevator
const R2 = N.room4(2);
const CODE4 = [7, 0, 3, 4];
function t8(n, pole) { const c = CODE4[pole]; n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); run(80); n.pc.setPin(2, true); n.pc.setPin(3, true); n.pc.setPin(4, true); n.pc.setPin(5, true); run(80); }
const r4 = n => N.X.r4(n).map(v => v === 1 ? 1 : 0).join('');
run(6000);
tap('L1'); run(1500); check(red('L1') === 1 && r4(P)[0] === '1', '12-pole pole 1 on -> 4-pole key 1 on (' + r4(P) + ')');
t8(P, 0); run(1500); check(!red('L1') && r4(P)[0] === '0', '4-pole key 1 off -> 12-pole pole 1 off');
t8(P, 1); run(1500); check(red('P1O') === 1, '4-pole key 2 -> 12-pole curtain 1 opens');
tap('P1O'); run(1500); check(!red('P1O') && r4(P)[1] === '0', '12-pole curtain 1 stopped -> 4-pole key 2 off (' + r4(P) + ')');
tap('L2'); run(1000); check(r4(P) === '0000', 'pole 2 (not linked): the 4-pole panel stays as it was');
t8(R2, 0); t8(R2, 3); run(500);
tap('SUP'); tap('SUP'); run(200); tap('SOFF'); run(2000);
check(r4(R2) === '0000', 'same line: room 2 all off from the 7-segment (' + r4(R2) + ')');
tap('L1'); run(1500); check(r4(P)[0] === '1', 'and the pair still works after the room command');
console.log('   bytes on the line:', N.wire.length);
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
