// alarm MCU: keypad arm / disarm, exit / entry delay, siren, remote, magnet, power cut, password change
const S = require('./sim'); const { run, check, AL, o } = S;
const { snap } = require('./oled');
const AK = { k6: [0, 0], k5: [0, 1], k4: [0, 2], k1: [0, 3], k2: [0, 4], kL: [0, 5], kR: [0, 6], k3: [0, 7], kOK: [1, 0], kD: [1, 1], k0: [1, 2], kC: [1, 3], k7: [1, 5], k8: [1, 6], k9: [1, 7] };
function key(k, ms) { const [ic, code] = AK[k], b = ic * 4; AL.A.setPin(b + 1, !!(code & 4)); AL.A.setPin(b + 2, !!(code & 2)); AL.A.setPin(b + 3, !!(code & 1)); AL.A.setPin(b, false); run(ms || 60); AL.A.setPin(b, true); run(150); }
const pin = s => { for (const c of s) key('k' + c); };
const red = z => [o(AL, 'B', 7), o(AL, 'D', 2), o(AL, 'D', 4)][z], wh = z => [o(AL, 'B', 6), o(AL, 'D', 1), o(AL, 'D', 3)][z];
const siren = n => o(AL, 'C', n + 1);
const sens = (n, v) => AL.C.setPin([4, 6, 5, 7][n], !!v);
const INT4 = { address: 10, flagRegister: 0x58, flagMask: 0x10, enableRegister: 0x59, enableMask: 0x10 };
function rf(code) {
  const T = 350 * 8; let at = AL.cpu.cycles + 1000;
  const ev = (l) => { const c = at; AL.cpu.addClockEvent(() => { AL.E.setPin(4, !!l); AL.cpu.setInterruptFlag(INT4); }, c - AL.cpu.cycles); };
  for (let r = 0; r < 4; r++) { ev(1); at += T; ev(0); at += 31 * T; for (let b = 23; b >= 0; b--) { const one = (code >> b) & 1; ev(1); at += (one ? 3 : 1) * T; ev(0); at += (one ? 1 : 3) * T; } }
  ev(1); at += T; ev(0); run(Math.ceil((at - AL.cpu.cycles) / 8000) + 50);
}
run(3000); snap('a_off');
check(wh(0) && !red(0) && !siren(0), 'off: zone 1 white');
key('kD'); snap('a_sel'); key('kOK'); pin('1234'); run(200);
check(red(0) || !wh(0), 'armed with the password: zone 1 leaving (blinking red)'); snap('a_exit');
run(41000); check(red(0) && !wh(0), 'after 40 s: zone 1 red');
run(20000);                                   // the 60 s quiet time after power-up has passed
sens(0, 1); run(300); sens(0, 0); snap('a_entry');
run(31000); check(siren(0) && !siren(1), 'no password in 30 s: siren 1 on (siren 2 off)'); snap('a_siren');
key('kD'); pin('1234'); run(300); check(!siren(0) && wh(0) && !red(0), 'password: siren off, alarm off');
console.log('wrong password');
key('kD'); key('kOK'); pin('9999'); run(300); check(wh(0) && !red(0), 'wrong password: stays off');
console.log('remote: hold OK 3 s, then a remote button');
key('kOK', 3300); run(200); rf(0xABC120 | 1); run(500);
rf(0xABC120 | 1); run(300); check(red(0) || !wh(0), 'remote button 1: zone 1 armed');
rf(0xABC120 | 2); run(300); check(wh(0) && !red(0), 'remote button 2: off');
rf(0x123450 | 1); run(300); check(wh(0), 'an unknown remote does nothing');
console.log('power cut keeps the state');
rf(0xABC120 | 1); run(42000); check(red(0), 'armed');
const ee = AL.ee.memory.slice(0, 0x80);
S.AL.cpu.reset ? 0 : 0;
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
require('fs').writeFileSync('ee_al.bin', Buffer.from(ee));
