// 12-pole SIM panel: M4 + M1 + M2 + M3 firmwares wired as on the board (avr8js)
const fs = require('fs');
const { CPU, AVRIOPort, AVREEPROM, EEPROMMemoryBackend } = require('/home/claude/avrsim/node_modules/avr8js');
const { step } = require('/home/claude/avrsim/step');
const core = require('/home/claude/avrsim/cfgcore');
const MS = 8000, HD = process.env.HEXDIR || '';
function prog(f, words) { const m = core.parseHex(fs.readFileSync(f, 'utf8')), p = new Uint16Array(words); for (const [a, v] of m) { if (a & 1) p[a >> 1] |= v << 8; else p[a >> 1] |= v; } return p; }
const P = (cpu, PIN, DDR, PORT) => new AVRIOPort(cpu, { PIN, DDR, PORT, externalInterrupts: [] });
function chip(file, big) {
  const cpu = new CPU(prog(file, big ? 32768 : 16384), big ? 4096 : 2048);
  const c = { cpu, A: P(cpu, 0x39, 0x3A, 0x3B), B: P(cpu, 0x36, 0x37, 0x38), C: P(cpu, 0x33, 0x34, 0x35), D: P(cpu, 0x30, 0x31, 0x32) };
  if (big) { c.E = P(cpu, 0x21, 0x22, 0x23); c.F = P(cpu, 0x20, 0x61, 0x62); c.G = P(cpu, 0x63, 0x64, 0x65);
    c.ee = new EEPROMMemoryBackend(2048);
    new AVREEPROM(cpu, c.ee, { eepromReadyInterrupt: 44, EECR: 0x3C, EEDR: 0x3D, EEARL: 0x3E, EEARH: 0x3F, eraseCycles: 34000, writeCycles: 34000 }); }
  const T0 = big ? { address: 30, flagRegister: 0x56, flagMask: 0x02, enableRegister: 0x57, enableMask: 0x02 }
                 : { address: 20, flagRegister: 0x58, flagMask: 0x02, enableRegister: 0x59, enableMask: 0x02 };
  const t = () => { if (cpu.data[0x53] & 7) cpu.setInterruptFlag(T0); cpu.addClockEvent(t, MS); }; cpu.addClockEvent(t, MS);
  let hi = 0; cpu.readHooks[0x4C] = () => { const v = Math.floor(cpu.cycles / 8) & 0xFFFF; hi = v >> 8; return v & 0xFF; }; cpu.readHooks[0x4D] = () => hi;
  for (const k of ['A', 'B', 'C', 'D', 'E', 'F', 'G']) if (c[k]) for (let i = 0; i < 8; i++) c[k].setPin(i, true);
  return c;
}
const M = [null, chip(HD + 'fw_p12_m1.hex'), chip(HD + 'fw_p12_m2.hex'), chip(HD + 'fw_p12_m3.hex')];
const M4 = chip(process.env.M4HEX || HD + 'fw_p12_m4.hex', true);
M4.E.setPin(6, false);
const INT6 = { address: 14, flagRegister: 0x58, flagMask: 0x40, enableRegister: 0x59, enableMask: 0x40 };
const o = (c, p, n) => (c.cpu.data[{ A: 0x3B, B: 0x38, C: 0x35, D: 0x32, E: 0x23, F: 0x62, G: 0x65 }[p]] >> n) & 1;
function wire() {
  M4.B.setPin(7, !!o(AL, 'E', 5)); M4.B.setPin(6, !!o(AL, 'E', 6)); M4.B.setPin(5, !!o(AL, 'E', 7)); M4.B.setPin(4, !!o(AL, 'B', 0));
  AL.B.setPin(2, !!o(M4, 'B', 2)); AL.B.setPin(3, !!o(M4, 'B', 0)); AL.B.setPin(4, !!o(M4, 'E', 7));
  const a = [o(M4, 'D', 6), o(M4, 'D', 5), o(M4, 'D', 4), o(M4, 'D', 1), o(M4, 'D', 0)];
  M[1].A.setPin(1, !!a[0]); M[1].A.setPin(0, !!a[1]); M[1].B.setPin(0, !!a[2]); M[1].B.setPin(1, !!a[3]); M[1].B.setPin(2, !!a[4]);
  for (let i = 0; i < 5; i++) M[2].A.setPin(i, !!a[i]);
  M[3].D.setPin(2, !!a[0]); M[3].D.setPin(3, !!a[1]); M[3].D.setPin(4, !!a[2]); M[3].D.setPin(7, !!a[3]); M[3].C.setPin(0, !!a[4]);
}
let AL = chip(HD + 'fw_p12_alarm.hex', true);
const SIM800 = require('./sim800'); let GSM = SIM800.attach(AL);
for (let i = 4; i < 8; i++) AL.C.setPin(i, false);   // sensors closed (normal)
const all = [M[1], M[2], M[3], M4, AL];
let T = 0, hook = null;
const extra = [];   // other panels on the RS485 line (net.js): [cpu, wrap]
function run(ms) { for (let t = 0; t < ms; t++) { for (const c of all) { const end = c.cpu.cycles + MS; while (c.cpu.cycles < end) step(c.cpu); } for (const [c, w] of extra) { const end = c.cycles + MS; while (c.cycles < end) step(c, w); } wire(); GSM.tick(); T++; if (hook) hook(); } }
let fails = 0, n = 0; const check = (c, m) => { n++; if (!c) fails++; console.log((c ? '  ok   ' : '  FAIL ') + m); };
const IC = [[['A', 4], ['A', 5], ['A', 6], ['A', 7]], [['C', 6], ['C', 5], ['C', 4], ['D', 7]], [['C', 0], ['C', 1], ['C', 2], ['C', 3]], [['A', 3], ['A', 2], ['A', 1], ['A', 0]]];
// key name -> [ic, code]
const K = { L1: [0, 4], L2: [0, 3], L3: [0, 5], L4: [0, 2], L5: [0, 6], L6: [0, 1], L7: [0, 7], L8: [0, 0], L9: [1, 4], L10: [1, 3], L11: [1, 5], L12: [1, 2],
  S1: [1, 6], S2: [1, 7], S3: [1, 0], S4: [1, 1], S5: [2, 0], S6: [2, 1], M: [2, 2], K13: [2, 3], K14: [2, 4], K15: [2, 5], EL: [3, 5], SON: [3, 0], SUP: [3, 1], SOFF: [3, 2], SDN: [2, 6], P1O: [3, 4], P1C: [3, 6], P2O: [3, 3], P2C: [3, 7] };
function press(k, ms) { const [ic, code] = K[k], d = IC[ic]; M4[d[1][0]].setPin(d[1][1], !!(code & 4)); M4[d[2][0]].setPin(d[2][1], !!(code & 2)); M4[d[3][0]].setPin(d[3][1], !!(code & 1)); M4[d[0][0]].setPin(d[0][1], false); run(ms); M4[d[0][0]].setPin(d[0][1], true); }
function tap(k) { press(k, 80); run(250); }
// outputs: [board, white port,bit, red port,bit]
const OUT = { L1: [1, 'A', 5, 'A', 4], L2: [1, 'D', 1, 'D', 0], L3: [1, 'A', 3, 'A', 2], L4: [1, 'B', 4, 'B', 3], L5: [2, 'C', 2, 'C', 3], L6: [2, 'B', 4, 'B', 3], L7: [2, 'A', 7, 'A', 6], L8: [2, 'B', 2, 'B', 1],
  L9: [3, 'C', 1, 'C', 2], L10: [3, 'D', 1, 'D', 0], L11: [3, 'C', 4, 'C', 3], L12: [3, 'B', 4, 'B', 3], K13: [3, 'B', 2, 'B', 1], S1: [3, 'C', 6, 'C', 5], S2: [3, 'A', 7, 'C', 7], S3: [3, 'A', 5, 'A', 6],
  S4: [3, 'A', 3, 'A', 4], S5: [3, 'A', 1, 'A', 2], S6: [3, 'B', 0, 'A', 0], EL: [3, null, 0, 'B', 5], P1O: [1, 'C', 0, 'C', 1], P1C: [1, 'D', 7, 'D', 4], P2O: [1, 'C', 2, 'C', 3], P2C: [1, 'D', 3, 'D', 2], A: [2, 'C', 0, 'C', 1] };
const red = k => { if (k === 'K14') return o(M4, 'G', 0); if (k === 'K15') return o(M4, 'G', 4); const x = OUT[k]; return o(M[x[0]], x[3], x[4]); };
const white = k => { if (k === 'K14') return o(M4, 'G', 1); if (k === 'K15') return o(M4, 'G', 2); const x = OUT[k]; return x[1] ? o(M[x[0]], x[1], x[2]) : 0; };
const POLES = ['L1', 'L2', 'L3', 'L4', 'L5', 'L6', 'L7', 'L8', 'L9', 'L10', 'L11', 'L12'];
function powerAL() { const mem = AL.ee.memory.slice(); AL = chip(HD + 'fw_p12_alarm.hex', true); AL.ee.memory.set(mem); for (let i = 4; i < 8; i++) AL.C.setPin(i, false); all[4] = AL; GSM = SIM800.attach(AL); return AL; }
module.exports = { powerAL, get GSM() { return GSM; }, get AL() { return AL; }, M, M4, run, press, tap, red, white, check, o, POLES, INT6, get T() { return T; }, setHook: h => hook = h, addChip: (c, w) => extra.push([c, w]), res: () => ({ n, fails }) };
