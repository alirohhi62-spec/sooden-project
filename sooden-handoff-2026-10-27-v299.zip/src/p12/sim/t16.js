const S = require('./sim'); const { run, tap } = S; const { snap } = require('./oled');
run(4000); tap('SUP'); run(200); snap('r_a'); tap('SON'); run(100); snap('r_b'); run(900); snap('r_c'); run(1500); snap('r_d');
