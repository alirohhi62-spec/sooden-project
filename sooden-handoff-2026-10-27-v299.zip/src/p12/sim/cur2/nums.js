const S=require('./sim');
const NUMS = ['09121111111', '09352222222', '09193333333'], CALLS = ['09121111111', '09352222222', ''];
function ck(b) { let c = 0x5A; for (const x of b) c = (((c << 1) | (c >> 7)) & 0xFF) ^ x; return c; }
function putNums(en) {
  const d = []; const pad = s => { const a = [...s].map(c => c.charCodeAt(0)); while (a.length < 14) a.push(0); return a; };
  NUMS.forEach(n => d.push(...pad(n))); CALLS.forEach(n => d.push(...pad(n))); d.push(en || 0);
  const rec = [0x5E, ...d]; rec.push(ck(rec));
  for (const base of [0x100, 0x180]) rec.forEach((v, i) => S.AL.ee.memory[base + i] = v);
}
module.exports={putNums};
