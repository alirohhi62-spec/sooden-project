const S = require('./sim'); const { run, tap, press, red, white, POLES, M4 } = S;
run(2600);
const st=()=>POLES.map(k=>red(k)).join('')+' K13:'+red('K13');
tap('L1'); console.log('after L1', st(), 'w', white('L1'));
run(500); console.log('later', st());
tap('L1'); console.log(st());
tap('L3'); run(300); console.log('L3', st());
tap('M'); for(let i=0;i<6;i++){run(400); console.log('M', S.T, st());}
