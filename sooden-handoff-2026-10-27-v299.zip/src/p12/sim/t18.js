// a programmer-made 4-pole room panel (room 3) with the programmer-made 12-pole panel (HEXDIR=prog/)
const S = require('./sim'); const { run, tap, check } = S;
const N = require('./net'); N.p12();
const R = N.X.m8(require('fs').readFileSync('prog4/n3.hex', 'utf8'), null, 1); S.addChip(R.cpu, 0xFFF); N.join(R.cpu, R.usart, 'room3');
const CODE4 = [7, 0, 3, 4];
function t8(n, pole) { const c = CODE4[pole]; n.pc.setPin(3, !!(c & 1)); n.pc.setPin(4, !!(c & 2)); n.pc.setPin(5, !!(c & 4)); n.pc.setPin(2, false); run(80); n.pc.setPin(2, true); n.pc.setPin(3, true); n.pc.setPin(4, true); n.pc.setPin(5, true); run(80); }
const r4 = () => N.X.r4(R).map(v => v === 1 ? 1 : 0).join('');
run(4000);
const w0 = N.wire.length; run(3000); check(N.wire.length === w0, 'quiet line: neither panel talks first (' + (N.wire.length - w0) + ' bytes)');
t8(R, 0); t8(R, 2); run(500); check(r4() === '1010', 'room 3: poles 1 and 3 on by hand (' + r4() + ')');
tap('SUP'); tap('SUP'); tap('SUP'); run(200); tap('SOFF'); run(2000); check(r4() === '0000', 'OFF on room 3 -> all off (' + r4() + ')');
tap('SON'); run(2000); check(r4() === '1111', 'ON on room 3 -> all on (' + r4() + ')');
const r = S.res(); console.log(`${r.n - r.fails}/${r.n} passed`);
