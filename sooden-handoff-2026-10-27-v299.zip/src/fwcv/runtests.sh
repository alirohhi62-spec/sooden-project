#!/bin/sh
# build every hex from the source folder $1 with AVR-GCC and run all simulator tests on them
# (the hex files of the programmer in /home/claude/fw/out are put back afterwards)
SRC=${1:-/home/claude/fwcv/src}
set -e
cd $SRC
sh build.sh > build.log 2>&1 || { tail -30 build.log; exit 1; }
sh build_big.sh > build_big.log 2>&1 || { tail -30 build_big.log; exit 1; }
grep -E "^fw_" build.log build_big.log | awk '{print $1, $2, $3}' | sed 's/^[^:]*://' > sizes.txt
[ -d /home/claude/fw/out.orig ] || cp -a /home/claude/fw/out /home/claude/fw/out.orig
cp $SRC/out/*.hex $SRC/out/*.elf /home/claude/fw/out/
cd /home/claude/avrsim
for t in ${TESTS:-tpx tp2 tgen tkinds tlat test t4single tremote ttimer tvac tesp tcustom tbig talarm tdark twifi}; do
  out=$(timeout 3000 node $t.js 2>&1) || true; echo "$t: $(echo "$out" | tail -1)   [FAIL lines: $(echo "$out" | grep -c FAIL)]"
done
cd $SRC
for f in "" "-DHAS_SEC=1 -DHAS_ILOCK=1 -DHAS_SCN=1"; do
  cp /home/claude/fw/sim.c $SRC/_sim.c
  gcc -O1 -w $f $SRC/_sim.c $SRC/sw.c -o /tmp/simcv && echo "host sim $f: $(/tmp/simcv | tail -1)"
  rm -f $SRC/_sim.c
done
rm -rf /home/claude/fw/out && cp -a /home/claude/fw/out.orig /home/claude/fw/out
echo "done"
