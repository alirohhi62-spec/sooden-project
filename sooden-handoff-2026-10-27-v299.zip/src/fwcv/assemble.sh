#!/bin/sh
set -e
S=/home/claude/fwcv/src; P=/home/claude/fwcv/pkg; O=/home/claude/fwcv/dist
rm -rf $O; mkdir -p $O
# --- 4 pole family
D=$O/sooden-4pole-CV; mkdir -p $D
cp $S/port.h $S/cfg.h $S/sw.h $S/sw.c $S/main_avr.c $S/build.sh $D/
cp $P/options_4p.h $D/options.h
cat $P/hdr_4p.txt $P/README-common.txt > $D/README-fa.txt
# --- 23-key families
big() {  # dir title models hexname options
  D=$O/$1; mkdir -p $D/atmega64 $D/atmega32
  cp $S/port.h $S/cfg.h $S/sw.h $S/sw.c $S/link.h $S/wifi64.h $S/wifi64.c $S/main64.c $D/atmega64/
  cp $P/$5 $D/atmega64/options.h
  cp $S/port.h $S/link.h $S/io32.c $D/atmega32/
  cp $P/options_io32.h $D/atmega32/options.h
  sed -e '/fw_big_io32/d' -e '/avr-objcopy -O ihex -R .eeprom out\/fw_big_io32/d' $S/build_big.sh > $D/atmega64/build_big.sh
  cat > $D/atmega32/build_io32.sh <<'X'
#!/bin/sh
# ATmega32 of the 23-key board with AVR-GCC (the hex fw_big_io32 of the programmer)
set -e
export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH
mkdir -p out
avr-gcc -mmcu=atmega32 -DF_CPU=8000000UL -Os -Wall -Wextra -std=gnu99 -mcall-prologues -mrelax -flto -ffunction-sections -fdata-sections -Wl,--gc-sections io32.c -o out/fw_big_io32.elf
avr-objcopy -O ihex -R .eeprom out/fw_big_io32.elf out/fw_big_io32.hex
avr-size out/fw_big_io32.elf
X
  sed -e "s|TITLE|$2|" -e "s|MODELS|$3|" -e "s|HEXNAME|$4|g" $P/hdr_big.txt > $D/README-fa.txt
  cat $P/README-common.txt >> $D/README-fa.txt
}
big sooden-alarm-CV "پنل‌های دزدگیردار ساده سودن (برد ۲۳ کلید)" "مدل‌ها: دزدگیردار ۱۴، ۱۲، ۱۰، ۸ و ۶ پل و دو چیدمان سفارشی (کیپد ۴ و ۶ رقمی): پل‌ها، سناریوها، دزدگیر، ریموت، وای‌فای و اپ، شبکهٔ دو پنل." fw_big_a options_alarm.h
big sooden-20pole-CV "پنل‌های ۲۰ پل سودن (برد ۲۳ کلید)" "مدل‌ها: ۲۰ پل، پل + سناریو سفارشی، ۲۰ پل سفارشی: پل‌ها، سناریوها، ریموت، وای‌فای و اپ، شبکهٔ دو پنل (بدون دزدگیر)." fw_big options_20.h
cd $O
for d in sooden-4pole-CV sooden-alarm-CV sooden-20pole-CV; do
  find $d -type f -name '*.c' -o -name '*.h' -o -name '*.txt' | xargs sed -i 's/$/\r/'   # Windows line ends for CodeVision
  for r in $(find $d -name README-fa.txt); do printf '\357\273\277' | cat - $r > $r.t && mv $r.t $r; done
  zip -qr $d.zip $d
done
ls -la $O
