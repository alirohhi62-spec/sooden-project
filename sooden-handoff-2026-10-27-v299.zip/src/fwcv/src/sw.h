/* Sooden two-way switch - hardware independent logic */
#ifndef SW_H
#define SW_H
#include "port.h"
#include "cfg.h"

/* features compiled into this firmware (every panel kind gets its own hex, only with what it has) */
#ifndef HAS_REMOTE
#define HAS_REMOTE 1
#endif
#ifndef HAS_PX
#define HAS_PX 0        /* two-panel network v2: every key reported, scenarios reach the other panel (no remote on an ATmega8) */
#endif
#if HAS_PX
#undef HAS_PAIR
#define HAS_PAIR 1
#endif
#ifndef HAS_PAIR
#define HAS_PAIR 1
#endif
#ifndef HAS_SEC
#define HAS_SEC 0       /* T_DELOFF, T_DELAY */
#endif
#ifndef HAS_ILOCK
#define HAS_ILOCK 0     /* T_ILOCK, T_OFFTMR (curtain, cooler) */
#endif
#ifndef HAS_SCN
#define HAS_SCN 0       /* T_EXIT, T_SLEEP, T_ELEV (EXIT / SLEEP / ELEVATOR scenarios) */
#endif
#ifndef HAS_ALARM
#define HAS_ALARM 0     /* keypad alarm: only in the alarm panels (23-key board) */
#endif
#if HAS_ALARM && !defined(SW_BIG)
#error "the alarm is only on the 23-key board"
#endif
#define HAS_PH (HAS_SEC || HAS_ILOCK)
#ifdef SW_BIG
/* the ATmega32 already filters the touches: they act at once */
#define KEY_PRESS_MS(s) 0
#define KEY_REL_MS      0
#define KEY_GAP_MS(s)   0
#define TRUTH(x)        ((x) != 0)
#define BOOT_STEP_BIG   60
#define BOOT_TOTAL      (BOOT_STEP_BIG * SW_NP)
#define BOOT_SHOW(w)    do { (w) = BIT(s->bootMs / BOOT_STEP_BIG); } while (0)   /* one white after the other */
typedef uint16_t crc_n_t;
#define PM_ALL(n) ((pm_t)((1UL << (n)) - 1))
#define DIM_KEEP  0                               /* dark: every white off (scenario 2 is lit by the supply) */
#else
#define KEY_PRESS_MS(s) ((s)->c.tpress)
#define KEY_REL_MS      T_RELEASE
#define KEY_GAP_MS(s)   ((uint16_t)(s)->c.tgap2 * 2)
#define TRUTH(x)        (x)
#define BOOT_TOTAL      ((uint16_t)T_BOOTSTEP * 4 * BOOT_ROUNDS)
#define BOOT_SHOW(w)    do { uint8_t k_ = (uint8_t)((s->bootMs / T_BOOTSTEP) & 3); (w) = BIT(k_ ^ (k_ >> 1)); } while (0)   /* circle 0 1 3 2 */
typedef uint8_t crc_n_t;
#define PM_ALL(n) ((uint8_t)((1u << (n)) - 1))
#define DIM_KEEP  0x08                            /* only pole 4 white stays */
#endif
#define MAX_REMOTES N_SLOTS
#define NO_REMOTE 0xFFFFFFUL    /* empty remote place (a real id always ends in 0) */

#ifdef SW_BIG
extern const pm_t bit32[32];
#define BIT(i) (bit32[(i)])
#define GETB(x, i) (((x) & BIT(i)) != 0)
#else
#define BIT(i) ((pm_t)(1u << (i)))
#define GETB(x, i) (((x) >> (i)) & 1)
#endif
typedef struct {
    /* hot 8/16-bit fields first: on the AVR they stay within the short (LDD, offset < 64) reach */
    uint8_t nphys;
    pm_t state, pendMask, pendVal, pendNotify, pendFast;
    pm_t white, red;
    uint8_t buzz, beepOn, booting;
    pm_t kRaw, kStable;
    uint8_t holdKey, holdDone, holdToggled;
    uint8_t mode, modePole, dimmed, lslot, logOn;
    uint8_t hOn, hK, hC, hStage, tsK, tsC, tsN, blkN;
    pm_t rtMask;
#ifdef SW_BIG
    uint8_t wifi;                 /* Wi-Fi module power (ATmega32 PD5 -> MP2315 EN), kept over a power cut */
#endif
    pm_t darkMask;                /* whites already dark (dimming / lighting up again goes one key at a time) */
    uint16_t dkMs;
    pm_t txMask, txVal;           /* link: own keys to report (v2: every key; v1: linked poles) */
    uint8_t outActive, outPole, outVal, outSeq, outTries, seq;
    uint8_t online, needFull, helloDone, synced, ackDue, ackSeq, rxn;
    uint8_t rfBits, rfOn;
    volatile uint8_t rfNew;
    uint16_t stag, msAcc, hMs, tsLeft, blkMs, rfHi, rfT, rng, jit;
    /* elapsed-time counters (saturating), advanced once per tick: cheaper than 32-bit stamps */
    uint8_t kMs, beepLeft, idleSec;
    uint16_t holdMs, modeMs, bootMs, stagMs, idleMs;
    uint16_t tmrSec[SW_NP];       /* service scenario / off timer: seconds left */
#if HAS_PH
    uint8_t ph[SW_NP];            /* 0 idle, 1 waiting (delay, delayed off, change-over pause), 2 on with a time limit */
    uint16_t cnt[SW_NP];          /* 100 ms units left in that phase */
    uint8_t tenAcc;
#endif
#if HAS_SCN
    pm_t elevOut;                 /* red / relay outputs of the elevator call */
    pm_t nightMask;               /* SLEEP night lights: the panel may go dark while they are on */
    uint16_t elevLeft;            /* ms the elevator relay stays on */
#endif
#if HAS_ALARM
    uint8_t alSt, enOn, enN, enPw, pir, sirenOn, sirenPin;
    uint8_t pirMs;
    uint16_t enVal, pin, enIdle, sirenBeep, bootDig, redHoldMs;
    uint8_t redPrev;              /* ON/OFF and change-password reds kept as they were for a moment */
    uint8_t alSaveDue;            /* EEPROM save waits until then too: writing blocks ~50 ms and would cut the beep */
    uint32_t alLeft;
#endif
#ifdef SW_BIG
    uint8_t ovDirty, ovPos, ovCrc;  /* settings changed from the phone / by a 4 s hold: being written to EEPROM */
#endif

    uint32_t bootAt;
    uint32_t lastNow, lastRf, lastRfAt, logged;
    volatile uint32_t rfCode;
    uint32_t rfAcc, rfPrev;
    uint32_t linkNow;
    uint16_t nextWait, outMs, txMs, peerMs;   /* link timing: countdown / elapsed ms */
    uint8_t ackWait, rxMs;
    uint16_t rtSec[SW_NP];        /* remote timer: seconds left */
    uint32_t rid[MAX_REMOTES];
    uint8_t tsel[N_SLOTS * 4];/* chosen timer length per place/button, 2 bits each */
#if HAS_PX
    uint8_t sMask[3], sVal[3];    /* keys of the other panel to switch (from our scenarios), waiting to be sent */
    uint8_t pst[3];               /* keys of the other panel that are on (as it last reported); bit p of byte p >> 3 */
    uint8_t outKind, fullN, fullC;
    uint16_t pressSeq;            /* last key press from the other panel (a repeated frame acts once) */
#ifdef SW_BIG
    uint8_t pressK;               /* key of the other panel touched in the phone app, to be sent (0xFF none) */
#endif
    uint8_t (*pxm)(uint8_t k, uint8_t which, uint8_t *m);   /* keys of the other panel in key k's scenario (PX_ON / PX_OFF)
                                                               into m[3]; returns 0 when there are none */
#endif
    uint8_t rxb[6];

    /* platform */
    void (*tx)(const uint8_t *p, uint8_t n);
    uint8_t (*eer)(uint16_t a);
    void (*eew)(uint16_t a, uint8_t v);
    Cfg c;
} Sw;

enum { M_NORMAL = 0, M_LEARN, M_ERASE, M_OK, M_TSET };

/* timing (ms) */
#define T_STAGGER   80    /* default when the configuration gives none */
#define T_PRESS     2     /* touch acts at once: the code only has to be steady this long (ms) */
#define T_GAP       30    /* default: a new touch is taken this long after the last one at the earliest (ms) */
#define T_RELEASE   3     /* the finger counts as lifted after this long without touch (ms) */
#define T_HOLD      5000
#define T_WINDOW    5000
#define T_OKSHOW    2000
#define T_BLINK     250
#define T_ACK       150
#define T_TURN      15    /* quiet time before answering on the RS485 line */
#define N_RETRY     4
#define T_PING      1000
#define T_OFFLINE   3500
#define T_RFREPEAT  400
#define T_BEEP      40    /* buzzer beep on touch (active buzzer) */
#define T_BOOTSTEP  120   /* power-up: one white LED at a time, circle 1-2-4-3 */
#define BOOT_ROUNDS 3
#define T_LOGWIN    900000UL  /* remote codes are recorded to EEPROM for 15 min after power-up */
#define T_RTHOLD    5000      /* hold a remote button: 2 blinks, release -> timer */
#define T_RTSET     15000     /* keep holding: 2 blinks, release -> choose the timer length */
#define T_RTIDLE    10000     /* choosing ends 10 s after the last press */
#define T_BLK       200       /* confirmation blink: 200 ms dark, 200 ms light */
#define T_DARKSTEP  50        /* dimming and lighting up again: one white every 50 ms, place 1 first */
#define WIFI_KEY    22        /* 23-key board: scenario 3 key (bottom right) */
#define T_WIFIHOLD  7000      /* hold it 7 s: Wi-Fi on / off; shorter: its scenario runs when the finger is lifted */
#define T_WIFIBEEP  200

/* frame */
#define F_SOF   0xA5
#define F_STATE 1
#define F_ACK   2
#define F_PING  3
#define F_HELLO 4
#define F_FULL  5
/* v2 (HAS_PX): F_FULL seq = chunk (keys 8 x chunk ..) | FULL_APPLY when the receiver should follow it (linked keys) */
#define F_ST    6     /* d = key | v << 7: this key of mine is now v (acked) */
#define F_SET   7     /* d = key | v << 7: switch your key to v (from a scenario of mine; acked) */
#define F_PRESS 8     /* d = key: act as if your key was touched (phone app through the other panel; acked) */
#define FULL_APPLY 0x80
#define PX_ON   0
#define PX_OFF  1

uint8_t sw_crc8(const uint8_t *p, crc_n_t n);
uint8_t sw_cfg_ok(const Cfg *c);
void sw_init(Sw *s, const Cfg *c, uint32_t now);
void sw_tick(Sw *s, uint32_t now, pm_t keys);
void sw_rx(Sw *s, uint8_t b, uint32_t now);
void sw_link(Sw *s, uint32_t now);   /* call after the outputs were written: may block while sending */
void sw_rf_edge(Sw *s, uint16_t dt, uint8_t level); /* ISR context */
#ifdef SW_BIG
uint8_t sw_app_press(Sw *s, uint8_t i, uint32_t now);   /* phone app: like a remote (lights a dark panel and acts) */
uint8_t sw_al_state(Sw *s);                             /* phone app: 0 off, 1 arming, 2 armed, 3 entry time, 4 siren */
uint8_t sw_al_code(Sw *s, uint16_t code);               /* phone app: right password arms / disarms (1), wrong: 0 */
uint8_t sw_al_setpin(Sw *s, uint16_t code);             /* phone app: new password, only when disarmed */
uint8_t sw_set(Sw *s, uint8_t k, char f, uint32_t v);   /* phone app: change one setting of key k (0 = refused) */
uint8_t sw_set_al(Sw *s, uint8_t arm, uint8_t entry, uint8_t siren, uint8_t dim);
uint8_t sw_apply(Sw *s, pm_t on, pm_t off);             /* phone scenario: poles on / off (0 = panel locked) */
pm_t sw_scn_poles(Sw *s);                               /* poles a scenario may switch (relay poles, curtains, cooler) */
void sw_ov_step(Sw *s);                                 /* call when the EEPROM is free: writes changed settings a byte at a time */
void sw_ov_clear(Sw *s);                                /* forget every phone change (the programmed settings return at the next start) */
uint16_t sw_left(Sw *s, uint8_t k);                     /* seconds left of a running timer of key k */
#if HAS_PX
uint8_t sw_px_press(Sw *s, uint8_t k);                  /* phone app: touch key k of the other panel (0 = not reachable) */
#endif
#endif

/* EEPROM layout
 * 0x00..0x04  last received remote code (for the programmer): 0xA7, code[23:16], [15:8], [7:0], crc
 * 0x10/0x50/0x90  learned remotes by place, 3 copies: magic, 4 x (id[23:16], id[15:8], id[7:0]), crc */
#define EE_LOG   0x00
#define EE_LOGMAGIC 0xA7
#define EE_COPY0 0x10
#define EE_COPY1 0x50
#define EE_COPY2 0x90
#define EE_MAGIC 0x60
/* 0xB0: recorded remote buttons, in the order they were first pressed (for the programmer):
   magic, next, count, then up to EE_RECN x (code[23:16], code[15:8], code[7:0]) as a ring */
#define EE_REC     0xB0
#define EE_RECMAGIC 0xB5
#define EE_RECN    100
/* 0x20/0x60/0x1E0: timer length chosen by the customer per place/button, 3 copies: magic, 16 bytes, crc */
#define EE_TS0 0x20
#define EE_TS1 0x60
#define EE_TS2 0x1E0
#define EE_TSMAGIC 0x61
#define EE_TSLEN (2 + N_SLOTS * 4)
#define EE_LEN   (2 + MAX_REMOTES * 3)   /* magic, 4 x id (FFFFFF = empty), crc */
/* 23-key board, 0x300/0x340/0x380: alarm password and armed state, 3 copies: magic, pin hi, pin lo, armed, crc */
#define EE_AL0 0x300
#define EE_AL1 0x305
#define EE_AL2 0x30A
#define EE_ALMAGIC 0x62
#define EE_ALLEN 5
/* 23-key board, 0x3C0/0x3FA/0x2F0: Wi-Fi on/off, 3 copies: magic, state, crc */
#define EE_WF0 0x3C0
#define EE_WF1 0x3FA
#define EE_WF2 0x2F0
/* 23-key board, 0x200..0x28B: settings changed from the phone or by a 4 s hold (they replace the programmed ones):
   magic, crc of the programmed settings (other programming = not used), minutes[23], sec1[23], sec2[23],
   onmask and offmask of places 13..20 (4 bytes each), alarm times (3), dark time, crc */
#define EE_OV      0x200
#define EE_OVMAGIC 0x64
#define OV_K0      12
#define OV_NK      8
#define OV_LEN     (2 + 3 * SW_NP + 2 * 4 * OV_NK + 4 + 1)
/* 0x290..0x2EF: phone scenarios, 12 x 8: kind (N F D, FF = empty), minutes hi, lo, 20 places x 2 bits
   (0 off, 1 on, 2 unchanged); names 18 bytes: 0x310 + 18 n (n < 9), 0x3C4 + 18 (n - 9) */
#define EE_PS      0x290
#define T_SCNHOLD  4000   /* custom scenario / group key held 4 s: stores what is on now */
#define EE_WFMAGIC 0x63
#define EE_WFLEN 3

/* alarm states */
enum { AL_OFF = 0, AL_ARMING, AL_ARMED, AL_ENTRY, AL_SIREN, AL_PAUSE };
#define T_ENTRYIDLE 10000  /* keypad closes after 10 s without a digit (not while the entry time runs) */
#define T_PWHOLD    2000   /* hold the change-password key 2 s */
#define T_ALBEEP    500    /* siren confirmation beep */
#define T_ALPAUSE   2000   /* quiet time after the siren, before the confirmation beep */
#define T_PIRMS     100    /* sensor must be active this long */
#define T_ELEVHOLD  1000   /* elevator: key held 1 s */
#define T_ELEVON    1000   /* elevator relay 1 s */
#define T_DIGSHOW   10000  /* power-up: digits lit 10 s */
#define T_REDHOLD   500    /* last digit: the reds change 0.5 s later, so its beep is heard in full */
#define T_ELEVBEEP  200    /* elevator: beep when the relay closes (confirmation) */

#endif
