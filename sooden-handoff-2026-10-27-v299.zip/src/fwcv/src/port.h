/* Sooden panels - compiler layer
 *
 * The same source files build with CodeVisionAVR (archive / maintenance) and with AVR-GCC
 * (the hex files of the SoodenProg programmer, tested in the simulator).
 * Everything that differs between the two compilers is here; the rest of the code is plain C.
 *
 *   ROM             a table or string in FLASH        (CodeVision: flash,  GCC: const __flash)
 *   PATCHED         a FLASH block the programmer fills in later (cfg_flash, px_flash)
 *   FS("text")      a string literal in FLASH, for ROM char * parameters
 *   ISR_xxx         interrupt routine header          (CodeVision: interrupt [xxx] void ...)
 *   cli() / sei()   interrupts off / on
 *   wdt_reset(), wdt_enable(WDTO_15MS | WDTO_1S)
 *   delay_us(n)     busy wait, n must be a constant
 *   ee_rd(a), ee_wr(a, v), ee_upd(a, v), ee_ready()   EEPROM byte access (address 0..)
 */
#ifndef PORT_H
#define PORT_H

#ifdef __CODEVISIONAVR__
/* ======================================================= CodeVisionAVR ======================================================= */
#include "options.h"            /* what this build holds (CodeVision has no -D switches) */
#define _IO_BITS_DEFINITIONS_   /* the register bit names (RXEN, OCIE2, ...) */
#include <io.h>                 /* the header of the chip chosen in Project | Configure | C Compiler */
#include <delay.h>
#include <string.h>

typedef unsigned char  uint8_t;
typedef signed char    int8_t;
typedef unsigned int   uint16_t;
typedef signed int     int16_t;
typedef unsigned long  uint32_t;
typedef signed long    int32_t;

#ifndef offsetof
#define offsetof(t, m)  ((unsigned int)&(((t *)0)->m))
#endif
#define ROM             flash
#define PATCHED         flash
#define FS(s)           (s)
#define INLINE
#define ATTR_UNUSED
#define NOINLINE
#define PACKED                         /* CodeVision never pads structures */
#define AT_SECTION(name)               /* placed by the linker; see README */
#ifndef _BV
#define _BV(b)          (1 << (b))
#endif

#define cli()           (SREG &= 0x7F)
#define sei()           (SREG |= 0x80)

static void wdt_reset(void)
{
#asm("wdr")
}
#define WDTO_15MS       0
#define WDTO_1S         6
static void wdt_enable(uint8_t v)
{
    uint8_t w = (uint8_t)(0x08 | (v & 7)), s = SREG;   /* WDE + prescaler */
    SREG &= 0x7F;
#asm("wdr")
    WDTCR = 0x18;                                      /* WDCE (WDTOE on the ATmega32) + WDE: timed change */
    WDTCR = w;
    SREG = s;
}

#define ee_rd(a)        (*(eeprom uint8_t *)(a))
#define ee_wr(a, v)     (*(eeprom uint8_t *)(a) = (v))
#define ee_upd(a, v)    do { if (ee_rd(a) != (uint8_t)(v)) ee_wr(a, v); } while (0)
#define ee_ready()      ((EECR & 0x02) == 0)           /* EEWE */

/* interrupt routines (CodeVision vector names) */
#define ISR_TIM2_COMP   interrupt [TIM2_COMP] void tim2_comp_isr(void)
#define ISR_TIM0_COMP   interrupt [TIM0_COMP] void tim0_comp_isr(void)
#define ISR_INT0        interrupt [EXT_INT0] void ext_int0_isr(void)
#define ISR_INT1        interrupt [EXT_INT1] void ext_int1_isr(void)
#define ISR_INT5        interrupt [EXT_INT5] void ext_int5_isr(void)
#define ISR_USART_RXC   interrupt [USART_RXC] void usart_rxc_isr(void)
#define ISR_USART0_RXC  interrupt [USART0_RXC] void usart0_rxc_isr(void)
#define ISR_USART0_DRE  interrupt [USART0_DRE] void usart0_dre_isr(void)
#define ISR_USART1_RXC  interrupt [USART1_RXC] void usart1_rxc_isr(void)
#define ISR_USART1_DRE  interrupt [USART1_DRE] void usart1_dre_isr(void)

#else
/* ========================================================== AVR-GCC ========================================================== */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#ifdef __AVR__
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/delay.h>

#define ROM             const __flash
#define PATCHED         const volatile __flash   /* written later by the programmer: never folded */
#define FS(s)           (__extension__({ static const __flash char __s[] = (s); &__s[0]; }))
#define INLINE          inline
#define ATTR_UNUSED     __attribute__((unused))
#define NOINLINE        __attribute__((noinline))
#define AT_SECTION(name) __attribute__((section(name), used))
#define PACKED          __attribute__((packed))
#define delay_us(n)     _delay_us(n)

#define ee_rd(a)        eeprom_read_byte((const uint8_t *)(a))
#define ee_wr(a, v)     eeprom_write_byte((uint8_t *)(a), (v))
#define ee_upd(a, v)    eeprom_update_byte((uint8_t *)(a), (v))
#define ee_ready()      eeprom_is_ready()

#define ISR_TIM2_COMP   ISR(TIMER2_COMP_vect)
#define ISR_TIM0_COMP   ISR(TIMER0_COMP_vect)
#define ISR_INT0        ISR(INT0_vect)
#define ISR_INT1        ISR(INT1_vect)
#define ISR_INT5        ISR(INT5_vect)
#define ISR_USART_RXC   ISR(USART_RXC_vect)
#define ISR_USART0_RXC  ISR(USART0_RX_vect)
#define ISR_USART0_DRE  ISR(USART0_UDRE_vect)
#define ISR_USART1_RXC  ISR(USART1_RX_vect)
#define ISR_USART1_DRE  ISR(USART1_UDRE_vect)
#else
/* host build (simulator of the logic on the PC): tables are plain constants */
#define ROM             const
#define PATCHED         const volatile
#define FS(s)           (s)
#define INLINE          inline
#define ATTR_UNUSED     __attribute__((unused))
#define NOINLINE
#define AT_SECTION(name)
#define PACKED          __attribute__((packed))
#endif
#endif

/* strings in FLASH (the same code for both compilers) */
ATTR_UNUSED static uint8_t f_eq(const char *s, ROM char *f)                 /* s == f */
{
    while (*f) { if (*s != *f) return 0; s++; f++; }
    return *s == 0;
}
ATTR_UNUSED static uint8_t f_eqn(const char *s, ROM char *f, uint8_t n)     /* the first n characters of s == f */
{
    while (n--) { if (*s != *f) return 0; if (!*f) return 1; s++; f++; }
    return 1;
}


/* 0xFF fill for the blocks the programmer patches (an erased flash reads 0xFF) */
#define FF8     0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
#define FF64    FF8, FF8, FF8, FF8, FF8, FF8, FF8, FF8
#define FF256   FF64, FF64, FF64, FF64

#endif
