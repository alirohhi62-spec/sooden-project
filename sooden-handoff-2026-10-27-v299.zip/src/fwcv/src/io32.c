/* Sooden 23-key board - ATmega32 @ 8 MHz crystal (fuses Low 3F, High C1: BOD 4 V, JTAG off, EESAVE)
 * Reads the three BS818A-2 touch chips and the 433 MHz receiver, drives the buzzer,
 * and reports everything to the ATmega64 over the clocked link (see link.h).
 * The same program for every model: what a key does is decided in the ATmega64.
 *
 * touch chip 1: valid PC4 (low = touched), code PC5 PC6 PC7 (bit2 bit1 bit0)
 * touch chip 2: valid PA7, code PA6 PA5 PA4
 * touch chip 3: valid PA3, code PA2 PA1 PA0
 * 433 MHz data PD3 (INT1), buzzer PB4 (high = on)
 * link out: clock PD1, data PD4     link in: clock PD2 (INT0), data PD0
 * Wi-Fi power: PD5 (pin 14) -> MP2315 EN, high = on; low from the first moment, then as the ATmega64 says
 */
#include "port.h"
#include "link.h"

/* key index: 0..19 = places 1..20, 20/21/22 = scenario 1/2/3; 0xFF = no key */
#define NK 23
static const uint8_t KEYMAP[3][8] = {
    /* chip 1, codes 0..7 */ { 6, 4, 2, 0, 12, 14, 16, 18 },
    /* chip 2 */             { 9, 11, 22, 21, 20, 10, 8, 0xFF },
    /* chip 3 */             { 19, 17, 15, 13, 1, 3, 5, 7 },
};

static volatile uint32_t ms;
ISR_TIM2_COMP { ms++; }
static uint32_t now_ms(void) { uint32_t v; cli(); v = ms; sei(); return v; }

/* ---------------- 433 MHz (EV1527, 24 bit): same decoder as the 4 pole panels ---------------- */
static uint16_t rfLast, rfHi, rfT;
static uint8_t rfBits, rfOn;
static uint32_t rfAcc, rfPrev;
static volatile uint32_t rfCode;
static volatile uint8_t rfNew;
ISR_INT1
{
    uint16_t hi;
    uint16_t lo;
    uint16_t T;
    uint16_t sh;
    uint16_t lg;
    uint8_t bv;
    uint16_t t = TCNT1, dt = t - rfLast;
    rfLast = t;
    if (!(PIND & _BV(3))) { rfHi = dt; return; }    /* falling edge: a high segment ended */
    hi = rfHi; lo = dt;
    if (hi >= 100 && hi <= 1200 && lo >= hi * 18u && lo <= hi * 45u && lo >= 3000) {
        rfT = lo / 31; rfBits = 0; rfAcc = 0; rfOn = 1;
        return;
    }
    if (!rfOn) return;
    T = rfT;

    if (hi > lo) { bv = 1; sh = lo; lg = hi; } else { bv = 0; sh = hi; lg = lo; }
    if (sh < T / 2 || sh > T * 2 || lg < T * 2 || lg > T * 5) { rfOn = 0; return; }
    rfAcc = (rfAcc << 1) | bv;
    if (++rfBits == 24) {
        rfOn = 0;
        if (rfAcc == rfPrev) { rfCode = rfAcc; rfNew = 1; }
        rfPrev = rfAcc;
    }
}

/* ---------------- link in (from the ATmega64) ---------------- */
static uint16_t lkLast;
static uint8_t lkBits, lkN, lkByte, lkBuf[LK_LEN];
static volatile uint8_t lkRx[LK_LEN], lkRxNew;
ISR_INT0
{
    uint8_t i;
    uint16_t t = TCNT1;
    if ((uint16_t)(t - lkLast) > LK_GAP_US) { lkBits = 0; lkN = 0; }   /* pause: new frame */
    lkLast = t;
    lkByte = (uint8_t)((lkByte << 1) | ((PIND & _BV(0)) ? 1 : 0));
    if (++lkBits < 8) return;
    lkBits = 0;
    if (lkN == 0 && lkByte != LK_SOF) return;
    lkBuf[lkN++] = lkByte;
    if (lkN < LK_LEN) return;
    lkN = 0;
    if (lk_crc(lkBuf + 1, LK_LEN - 2) != lkBuf[LK_LEN - 1]) return;
    for (i = 0; i < LK_LEN; i++) lkRx[i] = lkBuf[i];
    lkRxNew = 1;
}

/* ---------------- link out (to the ATmega64) ---------------- */
static void lk_send(uint8_t type, uint8_t seq, uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3)
{
    uint8_t i, b;
    uint8_t f[LK_LEN];
    f[0] = LK_SOF; f[1] = type; f[2] = seq; f[3] = d0; f[4] = d1; f[5] = d2; f[6] = d3;
    f[LK_LEN - 1] = lk_crc(f + 1, LK_LEN - 2);
    PORTD &= (uint8_t)~_BV(1);
    delay_us(LK_GAP_US + 50);                          /* a clear pause before every frame */
    for (i = 0; i < LK_LEN; i++) {
        for (b = 0x80; b; b >>= 1) {
            if (f[i] & b) PORTD |= _BV(4); else PORTD &= (uint8_t)~_BV(4);
            delay_us(LK_SETUP_US);
            PORTD |= _BV(1);
            delay_us(LK_HOLD_US);                    /* data stays put long after the edge: the */
            PORTD &= (uint8_t)~_BV(1);                /* receiver may answer the edge late */
        }
    }
    wdt_reset();
}

/* ---------------- touch ---------------- */
static uint32_t read_keys(void)
{
    uint32_t k = 0;
    uint8_t a = PINA, c = PINC;
    if (!(c & _BV(4))) {                                /* chip 1 */
        uint8_t code = (uint8_t)(((c >> 5) & 1) << 2 | ((c >> 6) & 1) << 1 | ((c >> 7) & 1));
        k |= 1UL << KEYMAP[0][code];
    }
    if (!(a & _BV(7))) {                                /* chip 2 */
        uint8_t code = (uint8_t)(((a >> 6) & 1) << 2 | ((a >> 5) & 1) << 1 | ((a >> 4) & 1));
        if (KEYMAP[1][code] != 0xFF) k |= 1UL << KEYMAP[1][code];
    }
    if (!(a & _BV(3))) {                                /* chip 3 */
        uint8_t code = (uint8_t)(((a >> 2) & 1) << 2 | ((a >> 1) & 1) << 1 | (a & 1));
        k |= 1UL << KEYMAP[2][code];
    }
    return k;
}

/* key events wait here until the ATmega64 acknowledges them */
#define QN 16
static struct { uint8_t type, key; } q[QN];
static uint8_t qh, qt, seq, tries;
static uint16_t waitMs;
static void q_push(uint8_t type, uint8_t key)
{
    uint8_t n = (uint8_t)((qt + 1) % QN);
    if (n == qh) qh = (uint8_t)((qh + 1) % QN);         /* full: the oldest goes */
    q[qt].type = type; q[qt].key = key; qt = n;
}

int main(void)
{
    uint8_t i;
    uint8_t tpress;
    uint8_t tgap;
    uint8_t fresh;
    uint8_t buz;
    uint8_t buzLeft;
    uint16_t helloMs;
    uint16_t setAge;
    uint16_t buzMs;
    uint32_t keys;
    uint32_t raw;
    uint32_t stable;
    uint32_t last;
    uint8_t kMs;
    uint16_t sincePress;
    /* JTAG off (it would take PC2..PC5); the fuse does it too */
    MCUCSR |= _BV(JTD); MCUCSR |= _BV(JTD);
    MCUCSR = 0;

    DDRA = 0x00;  PORTA = 0xFF;                         /* touch chips 2, 3 */
    DDRB = 0x1F;  PORTB = 0x00;                         /* PB4 buzzer; PB5..7 = ISP (shared): inputs */
    DDRC = 0x00;  PORTC = 0xFF;                         /* PC4..7 touch chip 1, PC0..3 unused (pull-up) */
    DDRD = _BV(1) | _BV(4) | _BV(5);                    /* link out clock / data, Wi-Fi power */
    PORTD = (uint8_t)~(_BV(1) | _BV(4) | _BV(5));       /* Wi-Fi off; inputs with pull-up: link in, 433, unused */

    OCR2 = 124; TCCR2 = _BV(WGM21) | _BV(CS22);          /* 1 ms */
    TIMSK |= _BV(OCIE2);
    TCCR1A = 0; TCCR1B = _BV(CS11);                      /* 1 us ticks (433 MHz and link timing) */
    MCUCR = _BV(ISC10) | _BV(ISC01) | _BV(ISC00);        /* INT1 any change, INT0 rising */
    GIFR = _BV(INTF0) | _BV(INTF1);
    GICR |= _BV(INT0) | _BV(INT1);
    wdt_enable(WDTO_1S);
    sei();

    tpress = 2; tgap = 30; fresh = 1; buz = 0; buzLeft = 0;
    helloMs = 250; setAge = 0; buzMs = 0;
    keys = 0; raw = 0; stable = 0; last = now_ms();
    kMs = 0;
    sincePress = 0xFFFF;

    for (;;) {
        uint32_t now;
        uint16_t dt;
        wdt_reset();
        now = now_ms();
        dt = (uint16_t)(now - last);
        if (dt > 1000) dt = 1000;
        last = now;
        if (dt) {
            kMs = kMs + dt < 255 ? (uint8_t)(kMs + dt) : 255;
            sincePress = sincePress + dt < 0xFFFF ? (uint16_t)(sincePress + dt) : 0xFFFF;
            helloMs += dt; setAge = setAge + dt < 60000U ? (uint16_t)(setAge + dt) : 60000U;
            waitMs = waitMs + dt < 60000U ? (uint16_t)(waitMs + dt) : 60000U;
            if (buz) { buzMs += dt; if (buzMs >= (uint16_t)buzLeft * 10) buz = 0; }
        }

        /* messages from the ATmega64 */
        if (lkRxNew) {
            uint8_t f[LK_LEN];
            cli(); memcpy(f, (const void *)lkRx, LK_LEN); lkRxNew = 0; sei();
            if (f[1] == LK_ACK) {
                if (qh != qt && f[2] == seq) { qh = (uint8_t)((qh + 1) % QN); tries = 0; waitMs = 1000; }
            } else if (f[1] == LK_SET) {
                if (f[3] >= 1 && f[3] <= 50) tpress = f[3];
                if (f[4] >= 5) tgap = f[4];
                if (f[5] & LK_F_WIFI) PORTD |= _BV(5); else PORTD &= (uint8_t)~_BV(5);   /* kept if the ATmega64 goes silent */
                setAge = 0; fresh = 0;
            } else if (f[1] == LK_BUZ) {
                buz = f[3] ? 1 : 0; buzLeft = f[4]; buzMs = 0;
            }
        }
        if (setAge > 2000) { buz = 0; fresh = 1; }      /* ATmega64 silent: safe state, ask again */
        if (buz) PORTB |= _BV(4); else PORTB &= (uint8_t)~_BV(4);

        /* touch: acts as soon as the code is steady (press ms); the next touch is taken once the
           finger was lifted and the gap since the last touch has passed (like the 4 pole panels) */
        keys = read_keys();
        if (keys != raw) { raw = keys; kMs = 0; }
        else {
            uint32_t up;
            uint32_t pressed = keys & ~stable;
            if (pressed && kMs >= tpress) {
                stable |= pressed;
                for (i = 0; i < NK; i++) if (pressed & (1UL << i)) q_push(LK_KDOWN, i);
                sincePress = 0;
            }
            up = stable & ~keys;
            if (up && kMs >= 3 && sincePress >= (uint16_t)tgap * 2) {
                stable &= keys;
                for (i = 0; i < NK; i++) if (up & (1UL << i)) q_push(LK_KUP, i);
            }
        }

        /* send: the oldest key event (again after 10 ms without answer, 6 tries), remote codes, hello */
        if (qh != qt && waitMs >= 10) {
            if (tries == 0) seq = (uint8_t)(seq + 1) ? (uint8_t)(seq + 1) : 1;
            if (tries >= 6) { qh = (uint8_t)((qh + 1) % QN); tries = 0; }   /* lost: drop it */
            else { lk_send(q[qh].type, seq, q[qh].key, 0, 0, 0); tries++; waitMs = 0; }
        }
        if (rfNew) {
            uint32_t c; cli(); c = rfCode; rfNew = 0; sei();
            lk_send(LK_RF, 0, (uint8_t)(c >> 16), (uint8_t)(c >> 8), (uint8_t)c, 0);
        }
        if (helloMs >= 300) {
            helloMs = 0;
            lk_send(LK_HELLO, 0, IO32_VERSION, fresh, 0, 0);
        }
    }
}
