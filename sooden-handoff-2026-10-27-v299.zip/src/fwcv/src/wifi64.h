/* Sooden 23-key board - Wi-Fi (ESP8266 with AT firmware on USART0) and the phone app protocol */
#ifndef WIFI64_H
#define WIFI64_H
#include "sw.h"

void wf_poll(Sw *s, uint32_t now);   /* call every main loop pass: powers the UART with the module, runs everything */

#endif
