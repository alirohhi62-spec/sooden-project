/* Sooden panel - configuration block (128 bytes at flash 0x1F80, written by the programmer) */
#ifndef CFG_H
#define CFG_H
#include "port.h"

#define CFG_ADDR   0x1F80
#define CFG_SIZE   128
#define CFG_M0     0x53
#define CFG_M1     0xD2
#define CFG_VER    3

#define BOARD_2P   0      /* 1 or 2 pole board (touch PB5/PD4, out PB3/PB4) */
#define BOARD_4P   1      /* 3 or 4 pole board (BS818A-2 coded touch, white+red per pole) */

enum { T_OFF = 0, T_NORMAL = 1, T_MASTER = 2, T_TIMER = 3,
       T_OFFTMR = 4,   /* off timer: touch -> after minutes[] switch offmask off (touch again cancels) */
       T_DELOFF = 5,   /* delayed off: touch on; touch -> sec1 s blinking, then off */
       T_DELAY  = 6,   /* push button: after sec1 s (0 = at once) on; sec2 s pulse (0 = stays on) */
       T_ILOCK  = 7,   /* interlocked (curtain / cooler speed): offmask = partner, onmask = pump,
                          sec1 = run time s (0 = no limit), sec2 = change-over pause x100 ms */
       /* 8..10: alarm keys, 23-key board only (see below) */
       T_EXIT   = 11,  /* EXIT scenario: after sec1 | sec2 << 8 seconds offmask off, then onmask started
                          (curtain close). Under 60 s the panel is locked meanwhile; from 60 s a touch cancels */
       T_SLEEP  = 12,  /* SLEEP scenario: same timing; at the end offmask off and onmask (night light) on */
       T_ELEV   = 13,  /* elevator call: held 1 s -> the red/relay output of onmask 1 s on */
       T_CUSTOM = 14,  /* 23 keys, places 13..20: custom scenario - touch: onmask on, offmask off (stepped);
                          held 4 s: the poles on right now are stored as onmask, the others as offmask */
       T_GROUP  = 15 };/* 23 keys, places 13..20: group - touch: onmask all on, or all off when one is on;
                          held 4 s: the poles on right now become the group (no red for either) */
#define T_SCN_LONG 60      /* scenario of at least this many seconds: touch cancels; shorter: panel locked */
/* remote button table entry: bits 0-3 = poles, bits 4-5 = action */
enum { A_TOGGLE = 0, A_ON = 1, A_OFF = 2 };
#define RT_TIMER 0x40     /* entry bit 6: holding this button starts a timer for its poles */
#define N_SLOTS  4        /* remote places on a 4-pole panel (one per pole) */
#define NO_LINK 0xFF

/* two-panel network v2 (HAS_PX): a second block in flash with the keys of the OTHER panel that each key's
   scenario switches (master / group: on-list, service: on + off, off timer / EXIT / SLEEP: off, custom: on + off).
   m0 = 'P', m1 = 'X', n = keys, on[n][3], off[n][3] (24-bit masks of the other panel's keys, high byte first),
   23-key board also: the other panel's model id and key letters for the phone app; crc8 over all bytes but the last */
#define PX_M0 0x50
#define PX_M1 0x58
#ifndef SW_BIG
#define PX_ADDR 0x1F40
#define PX_SIZE 64
#else
#define PX_ADDR 0xF300
#define PX_SIZE 256
#define PX_PMDL (3 + 6 * 23)          /* 141: other panel's model id, 8 bytes */
#define PX_PLAY (PX_PMDL + 8)         /* 149: other panel's key letters, 23 bytes */
#define PX_PNP  (PX_PLAY + 23)        /* 172: other panel's keys (4 for a 4-pole panel) */
#define PX_WIFI (PX_PNP + 1)          /* 173: 1 = this panel shows the other one in the phone app */
#endif

#ifndef SW_BIG
/* ===== 1..4 pole panels (ATmega8): 128 bytes at 0x1F80 ===== */
typedef uint8_t pm_t;      /* one bit per pole */
typedef uint8_t rm_t;      /* remote table entry: poles bits 0-3, action bits 4-5, RT_TIMER bit 6 */
#define SW_NP      4
#define RM_POLES(e) ((e) & 0x0F)
#define RM_ACT(e)   (((e) >> 4) & 3)
typedef struct {
    uint8_t m0, m1, ver;
    uint8_t role;        /* 0 = A, 1 = B */
    uint8_t board;       /* BOARD_2P / BOARD_4P */
    uint8_t npoles;      /* 1..4 as sold */
    uint8_t peerpoles;   /* informational */
    uint8_t remote;      /* 1 = 433 MHz receiver present/enabled (4P only) */
    uint8_t type[4];     /* T_* per pole */
    uint8_t link[4];     /* peer pole index or NO_LINK (v2: 0..22) */
    uint8_t offmask[4];  /* timer scenario: poles to switch off */
    uint8_t onmask[4];   /* master: target poles / timer: poles to switch on */
    uint8_t minutes[4];  /* timer scenario: auto-off minutes (0 = no auto-off) */
    uint8_t dimsec;      /* 4P: seconds idle before whites 1-3 go dark (0 = never) */
    uint8_t beep;        /* bit i = short buzzer beep when pole i is touched on this panel */
    uint8_t stag10;      /* group switching step in 10 ms units (0 = 80 ms) */
    uint8_t nslot;       /* remote places defined for this panel (0..N_SLOTS) */
    uint8_t rmap[N_SLOTS][16];   /* per remote place: button code 0..15 -> poles + action (+ RT_TIMER) */
    uint8_t tmin[4];             /* the 4 timer lengths the customer can choose from, minutes (0 = unused) */
    uint8_t tdef[N_SLOTS * 4];   /* default choice 0..3 per place/button, 2 bits each */
    uint8_t sec1[4];             /* T_DELOFF/T_DELAY/T_ILOCK seconds, see above */
    uint8_t sec2[4];
    uint8_t tpress;              /* touch: ms the key must be steady before it acts (programmer: 1..50, default 2) */
    uint8_t tgap2;               /* touch: shortest time between two touches, 2 ms units (programmer: 5..250, default 15 = 30 ms) */
    uint8_t rsv[1];
    uint8_t crc;         /* CRC-8 (poly 0x07, init 0) over bytes 0..126 */
} Cfg;
#else
/* ===== 23-key panels (ATmega64 main + ATmega32 inputs): 768 bytes at CFG_ADDR =====
   keys: 0..19 = places 1..20, 20/21/22 = scenario 1/2/3 (bottom row) */
#undef CFG_ADDR
#undef CFG_SIZE
#undef CFG_VER
#undef RT_TIMER
#define CFG_ADDR   0xF000
#define CFG_SIZE   768
#define CFG_VER    0x40
#define BOARD_BIG  2
#define T_KEY      8       /* keypad digit sec1 (1..6): no relay (red pin left free), white = entry open */
#define T_ALON     9       /* alarm ON/OFF key: red = armed */
#define T_ALPW     10      /* alarm change-password key (hold 2 s): red = new password being entered */
typedef uint32_t pm_t;     /* one bit per key (23 used) */
typedef uint32_t rm_t;     /* remote table entry: poles bits 0-22, action bits 24-25, RT_TIMER bit 26 */
#define SW_NP      23
#define RM_POLES(e) ((e) & 0x007FFFFFUL)
#define RM_ACT(e)   ((uint8_t)((e) >> 24) & 3)
#define RT_TIMER   0x04000000UL
typedef struct {
    uint8_t m0, m1, ver;
    uint8_t role;               /* 0 */
    uint8_t board;              /* BOARD_BIG */
    uint8_t npoles;             /* keys in use (informational) */
    uint8_t model;              /* layout id from the programmer (informational) */
    uint8_t remote;             /* 1 = 433 MHz remotes enabled */
    uint8_t type[SW_NP];
    uint8_t link[SW_NP];        /* key of the other panel this key follows (two-panel network), else NO_LINK */
    pm_t offmask[SW_NP];
    pm_t onmask[SW_NP];
    uint8_t minutes[SW_NP];
    uint8_t sec1[SW_NP];
    uint8_t sec2[SW_NP];
    pm_t beep;                  /* keys that beep when touched */
    uint8_t dimsec, stag10, nslot, tpress, tgap2, alarm;
    rm_t rmap[N_SLOTS][16];
    uint8_t tmin[4];
    uint8_t tdef[N_SLOTS * 4];
    uint8_t alArm;              /* alarm: seconds from the right password to armed (0 = at once) */
    uint8_t alEntry;            /* alarm: seconds to enter the password after the sensor saw someone */
    uint8_t alSiren;            /* alarm: seconds the siren sounds */
    char lay[SW_NP];            /* for the phone app: role of every key (letters, see wifi64.c) */
    char mdl[8];                /* for the phone app: model name, e.g. "a14" (0-terminated if shorter) */
    uint8_t rsv[CFG_SIZE - 8 - 2 * SW_NP - 8 * SW_NP - 3 * SW_NP - 4 - 6 - 4 * N_SLOTS * 16 - 4 - 4 * N_SLOTS - 3 - SW_NP - 8 - 1];
    uint8_t crc;                /* CRC-8 over bytes 0..CFG_SIZE-2 */
} PACKED Cfg;
#ifndef __CODEVISIONAVR__
_Static_assert(sizeof(Cfg) == CFG_SIZE, "big config must be exactly CFG_SIZE bytes");
#endif
#endif

#endif
