/* Sooden panels - ATmega8 @ 8 MHz (crystal: fuses 3F/D1, internal RC: 24/D1)
 * One source, one hex per panel kind; each hex holds only what that panel has:
 *   FW_BOARD    BOARD_4P or BOARD_2P
 *   HAS_REMOTE  433 MHz receiver (4P only)
 *   HAS_PAIR    RS485 link to one other panel (two-panel network, no CPU)
 * 4P board (3/4 pole): touch BS818A-2 on PC2 (valid, low) + PC3..PC5 (code)
 *   pole1 W=PB1 R=PB2, pole2 W=PB0 R=PD7, pole3 W=PC0 R=PC1, pole4 W=PD5 R=PD6
 *   433 MHz data on PD3 (INT1), active buzzer on PD2 (high = beep)
 * 2P board (1/2 pole): touch pole1=PB5, pole2=PD4 (active low), out pole1=PB3 pole2=PB4
 * RS485 (auto-direction MAX485 module): RXD/TXD, 9600 8N1
 */
#include "port.h"
#include "sw.h"

#ifndef F_CPU
#define F_CPU 8000000UL
#endif
#ifndef FW_BOARD
#error "build with -DFW_BOARD=BOARD_4P or -DFW_BOARD=BOARD_2P"
#endif
#if FW_BOARD == BOARD_2P && HAS_REMOTE
#error "the 1/2 pole board has no 433 MHz receiver"
#endif

/* configuration block, patched by the programmer (0xFF = not configured) */
PATCHED uint8_t cfg_flash[CFG_SIZE] AT_SECTION(".swcfg") = { FF64, FF64 };    /* 128 bytes */
#if HAS_PX
/* two-panel network v2: keys of the other panel in each key's scenario, patched by the programmer */
PATCHED uint8_t px_flash[PX_SIZE] AT_SECTION(".swpx") = { FF64 };            /* 64 bytes */
static uint8_t px_mask(uint8_t k, uint8_t which, uint8_t *m)
{
    PATCHED uint8_t *p;
    if (k >= 4) return 0;
    p = &px_flash[3 + (which ? 12 : 0) + 3 * k];
    m[2] = p[0]; m[1] = p[1]; m[0] = p[2];   /* stored high byte first */
    m[2] &= 0x7F;
    return (uint8_t)(m[0] | m[1] | m[2]);
}
static uint8_t px_valid(void)
{
    uint8_t i;
    uint8_t b[PX_SIZE];
    for (i = 0; i < PX_SIZE; i++) b[i] = px_flash[i];
    return b[0] == PX_M0 && b[1] == PX_M1 && b[2] == 4 && sw_crc8(b, PX_SIZE - 1) == b[PX_SIZE - 1];
}
#endif

static Sw S;
static volatile uint32_t ms;

ISR_TIM2_COMP { ms++; }

static uint32_t now_ms(void)
{
    uint32_t v;
    cli(); v = ms; sei();
    return v;
}

#if HAS_PAIR
static volatile uint8_t rxq[32];
static volatile uint8_t rxh, rxt;

ISR_USART_RXC
{
    /* framing errors are NOT dropped: auto-direction RS485 modules often bend the stop bit;
       every frame is protected by its CRC anyway (same as the original firmware) */
    uint8_t b = UDR;
    uint8_t n = (uint8_t)((rxh + 1) & 31);
    if (n != rxt) { rxq[rxh] = b; rxh = n; }
}

static void uart_put(uint8_t b)
{
    while (!(UCSRA & _BV(UDRE))) wdt_reset();
    UDR = b;
}

static void uart_tx(const uint8_t *p, uint8_t n)
{
    uart_put(0xFF);                   /* lead-in byte: lets the auto-direction module and the
                                         far receiver settle; ignored by the frame parser */
    while (n--) uart_put(*p++);
}
#endif

#if HAS_REMOTE
static uint16_t rfLast;
ISR_INT1
{
    uint16_t t = TCNT1;
    uint16_t dt = t - rfLast;
    rfLast = t;
    sw_rf_edge(&S, dt, (PIND & _BV(3)) ? 1 : 0);
}
static uint8_t ee_r(uint16_t a) { return ee_rd(a); }
static void ee_w(uint16_t a, uint8_t v) { ee_upd(a, v); }
#endif

#if FW_BOARD == BOARD_4P
static uint8_t read_keys(void)
{
    uint8_t code;
    if (PINC & _BV(2)) return 0;              /* no touch */
    code = (PINC >> 3) & 7;           /* PC3=bit0 PC4=bit1 PC5=bit2 */
    switch (code) {
    case 7: return 0x01;
    case 0: return 0x02;
    case 3: return 0x04;
    case 4: return 0x08;
    default: return 0;
    }
}

static void write_outputs(uint8_t w, uint8_t r, uint8_t bz)
{
    uint8_t b = PORTB & (uint8_t)~(_BV(0) | _BV(1) | _BV(2));
    uint8_t c = PORTC & (uint8_t)~(_BV(0) | _BV(1));
    uint8_t d = PORTD & (uint8_t)~(_BV(2) | _BV(5) | _BV(6) | _BV(7));
    if (bz) d |= _BV(2);                      /* active buzzer on PD2 */
    if (w & 1) b |= _BV(1);
    if (r & 1) b |= _BV(2);
    if (w & 2) b |= _BV(0);
    if (r & 2) d |= _BV(7);
    if (w & 4) c |= _BV(0);
    if (r & 4) c |= _BV(1);
    if (w & 8) d |= _BV(5);
    if (r & 8) d |= _BV(6);
    PORTB = b; PORTC = c; PORTD = d;
}
#else
static uint8_t read_keys(void)
{
    uint8_t k = 0;
    if (!(PINB & _BV(5))) k |= 0x01;
    if (!(PIND & _BV(4))) k |= 0x02;
    return k;
}

static void write_outputs(uint8_t w, uint8_t r, uint8_t bz)
{
    uint8_t b;
    (void)w; (void)bz;
    b = PORTB & (uint8_t)~(_BV(3) | _BV(4));
    if (r & 1) b |= _BV(3);
    if (r & 2) b |= _BV(4);
    PORTB = b;
}
#endif

int main(void)
{
    uint8_t i;
    uint8_t buf[CFG_SIZE];
    const Cfg *cfg;
    uint8_t why = MCUCSR;                     /* reset cause: power-on / brown-out / external (ISP) / watchdog */
    MCUCSR = 0;
    (void)why;

    for (i = 0; i < CFG_SIZE; i++) buf[i] = cfg_flash[i];
    cfg = (const Cfg *)buf;

    if (!sw_cfg_ok(cfg)) {
        /* not configured (or settings made for another panel kind): every pin stays an input */
        for (;;) ;
    }

    /* pin directions copied from the original firmwares (unused pins driven low);
       PB6/PB7 are the crystal pins and are left alone */
#if FW_BOARD == BOARD_4P
    DDRB = 0x3F;  PORTB = 0x00;
    DDRC = 0x03;  PORTC = 0x3C;               /* touch PC2..PC5 inputs with pull-up */
    DDRD = 0xF6;  PORTD = 0x08;               /* PD0 RXD, PD3 RF input with pull-up */
#else
    DDRB = 0x1F;  PORTB = 0x20;               /* PB5 touch input with pull-up */
    DDRC = 0x3F;  PORTC = 0x00;
    DDRD = 0xCE;  PORTD = 0x30;               /* PD0 RXD, PD4 touch, PD5 pull-up */
#endif

#if HAS_PAIR
    /* UART 9600 8N1 @ 8 MHz */
    UBRRH = 0; UBRRL = 51;
    UCSRA = 0;
    UCSRC = _BV(URSEL) | _BV(UCSZ1) | _BV(UCSZ0);
    UCSRB = _BV(RXCIE) | _BV(RXEN) | _BV(TXEN);
    S.tx = uart_tx;
#endif

    /* Timer2: 1 ms CTC (8 MHz / 64 / 125) */
    OCR2 = 124;
    TCCR2 = _BV(WGM21) | _BV(CS22);
    TIMSK |= _BV(OCIE2);

#if HAS_REMOTE
    S.eer = ee_r; S.eew = ee_w;
#endif
    sw_init(&S, cfg, 0);
#if HAS_PX
    if (px_valid()) S.pxm = px_mask;
#endif
#if HAS_REMOTE
    /* remote codes are recorded only after the mains was switched off and on again,
       not after the programmer (external reset) or the watchdog restarted the chip */
    S.logOn = (why & (_BV(PORF) | _BV(BORF))) != 0;
#endif

#if HAS_REMOTE
    if (cfg->remote) {
        TCCR1A = 0; TCCR1B = _BV(CS11);           /* 1 us ticks */
        MCUCR = (MCUCR & 0xF3) | _BV(ISC10);      /* INT1 any change */
        GIFR = _BV(INTF1);
        GICR |= _BV(INT1);
    }
#endif

    write_outputs(0, 0, 0);
    wdt_enable(WDTO_1S);
    sei();

    for (;;) {
        uint32_t now;
        wdt_reset();
        now = now_ms();
#if HAS_PAIR
        while (rxt != rxh) {
            uint8_t b = rxq[rxt];
            rxt = (uint8_t)((rxt + 1) & 31);
            sw_rx(&S, b, now);
        }
#endif
        sw_tick(&S, now, read_keys());
        write_outputs(S.white, S.red, S.buzz);
#if HAS_PAIR
        sw_link(&S, now);
#endif
    }
}
