#!/usr/bin/env python3
"""Make C99 declarations C89-compatible (declarations only at the start of a block), keeping their meaning.

  for (T i = 0; ...)          -> T i; at the start of the function, for (i = 0; ...)
                                 (only when every declaration of i in the function is such a loop variable of
                                  the same type, i is not used outside those loops and the loops are not nested)
  stmt; T x = e;              -> T x; at the start of the block, x = e; in place
                                 (only when x is not used earlier in that block and the declaration is simple)
  anything else               -> wrapped in its own block: { T x = e; ...rest of the block }   /  { T i = 0; for (; ...) }

Locations come from clang's JSON AST over several preprocessor configurations (every #if branch is seen at
least once; the edits of all configurations are merged).
usage: c89ize.py files... -- configs.txt     (each config line: clang arguments ... source.c)"""
import json, subprocess, sys, re, os, collections

def ast(src, args):
    cmd = ['clang', '-fsyntax-only', '-Wno-everything', '-std=gnu99', '-Xclang', '-ast-dump=json', '-DF_CPU=8000000UL'] + args + [src]
    out = subprocess.run(cmd, capture_output=True, text=True)
    if out.returncode:
        sys.exit('clang failed: ' + ' '.join(cmd) + '\n' + out.stderr[-3000:])
    return json.loads(out.stdout)

def resolve(node, st):
    if isinstance(node, dict):
        if 'offset' in node:
            if 'file' in node: st[0] = node['file']
            node['_f'] = st[0]
        for v in node.values():
            if isinstance(v, (dict, list)): resolve(v, st)
    elif isinstance(node, list):
        for x in node: resolve(x, st)

def eloc(l):
    if l is None: return None
    if 'expansionLoc' in l: l = l['expansionLoc']
    if 'offset' not in l: return None
    return (l.get('_f'), l['offset'], l.get('tokLen', 1))

def skip_ws(t, i):
    while i < len(t):
        if t[i].isspace(): i += 1
        elif t.startswith('/*', i): i = t.index('*/', i) + 2
        elif t.startswith('//', i): i = t.index('\n', i)
        else: break
    return i

def match_close(t, i):
    """i at an opening bracket -> offset after its partner"""
    pair = {'(': ')', '[': ']', '{': '}'}
    st = []
    while True:
        c = t[i]
        if c in '"\'':
            q = c; i += 1
            while t[i] != q: i += 2 if t[i] == '\\' else 1
        elif t.startswith('/*', i): i = t.index('*/', i) + 1
        elif t.startswith('//', i): i = t.index('\n', i)
        elif c in pair: st.append(pair[c])
        elif c in ')]}':
            assert st and st[-1] == c, t[i-60:i+5]
            st.pop()
            if not st: return i + 1
        i += 1

def tok_end(t, l):
    """offset after the last token of a range end; a macro call ends at its ')'"""
    if 'expansionLoc' in l:
        x = l['expansionLoc']
        o = x['offset'] + x.get('tokLen', 1)
        j = skip_ws(t, o)
        if j < len(t) and t[j] == '(' and re.match(r'[A-Za-z_]', t[x['offset']]): o = match_close(t, j)
        return o
    return l['offset'] + l.get('tokLen', 1)

def stmt_end(t, l):
    o = tok_end(t, l)
    if t[o - 1] == '}': return o
    j = skip_ws(t, o)
    assert t[j] == ';', t[o - 60:o + 20]
    return j + 1

def split_top(s):
    parts, d, cur, i = [], 0, '', 0
    while i < len(s):
        c = s[i]
        if c in '"\'':
            j = i + 1
            while s[j] != c: j += 2 if s[j] == '\\' else 1
            cur += s[i:j + 1]; i = j + 1; continue
        if c in '([{': d += 1
        if c in ')]}': d -= 1
        if c == ',' and d == 0: parts.append(cur); cur = ''
        else: cur += c
        i += 1
    parts.append(cur)
    return parts

def pp_regions(text):
    ev = [(m.start(), m.group(1)) for m in re.finditer(r'^[ \t]*#[ \t]*(if|ifdef|ifndef|elif|else|endif)\b.*$', text, re.M)]
    stack, marks, gid = [], [(0, ())], 0
    for off, d in ev:
        if d in ('if', 'ifdef', 'ifndef'): gid += 1; stack.append([gid, 0])
        elif d in ('elif', 'else'): stack[-1][1] += 1
        else: stack.pop()
        marks.append((off, tuple(tuple(x) for x in stack)))
    def region(o):
        r = ()
        for mo, st in marks:
            if mo <= o: r = st
            else: break
        return r
    return region

def kids(n): return n.get('inner', []) or []

class Plan:
    def __init__(self): self.edits = {}
    def ins(self, off, order, text, key): self.edits[key] = ('i', off, order, text)
    def dele(self, a, b): self.edits[('d', a, b)] = ('d', a, b)

VOTE = {}
EMIT = [False]
def vote(key, ok):
    if EMIT[0]: return VOTE.get(key, False) and ok
    VOTE[key] = VOTE.get(key, True) and ok
    return ok
PROBLEMS = set()
STATS = collections.Counter()

def plan_file(tree, fname, text, P, region):
    absf = os.path.abspath(fname)
    def mine(l): return l is not None and l[0] and os.path.abspath(l[0]) == absf
    ident = lambda name: re.compile(r'(?<![\w.>])' + re.escape(name) + r'\b')
    def masked(a, b, holes):
        s = list(text[a:b])
        for x, y in holes:
            for i in range(max(x, a), min(y, b)): s[i - a] = ' '
        return ''.join(s)
    for fn in [n for n in kids(tree) if n.get('kind') == 'FunctionDecl']:
        body = next((c for c in kids(fn) if c.get('kind') == 'CompoundStmt'), None)
        if not body: continue
        bb = eloc(body['range']['begin'])
        if not mine(bb): continue
        params = {c.get('name') for c in kids(fn) if c.get('kind') == 'ParmVarDecl'}
        decls = collections.defaultdict(list)
        fors = []
        def visit(n):
            k = n.get('kind')
            if k == 'ForStmt':
                init = kids(n)[0] if kids(n) else None
                if init and init.get('kind') == 'DeclStmt':
                    fors.append(n)
                    for v in kids(init):
                        if v.get('kind') == 'VarDecl': decls[v['name']].append(('for', v, init, n))
                    for c in kids(n)[1:]: visit(c)
                    return
            if k == 'DeclStmt':
                for v in kids(n):
                    if v.get('kind') == 'VarDecl': decls[v['name']].append(('blk', v, n, None))
            for c in kids(n): visit(c)
        visit(body)
        body_end = stmt_end(text, body['range']['end'])
        def fn_ok(name, lst):
            if not all(x[0] == 'for' for x in lst) or name in params: return False

            if not all(mine(eloc(x[2]['range']['begin'])) for x in lst): return False
            types = {x[1]['type']['qualType'] for x in lst}
            if len(types) != 1: return False
            t = types.pop()
            if '(' in t or '[' in t or re.search(r'\b(const|static|volatile)\b', t): return False
            if not all(len([v for v in kids(x[2]) if v.get('kind') == 'VarDecl']) == 1 for x in lst): return False
            rngs = [(eloc(x[3]['range']['begin'])[1], stmt_end(text, x[3]['range']['end'])) for x in lst]
            if any(a1 < a2 < b1 for a1, b1 in rngs for a2, b2 in rngs if (a1, b1) != (a2, b2)): return False
            if ident(name).search(masked(bb[1], body_end, rngs)): return False
            return True
        hoist_fn = collections.OrderedDict()
        for name, lst in decls.items():
            if not vote((fname, bb[1], name), fn_ok(name, lst)): continue
            hoist_fn[name] = lst[0][1]['type']['qualType']
        for f in fors:
            init = kids(f)[0]
            vs = [v for v in kids(init) if v.get('kind') == 'VarDecl']
            db = eloc(init['range']['begin']); de = eloc(init['range']['end']); fb = eloc(f['range']['begin'])
            if not (mine(db) and mine(de) and mine(fb)): continue
            semi = de[1] if text[de[1]] == ';' else text.index(';', de[1] + de[2])
            if len(vs) == 1 and vs[0]['name'] in hoist_fn:
                P.dele(db[1], vs[0]['loc']['offset'])
                STATS['for hoisted'] += 1
            else:
                end = stmt_end(text, f['range']['end'])
                P.dele(db[1], semi)
                P.ins(fb[1], 5, '{ ' + text[db[1]:semi] + '; ', ('wf', fb[1]))
                P.ins(end, 1, ' }', ('wfe', fb[1]))
                STATS['for wrapped'] += 1
        if hoist_fn:
            bytype = collections.OrderedDict()
            for nme, t in hoist_fn.items(): bytype.setdefault(t, []).append(nme)
            decl = ''.join('\n    ' + t + ('' if t.endswith('*') else ' ') + ', '.join(ns) + ';' for t, ns in bytype.items())
            P.ins(bb[1] + 1, 0, decl, ('hf', bb[1], decl))
        def blocks(n):
            if n.get('kind') == 'CompoundStmt': yield n
            for c in kids(n): yield from blocks(c)
        for blk in blocks(body):
            cb = eloc(blk['range']['begin']); ce = eloc(blk['range']['end'])
            if not (mine(cb) and mine(ce)): continue
            seen = False
            hoisted_here = []
            for st in kids(blk):
                if st.get('kind') != 'DeclStmt': seen = True; continue
                if not seen: continue
                b = eloc(st['range']['begin']); e = eloc(st['range']['end'])
                if not (mine(b) and mine(e)) or 'expansionLoc' in st['range']['begin']: continue
                semi = e[1] if text[e[1]] == ';' else text.index(';', e[1])
                src = text[b[1]:semi]
                vs = [v for v in kids(st) if v.get('kind') == 'VarDecl']
                parts = split_top(src)
                ok = len(parts) == len(vs) and region(b[1]) == region(cb[1])
                hoist, assign = [], []
                if ok:
                    for i, (v, p) in enumerate(zip(vs, parts)):
                        nm = v['name']
                        if ident(nm).search(masked(cb[1] + 1, b[1], [])): ok = False; break
                        m = re.match(r'^(.*?)\b' + re.escape(nm) + r'\b(.*)$', p, re.S)
                        if not m: ok = False; break
                        pre, rest = m.group(1), m.group(2)
                        if i == 0:
                            base = pre.strip()
                            top = base[base.rfind('*') + 1:] if '*' in base else base   # qualifiers of the variable itself
                            if not base or re.search(r'\b(static|extern|register)\b', base) or re.search(r'\bconst\b', top) or '(' in base: ok = False; break
                            tbase = re.sub(r'\s*\*+$', '', base)
                            tdecl = base
                        else:
                            star = pre.strip()
                            if star not in ('', '*'): ok = False; break
                            tdecl = tbase + (' *' if star else '')
                        r = rest.strip()
                        sep = '' if tdecl.endswith('*') else ' '
                        if r.startswith('='):
                            hoist.append(tdecl + sep + nm + ';')
                            assign.append(nm + ' = ' + r[1:].strip() + ';')
                        elif r == '' or (r.startswith('[') and '=' not in r):
                            hoist.append(tdecl + sep + nm + r + ';')
                        else: ok = False; break
                ok = vote((fname, 'd', b[1]), ok)
                if ok:
                    P.dele(b[1], semi + 1)
                    if assign: P.ins(b[1], 6, ' '.join(assign), ('as', b[1]))
                    hoisted_here += hoist
                    STATS['decl hoisted'] += 1
                else:
                    if region(b[1]) != region(ce[1]):
                        PROBLEMS.add((fname, text.count('\n', 0, b[1]) + 1)); continue
                    P.ins(b[1], 4, '{ ', ('wb', b[1]))
                    P.ins(ce[1], 2, '} ', ('wbe', b[1]))
                    STATS['decl wrapped'] += 1
            if hoisted_here:
                line_start = text.rfind('\n', 0, cb[1]) + 1
                ind = re.match(r'[ \t]*', text[line_start:]).group(0) + '    '
                P.ins(cb[1] + 1, 1, ''.join('\n' + ind + h for h in hoisted_here), ('hb', cb[1], tuple(hoisted_here)))

def apply(text, P):
    dels = sorted({(e[1], e[2]) for e in P.edits.values() if e[0] == 'd'})
    ins = collections.defaultdict(list)
    for e in P.edits.values():
        if e[0] == 'i': ins[e[1]].append((e[2], e[3]))
    keep = [True] * len(text)
    for a, b in dels:
        for i in range(a, b): keep[i] = False
    out = []
    for i in range(len(text) + 1):
        if i in ins: out.append(''.join(t for _, t in sorted(ins[i], key=lambda x: x[0])))
        if i < len(text) and keep[i]: out.append(text[i])
    s = ''.join(out)
    s = re.sub(r'[ \t]+\n', '\n', s)
    s = re.sub(r'\n[ \t]*\n([ \t]*\n)+', '\n\n', s)
    return s

if __name__ == '__main__':
    files = sys.argv[1:sys.argv.index('--')]
    cfgs = [l.split() for l in open(sys.argv[sys.argv.index('--') + 1]) if l.strip() and not l.startswith('#')]
    texts = {f: open(f).read() for f in files}
    P = {f: Plan() for f in files}
    regions = {f: pp_regions(texts[f]) for f in files}
    trees = []
    for c in cfgs:
        tree = ast(c[-1], c[:-1])
        resolve(tree, [c[-1]])
        for f in files:
            plan_file(tree, f, texts[f], Plan(), regions[f])
        trees.append(c)
    EMIT[0] = True
    STATS.clear()
    for c in cfgs:
        tree = ast(c[-1], c[:-1])
        resolve(tree, [c[-1]])
        for f in files:
            plan_file(tree, f, texts[f], P[f], regions[f])
    if PROBLEMS:
        print('declarations to move by hand:', sorted(PROBLEMS)); sys.exit(1)
    for f in files:
        open(f, 'w').write(apply(texts[f], P[f]))
    print(dict(STATS))
