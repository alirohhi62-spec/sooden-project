# 12-pol touch panel (Sooden) — complete technical handoff

> **راهنمای فارسی:** این فایل خلاصهٔ کامل همه چیزهایی است که تا امروز (۱۷ اکتبر ۲۰۲۶ / ۲۵ مهر ۱۴۰۵) از کد ۵ میکرو و سخت‌افزار پنل فهمیده شده است.
> اگر این فایل را همراه پوشهٔ `sources/` (سورس‌های بازیابی‌شده) و `pin_sheet.txt` به Claude بدهید، کل سیستم را بدون نیاز به تحلیل دوباره می‌فهمد.
> متن فنی به انگلیسی نوشته شده تا نام متغیرها و پایه‌ها دقیق بماند.
> بخش ۱۲ تصمیم‌های طراحی کد جدید و بخش ۱۳ سؤال‌های باز است.

**Instruction to Claude (or any engineer) receiving this file:** read `CONTINUE.md` first; it holds the latest decisions (2026-10-18) and overrides this file where they differ. This document is the full technical analysis; everything below was verified against the original compiler output.
- Read §0 first.
- The recovered original sources are in `sources/`.
- The owner (designer/programmer of the hardware and firmware) answers questions in Persian. Answer him in Persian.
- Do not re-analyse the hex files; that work is done.

---

## 0. Status and provenance

- **System:** a commercial smart-home glass touch panel, "پنل لمسی ۱۲ پل سیمکارتی" (Sooden engineering group).
  - 27×20 cm, flush box 240×185×90 mm.
  - 12 × 220 V outputs, 3-zone alarm, Wi-Fi app, SMS, RF remote, 2 curtains, elevator call, 3 extra outputs (valves / boiler "پکیج"), child lock, user scenarios.
  - Brochure features not yet implemented: SMS on power failure, multi-panel network over cable, battery backup.
- **5 MCUs, all CodeVision AVR 3.14, 8 MHz, no watchdog enabled:**

| short name | chip | role | recovered source |
|---|---|---|---|
| M1 (M1-32) | ATmega32A | slave: L1–L4, 2 curtains, N2/N3/N4, OLED 1 | `sources/m32_1/cod.c` |
| M2 (M2-32) | ATmega32A | slave: L5–L8, N1, OLED 2 | `sources/m32_2/cod.c` |
| M3 (M3-32) | ATmega32A | slave: L9–L12, S1–S6 LEDs, K1 LED pair, elevator, OLED 3 | `sources/m32_3/cod.c` |
| M4 (M4-64, "WiFi") | ATmega64A | MASTER: 4 touch ICs, all load state, scenarios, ESP8266 app, RF RX, K2/K3, standby | `sources/m64_wifi/cod.c` |
| M-64 ("alarm") | ATmega64A | alarm: keypad (2 touch ICs), OLED 4, 3 zones, sensors, sirens, SIM800 SMS/call, own RF RX | `sources/m64_alarm/cod.c` |

- **How the sources were recovered.** The owner had lost his sources but still had the CodeVision `Debug\List` output.
  - The `.lst` files contain every source line as comments. They were extracted with a script.
  - Every listed opcode was compared with the matching `cod.hex`. All 5 match 100 %, so the sources are exactly what is flashed.
  - The listing truncates lines longer than about 120 characters. These were rebuilt:
    - Wi-Fi: 9 lines rebuilt from the compiled code, marked `// [restored from compiled code...]`. 4 more lines lost only their comment text.
    - Alarm: rebuilt from an older full source the owner had.
    - `BigNum` table: rebuilt from the flash data.
  - The Russian comments in `ssd1306.c` were already lost and appear as `?`.
- **Original project folders** (on the owner's PC): `D:\new key\Key CR\typ 6\12 pol new\cod\cod new\COD_Antenna_GSM_Zoon\Masjed\cod\`
  - `cod_M1-32`, `cod_M2-32`, `cod_M3-32`
  - `cod_M4-64\cod - 1par - wifi - RF - senario - stand_by#`
  - `cod_MA-64\cod_RF_Antenna1`
- **Versions.** The installed panels run this latest version, slightly customised per project.
  - Two older hex files (Wi-Fi `f04069bf`, alarm `5098f01e`) and an older alarm source (`alarm_gsm.c`) also exist. They are NOT the current version.
- **Owner's goal:** rewrite all 5 firmwares from scratch, clean, keeping the same hardware (see §12).

---

## 1. Architecture

```
 4× BS818A touch ICs ─► [M4 ATmega64 = MASTER] ◄─UART0 9600─ ESP8266 ◄─ TCP 6269 ─ mobile app
                          │   RF RX 433 (INT6/PE6), RF TX 433 (PC7, unused yet)
                          │   K2/K3 LED+relay pairs on PORTG, click relay PG3, Wi-Fi LED PF7, 7-segment on PORTF
                          │   UART1 PD2/PD3 → RS485 module (reserved for panel network)
      BUS A (5 bit, 1-way, shared) ─┬─► M1 ATmega32 (L1–L4, curtains, N2 N3 N4, OLED1)
                                    ├─► M2 ATmega32 (L5–L8, N1, OLED2)
                                    └─► M3 ATmega32 (L9–L12, S1–S6, K1, elevator, OLED3)
      BUS B (4 bit) ◄────────────┐
      BUS C (3 bit) ─────────────┴──► [M-64 ATmega64 = ALARM] ◄─UART0 9600─ SIM800
                                       2× BS818A keypad, OLED4, 3 zones, sensors, 3 sirens, RF RX (INT4/PE4)
      alarm PB1 (pulse) ─────────────► M1 PB7 (toggles N4 = GSM signal LED)
```

- **M4 is the brain.**
  - All touch keys except the alarm keypad are wired to M4, not to the M32s.
  - M4 keeps the state of every load (`Red_*` flags and the app bitmap `w[0..2]`).
  - M4 decides scenarios and standby, and sends commands.
- **M32s are dumb slaves.**
  - They have no touch input.
  - They decode bus-A codes, toggle their white/red LED pairs and redraw their OLED.
- **Relays** are driven from each MCU's **red** pin through a ULN: red LED on = relay on. The relay board has a hardware interlock between curtain open and close.
- **White LED** = backlight of the key while the load is off.
- **Bus commands are toggles with no acknowledge.** A missed pulse silently desynchronises M4's state from the real outputs. This is the main robustness weakness.

---

## 2. Pin maps

Pin numbers are TQFP physical pins. The full transcribed sheet is in `pin_sheet.txt`.

### 2.1 Loads (bus-A code → owner MCU, white pin, red pin, touch key on M4)

| code | name (code) | MCU | W | R | touch IC/key (bin2 bin1 bin0) |
|---|---|---|---|---|---|
| 11110 | N1 (lock-icon LED; blinks on scenario save) | M2 | 19 PC0 | 20 PC1 | – |
| 11101 | N2 (power-outage LED) | M1 | 30 PA7 | 31 PA6 | – |
| 11100 | N3 (Wi-Fi LED) | M1 | 25 PC6 | 26 PC7 | – |
| 11011 | N4 (GSM signal LED) — driven locally by M1 PB7 input, not by bus | M1 | 23 PC4 | 24 PC5 | – |
| 11010 | L1 | M1 | 32 PA5 | 33 PA4 | I1 T4 100 |
| 11001 | L2 | M1 | 9 PD1 | 8 PD0 | I1 T5 011 |
| 11000 | L3 | M1 | 34 PA3 | 35 PA2 | I1 T3 101 |
| 10111 | L4 | M1 | 44 PB4 | 43 PB3 | I1 T6 010 |
| 10110 | L5 | M2 | 21 PC2 | 22 PC3 | I1 T2 110 |
| 10101 | L6 | M2 | 44 PB4 | 43 PB3 | I1 T7 001 |
| 10100 | L7 | M2 | 30 PA7 | 31 PA6 | I1 T1 111 |
| 10011 | L8 | M2 | 42 PB2 | 41 PB1 | I1 T8 000 |
| 10010 | L9 | M3 | 20 PC1 | 21 PC2 | I2 T4 100 |
| 10001 | L10 | M3 | 10 PD1 | 9 PD0 | I2 T5 011 |
| 10000 | L11 | M3 | 23 PC4 | 22 PC3 | I2 T3 101 |
| 01111 | L12 | M3 | 44 PB4 | 43 PB3 | I2 T6 010 |
| 01110 | S1 LED | M3 | 25 PC6 | 24 PC5 | key S1 = I2 T2 110 |
| 01101 | S2 LED | M3 | 30 PA7 | 26 PC7 | key S2 = I2 T1 111 |
| 01100 | S3 LED | M3 | 32 PA5 | 31 PA6 | key S3 = I2 T8 000 |
| 01011 | S4 LED | M3 | 34 PA3 | 33 PA4 | key S4 = I2 T7 001 |
| 01010 | S5 LED | M3 | 36 PA1 | 35 PA2 | key S5 = I3 T8 000 |
| 01001 | S6 LED | M3 | 40 PB0 | 37 PA0 | key S6 = I3 T7 001 |
| 01000 | K1 (owner's name; radiator icon) | M3 | 42 PB2 | 41 PB1 | I3 T5 011 |
| – | K2 (valve icon) | M4 | 34 PG1 | 33 PG0 | I3 T4 100 |
| – | K3 (lock icon, bottom-left) | M4 | 43 PG2 | 19 PG4 | I3 T3 101 |
| – | M master key | – | | | I3 T6 010 |
| – | 7-seg DOWN / UP / ON / OFF keys | – | | | I3 T2 110 / I4 T7 001 / I4 T8 000 / I4 T6 010 |
| 00111 | elevator (toggle, PB5) | M3 | 1 PB5 | – | I4 T3 101 |
| 00110 | curtain 1 open (owner) | M1 | 16 PD7 | 13 PD4 | I4 T2 110 |
| 00101 | curtain 1 close (owner) | M1 | 19 PC0 | 20 PC1 | I4 T4 100 |
| 00100 | curtain 2 open (owner) | M1 | 12 PD3 | 11 PD2 | I4 T1 111 |
| 00011 | curtain 2 close (owner) | M1 | 21 PC2 | 22 PC3 | I4 T5 011 |
| 00000 | Led_PoL = ULN group power, toggled at standby | M1 | 1 PB5 | – | – |
| 00001 | Stand_by_1: standby toggle (all three M32) | | | | |
| 00010 | Stand_by: wake, no delay (all three M32) | | | | |

**Naming traps in the current code:**
- **K naming is swapped K1↔K3 between the owner's naming and the code.**
  - Code `Touch_K1` (BIN3 = 101, key I3 T3) → `OUT_K1` toggles PG2/PG4. That is the owner's **K3**.
  - Code `Touch_K3` (011, key I3 T5) → `OUT_K3` sends bus code 01000, the M3 PB2/PB1 pair. That is the owner's **K1**.
  - K2 matches in both.
  - The alarm source also swaps K1/K3 in its `OUT_K*` macro names. The net end-to-end mapping is correct.
- **Curtains:** M4 macro names `OUT_P1O`/`OUT_P1C` (and `OUT_P2O`/`OUT_P2C`) are swapped relative to the M1 macro names. The physical mapping is consistent: key → code → pin as in the table above.
- **Unused codes:** M4 never sends codes N2, N4, Led_PoL or S1–S4. S5 is sent only by "exit", S6 only by lock.

### 2.2 Bus A pins (5 lines, bit order = code order left→right)

- M4 (driver): 31 PD6, 30 PD5, 29 PD4, 26 PD1, 25 PD0.
- M1: 36 PA1, 37 PA0, 40 PB0, 41 PB1, 42 PB2.
- M2: 37 PA0, 36 PA1, 35 PA2, 34 PA3, 33 PA4.
- M3: 11 PD2, 12 PD3, 13 PD4, 16 PD7, 19 PC0.

### 2.3 Bus B (alarm → M4, 4 lines) and bus C (M4 → alarm, 3 lines)

| | lines (from → to) |
|---|---|
| B | alarm 7 PE5 → M4 17 PB7; alarm 8 PE6 → M4 16 PB6; alarm 9 PE7 → M4 15 PB5; alarm 10 PB0 → M4 14 PB4 |
| C | M4 12 PB2 → alarm 12 PB2; M4 10 PB0 → alarm 13 PB3; M4 9 PE7 → alarm 14 PB4 |

### 2.4 Touch ICs (BS818A-2, outputs: pin16 = bin3 = active-low "valid", pins 15/14/13 = bin2/bin1/bin0)

| IC | MCU | bin3 (strobe) | bin2 | bin1 | bin0 | keys |
|---|---|---|---|---|---|---|
| ICT1 | M4 | 47 PA4 | 46 PA5 | 45 PA6 | 44 PA7 | L1–L8 |
| ICT2 | M4 | 41 PC6 | 40 PC5 | 39 PC4 | 32 PD7 | L9–L12, S1–S4 |
| ICT3 | M4 | 35 PC0 | 36 PC1 | 37 PC2 | 38 PC3 | S5, S6, K1–K3, M, 7-seg DOWN |
| ICT4 | M4 | 48 PA3 | 49 PA2 | 50 PA1 | 51 PA0 | elevator, curtains, 7-seg UP/ON/OFF |
| ICT1 | alarm | 51 PA0 | 50 PA1 | 49 PA2 | 48 PA3 | R, L, 1–6 |
| ICT2 | alarm | 47 PA4 | 46 PA5 | 45 PA6 | 44 PA7 | 0, 7, 8, 9, C, OK, D |

**Alarm keypad codes (the program is correct; the old paper sheet is wrong):**
- ICT1:
  - R = 110, L = 101
  - 1 = 011, 2 = 100, 3 = 111, 4 = 010, 5 = 001, 6 = 000
- ICT2:
  - 0 = 010, 7 = 101, 8 = 110, 9 = 111
  - C = 011, OK = 000, D (ON/OFF) = 001

### 2.5 Other pins

**M4 (Wi-Fi)**

| function | pin |
|---|---|
| UART0 → ESP8266 | PE0 / PE1 |
| UART1 → RS485 auto-direction module (reserved) | PD2 = RXD1, PD3 = TXD1 |
| RF receiver | 8 PE6 (INT6) |
| RF transmitter 433 MHz (reserved) | 42 PC7 |
| click relay / buzzer, gives touch feedback when no output relay clicks; macro `Buzzer`, unused | 18 PG3 |
| Wi-Fi LED, toggled together with N3 | 54 PF7 |

- 7-segment, common anode, Vcc on 7-seg pins 3 and 8, DP unused:

| segment | A | B | C | D | E | F | G |
|---|---|---|---|---|---|---|---|
| M4 pin | 61 PF0 | 60 PF1 | 59 PF2 | 55 PF6 | 56 PF5 | 57 PF4 | 58 PF3 |

- Reserved sensor inputs: 6 PE3, 7 PE4, PE5, PE6. Caution: the current code sets PE3/PE4 as outputs, and PE6 is the RF RX pin.
- ISP pins: SCK 11 PB1, MISO 3 PE1, MOSI 2 PE0.

**Alarm**

| function | pin |
|---|---|
| UART0 → SIM800, 9600 | |
| GSM reset | 25 PD0 (`Rset_GSM`) |
| GSM antenna pulse → M1 PB7 | 11 PB1 |
| RF receiver | 6 PE4 (INT4) |
| buzzer | 19 PB5 |
| Led_PoL / "N" output | 35 PC0 |
| OLED | SCL 31 PD6, SDA 30 PD5 |

- Zone LEDs (W/R): Z1 16 PB6 / 17 PB7, Z2 26 PD1 / 27 PD2, Z3 28 PD3 / 29 PD4. Armed indicator D: 5 PE3 / 4 PE2.
- Sensors (program numbering): S1 = PC4, S2 = PC6, S3 = PC5, S4 = PC7. **PC7 is reserved for power-fail detection.**
- Sirens: Z1 = PC1, Z2 = PC2, Z3 = PC3.

**M32s**
- OLED: software I2C, SCL = PD6 (pin 15), SDA = PD5 (pin 14).
- M1 PB7 (pin 3) = GSM pulse input that toggles N4.
- ISP: SCK PB7, MISO PB6, MOSI PB5.

---

## 3. Bus protocols (current implementation)

All buses are idle-high and active-low. Codes are bit patterns written directly to the pins.

**Bus A (M4 → M32s)**
- M4 sets the code, holds it 40 ms, returns to idle (11111) and waits 10 ms (`OUT` macro).
- Each M32 loop:
  - `if(Touch && L)` → `delay_ms(20)` → compare against its own codes and toggle the matching LED pair.
  - If the load is on its OLED, call `Status()`, which redraws 4 × "ON "/"OFF" over software I2C (about 20 ms).
  - Set `L=0`, then wait for idle to set `L=1` again.
- So the minimum safe spacing between two commands is about 60 ms.
- Codes for all three M32s:
  - `00001` = standby toggle: OFF, or ON with delay.
  - `00010` = wake (ON) without delay.

**Bus B (alarm → M4)**
- Alarm sets the code, holds 30 ms, idle 1111, waits 10 ms.
- M4: `if(Touch_IN_S && L_IN_S)` → `delay_ms(15)` → decode.
- Codes:
  - S1 1110, S2 1101, S3 1100, S4 1011, S5 (exit) 1010.
  - Alarm ON 1001, Alarm OFF 1000.
  - "Stand_by" 0111. The alarm sends this after every keypad touch or event. It wakes M4 and resets M4's standby timer.
  - K1 on 0010, K1 off 0001, K2 on 0100, K3 on 0110, K3 off 0101 (code names; see the K-swap trap in §2.1).
  - In effect: SMS `K1on` switches code-K1 = PG2/PG4 (the owner's **K3**), and SMS `K3on` switches the M3 PB2/PB1 pair (the owner's **K1**). **Decided (2026-10-17): in the rewrite SMS `K1`/`K2`/`K3` must drive the owner's K1 (radiator, M3 PB2/PB1), K2 (valve, PG1/PG0) and K3 (lock icon, PG2/PG4).**

**Bus C (M4 → alarm)**
- Same timing as bus B. The alarm decodes after 15 ms.
- Codes:
  - Lock 110: toggles the alarm keypad lock (child lock).
  - Alarm order 101: arm/disarm request from the app, no password.
  - Alarm feed 100: status request; the alarm answers on bus B with ON or OFF.
  - Stand_by 011: alarm enters or leaves standby.

**Timing base:** both M64s use Timer0 overflow every ~25 ms (TCNT0 = 0x3D, clk/1024). The M32s have no timer.

---

## 4. M32 slave firmware (M1, M2, M3)

All three share the same structure. M1 is shown.
- `main`:
  - Set up ports, `i2c_init`, `LCD_init`, contrast 255.
  - `LCD_DrawImage(5)` = background picture with 4 lamp icons, then `Status()`.
- Loop:
  - Decode the bus as described in §3.
  - Each load macro toggles both W and R pins (`PORTx.n =~ PORTx.n`). Some also toggle a bit flag (N2, N3, N4 on M1; N1 on M2; S1–S6 on M3) so standby can restore them.
  - M1 only: an edge on PB7 toggles N4 (the GSM pulse from the alarm).
- `Stand_by(Typ)`:
  - Typ 0 (OFF): all W and R off in stages (with delays), `Led_LP` toggled (M1), `LCD_DrawImage(0)` = black screen.
  - Typ 1 (ON with delay): image 5 + `Status()`. Flagged items return to red or white as before. All L loads return to **white (off)**, which is safe because M4 only enters standby when all loads are off. Then `Led_LP` is toggled back.
  - Typ 2: same as Typ 1, without delays.
  - Standby state `S_by` is itself a toggle: code 00001 flips between OFF and ON.
- `Status()`: prints "ON " / "OFF" for the four lamps at OLED positions (36,1), (20,1), (36,6), (20,6), based on the red pins.
- **M3 extras:**
  - Elevator `PB5` toggles (`ELEVATOR`).
  - K1 pair on PB2/PB1. On standby restore it returns to white only if red is off.

---

## 5. M4 master firmware (Wi-Fi)

### 5.1 Main loop order
1. Standby check:
   - Condition: `Stand_by_Countr ≥ 2000` (~50 s) AND all of L1–L12 and the four curtain flags are 0.
   - Action: `TIMER0_OFF`, `White(0)`, `Data_Clean`, then block while waiting for a wake source:
     - Own touch → `White(0)`.
     - Bus B activity → `White(1)`.
     - ESP data containing "IPD" or "CONNECT", or an RF code → `White(2)`.
2. Touch handling, ignored while `Red_Lock`. This is a busy loop with a counter (`chek ≥ 5000` before the first action). It reads which IC is active (strobe) and decodes the key:
   - **ICT1:** L1–L8 → `OUT_Lx`, toggle the `w[]` bit, `Send_Fead_Back(1)`.
   - **ICT2:**
     - L9–L12 → `OUT_Lx`.
     - Scenario keys S1–S4: a short press runs `Scenario_n(0)`. Holding (`Scenario_Countr ≥ 100`, about 3 s) runs `Scenario_n(1)` = save.
   - **ICT3:**
     - S5 → `Scenario_E()`.
     - Code-K1 → toggle the PG2/PG4 pair.
     - Code-K2 → 2-second pulse.
     - Code-K3 → 2-second pulse on bus A code 01000.
     - M key:
       - Short press → `Scenario_M()`.
       - Hold about 3 s → toggle `Wifi_ON` and call `WiFi(0)`.
       - Hold about 9 s → `WiFi(9)` (remove the AP password), only when Wi-Fi is on.
   - **ICT4:** elevator, the 4 curtain codes (each toggles a `Red_Par` flag and a `w[1]` bit).
   - **Long-press functions:**
     - Code-K1 held about 3 s → RF learn mode (`Led_Learn_ON`; times out after 200 ticks, about 5 s).
     - Code-K2 held about 3 s → RF format (erase all stored remotes).
     - S6 (`Touch_Lock`) held about 3 s → toggle the S6 LED and send bus C Lock.
3. Bus B input → `Scenario_1..4(0)`, `Scenario_E`, `WiFi(13)`/`WiFi(14)` (alarm OFF/ON report to the app), K1/K2/K3 on/off.
4. RF decode (see §7). In normal mode, a valid remote calls `Ralay_Control(key)`, which maps remote keys to L1–L12.
5. ESP strings: "WIFI GOT IP", "FAIL", "0,CONNECT"/"1,CONNECT", "+IPD,0"/"+IPD,1" (→ `WiFi(4)`), "0,CLOSED"/"1,CLOSED".

### 5.2 Scenarios
- **Storage:** EEPROM `S1_1..S4_16`. Each holds 16 bytes for L1–L12 and the 4 curtain flags; 0 = was on, 1 = was off.
- **Save:** `Scenario_n(1)` blinks N1 (`OUT_N1`), stores the current states, waits 1 s and blinks N1 again.
- **Recall:** `Scenario_n(0)` toggles only the outputs that differ from the stored state, 50 ms apart.
- `Scenario_M` (master key):
  - If any of L1–L12 or curtain 2 (`Red_Par_21`/`22`) is off, everything that is off is turned on.
  - Otherwise everything is toggled off.
- `Scenario_E` (exit, S5): S5 LED on, `delay_ms(15000)` (blocking), S5 LED off, then everything that is on is turned off.

### 5.3 `White(Typ)` (standby)
- Typ 0: bus A 00001, then K white LEDs, then bus C Stand_by.
- Typ 1: bus A 00001, then K white LEDs, no bus C.
- Typ 2: bus A 00010, then K white LEDs, then bus C Stand_by.

### 5.4 EEPROM (M4)

| item | content |
|---|---|
| S1_1..S4_16 | 0x00–0x3F, the 4 scenarios |
| `g_u32eeprom[5]` | 0x40, RF remote codes (0xFFFFFFFF = empty) |
| `o` | 0x54, first-boot flag; erased EEPROM = 0xFF triggers defaults |
| `Wifi_ON` | 0x55, **0 = Wi-Fi enabled** |
| `Usere[22]` | 0x56, router SSID |
| `POL_Eeprom_Variable` | 0x6C, app configuration string |

- The default app configuration string is `"#T*A1/Uaiadbdbbbbeeddcc*H1/Ucvvd+#X1*Z1++"` (`POL_j = 41`). Its middle part (index 7 onwards) holds the key/icon type letters the app shows; `Line#` overwrites them.

### 5.5 App protocol

- **Transport:** ESP8266 AT firmware, UART0 9600. Setup:
  - `AT+CWMODE=3`
  - `AT+CIPMUX=1`
  - `AT+CIPSERVER=1,6269`
  - `AT+CIFSR` (read the IP)
  - Soft-AP SSID `SUNTOUCH`.
- **Receive:** an RX ISR fills a 252-byte buffer `data[]`, wrapping at 250. The main loop uses `strstr()` on it.
- **Send:** `AT+CIPSEND=<id>,<len>` with `<id>` 0 or 1 (two clients), then the raw bytes.
- **State bitmap `w[]`:**
  - `w0`: 0x80 L2, 0x40 L1, 0x20 L4, 0x10 L3, 0x08 L6, 0x04 L5, 0x02 L8, 0x01 L7
  - `w1`: 0x80 L10, 0x40 L9, 0x20 L12, 0x10 L11, 0x08 P1O, 0x04 P1C, 0x02 P2O, 0x01 P2C
  - `w2`: 0x80 K1, 0x40 K2, 0x20 K3, 0x10 EL (code naming)
- **App → panel** (dispatch in `WiFi(4)` and the parts after it):

| message | action |
|---|---|
| `@TA1U` | reply `@TA1U`+w0+w1 (7 bytes) |
| `@TH1U` | reply `@TH1U`+w2 (6 bytes) |
| `&TA1U<bits>` | `WiFi(6)`: 16 bits, desired state of L1..L12 and curtains (bit order per `x[]` mapping in the source) |
| `&TH1U<bits>` | `WiFi(12)`: K1, K2, K3, EL |
| `!&...` | general scenario, 20 bits |
| `!^T...` | floor scenario |
| `!~TA1...` | local scenario 1 (16 bits) |
| `!~TH1...` | local scenario 2 (4 bits) |
| `@M_IP` | reply `%<MAC 17><+><IP 16><+><SSID 20>%` |
| `@M_F_C` | reply `#T` |
| `@M_F_T` | reply the config string |
| `Line#<16 chars>` | write config string bytes 7..22, reply `ok\n` |
| `:*<AT command>*` | pass a raw AT command to the ESP (change AP password) |
| `:#<AT+CWJAP=...>#` | join a router; the SSID is stored in `Usere` |
| `&X1Z1` | bus C "alarm order" (toggle arm, no password!) |
| `@X1Z` | bus C "alarm feed" → later reply `@X1Z1on` / `@X1Z1of` |

- **Panel → app, unsolicited:**
  - After `GOT IP`: `@M_S=<ip>`, `@M_S=Repeat` (no IP) or `@M_S=Error`.
  - State feedback after every change: `Send_Fead_Back(1)` sends A1, `Send_Fead_Back(3)` sends H1.

---

## 6. Alarm firmware (M-64)

- **Keypad and OLED menu.** Menu functions: `OLED_ON_OFF`, `OLED_Pass`, `OLED_SMS`, `OLED_Call`, `Button`.
  - R/L arrows rotate between pages: Zones / arm, Password change, SMS numbers (3), Call number (1).
  - D (ON/OFF) asks for the 4-digit password, then arms or disarms the enabled zones.
  - Digits select zones Z1–Z3 (`Z1..Z3` in EEPROM).
  - The default password is `1234`. It is set on first boot, when EEPROM `o` is non-zero (erased chip).
  - The OLED returns to the home page after 400 ticks (~10 s).
  - Bus C Lock toggles `Lock`. When `Lock = 0`, the keypad is ignored.
- **Zone state machine** (per zone x; ticks of 25 ms):
  - **Arm:**
    - From the keypad: `Alarm_Time_x = 1`, `Alarm_On_x = 0`.
    - From SMS or RF: `Alarm_Time_x = 2000`, so arming is instant.
  - `Alarm_On=0` and time ≥ 1600 (~40 s exit delay): `Alarm_On=1`, short siren beep, SMS "Alarm ON" (`GSM(2)`).
  - `Alarm_On=1` and the sensor is active for a short debounce: `Alarm_On=2`, timer restarts.
  - `Alarm_On=2` and time ≥ 1200 (~30 s entry delay): siren on, `Alarm_On=3`, OLED alarm page, SMS "Alarm Active Zx" to all numbers, then `ATD` call (`GSM(3)`), `GSM_Activ=1`.
  - `Alarm_On=3` and time ≥ 12000 (~5 min): siren off, `Alarm_On=1` (re-armed), `Alarm_Cunter++`. After 3 rounds the zone LED is toggled off.
  - Every event also sends bus B "Stand_by" (activity), and the arm/disarm state is reported on bus B as Alarm ON/OFF (`Alarm_Feed`).
- **GSM** (SIM800, UART0 9600, `GSM(Part)`):
  - **Boot:** `AT+CMGF=1`, `AT+CMGDA="DEL ALL"`.
  - **Every ~15 s** (`Antenna_Time ≥ 600`): `AT+CPIN?` → `AT+CREG?` → `AT+CSQ`. The result drives the N4 signal LED pulses on alarm PB1 → M1 PB7:
    - CSQ ≥ 15: steady.
    - CSQ 10–14: blink every 5 s.
    - CSQ < 10: blink every 2 s.
  - **On `+CMTI`:** `AT+CMGR=<idx>`, check the sender against the 3 stored numbers (last 10 digits), then:
    - `Z1on`, `Z1off`, `Z2on`, `Z2off`, `Z3on`, `Z3off`, `Zon`, `Zoff` → zones.
    - `S1on`..`S4on` → bus B scenario codes.
    - `K1on`, `K1off`, `K2on`, `K3on` → bus B K codes.
    - Reply with an SMS status to all numbers, then `AT+CMGDA` (delete all).
  - **SMS format:**
    - `AT+CMGS="<number>"`, wait 500 ms for `>`, send the text, then 0x1A.
    - Texts: "Alarm ON / Zx ON|OFF", "Alarm OFF…", "Kn ON|OFF", "Senario OK", "Alarm Active / Zx Active".
  - **Call:** `ATD<number>;` (owner confirms it works in practice).
- **RF (alarm):** same EV1527 decoder, INT4, 5 remotes.
  - Remote keys: 0001 → toggle Z1, 0010 → Z2, 0100 → Z3. Arming by remote is instant.
  - Learn = OK key held while all zones are off. Format = C key held while all zones are off.
- **Standby (alarm):** bus C 011 → `Stand_by(0)`: Timer0 off, LEDs off, black OLED. Exit on:
  - bus C 011 again,
  - a touch,
  - an SMS (`+CMTI`),
  - or a sensor while armed (`Exit_Stand_by`).
- **EEPROM (alarm):**

| item | content |
|---|---|
| `g_u32eeprom[5]` | 0x00, RF remote codes |
| `o` | 0x14, first-boot flag |
| `Z1`, `Z2`, `Z3` | 0x15–0x17, armed zones |
| `Memory_pass[5]` | 0x18, password |
| `SMS_Number_1..3[13]` | 0x1D / 0x2A / 0x37 |
| `SMS_N1..3` | 0x44–0x46, 1 = empty |
| `Call_Number[13]` | 0x47 |
| `Call_N1` | 0x54, 1 = empty |

---

## 7. RF remotes (both M64s)

- **Decoder:**
  - The external interrupt fires on any edge.
  - Timer1 at clk/8 measures each high and low time.
  - Sync is a low/high ratio of 20–40. A bit is a 2–4× ratio: long low = 0, long high = 1.
  - A frame is 24 bits. `EV_Code & 0xFFFFFFF0` is the remote ID (20 bits); `EV_Code & 0x0F` is the key.
- **Storage:** 5 remotes per MCU in EEPROM.
- **M4 key mapping** (`Ralay_Control`):

| key | load |
|---|---|
| 0001 | L2 |
| 0010 | L1 |
| 1000 | L4 |
| 0100 | L3 |
| 0101 | L6 |
| 1110 | L5 |
| 1001 | L8 |
| 1010 | L7 |
| 0110 | L10 |
| 0111 | L9 |
| 1011 | L12 |
| 1101 | L11 |

---

## 8. OLED driver (`ssd1306.c`, included in M1, M2, M3 and alarm)

- **Hardware and API:**
  - SSD1306 128×64 at I2C address 0x78, using the CodeVision software `i2c.h` (pins set in project settings: SDA = PD5, SCL = PD6).
  - API: `LCD_init`, `LCD_Contrast`, `LCD_Mode`, `LCD_Sleep`, `LCD_Commmand`, `LCD_Goto`, `LCD_Goto2X`, `LCD_Clear`, `LCD_Char`, `LCD_CharBig`, `LCD_BigNum`, `LCD_Printf(buf, size 0/1/2)`, `LCD_DrawImage(n)`.
- **Images:** full-screen 1026-byte flash images. Each MCU has its own artwork in its own `ssd1306.c`.
  - M32s: image 0 = black, image 5 = lamp page.
  - Alarm: images 0–3 and 5 (menu pages).
- **Fonts:** a 5×8 font `LCD_Buffer[0x500]` and `BigNum[15][96]`.
- **Origin:** the driver came from iot-researcher.ir (Peyman Naderi).

---

## 9. Timers and constants (ticks = 25 ms)

| timer | value | meaning |
|---|---|---|
| M4 `Stand_by_Countr` | 2000 | ~50 s idle → standby (only when everything is off) |
| M4 RF learn | 200 | ~5 s learn window |
| M4 long press | 100 × 30 ms | ~3 s (scenario save, lock, learn, format, Wi-Fi toggle); Wi-Fi password reset 300 × 30 ms ≈ 9 s |
| alarm exit delay | 1600 | ~40 s |
| alarm entry delay | 1200 | ~30 s |
| alarm siren | 12000 | ~5 min; 3 rounds max |
| alarm OLED / button timeout | 400 | ~10 s |
| alarm GSM poll | 600 | ~15 s |
| alarm learn | 100000 loop counts | busy-loop timeout |

The owner wants these values kept for now.

---

## 10. Known bugs and weaknesses in the current code

These must not be reproduced in the rewrite.

1. **Unacknowledged toggle buses** (A, B, C). Any missed pulse desynchronises the state, and there is no way to resynchronise.
   - **M32s miss commands.** They are blind while they redraw the OLED.
   - **Scenario recall from the app (`WiFi(6)`) misses DY spacing.** No `DY=1` is set after L10–L12 and the curtains, so commands go out about 10 ms apart and are missed. This is the likely cause of "loads not restored after a scenario".
   - **Standby uses a toggle code (00001).** If an M32 resets, the standby state inverts.
2. **`Ralay_Control` (M4):** L11 and L12 flip `w[1]` bit 0x40 (the L9 bit). They should flip 0x10 and 0x20, so the app shows the wrong state.
3. **`Send_Fead_Back` does not set `Data_connected[4]='U'`.** After other replies, feedback can go out with a wrong header (e.g. 'Z').
4. **No password on app commands.** `&X1Z1` toggles the alarm for anyone on the `SUNTOUCH` network, and the M key held 9 s opens the AP. The owner's decision is to leave this as it is for now.
5. **Long blocking delays:**
   - `Scenario_E` waits 15 s.
   - GSM SMS sending waits 5 s per number, with interrupts disabled.
   - Learn/format busy loops.
   - Inputs and ESP data are lost during these waits.
6. **`cli`/`sei` misuse.** Many functions disable interrupts while UART data is arriving, and `Data_Clean` (M4) re-enables them in the middle of these "critical" sections.
7. **`EE_FindFreeIndex` returns -1 into an unsigned char.** The `!= -1` test is always true; with 5 remotes stored, a 6th is written to slot 255.
8. **String handling:**
   - `WiFi(7)`/`WiFi(8)` build `str` without a terminating zero after `\r`, and can read past `data[]`.
   - Alarm `sscanf("%d")` writes into a `char` (`Add_Antenna`).
9. **Alarm standby ignores RF.** `Stand_by(0)` does not check `Revice_Flag`, so a remote press waits until another wake event.
10. **Alarm `ATD` and `ATH` are sent without CR** (CodeVision `puts` adds only LF). The owner says they work in practice. Keep this as it is.
11. **Hardware and pin issues:**
    - No watchdog on any MCU.
    - M4 PE3/PE4 are set as outputs although they are reserved sensor inputs.
    - Click relay PG3 is unused.
    - 7-segment keys are commented out.
12. **Naming chaos.** K1↔K3 and the curtain open/close names are swapped between files (see §2.1). Use the owner's naming in the rewrite.

---

## 11. Files in this bundle

| path | content |
|---|---|
| `HANDOFF.md` | this file |
| `pin_sheet.txt` | full pin tables transcribed from the owner's handwritten sheets, with his answers merged |
| `decisions.md` | rewrite decisions (English) |
| `answers_2026-10-17.txt` | owner's original Persian answers to 30 questions |
| `sources/m32_1/cod.c`, `sources/m32_1/ssd1306.c` | M1, original recovered source |
| `sources/m32_2/...`, `sources/m32_3/...` | M2, M3 |
| `sources/m64_wifi/cod.c` | M4 (no `ssd1306.c`; it has no OLED) |
| `sources/m64_alarm/cod.c`, `sources/m64_alarm/ssd1306.c` | alarm |

---

## 12. Decisions for the rewrite (agreed with the owner, 2026-10-17)

**Hardware and toolchain**
- The hardware stays the same: buses A, B and C keep their wiring.
- Make bus traffic robust: use explicit on/off codes or periodic state refresh where the code space allows, enough spacing between commands, and resynchronisation after standby or reset.
- Compiler: CodeVision AVR. MCUs: 3 × ATmega32A, 2 × ATmega64A.

**Naming**
- Name keys by position and function (S1–S6, K1–K3, L1–L12, N1–N4, M), never by icon. Icons are only print artwork and change per project.
- Use the owner's K naming: K1 = M3 PB2/PB1 (radiator), K2 = PG1/PG0 (valve), K3 = PG2/PG4 (lock icon).

**Keys and indicators**
- K1–K3 are latched outputs for now. They are also controlled by SMS, and SMS `Kn` must drive the owner's Kn (fixing the current K1↔K3 swap).
- S1–S6 are user-defined scenarios. They are also run by SMS.
- M: all ON has priority; if everything is already on, a touch switches everything off.
- N1 keeps its current behaviour: it only blinks to confirm that a scenario was saved.
- N2 = power-outage LED. N3 = Wi-Fi LED. N4 = GSM signal LED. Led_PoL = ULN group power, off in standby.

**Inputs and new features**
- Power fail: alarm PC7 (keep it as a `#define`), with an SMS on power loss and the N2 LED.
- Reserved inputs: M4 PE3, PE4, PE5, PE6 (motion, lux, …) and alarm PC7.
- 7-segment (common anode, DP unused): selects a room or zone, 1–9, A–Z, a–z, with UP/DOWN. ON/OFF sends "all on / all off" for that room over the network.
- **Panel network (new):**
  - RS485 on M4 UART1 (PD2/PD3), through an auto-direction TTL-RS485 module (no DE/RE pin; listen before talk, gap after each frame).
  - RF 433 MHz ASK transmitter on M4 PC7, plus the existing receiver.
  - Both peer-to-peer and master/slave modes, selectable per project.
  - The RF output must also control third-party 433 MHz EV1527 relays and sockets.
  - Draft protocol: RS485 frame `0xAA | dst | src | cmd | len | data | CRC8` with ACK and 3 retries, address 0 = broadcast. RF uses the EV1527-compatible 24 bits `[house-ID 16][room 4][cmd 4]`.

**Behaviour to keep as it is for now**
- All timings stay as they are.
- No app password.
- GSM `ATD`/`ATH` stay as they are.
- The mobile app belongs to the owner and can be changed if the protocol changes.

**Agreed work order:**
1. Protocol specification (the 3 internal buses, RS485 and RF). The owner approves it first.
2. M32 firmware.
3. M4 firmware.
4. Alarm firmware.

## 13. Open questions

- Extra features the owner wants (question 30). He will tell later.
- Final approval of the protocol specification.
