# SOODEN — master handoff for a new Claude session (state at 2026-10-27, 15:35 Tehran)

Read this whole file once before doing anything. It is written for you (the AI), not for the owner.
Everything the earlier sessions built is in this bundle (`src/…`) or in the owner's GitHub repo; nothing
else survives (the old cloud container is gone).

---------------------------------------------------------------------------------------------------
## 0. Who, what, and the rules you must follow

Owner: Ali (alirtg00@gmail.com), Sooden technical/engineering group (گروه فنی مهندسی سودن), Iran. He designs and
sells glass touch-switch panels for smart homes (lights, curtains, scenarios, alarm, SIM/GSM, Wi-Fi app, 433 MHz
remotes, RS485 two-panel network). He is a hardware person, not a programmer.

Three products you maintain together:
1. **Panel firmware** (AVR C, avr-gcc): one shared core (`sw.c`) for many boards + board files.
2. **SoodenProg** («برنامه سودن» = the programmer / configurator): a single big HTML page (wizard) + a small
   Windows helper exe (local HTTP server that runs avrdude with a USBasp). He programs every panel with it.
   Delivered as `SoodenProg-vX.Y.Z.zip`. **Latest delivered: v2.9.9** (in `deliverables/`).
3. **Mobile app «سودن»** (Flutter, Android): repo `https://github.com/alirohhi62-spec/sooden-project`
   (branch `main`), APK built by GitHub Actions.

### Standing working rules (all stated by him — obey exactly)
- **Reply in Persian (Farsi)** always. Keep it clear and simple; he reads on a phone.
- **Explain planned changes first and get his explicit confirmation before implementing.** «بله»/«تایید»/«انجام بده»
  = go. For UI changes show a **preview (screenshots/mockup) first**, implement only after approval.
- **Check carefully before delivering.** Each hardware test costs him ~30 min. Run the simulators and tests
  (section 6) for every firmware change; never hand over untested firmware.
- **A new request means the previous version is approved**: don't touch or rearrange approved things; add on top.
- Programmer delivery: always the zip package `SoodenProg-vX.Y.Z.zip`, next version on top of the last
  (v2.10.0 is next). Update `راهنما.txt` (guide inside the zip) with a version note in Persian.
- Every APK update: send him the direct artifact link (or https://github.com/alirohhi62-spec/sooden-project/actions).
  He asked once for "only the download link" — give the artifact URL
  `https://github.com/alirohhi62-spec/sooden-project/actions/runs/<run>/artifacts/<id>`.
- CodeVision AVR sources only when he says «کد ویژن» (generator in `src/fwcv/`).
- «برنامه سودن» means SoodenProg, not the app. Family names: «برنامه ۴ پل», «برنامه دزدگیردار ساده»,
  «برنامه ۲۰ پل», «برنامه دزدگیر سیمکارتی», «برنامه ۱۲ اقتصادی» (see §2).
- "تی تی پی" = the TTP223 old-board job (23-key board with ATmega16 instead of ATmega32; not done yet).
- He is in Asia/Tehran; dates he uses are Solar Hijri (1405).

### Standing product rules (apply to every panel, don't ask again)
- Remote learn: hold pole 1 (≈5 s) → its white blinks; touching another pole moves the blink there; pressing a
  remote button stores that remote on the blinking pole/place. Hold pole 2 = erase all remotes.
  (SIM panel exception: learn on key 13, erase on key 14.)
- Master: switches only the lighting poles; "all on" has priority (any off → all on; all on → all off);
  per-pole choice in the programmer which poles the master switches.
- Group switching is always step-by-step (default 100 ms per step).
- Curtain icons: left = open (باز), right = close (بسته). Never both curtain relays at once (interlock).
- Standby after 1 min idle; waking (touch) plays the same motion as power-up on most boards; first touch in the
  dark only wakes. Since v2.9.5 **a phone connecting over Wi-Fi also wakes the panel** (nothing switched).
- RS485 modules are auto-direction (no DE/RE pin).
- App must show a state only after the panel confirms it.
- Every relay is on the same pin as its pole's red LED.

---------------------------------------------------------------------------------------------------
## 1. Environment setup in a fresh session

```
unzip sooden-handoff-*.zip -d ~/sooden && cd ~/sooden
# AVR toolchain (was ~/tc/avr-gcc-14.1.0-x64-linux): Zak Kemble build avr-gcc 14.1.0 x64 linux
#   https://github.com/ZakKemble/avr-gcc-build/releases  -> unpack to ~/tc/avr-gcc-14.1.0-x64-linux
#   (build scripts do: export PATH=$HOME/tc/avr-gcc-14.1.0-x64-linux/bin:$PATH)
cd src/avrsim && npm install          # avr8js (simulator), used by all sim tests
# programmer UI tests use Playwright (require('/opt/node-tools/node_modules/playwright') in the old box;
#   change the require path or `npm i playwright` and use the preinstalled chromium)
cd src/dartcheck && npm install       # web-tree-sitter + tree-sitter-wasms: Dart syntax check (no Flutter SDK here)
git clone https://github.com/alirohhi62-spec/sooden-project   # the app (needs the GitHub connection/add_repo)
```
Paths inside scripts are absolute to the old box (`/home/claude/fw`, `/home/claude/avrsim`, `/home/claude/p6`,
`/home/claude/p12/...`, `/home/claude/cfgtool`, `/home/claude/out`, `/home/claude/prog/tests`). Easiest: recreate
the same layout: `mkdir -p /home/claude && cp -r src/* /home/claude/` (bundle folders map 1:1:
`src/fw → /home/claude/fw`, `src/avrsim → /home/claude/avrsim`, …, `deliverables → /home/claude/out`).
Scratch path used by some tests: `/tmp/claude-0/-home-claude/7e855f78-334c-56de-9b8b-1622f66810c6/scratchpad/`
(create it, or sed-replace it).

GitHub: `gh workflow run` fails (no GraphQL) → dispatch with
`gh api -X POST repos/alirohhi62-spec/sooden-project/actions/workflows/<file>.yml/dispatches -f ref=main`.
Pushing to `main` triggers `build-apk.yml` (artifact `sooden-app-apk`). Get the artifact id with
`gh api repos/alirohhi62-spec/sooden-project/actions/runs/<run>/artifacts`.

---------------------------------------------------------------------------------------------------
## 2. Product families and boards

| Family (his name) | Board / MCUs | Firmware source | Hex names |
|---|---|---|---|
| ۴ پل (1/2/3/4-pole, ATmega8) | 4P board BS818A-2 coded touch; 2P board | `fw/main_avr.c` + `sw.c`; build `fw/build.sh`, `build_2p.sh` | `fw_4p*`, `fw_2p*` |
| تاینی ۱۳ (1-pol, 2-pol, bell, logo bell; no crystal) | ATtiny13 + BS813C-1 | `t13/t13.c`, `tiny/` tools | `t13_*` (archived models in programmer) |
| شش پل ساده (no crystal, ATmega32, E4/D9) | 6 poles + key7 EXIT + key8 master | `p6/p6.c` | `fw_6p.hex` |
| شش پل کریستال (remote / Wi-Fi / network; DE/D1… see guide) | ATmega32 8 MHz; Wi-Fi OR RS485 on UART PD0/PD1; RF PD3; Wi-Fi EN PB4; buzzer PA6 | `p6/p6x.c` (VAR_REMOTE / VAR_WIFI / VAR_NET), build `p6/build_p6x.sh` | `fw_6p_remote/_wifi/_net` |
| دزدگیردار ساده (alarm 14/12/10/8/6 pole + 2 custom) & ۲۰ پل | "23-key board": ATmega32 (touch, `io32.c`) + ATmega64 (logic `main64.c`+`sw.c`+`wifi64.c`) | build `fw/build_big.sh` | `fw_big_*` (`_a_` = alarm; suffix s/i/x = pole-kind groups; `_p` = two-panel) |
| دزدگیر سیمکارتی (12-pole SIM panel) | 5 MCUs: M4 ATmega64 (main+Wi-Fi: `fw/main_p12.c`+`sw.c`+`wifi64.c` with SW_P12), M1–M3 ATmega32 (`p12/fw/m32_p12.c`), alarm ATmega64 (`p12/fw/alarm_p12.c`, GSM SIM800) | `fw/build_p12.sh` | `fw_p12_m4/m1/m2/m3/alarm` |
| ۱۲ اقتصادی (E12) | single ATmega64; Wi-Fi UART + network UART at once; fuses 3F/C1/FF | `fw/main_e12.c` + `sw.c` + `wifi64.c` (SW_BIG + SW_E12), build `fw/build_e12.sh` | `fw_e12[_s|i|x|si|sx|ix|six][_p]` |

Old/original programs (reference only): `ref/cod_gcc.c` = his original RF-12 panel program (ESP AT handling the
new firmware was compared against on 2026-10-27), `ref/masjed/` = original 12-pole SIM panel sources (CodeVision),
`ref/app-orig/` was the original app (not included; repo history has it).

### Firmware core facts
- `sw.c`/`sw.h`/`cfg.h`: hardware-independent logic; config block written by the programmer into flash
  (ATmega8: 128 B at 0x1F80; ATmega64 boards: 768 B at 0xF000, section `.swcfg`; two-panel block `.swpx` at 0xF300).
  Pole kinds: T_OFF, T_NORMAL, T_MASTER, T_TIMER, T_OFFTMR, T_DELOFF, T_DELAY, T_ILOCK (curtain/cooler), alarm keys,
  T_EXIT, T_SLEEP, T_ELEV, T_CUSTOM, T_GROUP. Each hex contains only the kinds that panel uses (HAS_SEC/ILOCK/SCN…).
- `cfg.h` E12 block: N_SLOTS 12, rm_t uint8, `char ssid[16]` at bytes 751..766 (Wi-Fi name from the programmer).
  6-pole: CF_SIZE 256, SSID at 192..207.
- `wifi64.c` = ESP8266 AT state machine + phone protocol for all ATmega64 Wi-Fi boards (23-key, P12 M4, E12).
  `p6/p6x.c` has its own port of the same logic for the 6-pole (keep both in sync!).
- Phone protocol (TCP 6269, up to 5 phones): `@M_IP` → `%mac(17)+ip(16)+router(20)%`; `@M_MDL` → `$MDL=SD23-<model>-1.0$`;
  `@M_LAY` → `$LAY#<letters>$`; `@M_CAP`; `@K` → `$K#hex$`; `&K#nn`; alarm `@X1Z`, `&X1Z1#pass`; labels `Lbl#nn#ii~text#`;
  clock `&CLK#…`; vacation `Vac#…`; `#AT+CWJAP="ssid","pw"#` (join home router, answer `@M_S=<ip>|Repeat|Error`);
  `*AT+CWSAP="name","pw",1,4*` (panel AP name/password). Full list in the header comment of `wifi64.c`.
  Phones in their "first steps" (@M_IP, @M_F_C, @M_F_T, @TA1…) get nothing pushed; others are `live` and get pushes.
- EEPROM (ATmega64 boards): labels 0x400.. (23×41; E12 reuses keys 13..20 area for remote copies 0x5F0/0x616/0x63C and
  timer copies 0x670/0x6A2/0x6D4), `EE_APINIT` 0x7C0 (crc of the AP name already given to the module), `EE_USER`
  0x7C1 (router name 20 B). 6-pole: EE_USER 0x372.

### What changed in the last days (all delivered, simulator-tested, NOT yet confirmed on hardware unless noted)
- v2.9.3 unique Wi-Fi AP name per panel: programmer field «اسم وای‌فای این پنل», else `sooden-` + last 4 hex of the
  module MAC (given to the module once; crc in EE_APINIT).
- v2.9.4 **router off**: 20 s without router IP → `AT+CWMODE_CUR=2` (old AT: `AT+CWQAP`) so the panel AP stays
  usable; every 2 min with no phone connected → `AT+RST` so the module rejoins by itself; only if a router was set
  (EE_USER). App join while stopped: `AT+CWMODE=3` first. AT strings with `\" \, \\` escapes; one 120-byte command
  buffer (6-pole 104); frame end mark only outside quotes; Persian (UTF-8) names OK.
- v2.9.5 **wake on phone connect** (`sw_wake()` in sw.c; 6-pole `standby=0`).
- v2.9.6 **router-join answer like the old program**: the module changes channel while joining, the phone drops
  and reconnects; `@M_S` now goes to the join link AND every `live` phone for 60 s (`joinRes/joinSent`), join wait
  30 s, a late `WIFI GOT IP` after Error still answers. Owner was testing this on a **6-pole Wi-Fi** panel
  (MAC f0:24:f9:cb:2f:f9, router "aramdaftar"). Before v2.9.6 he saw the IP appear but "پنل به مودم وصل نشد".
- v2.9.7: like his old program, the router address is read 2 s after `WIFI GOT IP` (state W_JOINW), and 0.0.0.0
  is asked again up to 3 times before `Repeat`; unsolicited `WIFI GOT IP` also read 2 s later. Tests: avrsim/tjoin.js (8),
  p6/t6join.js (3), esp.js option `ipLag`.
- v2.9.8 (6-pole test build): black box in p6x.c (`@M_DBG` live, `@M_DBS` saved to EEPROM 0x3B0 75 s after each join;
  app button «خواندن گزارش پنل»). It proved the fault: after `AT+CWMODE_CUR=2` (router not found) the app's join sent
  `AT+CWMODE=3`; the real 6-pole module then went silent on the UART (still accepting TCP) until a power cut.
- v2.9.9 FIX (all Wi-Fi boards): never change the module mode; stopping the router search = `AT+CWQAP` only; join sent
  directly. Fake ESP now hangs like the real one on CWMODE=3 after AP-only (`E.hung`), tsta/t6sta check it never happens.
  Black box still in the 6-pole. **CONFIRMED on hardware 2026-10-27 15:12: the 6-pole joined the home modem with v2.9.9.**
  Still to check on hardware: control through the home Wi-Fi, modem-off behaviour, the other Wi-Fi panels with v2.9.9.
- Pending approval: app handling of several panels on one modem (select a panel on the Locations page → connect to that
  panel, read its info, show its page; manual choice has priority; panel type only from the panel's own $MDL; SIM prompt
  only for SIM panels). Found bugs: matchLocation picks the FIRST location with the same modemName; the first location
  inherits legacy global keys (e.g. panel12_last_sim12) via LocStore.read fallback.
- Lesson from the 6-pole hunt (several failed hardware rounds, owner frustrated): do not guess. When hardware behaves
  differently from the simulator, add diagnostics first (black box / app report), compare with his original programs
  (`ref/cod_gcc.c` = RF-12, `ref/old-6pole-wifi.hex` = his old 6-pole Wi-Fi hex: CWMODE=3, CIPMUX=1, CIPSERVER=1,6269,
  CIFSR, AP "SUNTOUCH" open, join passed through, never changes the module mode), and make the fake ESP reproduce the
  real fault before fixing.
- After v2.9.9 the owner confirmed: 6-pole on the home modem, app works through the home Wi-Fi.
- **Outside access test (2026-10-27): his TP-Link ADSL modem (TD-W8961N-class, 192.168.1.1) gets WAN 100.108.141.207 /
  gw 100.108.128.1 = CGNAT (shared IP, 100.64.0.0/10).** The app's HomeNet correctly reported «آی‌پی مشترک». Port
  forwarding/UPnP cannot work there; outside control needs either a real public IP from the ISP or the **server** (§6A).
  Note also: two panels behind one modem both map external port 6269 → only one reachable from outside; needs a
  per-panel external port (part of the multi-panel plan).

---------------------------------------------------------------------------------------------------
## 3. SoodenProg (programmer)

- Source: `cfgtool/wizard.src.html` (the wizard page, ~6 MB after build because all hexes are embedded) +
  `cfgtool/patches/*.js` (p12.js, seg.js, proj.js, brochure.js) + `cfgtool/parts_*.css/js` + images.
  `python3 cfgtool/build3.py` → `/home/claude/out/sooden-programmer.html` (embeds every `fw/out/*.hex` as
  `<script id="fw-NAME">`, plus `avrsim/cfgcore.js` = the config-block builder shared with the simulator).
- Package: unzip the last package (`deliverables/SoodenProg-v2.9.9.zip`), replace `SoodenProg/www/index.html` with the built html, edit
  `SoodenProg/راهنما.txt` (first line = version + features; add a «- نسخه x.y.z:» note above the previous one),
  zip as the next version. The exe (`SoodenProg.exe`, source `prog/src/soodenprog.c`, a local HTTP server with a
  per-run token that runs avrdude for fixed operations: probe, EEPROM read, program with whitelisted fuses, remote
  library json, archive) has not changed for a while — reuse it from the zip.
- 6-pole hexes are built in `p6/` and must be copied to `fw/out/` before building the programmer
  (`cp p6/fw_6p_wifi.hex fw/out/` etc.).
- Wizard path: single panel / two-panel (pair) / (CPU network later) → crystal? → modules → model card →
  panel picture editor (pole kinds per key), remotes table, master ticks, Wi-Fi name, brochure, program.
  E12 model has its own picture (E12_BOX), kinds per pole (1–8 light/empty, 9–12 also curtain pairs 9/10 & 11/12,
  custom, scenarios), 12 remote places.
- Programmer tests: `prog/tests/itest_*.js` (Playwright on the built html). Run at v2.9.6: itest_ssid, itest_e12,
  itest_6pair, itest_p12master (all pass); itest_e12pair passed at v2.9.4. itest6/itest10 failures are old/known.
- Fuses written (whitelist): ATmega8 crystal 3F/D1, no-crystal 24/D1, tiny13 62/FF, ATmega32 3F/C1 (6-pole simple E4/D9,
  6-pole crystal DE/D1), ATmega64 3F/C1/FF; SIM panel M4+alarm DE/D1/FF.

---------------------------------------------------------------------------------------------------
## 4. Mobile app (repo alirohhi62-spec/sooden-project, Flutter, GetX, floor DB)

- minSdk 28 (Android 9). Package `ir.sooden.app`. Native code: `android/app/src/main/kotlin/.../MainActivity.kt`
  (MethodChannel `sooden/sms`: `send` SMS, `wifiSettings`, `bindWifi {on}`; EventChannel `sooden/sms_in`).
- Panel pages: `lib/panel12/` (12-pole SIM panel, Panel12Controller/Panel12TabHost, demo mode), `lib/sd23/`
  (23-key family + E12 + 6-pole + pair "panel 2" tabs; `sd23_controller.dart` modelNames incl. 'e12':'۱۲ اقتصادی',
  `sd23_screen.dart` `_e12Panel()`), `lib/sim12/` (SMS mode). Old generic pages under `lib/presentation/`.
- Connection: `ConnectionWrapperImpl` (`lib/data/.../connection_wraper/connection_wraper_impl.dart`) picks the
  location: phone SSID = location's panelWifiName or modemName → auto; else BSSID tail = stored MAC → auto (and
  learns the new AP name); else with >1 location ask (`lib/presentation/widgets/location_picker.dart`), remembered
  per network. On the home Wi-Fi: `HomeNet.checkLanIp` (re-finds the panel by MAC if its LAN IP changed) and
  `HomeNet.refreshOutside` (public IP via ipify → saved as staticIp; UPnP IGD AddPortMapping 6269 → panel; CGNAT
  detection). `IpConfig` decides IP: panel AP 192.168.4.1 / panelIpOnModem / staticIp and sets `LocStore.via`
  ('panel'|'modem'|'static') and `WifiBind.set(via != static)`.
- `lib/core/utils/loc_store.dart`: per-location phone storage (`loc<id>_<key>` in GetStorage; legacy keys belong to
  the first location). `lib/core/utils/home_net.dart`, `lib/core/utils/wifi_bind.dart`.
- `WifiBind` (2026-10-27): Android sends traffic over mobile data when the panel Wi-Fi has no internet → the app
  process is bound to the Wi-Fi network (`bindProcessToNetwork`), re-bound by a NetworkCallback when the Wi-Fi comes
  back (module channel change), released outside. Only this app is affected.
- New location page (`lib/presentation/screens/tabs/settings/pages/new_location_screen.dart` + logic
  `lib/presentation/logic/new_location_logic.dart`): dark glass, 3 numbered cards with a guide line per field,
  phone-Wi-Fi status pill, Persian error card («دوباره» / «تنظیمات وای‌فای»), «تنظیمات بیشتر» (static IP, outside
  status, server address/password per location — stored only, for the future server). Panel AP name any letters
  ≤32 bytes, password empty (open, ecn 0) or 8..40 (ecn 4); modem ≤32/64; AT escapes in `NewLocationLogic.atEsc`.
  Modem test: sends `#AT+CWJAP…#`, then `_pollJoin` asks the panel itself (`HomeNet.askIp('192.168.4.1')` or
  `findPanel` on the home Wi-Fi) for up to ~48 s; «Repeat» keeps waiting.
- First-run note (`lib/presentation/widgets/first_run_note.dart`, shown once from the splash): Android 9+, location
  permission/GPS, how to turn on panel Wi-Fi, «وصل بمان» on the no-internet warning.
- Not-found screen shows an outside-connection hint when `via == 'static'` fails (IP may have changed / CGNAT / UPnP off).
- Tests & screenshots (GitHub Actions, results pushed to orphan branches `shots-*`): `test/e12_test.dart`
  (screens-e12.yml), `test/p6pair_test.dart` (screens-p6.yml), `test/loc_test.dart` (screens-loc.yml),
  `test/newloc_test.dart` + `test/homenet_test.dart` (screens-newloc.yml), `screens.yml` (older). Fonts: Dana_FaNum
  (Persian digits) → use fontFamily 'Roboto' for Latin digits (IP, Wi-Fi names); tests load Roboto/MaterialIcons from
  `$FLUTTER_ROOT/bin/cache/artifacts/material_fonts`. In testWidgets wrap real IO (GetStorage.init) in `tester.runAsync`.
- No Flutter SDK locally: check Dart syntax with `node dartcheck/check.js file.dart`; real compile = CI.
- Diagnostics added 2026-10-27: modem-test report box (`modemDiag` in NewLocationLogic, `HomeNet.askIpWhy`) and button
  «خواندن گزارش پنل» (`readPanelReport` → `HomeNet.askDbg` @M_DBG/@M_DBS).
- Latest APK: run 40481648006, artifact 12722913941 (commit c3d1836)
  https://github.com/alirohhi62-spec/sooden-project/actions/runs/40481648006/artifacts/12722913941

---------------------------------------------------------------------------------------------------
## 5. Simulators and tests (run them for every firmware change)

`avrsim/` (avr8js): `big.js` (23-key board ATmega32+ATmega64), `e12.js`, `mix.js`, `esp.js` (fake ESP8266 AT 1.x:
CWMODE/CWMODE_CUR/CWQAP/RST/CWJAP/CWSAP with escapes, router on/off `modemOff/modemOn`, `joinDrop`, `joinLate`,
SNTP, fake phones), `cfgcore.js` (config builder, shared with the programmer).
Key tests (all passing at v2.9.9):
- avrsim: tesp (75), tsta (18, also `OLDAT=1`; checks the module never hangs), tjoin (8), twake (5), tpx (31, stack check), tssid (5), te12 (40),
  te12_e2e (10, uses the programmer-made hex `pr_e12.hex` from itest_e12), te12net (7), te12pair_e2e (5),
  te12ssid (1), tbigmaster (4); plus many older (talarm, tvac, ttimer, tremote, …).
- p6: t6wifi (33), t6x_wifi (15), t6s (9), t6sta (8), t6wake (4), t6join (3), t6dbg (6), t6 (15), t6rf (36), t6x_net/remote.
- p12/sim (SIM panel, 5 MCUs): `HEXDIR=new7/ node t20.js` (41), t21 (11), t23 (13), t5 (12), t9 (1), t11 (17);
  `HEXDIR=prog3s/ node t17.js` (9) — prog3s = programmer-made pair; when M4 changes, make a new dir by copying the
  config bytes ≥0xF000 from `prog3n/fw_p12_m4.hex` into the new `fw/out/fw_p12_m4.hex`:
  `node -e "const c=require('/home/claude/avrsim/cfgcore'),fs=require('fs');const o=c.parseHex(fs.readFileSync('prog3n/fw_p12_m4.hex','utf8')),n=c.parseHex(fs.readFileSync('/home/claude/fw/out/fw_p12_m4.hex','utf8'));for(const [a,v] of o)if(a>=0xF000)n.set(a,v);fs.writeFileSync('prog3X/fw_p12_m4.hex',c.writeHex(n))"`.
  new7 = all current fw_p12_*.hex + nums.js/sim800.js.
- Procedure after a firmware change: build (`fw/build_big.sh`, `build_e12.sh`, `build_p12.sh`, `p6/build_p6x.sh`),
  copy p6 hexes to fw/out, run the tests above, `python3 cfgtool/build3.py`, run itest_* programmer tests, verify the
  embedded hexes equal fw/out, package the zip.

---------------------------------------------------------------------------------------------------
## 6. Open items / where to continue

Immediate:
1. v2.9.9 CONFIRMED on the 6-pole (joins the modem, app works via home Wi-Fi). Still to try on hardware: modem off →
   phone on the panel Wi-Fi works; modem back → panel rejoins by itself (~2-3 min, no phone connected); wake on
   connect; the other Wi-Fi panels (23-key, SIM M4, E12) with v2.9.9.
2. Waiting for approval: **several panels on one modem** in the app (plan in §2 "Pending approval"; add a per-panel
   external port for outside access).
3. Next big task the owner wants: **the server** (§6A). Write the full design first, get approval, then build stage by stage.
4. The 6-pole black box can be removed in a later version (ask him); it is harmless.

---------------------------------------------------------------------------------------------------
## 6A. THE SERVER (next big task — design not yet written or approved)

Why: most customers' home internet in Iran is behind CGNAT (his own: 100.108.x.x) or 4G/TD-LTE; static IP + port
forwarding cannot reach the panel. The owner already said: "normal customers go through the server; static IP +
password stays an optional extra-security mode"; "app works over the local network for now, server later once all
panels are done"; "very soon we will connect the app to the server" (2026-10-27). He hosts his APK on his own site
sooden.ir; an older note mentions his own server/hosting (NetAfraz) for ESP-based remote control.

What exists already:
- App: per-location fields «آدرس سرور» / «رمز سرور» (stored with LocStore keys `server_addr`, `server_pass`), not used yet.
- Panels: ESP8266 AT firmware (AT 1.x; CIPMUX=1 server on 6269 with up to 5 links). AT supports outgoing TCP
  (`AT+CIPSTART=<id>,"TCP","host",port`) while the local server runs (CIPMUX=1), SSL only on some AT builds.
- Same phone protocol for all Wi-Fi panels (`@M_IP`, `@M_MDL`, `@K`, `&K#nn`, …) → a server can simply relay it.

Design to propose (must be explained to him and approved before any code; preview screens first):
1. Panel side (wifi64.c + p6x.c, all Wi-Fi boards): when on a router with internet, keep ONE outgoing TCP link
   (link id 4) to the server; register with panel MAC + a per-panel secret (set by the programmer or first app
   pairing); heartbeat; reconnect with back-off; data from the server link is treated exactly like a phone link
   (same command parser) — so no new protocol on the panel side except register/heartbeat. Keep RAM/stack in mind
   (6-pole ATmega32 has ~700 B free; QN/PN sizes).
2. Server: small relay (e.g. Node.js or Go) on his host: panels register by MAC; phones log in with the panel
   MAC/secret (or account + list of panels); the server pipes bytes between the phone session and the panel link;
   shows online/offline; later push notifications (alarm). TLS between app and server; the panel link may be plain TCP
   + shared-secret HMAC if the ESP AT build has no SSL. Hosting needs a public IP and an open port.
3. App: connection order = panel Wi-Fi → home modem (LAN) → static IP (if set) → server; per location; the "via"
   ('panel'|'modem'|'static'|'server') already exists in LocStore — add 'server'. Pairing UI in «تنظیمات بیشتر».
4. Programmer: optional server address/port/secret written into the config block (or set from the app).
Open questions for him: which host/domain (sooden.ir? VPS?), accounts per customer or per panel, security level,
SSL support on his ESP modules (AT version), whether the SIM panel (SMS) stays as the fallback.

Approved earlier but not yet built / held (ask before starting):
- SIM panel: peer (panel 2) view in the app; installer stage 2 remainder (key roles table in M4 EEPROM, OLED room
  names as bitmaps to M1 at 0x7000) — held.
- App lag on the SIM panel page after going to Wi-Fi (many initial queries, full rebuilds) — "check in later edits".
- CPU network (RS485 with a central ATmega8 "CPU", up to 25 panels) — comes after single + two-panel for every model.
- Static IP for the panel module on the home LAN; several Wi-Fi panels in one home as tabs (router mode + UDP
  discovery) — held.
- Board diagnoser inside SoodenProg — held.
- "تی تی پی": 23-key old board with ATmega16 + TTP223 — not started.
- Relay tick at power-up on ATmega8 1/2-pole/bell: hardware fix suggested (10k pull-downs on PB3/PB4), unresolved.
- Hardware test reports pending for many earlier versions (SIM panel alarm-settings, etc.).

Older docs (more detail, partly outdated): `docs/p12-HANDOFF.md` (full SIM-panel firmware analysis),
`docs/HANDOFF-E12.md`, and the claude.ai Project «سودن» docs (panel-12pol/*, panel-e12/*, claude/FAMILIES.md,
panel-12pol/DECISIONS-2026-10-27.md). Newer decisions in this file override them.

---------------------------------------------------------------------------------------------------
## 7. Bundle contents

```
HANDOFF.md                 this file
deliverables/              SoodenProg-v2.9.9.zip (latest package: www/index.html, SoodenProg.exe, avrdude, guide)
src/fw/                    AVR firmware sources + build scripts + out/*.hex (current builds of every family)
src/p6/                    6-pole firmware (p6.c simple, p6x.c crystal) + hexes + tests (h.js/h2.js harness)
src/p12/                   SIM panel: fw/ (M1–M3, alarm, GSM, OLED fonts), sim/ (5-MCU simulator + tests + hex dirs), handoff/
src/avrsim/                simulator + tests (npm install)
src/cfgtool/               programmer sources (wizard.src.html, patches, build3.py)
src/prog/                  helper exe source (src/soodenprog.c), programmer tests (tests/*.js, *.py)
src/fwcv/                  CodeVision source generator (assemble.sh, c89ize.py, dist/) — only on «کد ویژن»
src/t13/, src/tiny/        ATtiny13 firmware + tools
src/dartcheck/             Dart syntax checker (npm install)
ref/cod_gcc.c              owner's original RF-12 program (reference)
ref/old-6pole-wifi.hex     owner's old 6-pole Wi-Fi firmware (CodeVision hex, reference)
ref/masjed/                original SIM-panel CodeVision sources (reference)
docs/                      older handoffs
```
