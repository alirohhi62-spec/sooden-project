#include <io.h>
#include <delay.h>


//---------------------------OLED----------------------------------


#include <stdio.h>
#include <i2c.h>
#include "ssd1306.c"
/*
iot-researcher.ir
Peyman Naderi
t.me/Nadei_default
*/

#include <delay.h>

void LCD_init(void);  //íà÷àëüíàÿ èíèöèàëèçàöèÿ äèñïëåÿ
void LCD_Commmand(unsigned char ControByte, unsigned char DataByte); //êîìàíäû äèñïëåþ èëè äàííûå
void LCD_Goto(unsigned char x, unsigned char y);    //óñòàíîâèòü êîîðäèíàòû
void LCD_Goto2X(unsigned char x, unsigned char y); //óñòàíîâèòü êîîðäèíàòû óìíîæåíûå íà 2
void LCD_Clear(void);  //î÷èñòêà âñåãî äèñïëåÿ
void LCD_Contrast(char set_contrast); //íàñòðîéêà êîíòðàñòà îò 0 äî 255
void LCD_BigNum(unsigned char num);  //âûâîä áîëüøèõ öèôð
void LCD_Char(unsigned int c);  //âûâîä ñèìâîëà
void LCD_CharBig(unsigned int c); // âûâîä êðóïíûõ ñèìâîëîâ
void LCD_Printf(unsigned char* buf, unsigned char size); //ïå÷àòàåò ñòðîêó ñ ðàçìåðàìè - 0 ñàìûé ìåëêèé 2 - óâåëè÷èíûé - ...
void LCD_DrawImage(unsigned char num_image); //âûâîäèò êàðòèíêó èç ôëåø
void LCD_Bat(unsigned char y,unsigned char x, unsigned char z);   //ðèñóåò áàòàðåéêó ïî êîîðäèíàòàì z - îò 0 äî 10 äåëåí ...
void LCD_Mode(char set_mode); //1 - inverted / 0 - normal
void LCD_Sleep(char set);   //1 - on sleep / 0 - off sleep

unsigned char LCD_X,LCD_Y;

#define SSD1306_I2C_ADDRESS					 0x78
// size
#define SSD1306_LCDWIDTH                      128
#define SSD1306_LCDHEIGHT                     64
#define SSD1306_DEFAULT_SPACE                 5
// Commands
#define SSD1306_SETCONTRAST                  0x81
#define SSD1306_DISPLAYALLON_RESUME          0xA4
#define SSD1306_DISPLAYALLON                 0xA5
#define SSD1306_NORMALDISPLAY                0xA6
#define SSD1306_INVERTDISPLAY                0xA7
#define SSD1306_DISPLAYOFF                   0xAE
#define SSD1306_DISPLAYON                    0xAF
#define SSD1306_SETDISPLAYOFFSET             0xD3
#define SSD1306_SETCOMPINS                   0xDA
#define SSD1306_SETVCOMDETECT                0xDB
#define SSD1306_SETDISPLAYCLOCKDIV           0xD5
#define SSD1306_SETPRECHARGE                 0xD9
#define SSD1306_SETMULTIPLEX                 0xA8
#define SSD1306_SETLOWCOLUMN                 0x00
#define SSD1306_SETHIGHCOLUMN                0x10
#define SSD1306_SETSTARTLINE                 0x40
#define SSD1306_MEMORYMODE                   0x20
#define SSD1306_COLUMNADDR                   0x21
#define SSD1306_PAGEADDR                     0x22
#define SSD1306_COMSCANINC                   0xC0
#define SSD1306_COMSCANDEC                   0xC8
#define SSD1306_SEGREMAP                     0xA0
#define SSD1306_CHARGEPUMP                   0x8D
#define SSD1306_EXTERNALVCC                   0x1
#define SSD1306_SWITCHCAPVCC                  0x2
// Scrolling #defines
#define SSD1306_ACTIVATE_SCROLL               0x2F
#define SSD1306_DEACTIVATE_SCROLL             0x2E
#define SSD1306_SET_VERTICAL_SCROLL_AREA      0xA3
#define SSD1306_RIGHT_HORIZONTAL_SCROLL       0x26
#define SSD1306_LEFT_HORIZONTAL_SCROLL        0x27
#define SSD1306_VERT_AND_RIGHT_HORIZ_SCROLL   0x29
#define SSD1306_VERT_AND_LEFT_HORIZ_SCROLL    0x2A

#define COMAND		                          0x00
#define DATA		                          0x40

flash unsigned char image0[1026] =
{
};

flash unsigned char image1[1026] =
{
};

flash unsigned char image2[1026] =
{
};

flash unsigned char image3[1026] =
{
};

flash unsigned char image5[1026] =
{
};

flash unsigned char LCD_Buffer[0x0500] =
{
//0x3E, 0x51, 0x49, 0x45, 0x3E,// B0
};

flash unsigned char BigNum[15][96] =
{ //0
{0x00, 0x00, 0x00, 0xC0, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
 //1
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xE0, 0xF0,
 //2
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
   //3
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //4
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  //5
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
 //6
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //7
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //8
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
    //9
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //:    10
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...
  // .   11
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...
 //space   12
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...
 //Ãðàäóñû    13
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x11, 0x11, 0x11, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...

};

void LCD_init(void)
 0000 000A {
 .FSTART _LCD_init
  LCD_Sleep(0);
  delay_ms(10);
  LCD_Commmand(COMAND, SSD1306_SETDISPLAYCLOCKDIV);
  LCD_Commmand(COMAND, 0x80);
  LCD_Commmand(COMAND, SSD1306_SETMULTIPLEX);
  LCD_Commmand(COMAND, 0x3F);
  LCD_Commmand(COMAND, SSD1306_SETDISPLAYOFFSET);
  LCD_Commmand(COMAND, 0x00);
  LCD_Commmand(COMAND, SSD1306_SETSTARTLINE | 0x00);
    // We use internal charge pump
  LCD_Commmand(COMAND, SSD1306_CHARGEPUMP);
  LCD_Commmand(COMAND, 0x14);
    // Horizontal memory mode
  LCD_Commmand(COMAND, SSD1306_MEMORYMODE);
  LCD_Commmand(COMAND, 0x00);
  LCD_Commmand(COMAND, SSD1306_SEGREMAP | 0x1);
  LCD_Commmand(COMAND, SSD1306_COMSCANDEC);
  LCD_Commmand(COMAND, SSD1306_SETCOMPINS);
  LCD_Commmand(COMAND, 0x12);
    // Max contrast
  LCD_Commmand(COMAND, SSD1306_SETCONTRAST);
  LCD_Commmand(COMAND, 0xCF);
  LCD_Commmand(COMAND, SSD1306_SETPRECHARGE);
  LCD_Commmand(COMAND, 0xF1);
  LCD_Commmand(COMAND, SSD1306_SETVCOMDETECT);
  LCD_Commmand(COMAND, 0x40);
  LCD_Commmand(COMAND, SSD1306_DISPLAYALLON_RESUME);
    // Non-inverted display
  LCD_Mode(0);
    // Turn display back on
  LCD_Sleep(1);

  LCD_Clear();
  LCD_Goto(0,0);
}
 .FEND

void LCD_Contrast(char set_contrast)
{
 .FSTART _LCD_Contrast
  LCD_Commmand(COMAND, SSD1306_DISPLAYOFF);
	set_contrast -> Y+0
  delay_ms(10);
  LCD_Commmand(COMAND, SSD1306_SETCONTRAST);
  LCD_Commmand(COMAND, set_contrast);
  LCD_Commmand(COMAND, SSD1306_DISPLAYON);
}
 .FEND

void LCD_Mode(char set_mode)
{
 .FSTART _LCD_Mode
 if(set_mode==0){ LCD_Commmand(COMAND, SSD1306_NORMALDISPLAY); }
	set_mode -> Y+0
 if(set_mode==1){ LCD_Commmand(COMAND, SSD1306_INVERTDISPLAY); }
}
 .FEND

void LCD_Sleep(char set)
{
 .FSTART _LCD_Sleep
  if(set==0){LCD_Commmand(COMAND,SSD1306_DISPLAYOFF);}
	set -> Y+0
  if(set==1){LCD_Commmand(COMAND,SSD1306_DISPLAYON);}
}
 .FEND

void LCD_Commmand(unsigned char ControByte, unsigned char DataByte)
{
 .FSTART _LCD_Commmand
  i2c_start();
	ControByte -> Y+1
	DataByte -> Y+0
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(ControByte);
  i2c_write(DataByte);
  i2c_stop();
}
 .FEND

void LCD_Goto(unsigned char x, unsigned char y)
{
 .FSTART _LCD_Goto
	LCD_X = x;
	LCD_Y = y;

	// óñòàíîâêà  è íàñòðîéêà
	LCD_Commmand(COMAND, 0xB0 + y);//óñòàíîâèòü àäðåñ íà÷àëà êîîðäèíàò
	LCD_Commmand(COMAND, x & 0xf);//óñòàíîâèòü íèæíèé àäðåñ ñòîëáöà
	LCD_Commmand(COMAND,0x10 | (x >> 4));//óñòàíîâèòü âåðõíèé àäðåñ ñòîëáöà
}
 .FEND

void LCD_Goto2X(unsigned char x, unsigned char y)
{
 .FSTART _LCD_Goto2X
	LCD_X = x;
	LCD_Y = y;

	// óñòàíîâêà  è íàñòðîéêà
	LCD_Commmand(COMAND, 0xB0 + y);//óñòàíîâèòü àäðåñ íà÷àëà êîîðäèíàò
	LCD_Commmand(COMAND, 2*x & 0xf);//óñòàíîâèòü íèæíèé àäðåñ ñòîëáöà
	LCD_Commmand(COMAND,0x10 | (2*x >> 4));//óñòàíîâèòü âåðõíèé àäðåñ ñòîëáöà
}
 .FEND

void LCD_Clear(void)
{
 .FSTART _LCD_Clear
	unsigned short i;
	unsigned short x=0;
	unsigned short y=0;
	LCD_Goto(0,0);

	for (i=0; i<(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8); i++) //(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8)
	{
		LCD_Char(' ');
		x ++;
		if(x>SSD1306_LCDWIDTH)
		{
			x =0;
			y++;
			LCD_Goto(0,y);
		}
	}
	LCD_X =SSD1306_DEFAULT_SPACE;
	LCD_Y =0;
}
 .FEND

void LCD_Char(unsigned int c)
{
 .FSTART _LCD_Char
  unsigned char x = 0;
  i2c_start();
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(DATA);//data mode
  for (x=0; x<5; x++)
	{
     i2c_write(LCD_Buffer[c*5+x]);
     }
  i2c_write(0x00);  //ïðîáåî â îäíó òî÷êó ìåæäó ñèìâîëàìè
  i2c_stop();    // stop transmitting

	LCD_X += 8;
	if(LCD_X>SSD1306_LCDWIDTH)
	{
		LCD_X = SSD1306_DEFAULT_SPACE;
	}
}
 .FEND

void LCD_BigNum(unsigned char num)
{
 .FSTART _LCD_BigNum
  unsigned char x = 0;
  unsigned char z = 0;

  unsigned char y_s = LCD_Y;

  if(num!=46&&num!=32&&num!=32&&num!=67){num = num - 48;}
	num -> Y+4
	y_s -> R19
  else
   {
   if(num==46){ num = 11; }  // .
   if(num==32){ num = 12; }  // space
   if(num==67){ num = 13; }  // ãðàäóñû
   }

  i2c_start();
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(DATA);//data mode
  for (x=0; x<96; x++)
	{
     i2c_write(BigNum[num][x]);
     if(z>=23)
     {
       i2c_stop();    // stop transmitting
       LCD_Goto(LCD_X,LCD_Y+1);

       z=0;
       i2c_start();
       i2c_write(SSD1306_I2C_ADDRESS);
       i2c_write(DATA);//data mode
     }else{z++;}

     }
  i2c_stop();    // stop transmitting

	LCD_X += 23;
    LCD_Goto(LCD_X,y_s);
    if(LCD_X>SSD1306_LCDWIDTH)
	{
		LCD_X = SSD1306_DEFAULT_SPACE;
	}
}
 .FEND

void LCD_CharBig(unsigned int c)
{
 .FSTART _LCD_CharBig
  unsigned char x = 0;
  unsigned int m = 0;

  i2c_start();
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(DATA);//data mode
  for (x=0; x<5; x++)
	{
     m = LCD_Buffer[c*5+x];
     i2c_write(m);
     i2c_write(m);
     }
  i2c_write(0x00);  //ïðîáåî â îäíó òî÷êó ìåæäó ñèìâîëàìè
  i2c_stop();    // stop transmitting
	LCD_X += 11;
	if(LCD_X>SSD1306_LCDWIDTH)
	{
		LCD_X = SSD1306_DEFAULT_SPACE;
	}
}
 .FEND

void LCD_Printf(unsigned char* buf, unsigned char size) //âûâîäèì ñòðîêó èç áóôåðà
{
 .FSTART _LCD_Printf

	while (*buf!=0)
	*buf -> Y+1
	size -> Y+0
	{
       if(size==0)
       {
		if((LCD_X>SSD1306_LCDWIDTH)||(LCD_X<5)){LCD_X=SSD1306_DEFAULT_SPACE;}
		LCD_Char(*buf++);
        }
       if(size==1)
       {
        if((LCD_X>SSD1306_LCDWIDTH)||(LCD_X<5)){LCD_X=SSD1306_DEFAULT_SPACE;}
        LCD_CharBig(*buf++);
       }
       if(size==2)
       {
        if((LCD_X>SSD1306_LCDWIDTH)||(LCD_X<24)){LCD_X=SSD1306_DEFAULT_SPACE;}
        LCD_BigNum(*buf++);
       }
	}
}
 .FEND

void LCD_DrawImage(unsigned char num_image)
{
 .FSTART _LCD_DrawImage
	unsigned int i;
	unsigned char x=0;
	unsigned char y=0;
	LCD_Goto(0,0);
	num_image -> Y+4

	for (i=0; i<(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8); i++)
	{
        if(num_image==0)
        {
		LCD_Commmand(DATA, image0[i]);
        }

        if(num_image==1)
        {
		LCD_Commmand(DATA, image1[i]);
        }

        if(num_image==2)
        {
		LCD_Commmand(DATA, image2[i]);
        }

        if(num_image==3)
        {
		LCD_Commmand(DATA, image3[i]);
        }

        if(num_image==5)
        {
		LCD_Commmand(DATA, image5[i]);
        }

		x++;
		if(x>=SSD1306_LCDWIDTH)
		{
			x=0;
			y++;
			LCD_Goto(0,y);
		}
	}
}
 .FEND

void LCD_Bat(unsigned char y,unsigned char x, unsigned char z)
{
 unsigned char i=0;

 LCD_Goto2X(x-1,y);
 LCD_Commmand(DATA, 0xFF); LCD_Commmand(DATA, 0xFF);
 LCD_Goto2X(x+2,y);
for (i=0; i<14; i++)
	{
       if(i<11)
       {
         if(z>=i){ LCD_Commmand(DATA, 0xBD); }
         else    { LCD_Commmand(DATA, 0x81); LCD_Commmand(DATA, 0x81); }
       }
       if(i==11)      {LCD_Commmand(DATA, 0xFF); LCD_Commmand(DATA, 0xFF);}
       if(i==12)      {LCD_Commmand(DATA, 0x3C); LCD_Commmand(DATA, 0x3C);}
       if(i==13)      {LCD_Commmand(DATA, 0x3C); LCD_Commmand(DATA, 0x3C);}
       LCD_Goto2X(x+i,y);
	}

}


/*
iot-researcher.ir
Peyman Naderi
t.me/Nadei_default
*/


//---------------------------Touch----------------------------------


#define Touch      (PINA.1 ==0 || PINA.0 ==0 || PINB.0 ==0 || PINB.1 ==0 || PINB.2 ==0)

#define Touch_N2    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==1
#define Touch_N3    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==0
//#define Touch_N4    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==1
#define Touch_N4    PINB.7 ==0

#define Touch_L1    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==0
#define Touch_L2    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==0 && PINB.2 ==1
#define Touch_L3    PINA.1 ==1 && PINA.0 ==1 && PINB.0 ==0 && PINB.1 ==0 && PINB.2 ==0
#define Touch_L4    PINA.1 ==1 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==1 && PINB.2 ==1

#define Touch_P1O   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==1 && PINB.2 ==0
#define Touch_P1C   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==1

#define Touch_P2O   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==1 && PINB.1 ==0 && PINB.2 ==0
#define Touch_P2C   PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==1

#define Touch_Ss    PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==0 && PINB.1 ==0 && PINB.2 ==1
#define Touch_Sd    PINA.1 ==0 && PINA.0 ==0 && PINB.0 ==0 && PINB.1 ==1 && PINB.2 ==0


//---------------------------Led----------------------------------


bit     N2 =0 , N3 =0 , N4 =0;


#define Led_N2        PORTA.7 =~ PORTA.7  , PORTA.6 =~ PORTA.6 , N2 =! N2
#define White_N2      PORTA.7
#define Red_N2        PORTA.6

#define Led_N3        PORTC.6 =~ PORTC.6  , PORTC.7 =~ PORTC.7 , N3 =! N3
#define White_N3      PORTC.6
#define Red_N3        PORTC.7

#define Led_N4        PORTC.4 =~ PORTC.4  , PORTC.5 =~ PORTC.5 , N4 =! N4
#define White_N4      PORTC.4
#define Red_N4        PORTC.5


#define Led_L1        PORTA.5 =~ PORTA.5  , PORTA.4 =~ PORTA.4 //, LCD_DrawImage(2)
#define White_L1      PORTA.5
#define Red_L1        PORTA.4

#define Led_L2        PORTD.1 =~ PORTD.1  , PORTD.0 =~ PORTD.0 //, LCD_DrawImage(0)
#define White_L2      PORTD.1
#define Red_L2        PORTD.0

#define Led_L3        PORTA.3 =~ PORTA.3  , PORTA.2 =~ PORTA.2 //, LCD_DrawImage(3)
#define White_L3      PORTA.3
#define Red_L3        PORTA.2

#define Led_L4        PORTB.4 =~ PORTB.4  , PORTB.3 =~ PORTB.3 //, LCD_DrawImage(1)
#define White_L4      PORTB.4
#define Red_L4        PORTB.3


#define Led_P1O       PORTD.7 =~ PORTD.7  , PORTD.4 =~ PORTD.4
#define White_P1O     PORTD.7
#define Red_P1O       PORTD.4

#define Led_P1C       PORTC.0 =~ PORTC.0  , PORTC.1 =~ PORTC.1
#define White_P1C     PORTC.0
#define Red_P1C       PORTC.1

#define Led_P2O       PORTD.3 =~ PORTD.3  , PORTD.2 =~ PORTD.2
#define White_P2O     PORTD.3
#define Red_P2O       PORTD.2

#define Led_P2C       PORTC.2 =~ PORTC.2  , PORTC.3 =~ PORTC.3
#define White_P2C     PORTC.2
#define Red_P2C       PORTC.3


#define Led_LP       PORTB.5 =~ PORTB.5


//---------------------------Stand_by--------------------------------


  void Stand_by (char Typ);


//---------------------------Status----------------------------------


void Status(void);

#define Status_Time   Status_Countr >= 60000


//---------------------------Function  Main----------------------------------


void main(void)
 0000 0070  {
 .FSTART _main
 0000 0071 
 0000 0072  //long unsigned int Status_Countr =0;
 0000 0073 
 0000 0074  bit L =1 , L1 =1 , S_by =0;
 0000 0075 
 0000 0076 
 0000 0077  delay_ms(300);
	L1 -> R15.1
	S_by -> R15.2
 0000 0078 
 0000 0079 
 0000 007A     DDRA  = 0b11111100;
 0000 007B     PORTA = 0b10101011;
 0000 007C 
 0000 007D     DDRB  = 0b00111000;
 0000 007E     PORTB = 0b10110111;
 0000 007F 
 0000 0080     DDRC  = 0b11111111;
 0000 0081     PORTC = 0b01010101;
 0000 0082 
 0000 0083     DDRD  = 0b11111111;
 0000 0084     PORTD = 0b10001010;
 0000 0085 
 0000 0086     i2c_init();
 0000 0087     LCD_init();
 0000 0088     LCD_Contrast(255);
 0000 0089     LCD_Mode(0);
 0000 008A 
 0000 008B     delay_ms(300);
 0000 008C 
 0000 008D     LCD_DrawImage(5);
 0000 008E 
 0000 008F     Status();
 0000 0090 
 0000 0091     delay_ms(300);
 0000 0092 
 0000 0093  while(1)
 0000 0094   {
 0000 0095       //if(Status_Time) Status() , Status_Countr =0;
 0000 0096 
 0000 0097 
 0000 0098       if(Touch && L)
 0000 0099         {
 0000 009A             delay_ms(20);
 0000 009B 
 0000 009C             if(Touch_N2)   Led_N2;
 0000 009D 
 0000 009E             if(Touch_N3)   Led_N3;
 0000 009F 
 0000 00A0             //if(Touch_N4)   Led_N4;
 0000 00A1 
 0000 00A2 
 0000 00A3             if(Touch_L1)   Led_L1 , Status(); //Status_Countr =1;
 0000 00A4 
 0000 00A5             if(Touch_L2)   Led_L2 , Status(); //Status_Countr =1;
 0000 00A6 
 0000 00A7             if(Touch_L3)   Led_L3 , Status(); //Status_Countr =1;
 0000 00A8 
 0000 00A9             if(Touch_L4)   Led_L4 , Status(); //Status_Countr =1;
 0000 00AA 
 0000 00AB 
 0000 00AC             if(Touch_P1O)  Led_P1O ;
 0000 00AD 
 0000 00AE             if(Touch_P1C)  Led_P1C ;
 0000 00AF 
 0000 00B0 
 0000 00B1             if(Touch_P2O)  Led_P2O ;
 0000 00B2 
 0000 00B3             if(Touch_P2C)  Led_P2C ;
 0000 00B4 
 0000 00B5 
 0000 00B6             if(Touch_Ss)   { if(S_by) S_by =0 , Stand_by(1) ; else  S_by =1 , Stand_by(0) ; }
 0000 00B7 
 0000 00B8             if(Touch_Sd)     S_by =0 , Stand_by(2) ;
 0000 00B9 
 0000 00BA 
 0000 00BB         //------------------------------------------------------------------
 0000 00BC 
 0000 00BD             L =0;
 0000 00BE         }
 0000 00BF 
 0000 00C0       if(!Touch && !L)    L =1;
 0000 00C1 
 0000 00C2 
 0000 00C3       if(Touch_N4 && L1)   Led_N4 , L1 =0;
 0000 00C4 
 0000 00C5       if(!Touch_N4 && !L1) L1 =1;
 0000 00C6 
 0000 00C7 
 0000 00C8       //if(Status_Countr >= 1) Status_Countr ++;
 0000 00C9   }
 0000 00CA 
 0000 00CB  }
 .FEND


//---------------------------Function  Stand_by------------------------------


    void Stand_by (char Typ)
 0000 00D2      {
 .FSTART _Stand_by
 0000 00D3         if(Typ == 0)   // OFF
	Typ -> Y+0
 0000 00D4          {
 0000 00D5              White_N2 =0  , Red_N2  =0;
 0000 00D6 
 0000 00D7              White_N3 =0  , Red_N3  =0;
 0000 00D8 
 0000 00D9              //White_N4 =0  , Red_N4  =0;
 0000 00DA 
 0000 00DB              delay_ms(100);
 0000 00DC 
 0000 00DD              White_L1 =0  , Red_L1  =0;
 0000 00DE 
 0000 00DF              White_L2 =0  , Red_L2  =0;
 0000 00E0 
 0000 00E1              White_L3 =0  , Red_L3  =0;
 0000 00E2 
 0000 00E3              White_L4 =0  , Red_L4  =0;
 0000 00E4 
 0000 00E5              delay_ms(500);
 0000 00E6 
 0000 00E7              White_P1O =0 , Red_P1O =0;
 0000 00E8 
 0000 00E9              White_P1C =0 , Red_P1C =0;
 0000 00EA 
 0000 00EB              White_P2O =0 , Red_P2O =0;
 0000 00EC 
 0000 00ED              White_P2C =0 , Red_P2C =0;
 0000 00EE 
 0000 00EF              delay_ms(100);
 0000 00F0 
 0000 00F1              Led_LP;
 0000 00F2 
 0000 00F3              delay_ms(200);
 0000 00F4 
 0000 00F5              LCD_DrawImage(0);
 0000 00F6          }
 0000 00F7 
 0000 00F8         if(Typ == 1)   // ON ==> Delay
 0000 00F9          {
 0000 00FA              LCD_DrawImage(5) , Status();
 0000 00FB 
 0000 00FC              if(N2)   Red_N2 =1 ;   else   White_N2 =1 ;
 0000 00FD 
 0000 00FE              if(N3)   Red_N3 =1 ;   else   White_N3 =1 ;
 0000 00FF 
 0000 0100              //if(N4)   Red_N4 =1 ;   else   White_N4 =1 ;
 0000 0101 
 0000 0102              delay_ms(100);
 0000 0103 
 0000 0104              White_L1 =1  , White_L2  =1;
 0000 0105 
 0000 0106              White_L3 =1  , White_L4  =1;
 0000 0107 
 0000 0108              delay_ms(500);
 0000 0109 
 0000 010A              White_P1O =1 , White_P1C =1;
 0000 010B 
 0000 010C              White_P2O =1 , White_P2C =1;
 0000 010D 
 0000 010E              delay_ms(100);
 0000 010F 
 0000 0110              Led_LP;
 0000 0111          }
 0000 0112 
 0000 0113         if(Typ == 2)   // ON ==> NO Delay
 0000 0114          {
 0000 0115              LCD_DrawImage(5) , Status();
 0000 0116 
 0000 0117              if(N2)   Red_N2 =1 ;   else   White_N2 =1 ;
 0000 0118 
 0000 0119              if(N3)   Red_N3 =1 ;   else   White_N3 =1 ;
 0000 011A 
 0000 011B              //if(N4)   Red_N4 =1 ;   else   White_N4 =1 ;
 0000 011C 
 0000 011D 
 0000 011E              White_L1 =1  , White_L2  =1;
 0000 011F 
 0000 0120              White_L3 =1  , White_L4  =1;
 0000 0121 
 0000 0122              White_P1O =1 , White_P1C =1;
 0000 0123 
 0000 0124              White_P2O =1 , White_P2C =1;
 0000 0125 
 0000 0126 
 0000 0127              Led_LP;
 0000 0128          }
 0000 0129      }
 .FEND


//---------------------------Function  Oled----------------------------------


    void Status(void)
 0000 0130      {
 .FSTART _Status
 0000 0131         unsigned char buff[50];
 0000 0132         unsigned char v =0;
 0000 0133 
 0000 0134 
 0000 0135         //LCD_DrawImage(5);
 0000 0136 
 0000 0137 
 0000 0138         if(Red_L1 == 1)   LCD_Goto2X(36 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
	buff -> Y+1
 0000 0139 
 0000 013A           else            LCD_Goto2X(36 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 013B 
 0000 013C 
 0000 013D         if(Red_L2 == 1)   LCD_Goto2X(20 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
 0000 013E 
 0000 013F           else            LCD_Goto2X(20 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 0140 
 0000 0141 
 0000 0142         if(Red_L3 == 1)   LCD_Goto2X(36 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
 0000 0143 
 0000 0144           else            LCD_Goto2X(36 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 0145 
 0000 0146 
 0000 0147         if(Red_L4 == 1)   LCD_Goto2X(20 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
 0000 0148 
 0000 0149           else            LCD_Goto2X(20 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 014A      }
 .FEND
 .FSTART _put_buff_G100
 .FEND
 .FSTART __print_G100
 .FEND
 .FSTART _sprintf
 .FEND
 .FSTART _strlen
 .FEND
 .FSTART _strlenf
 .FEND
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 27 TIMES, CODE SIZE REDUCTION:49 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:9 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:5 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:42 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:13 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:9 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
END OF CODE MARKER