#include <io.h>
#include <delay.h>


//---------------------------OLED----------------------------------


#include <stdio.h>
#include <i2c.h>
#include "ssd1306.c"
/*
iot-researcher.ir
Peyman Naderi
t.me/Nadei_default
*/

#include <delay.h>

void LCD_init(void);  //íà÷àëüíàÿ èíèöèàëèçàöèÿ äèñïëåÿ
void LCD_Commmand(unsigned char ControByte, unsigned char DataByte); //êîìàíäû äèñïëåþ èëè äàííûå
void LCD_Goto(unsigned char x, unsigned char y);    //óñòàíîâèòü êîîðäèíàòû
void LCD_Goto2X(unsigned char x, unsigned char y); //óñòàíîâèòü êîîðäèíàòû óìíîæåíûå íà 2
void LCD_Clear(void);  //î÷èñòêà âñåãî äèñïëåÿ
void LCD_Contrast(char set_contrast); //íàñòðîéêà êîíòðàñòà îò 0 äî 255
void LCD_BigNum(unsigned char num);  //âûâîä áîëüøèõ öèôð
void LCD_Char(unsigned int c);  //âûâîä ñèìâîëà
void LCD_CharBig(unsigned int c); // âûâîä êðóïíûõ ñèìâîëîâ
void LCD_Printf(unsigned char* buf, unsigned char size); //ïå÷àòàåò ñòðîêó ñ ðàçìåðàìè - 0 ñàìûé ìåëêèé 2 - óâåëè÷èíûé - ...
void LCD_DrawImage(unsigned char num_image); //âûâîäèò êàðòèíêó èç ôëåø
void LCD_Bat(unsigned char y,unsigned char x, unsigned char z);   //ðèñóåò áàòàðåéêó ïî êîîðäèíàòàì z - îò 0 äî 10 äåëåí ...
void LCD_Mode(char set_mode); //1 - inverted / 0 - normal
void LCD_Sleep(char set);   //1 - on sleep / 0 - off sleep

unsigned char LCD_X,LCD_Y;

#define SSD1306_I2C_ADDRESS					 0x78
// size
#define SSD1306_LCDWIDTH                      128
#define SSD1306_LCDHEIGHT                     64
#define SSD1306_DEFAULT_SPACE                 5
// Commands
#define SSD1306_SETCONTRAST                  0x81
#define SSD1306_DISPLAYALLON_RESUME          0xA4
#define SSD1306_DISPLAYALLON                 0xA5
#define SSD1306_NORMALDISPLAY                0xA6
#define SSD1306_INVERTDISPLAY                0xA7
#define SSD1306_DISPLAYOFF                   0xAE
#define SSD1306_DISPLAYON                    0xAF
#define SSD1306_SETDISPLAYOFFSET             0xD3
#define SSD1306_SETCOMPINS                   0xDA
#define SSD1306_SETVCOMDETECT                0xDB
#define SSD1306_SETDISPLAYCLOCKDIV           0xD5
#define SSD1306_SETPRECHARGE                 0xD9
#define SSD1306_SETMULTIPLEX                 0xA8
#define SSD1306_SETLOWCOLUMN                 0x00
#define SSD1306_SETHIGHCOLUMN                0x10
#define SSD1306_SETSTARTLINE                 0x40
#define SSD1306_MEMORYMODE                   0x20
#define SSD1306_COLUMNADDR                   0x21
#define SSD1306_PAGEADDR                     0x22
#define SSD1306_COMSCANINC                   0xC0
#define SSD1306_COMSCANDEC                   0xC8
#define SSD1306_SEGREMAP                     0xA0
#define SSD1306_CHARGEPUMP                   0x8D
#define SSD1306_EXTERNALVCC                   0x1
#define SSD1306_SWITCHCAPVCC                  0x2
// Scrolling #defines
#define SSD1306_ACTIVATE_SCROLL               0x2F
#define SSD1306_DEACTIVATE_SCROLL             0x2E
#define SSD1306_SET_VERTICAL_SCROLL_AREA      0xA3
#define SSD1306_RIGHT_HORIZONTAL_SCROLL       0x26
#define SSD1306_LEFT_HORIZONTAL_SCROLL        0x27
#define SSD1306_VERT_AND_RIGHT_HORIZ_SCROLL   0x29
#define SSD1306_VERT_AND_LEFT_HORIZ_SCROLL    0x2A

#define COMAND		                          0x00
#define DATA		                          0x40


/*
flash unsigned char image0[1026] =
{
};

flash unsigned char image1[1026] =
{
};

flash unsigned char image2[1026] =
{
};

flash unsigned char image3[1026] =
{
};
*/


flash unsigned char image0[1026] =
{
};

flash unsigned char image5[1026] =
{
};

flash unsigned char LCD_Buffer[0x0500] =
{
//0x3E, 0x51, 0x49, 0x45, 0x3E,// B0
};

flash unsigned char BigNum[15][96] =
{ //0
{0x00, 0x00, 0x00, 0xC0, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
 //1
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xE0, 0xF0,
 //2
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
   //3
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //4
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  //5
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
 //6
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //7
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //8
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
    //9
{0x00, 0x00, 0x00, 0xE0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0, 0xF0,
  //:    10
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...
  // .   11
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...
 //space   12
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...
 //Ãðàäóñû    13
{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x11, 0x11, 0x11, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, ...

};

void LCD_init(void)
 0000 000A {
 .FSTART _LCD_init
  LCD_Sleep(0);
  delay_ms(10);
  LCD_Commmand(COMAND, SSD1306_SETDISPLAYCLOCKDIV);
  LCD_Commmand(COMAND, 0x80);
  LCD_Commmand(COMAND, SSD1306_SETMULTIPLEX);
  LCD_Commmand(COMAND, 0x3F);
  LCD_Commmand(COMAND, SSD1306_SETDISPLAYOFFSET);
  LCD_Commmand(COMAND, 0x00);
  LCD_Commmand(COMAND, SSD1306_SETSTARTLINE | 0x00);
    // We use internal charge pump
  LCD_Commmand(COMAND, SSD1306_CHARGEPUMP);
  LCD_Commmand(COMAND, 0x14);
    // Horizontal memory mode
  LCD_Commmand(COMAND, SSD1306_MEMORYMODE);
  LCD_Commmand(COMAND, 0x00);
  LCD_Commmand(COMAND, SSD1306_SEGREMAP | 0x1);
  LCD_Commmand(COMAND, SSD1306_COMSCANDEC);
  LCD_Commmand(COMAND, SSD1306_SETCOMPINS);
  LCD_Commmand(COMAND, 0x12);
    // Max contrast
  LCD_Commmand(COMAND, SSD1306_SETCONTRAST);
  LCD_Commmand(COMAND, 0xCF);
  LCD_Commmand(COMAND, SSD1306_SETPRECHARGE);
  LCD_Commmand(COMAND, 0xF1);
  LCD_Commmand(COMAND, SSD1306_SETVCOMDETECT);
  LCD_Commmand(COMAND, 0x40);
  LCD_Commmand(COMAND, SSD1306_DISPLAYALLON_RESUME);
    // Non-inverted display
  LCD_Mode(0);
    // Turn display back on
  LCD_Sleep(1);

  LCD_Clear();
  LCD_Goto(0,0);
}
 .FEND

void LCD_Contrast(char set_contrast)
{
 .FSTART _LCD_Contrast
  LCD_Commmand(COMAND, SSD1306_DISPLAYOFF);
	set_contrast -> Y+0
  delay_ms(10);
  LCD_Commmand(COMAND, SSD1306_SETCONTRAST);
  LCD_Commmand(COMAND, set_contrast);
  LCD_Commmand(COMAND, SSD1306_DISPLAYON);
}
 .FEND

void LCD_Mode(char set_mode)
{
 .FSTART _LCD_Mode
 if(set_mode==0){ LCD_Commmand(COMAND, SSD1306_NORMALDISPLAY); }
	set_mode -> Y+0
 if(set_mode==1){ LCD_Commmand(COMAND, SSD1306_INVERTDISPLAY); }
}
 .FEND

void LCD_Sleep(char set)
{
 .FSTART _LCD_Sleep
  if(set==0){LCD_Commmand(COMAND,SSD1306_DISPLAYOFF);}
	set -> Y+0
  if(set==1){LCD_Commmand(COMAND,SSD1306_DISPLAYON);}
}
 .FEND

void LCD_Commmand(unsigned char ControByte, unsigned char DataByte)
{
 .FSTART _LCD_Commmand
  i2c_start();
	ControByte -> Y+1
	DataByte -> Y+0
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(ControByte);
  i2c_write(DataByte);
  i2c_stop();
}
 .FEND

void LCD_Goto(unsigned char x, unsigned char y)
{
 .FSTART _LCD_Goto
	LCD_X = x;
	LCD_Y = y;

	// óñòàíîâêà  è íàñòðîéêà
	LCD_Commmand(COMAND, 0xB0 + y);//óñòàíîâèòü àäðåñ íà÷àëà êîîðäèíàò
	LCD_Commmand(COMAND, x & 0xf);//óñòàíîâèòü íèæíèé àäðåñ ñòîëáöà
	LCD_Commmand(COMAND,0x10 | (x >> 4));//óñòàíîâèòü âåðõíèé àäðåñ ñòîëáöà
}
 .FEND

void LCD_Goto2X(unsigned char x, unsigned char y)
{
 .FSTART _LCD_Goto2X
	LCD_X = x;
	LCD_Y = y;

	// óñòàíîâêà  è íàñòðîéêà
	LCD_Commmand(COMAND, 0xB0 + y);//óñòàíîâèòü àäðåñ íà÷àëà êîîðäèíàò
	LCD_Commmand(COMAND, 2*x & 0xf);//óñòàíîâèòü íèæíèé àäðåñ ñòîëáöà
	LCD_Commmand(COMAND,0x10 | (2*x >> 4));//óñòàíîâèòü âåðõíèé àäðåñ ñòîëáöà
}
 .FEND

void LCD_Clear(void)
{
 .FSTART _LCD_Clear
	unsigned short i;
	unsigned short x=0;
	unsigned short y=0;
	LCD_Goto(0,0);

	for (i=0; i<(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8); i++) //(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8)
	{
		LCD_Char(' ');
		x ++;
		if(x>SSD1306_LCDWIDTH)
		{
			x =0;
			y++;
			LCD_Goto(0,y);
		}
	}
	LCD_X =SSD1306_DEFAULT_SPACE;
	LCD_Y =0;
}
 .FEND

void LCD_Char(unsigned int c)
{
 .FSTART _LCD_Char
  unsigned char x = 0;
  i2c_start();
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(DATA);//data mode
  for (x=0; x<5; x++)
	{
     i2c_write(LCD_Buffer[c*5+x]);
     }
  i2c_write(0x00);  //ïðîáåî â îäíó òî÷êó ìåæäó ñèìâîëàìè
  i2c_stop();    // stop transmitting

	LCD_X += 8;
	if(LCD_X>SSD1306_LCDWIDTH)
	{
		LCD_X = SSD1306_DEFAULT_SPACE;
	}
}
 .FEND

void LCD_BigNum(unsigned char num)
{
 .FSTART _LCD_BigNum
  unsigned char x = 0;
  unsigned char z = 0;

  unsigned char y_s = LCD_Y;

  if(num!=46&&num!=32&&num!=32&&num!=67){num = num - 48;}
	num -> Y+4
	y_s -> R19
  else
   {
   if(num==46){ num = 11; }  // .
   if(num==32){ num = 12; }  // space
   if(num==67){ num = 13; }  // ãðàäóñû
   }

  i2c_start();
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(DATA);//data mode
  for (x=0; x<96; x++)
	{
     i2c_write(BigNum[num][x]);
     if(z>=23)
     {
       i2c_stop();    // stop transmitting
       LCD_Goto(LCD_X,LCD_Y+1);

       z=0;
       i2c_start();
       i2c_write(SSD1306_I2C_ADDRESS);
       i2c_write(DATA);//data mode
     }else{z++;}

     }
  i2c_stop();    // stop transmitting

	LCD_X += 23;
    LCD_Goto(LCD_X,y_s);
    if(LCD_X>SSD1306_LCDWIDTH)
	{
		LCD_X = SSD1306_DEFAULT_SPACE;
	}
}
 .FEND

void LCD_CharBig(unsigned int c)
{
 .FSTART _LCD_CharBig
  unsigned char x = 0;
  unsigned int m = 0;

  i2c_start();
  i2c_write(SSD1306_I2C_ADDRESS);
  i2c_write(DATA);//data mode
  for (x=0; x<5; x++)
	{
     m = LCD_Buffer[c*5+x];
     i2c_write(m);
     i2c_write(m);
     }
  i2c_write(0x00);  //ïðîáåî â îäíó òî÷êó ìåæäó ñèìâîëàìè
  i2c_stop();    // stop transmitting
	LCD_X += 11;
	if(LCD_X>SSD1306_LCDWIDTH)
	{
		LCD_X = SSD1306_DEFAULT_SPACE;
	}
}
 .FEND

void LCD_Printf(unsigned char* buf, unsigned char size) //âûâîäèì ñòðîêó èç áóôåðà
{
 .FSTART _LCD_Printf

	while (*buf!=0)
	*buf -> Y+1
	size -> Y+0
	{
       if(size==0)
       {
		if((LCD_X>SSD1306_LCDWIDTH)||(LCD_X<5)){LCD_X=SSD1306_DEFAULT_SPACE;}
		LCD_Char(*buf++);
        }
       if(size==1)
       {
        if((LCD_X>SSD1306_LCDWIDTH)||(LCD_X<5)){LCD_X=SSD1306_DEFAULT_SPACE;}
        LCD_CharBig(*buf++);
       }
       if(size==2)
       {
        if((LCD_X>SSD1306_LCDWIDTH)||(LCD_X<24)){LCD_X=SSD1306_DEFAULT_SPACE;}
        LCD_BigNum(*buf++);
       }
	}
}
 .FEND

void LCD_DrawImage(unsigned char num_image)
{
 .FSTART _LCD_DrawImage
	unsigned int i;
	unsigned char x=0;
	unsigned char y=0;
	LCD_Goto(0,0);
	num_image -> Y+4

	for (i=0; i<(SSD1306_LCDWIDTH*SSD1306_LCDHEIGHT/8); i++)
	{
/*
        if(num_image==0)
        {
		LCD_Commmand(DATA, image0[i]);
        }

        if(num_image==1)
        {
		LCD_Commmand(DATA, image1[i]);
        }

        if(num_image==2)
        {
		LCD_Commmand(DATA, image2[i]);
        }

        if(num_image==3)
        {
		LCD_Commmand(DATA, image3[i]);
        }
*/

        if(num_image==0)
        {
		LCD_Commmand(DATA, image0[i]);
        }

        if(num_image==5)
        {
		LCD_Commmand(DATA, image5[i]);
        }

		x++;
		if(x>=SSD1306_LCDWIDTH)
		{
			x=0;
			y++;
			LCD_Goto(0,y);
		}
	}
}
 .FEND

void LCD_Bat(unsigned char y,unsigned char x, unsigned char z)
{
 unsigned char i=0;

 LCD_Goto2X(x-1,y);
 LCD_Commmand(DATA, 0xFF); LCD_Commmand(DATA, 0xFF);
 LCD_Goto2X(x+2,y);
for (i=0; i<14; i++)
	{
       if(i<11)
       {
         if(z>=i){ LCD_Commmand(DATA, 0xBD); }
         else    { LCD_Commmand(DATA, 0x81); LCD_Commmand(DATA, 0x81); }
       }
       if(i==11)      {LCD_Commmand(DATA, 0xFF); LCD_Commmand(DATA, 0xFF);}
       if(i==12)      {LCD_Commmand(DATA, 0x3C); LCD_Commmand(DATA, 0x3C);}
       if(i==13)      {LCD_Commmand(DATA, 0x3C); LCD_Commmand(DATA, 0x3C);}
       LCD_Goto2X(x+i,y);
	}

}


/*
iot-researcher.ir
Peyman Naderi
t.me/Nadei_default
*/


//---------------------------Touch----------------------------------


#define Touch      (PINA.0 ==0 || PINA.1 ==0 || PINA.2 ==0 || PINA.3 ==0 || PINA.4 ==0)

#define Touch_N1    PINA.0 ==1 && PINA.1 ==1 && PINA.2 ==1 && PINA.3 ==1 && PINA.4 ==0

#define Touch_L5    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==1 && PINA.3 ==1 && PINA.4 ==0
#define Touch_L6    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==1 && PINA.3 ==0 && PINA.4 ==1
#define Touch_L7    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==1 && PINA.3 ==0 && PINA.4 ==0
#define Touch_L8    PINA.0 ==1 && PINA.1 ==0 && PINA.2 ==0 && PINA.3 ==1 && PINA.4 ==1

#define Touch_Ss    PINA.0 ==0 && PINA.1 ==0 && PINA.2 ==0 && PINA.3 ==0 && PINA.4 ==1
#define Touch_Sd    PINA.0 ==0 && PINA.1 ==0 && PINA.2 ==0 && PINA.3 ==1 && PINA.4 ==0


//---------------------------Led----------------------------------


bit     N1 =0;


#define Led_N1        PORTC.0 =~ PORTC.0  , PORTC.1 =~ PORTC.1 , N1 =! N1
#define White_N1      PORTC.0
#define Red_N1        PORTC.1


#define Led_L5        PORTC.2 =~ PORTC.2  , PORTC.3 =~ PORTC.3 //, LCD_DrawImage(2)
#define White_L5      PORTC.2
#define Red_L5        PORTC.3

#define Led_L6        PORTB.4 =~ PORTB.4  , PORTB.3 =~ PORTB.3 //, LCD_DrawImage(0)
#define White_L6      PORTB.4
#define Red_L6        PORTB.3

#define Led_L7        PORTA.7 =~ PORTA.7  , PORTA.6 =~ PORTA.6 //, LCD_DrawImage(3)
#define White_L7      PORTA.7
#define Red_L7        PORTA.6

#define Led_L8        PORTB.2 =~ PORTB.2  , PORTB.1 =~ PORTB.1 //, LCD_DrawImage(1)
#define White_L8      PORTB.2
#define Red_L8        PORTB.1


//---------------------------Stand_by--------------------------------


  void Stand_by (char Typ);


//---------------------------Status----------------------------------


void Status(void);

#define Status_Time   Status_Countr >= 60000


//---------------------------Function  Main----------------------------------


void main(void)
 0000 004B  {
 .FSTART _main
 0000 004C 
 0000 004D  //long unsigned int Status_Countr =0;
 0000 004E 
 0000 004F  bit L =1 , S_by =0;
 0000 0050 
 0000 0051 
 0000 0052  delay_ms(300);
	S_by -> R15.1
 0000 0053 
 0000 0054 
 0000 0055     DDRA  = 0b11100000;
 0000 0056     PORTA = 0b10011111;
 0000 0057 
 0000 0058     DDRB  = 0b01111111;
 0000 0059     PORTB = 0b10010100;
 0000 005A 
 0000 005B     DDRC  = 0b11111111;
 0000 005C     PORTC = 0b00000101;
 0000 005D 
 0000 005E     DDRD  = 0b11111111;
 0000 005F     PORTD = 0b00000000;
 0000 0060 
 0000 0061 
 0000 0062     i2c_init();
 0000 0063     LCD_init();
 0000 0064     LCD_Contrast(255);
 0000 0065     LCD_Mode(0);
 0000 0066 
 0000 0067     delay_ms(300);
 0000 0068 
 0000 0069     LCD_DrawImage(5);
 0000 006A 
 0000 006B     Status();
 0000 006C 
 0000 006D     delay_ms(300);
 0000 006E 
 0000 006F  while(1)
 0000 0070   {
 0000 0071       //if(Status_Time) Status() , Status_Countr =0;
 0000 0072 
 0000 0073 
 0000 0074       if(Touch && L)
 0000 0075         {
 0000 0076             delay_ms(20);
 0000 0077 
 0000 0078             if(Touch_N1)  Led_N1;
 0000 0079 
 0000 007A 
 0000 007B             if(Touch_L5)  Led_L5 , Status(); //Status_Countr =1;
 0000 007C 
 0000 007D             if(Touch_L6)  Led_L6 , Status(); //Status_Countr =1;
 0000 007E 
 0000 007F             if(Touch_L7)  Led_L7 , Status(); //Status_Countr =1;
 0000 0080 
 0000 0081             if(Touch_L8)  Led_L8 , Status(); //Status_Countr =1;
 0000 0082 
 0000 0083 
 0000 0084             if(Touch_Ss)   { if(S_by) S_by =0 , Stand_by(1) ; else  S_by =1 , Stand_by(0) ; }
 0000 0085 
 0000 0086             if(Touch_Sd)     S_by =0 , Stand_by(2) ;
 0000 0087 
 0000 0088 
 0000 0089         //------------------------------------------------------------------
 0000 008A 
 0000 008B             L =0;
 0000 008C         }
 0000 008D 
 0000 008E       if(!Touch && !L)    L =1;
 0000 008F 
 0000 0090 
 0000 0091       //if(Status_Countr >= 1) Status_Countr ++;
 0000 0092   }
 0000 0093 
 0000 0094  }
 .FEND


//---------------------------Function  Stand_by------------------------------


    void Stand_by (char Typ)
 0000 009B      {
 .FSTART _Stand_by
 0000 009C         if(Typ == 0)   // OFF
	Typ -> Y+0
 0000 009D          {
 0000 009E              White_N1 =0  , Red_N1  =0;
 0000 009F 
 0000 00A0              delay_ms(200);
 0000 00A1 
 0000 00A2              White_L5 =0  , Red_L5  =0;
 0000 00A3 
 0000 00A4              White_L6 =0  , Red_L6  =0;
 0000 00A5 
 0000 00A6              White_L7 =0  , Red_L7  =0;
 0000 00A7 
 0000 00A8              White_L8 =0  , Red_L8  =0;
 0000 00A9 
 0000 00AA              delay_ms(700);
 0000 00AB 
 0000 00AC              LCD_DrawImage(0);
 0000 00AD          }
 0000 00AE 
 0000 00AF         if(Typ == 1)   // ON ==> Delay
 0000 00B0          {
 0000 00B1              LCD_DrawImage(5) , Status();
 0000 00B2 
 0000 00B3              if(N1)   Red_N1 =1 ;   else   White_N1 =1 ;
 0000 00B4 
 0000 00B5              delay_ms(200);
 0000 00B6 
 0000 00B7              White_L5 =1  , White_L6  =1;
 0000 00B8 
 0000 00B9              White_L7 =1  , White_L8  =1;
 0000 00BA          }
 0000 00BB 
 0000 00BC         if(Typ == 2)   // ON ==> NO Delay
 0000 00BD          {
 0000 00BE              LCD_DrawImage(5) , Status();
 0000 00BF 
 0000 00C0              if(N1)   Red_N1 =1 ;   else   White_N1 =1 ;
 0000 00C1 
 0000 00C2 
 0000 00C3              White_L5 =1  , White_L6  =1;
 0000 00C4 
 0000 00C5              White_L7 =1  , White_L8  =1;
 0000 00C6          }
 0000 00C7      }
 .FEND


//---------------------------Function  Oled----------------------------------


    void Status(void)
 0000 00CE      {
 .FSTART _Status
 0000 00CF         unsigned char buff[50];
 0000 00D0         unsigned char v =0;
 0000 00D1 
 0000 00D2 
 0000 00D3         //LCD_DrawImage(5);
 0000 00D4 
 0000 00D5 
 0000 00D6         if(Red_L5 == 1)   LCD_Goto2X(36 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
	buff -> Y+1
 0000 00D7 
 0000 00D8           else            LCD_Goto2X(36 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 00D9 
 0000 00DA 
 0000 00DB         if(Red_L6 == 1)   LCD_Goto2X(20 , 1) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
 0000 00DC 
 0000 00DD           else            LCD_Goto2X(20 , 1) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 00DE 
 0000 00DF 
 0000 00E0         if(Red_L7 == 1)   LCD_Goto2X(36 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
 0000 00E1 
 0000 00E2           else            LCD_Goto2X(36 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 00E3 
 0000 00E4 
 0000 00E5         if(Red_L8 == 1)   LCD_Goto2X(20 , 6) , sprintf(buff , "ON "  , v) , LCD_Printf(buff , 0);
 0000 00E6 
 0000 00E7           else            LCD_Goto2X(20 , 6) , sprintf(buff , "OFF" , v) , LCD_Printf(buff , 0);
 0000 00E8      }
 .FEND
 .FSTART _put_buff_G100
 .FEND
 .FSTART __print_G100
 .FEND
 .FSTART _sprintf
 .FEND
 .FSTART _strlen
 .FEND
 .FSTART _strlenf
 .FEND
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 27 TIMES, CODE SIZE REDUCTION:49 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:9 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:5 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:1 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:42 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:13 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:9 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:3 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
END OF CODE MARKER