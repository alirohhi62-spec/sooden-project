#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* SOODEN: AVR-GCC port of the CodeVision project (ATmega64A, 8 MHz, USART0 9600 8N1). */

/* CodeVision delay_ms(unsigned int) */
static void delay_ms(unsigned int ms) { while (ms--) _delay_ms(1); }

/* CodeVision stdio on USART0: putchar, and puts = string + new line */
static void cv_putchar(char c) { while (!(UCSR0A & (1 << UDRE0))); UDR0 = c; }
static void cv_puts(const char *s) { while (*s) cv_putchar(*s++); cv_putchar('\n'); }
#undef putchar
#define putchar(c) cv_putchar(c)
#define puts(s)    cv_puts(s)
             

// SOODEN: default panel wifi = name "sooden", password "sooden123" (WPA2 needs 8..63 characters).
//         To change it, edit the two AT+CWSAP lines below.             

                                  
//---------------------------Definition----------------------------------
                                            
                     
unsigned int          Screen_Condition_Countr_1 , Timer_Screen =270 ;
                     

unsigned char   p1[6];                                    //  -> 35 - 69 = 34  <-
                                                         //  |                  |  
// SOODEN: 10 lighting keys + 1 curtain (2 keys) + elevator + alarm
unsigned char   POL_Variable[] = "#T*A1/Uaaaaaaaaaa/Vp1*L+#X1*Z1++" , POL_j =32;

unsigned char   KeysCount =10 , Scenario_Count =12 , w[2];


#define Sleep   Sleep_Countr >= 1000 && Red1 ==0 && Red2 ==0 && Red3 ==0 && Red4 ==0 && Red5 ==0 && Red6 ==0 && Red7 ==0 && Red9 ==0 && Red10 ==0 && Red11 ==0 && Red12 ==0 && Red_Par_1 ==0 && Red_Par_2 ==0

#define Sleep_POL    Led8 , w[0] ^=0X01   


#define Led_S         //Led_R , delay_ms(25000) , Led_R

#define Led_E         Led_R , delay_ms(15000) , Led_R


#define Scenario_R    Scenario_E()

#define Scenario_C    Led_A

#define Scenario_L    Scenario_M()


//---------------------------Touch----------------------------------


#define Touch     (((PINE>>2)&1) ==0 || ((PINE>>3)&1) ==0 || ((PINE>>4)&1) ==0 || ((PINE>>5)&1) ==0 || ((PINB>>1)&1) ==0)

#define Touch1    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0
#define Touch2    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1
#define Touch3    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0
#define Touch4    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1
#define Touch5    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0
#define Touch6    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1
#define Touch7    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0
#define Touch8    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1
#define Touch9    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0
#define Touch10   ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1
#define Touch11   ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0
#define Touch12   ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1
#define Touch13   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0
#define Touch14   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1

#define Touch_R   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0
#define Touch_C   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1
#define Touch_L   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0


//---------------------------Touch WiFi----------------------------------


#define Touch_W   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1

#define Touch_F   ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0


//---------------------------Touch RF----------------------------------


#define Touch_RF_Sleep     ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0


#define Touch_Learn_ON     ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1


#define Touch_Format_ON    ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1


//---------------------------Touch Alarm----------------------------------


#define Touch_D    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0
#define Touch_P    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1

#define Touch_1    ((PINE>>2)&1) ==1 && ((PINE>>3)&1) ==0 && ((PINE>>4)&1) ==0 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==0
#define Touch_2    ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==1
#define Touch_3    ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==1 && ((PINB>>1)&1) ==0
#define Touch_4    ((PINE>>2)&1) ==0 && ((PINE>>3)&1) ==1 && ((PINE>>4)&1) ==1 && ((PINE>>5)&1) ==0 && ((PINB>>1)&1) ==1


//---------------------------Led----------------------------------

unsigned char F5 =0 , G3 =0 , F6 =0 , G2 =0 , G0 =0 , LLearn =0 , LFormat =0; 


#define Led1        PORTF ^= 0b00010000 , PORTF ^= 0b00100000 , F5 =! F5    //F4 , F5
#define White1      PORTF ^= 0b00010000
#define Red1        F5

#define Led2        PORTE ^= (1<<7)  , PORTB ^= (1<<0)      
#define White2      PORTE ^= (1<<7)
#define Red2        ((PORTB>>0)&1)

#define Led3        PORTA ^= (1<<5)  , PORTA ^= (1<<4)     
#define White3      PORTA ^= (1<<5)
#define Red3        ((PORTA>>4)&1)

#define Led4        PORTB ^= (1<<2)  , PORTB ^= (1<<3)      
#define White4      PORTB ^= (1<<2)
#define Red4        ((PORTB>>3)&1)

#define Led5        PORTA ^= (1<<3)  , PORTA ^= (1<<2)        
#define White5      PORTA ^= (1<<3)
#define Red5        ((PORTA>>2)&1)

#define Led6        PORTG ^= 0b00010000 , PORTG ^= 0b00001000 , G3 =! G3    //G4 , G3      
#define White6      PORTG ^= 0b00010000
#define Red6        G3

#define Led7        PORTA ^= (1<<1)  , PORTA ^= (1<<0)      
#define White7      PORTA ^= (1<<1)
#define Red7        ((PORTA>>0)&1)

#define Led8        PORTB ^= (1<<6)  , PORTB ^= (1<<7)
#define White8      PORTB ^= (1<<6)
#define Red8        ((PORTB>>7)&1)

#define Led9        PORTF ^= 0b10000000 , PORTF ^= 0b01000000 , F6 =! F6    //F7 , F6
#define White9      PORTF ^= 0b10000000
#define Red9        F6

#define Led10       PORTB ^= (1<<5)  , PORTB ^= (1<<4)      
#define White10     PORTB ^= (1<<5)
#define Red10       ((PORTB>>4)&1)

// SOODEN: light channels 11 and 12 are not used as lights on this panel:
//         keys 11/12 are the curtain keys (see Led_Par_1 / Led_Par_2).
#define Led11       0
#define White11     0
#define Red11       0

#define Led12       0
#define White12     0
#define Red12       0


/* SOODEN: curtain open = key 11: white LED output 11 (PORTA.7), red LED + relay output 19 (PORTA.6) */
#define Led_Par_1       PORTA ^= (1<<7) , PORTA ^= (1<<6)
#define White_Par_1     PORTA ^= (1<<7)
#define Red_Par_1       ((PORTA>>6)&1)

/* SOODEN: curtain close = key 12: white LED output 12 (PORTG.1), red LED + relay output 20 (PORTG.0) */
#define Led_Par_2       PORTG ^= 0b00000010 , PORTG ^= 0b00000001 , G0 =! G0
#define White_Par_2     PORTG ^= 0b00000010
#define Red_Par_2       G0


#define Led_R       PORTC ^= (1<<1) , PORTC ^= (1<<2)
#define White_R     PORTC ^= (1<<1)
                 
#define Led_L       PORTC ^= (1<<7) , PORTC ^= (1<<6)
#define White_L     PORTC ^= (1<<7)

#define Led_M    (Red1 ==0 || Red2 ==0 || Red3 ==0 || Red4 ==0 || Red5 ==0 || Red6 ==0 || Red7 ==0 || Red8 ==0 || Red9 ==0 || Red10 ==0)

                 
//---------------------------Led RF-----------------------------------------
                                  
                   
#define    Led_Learn_ON     PORTF &= 0b11001111                       , F5 =0 , LLearn =! LLearn    //POL1  F4 , F5
#define    Led_Learn_OFF    PORTF &= 0b11001111 , PORTF |= 0b00010000 , F5 =0 , LLearn =! LLearn    //POL1  F4
                   
#define    Led_Format_ON    PORTE &= 0b01111111 , PORTB &= 0b11111110 , LFormat =! LFormat          //POL2  E7 , B0
#define    Led_Format_OFF   PORTE |= 0b10000000 , LFormat =! LFormat          //POL2  E7 

                 
//---------------------------Led Alarm----------------------------------



unsigned char                 Red =0 , Number =0 , Dlete_Senario =0;
unsigned char       Alarm_On =0 , Alarm_Cunter =0 , num =0 , pass[5];


#define Led_D       PORTF ^= 0b00001000 , PORTF ^= 0b00000100 , F2 =! F2 , Red =1    //F3 , F2
#define White_D     PORTF ^= 0b00001000
#define Red_D       F2

#define Led_P       PORTE ^= (1<<6)  , PORTD ^= (1<<0)      
#define White_P     PORTE ^= (1<<6)
#define Red_P       ((PORTD>>0)&1)


#define Led_N_OFF       PORTF &= 0b11111101 , PORTD &= (unsigned char)~(1<<1) , delay_ms(200) , PORTC &= (unsigned char)~(1<<3) , PORTD &= (unsigned char)~(1<<5) , PORTC &= (unsigned char)~(1<<5) , PORTD &= (unsigned char)~(1<<7)   /* digits 5,6 = white outputs 19,20 */

#define Led_N_ON        PORTF |= 0b00000010 , PORTD |= (1<<1) , delay_ms(200) , PORTC |= (1<<3) , PORTD |= (1<<5) , PORTC |= (1<<5) , PORTD |= (1<<7)

#define Alarm_Buzer     PORTD ^= (1<<4)     
#define Buzer           ((PORTD>>4)&1)

#define Input_Sensur    ((PINC>>4)&1)    

                 
//---------------------------Elevator----------------------------------


#define Led_A    PORTC ^= (1<<6) , delay_ms(1000) , PORTC ^= (1<<6)

                 
//---------------------------Function Scenario----------------------------------


  void White        (char Typ);

  void Scenario_M   (void);

  void Scenario_E   (void);

  void Alarm        (char Activ);

  void Screen       (char Par);


//---------------------------Variable Wifi----------------------------------


unsigned char   data[252] , str[82] , Data_connected[252] , Mac_Ip[19] , Static_Ip[18];

volatile unsigned char i =0;   /* SOODEN: shared with the USART interrupt */
unsigned char   j =0 , Read_Ip =2;

// SOODEN: new eeprom storage

// SOODEN: up to 3 phones (link ids 0..2)
unsigned char   Conn[3] = {0,0,0} , Id_S =0;
unsigned char   Wifi_ON =0;     /* SOODEN: global so an ESP reset can restart the server */
/* SOODEN: scenario timers (minutes left; counted by TIMER0, 2400 ticks of 25 ms = 1 minute) */
volatile unsigned long Min_Acc = 0;   /* SOODEN: timer counts (128 us each); 468750 = exactly 1 minute */
/* SOODEN: panel clock, set by the phone: days since 2000-01-01 and minute of the day (local time) */
unsigned int  Clk_Day = 0 , Clk_Min = 0;
unsigned char Clk_Ok = 0;
unsigned char Vac_Due = 0;            /* bit0..5 = step 1..6 due, bit7 = end due */
unsigned int  Vac_Night = 0;          /* night (day number) of the due events */
unsigned int  Vac_LastNight = 0xFFFF , Vac_LastT = 0xFFFF;
volatile unsigned int  Exit_Ticks = 0;
volatile unsigned char Exit_Due = 0;
volatile unsigned char Min_Flag = 0;
unsigned int  Pend[12];
unsigned char Pend_Due[12];


//---------------------------Led Wifi----------------------------------


#define Led_Remove_Wifi_Pass    Led_L    //Pol Exit


//---------------------------Function Wifi----------------------------------


  void WiFi            (char Part);

  void Send_Fead_Back  (char Fead_Back);
  void Scn_Start       (unsigned char n);
  static unsigned char Scn_Minutes (void);
  static void Scn_Tick (void);
  static void Vac_Minute (void);
  static void Vac_Run (void);
  static void Vac_Write (unsigned char *p);
  static void Vac_Read (void);
  static void Clk_Set (unsigned char *p);
  static void Exit_Run (void);
  static void Wait_Payload (void);
  void Scn_Report      (unsigned char n);
  void Send_Event      (char Ev);
  void Wifi_Start      (void);

  void Send_Data       (char Id , unsigned char Cunter);
  void Reply           (unsigned char Cunter);
  void Broadcast       (unsigned char Cunter);

  void Data_Clean      (void);



/* SOODEN: CodeVision "eeprom" variables.  The program uses this RAM copy;
   ee_sync() writes every changed byte back to the EEPROM. */
typedef struct {
    unsigned char Magic1, Magic2;
    unsigned int  Screen_Condition_1;
    char          F2, o, ch_pass[5], Usere[22], POL_Eeprom_Variable[40];
    unsigned char Cfg_Ver, Ap_Init;
} EE_t;
EE_t EE, EE_shadow;
/* SOODEN: vacation program.  Times are minutes after midnight of the night it starts (0..2879, so a
   step may be after midnight).  mask = 10 lights, bit0 = light 1.  c = curtain 'O' / 'C' / '-'. */
#define VAC_STEPS 6
typedef struct { unsigned int t; unsigned int mask; char c; } VacStep_t;
typedef struct {
    unsigned char on;            /* 1 = active                                   */
    unsigned int  d0 , d1;       /* first and last night (days since 2000-01-01) */
    unsigned char n;             /* number of steps 1..6                          */
    VacStep_t     st[VAC_STEPS];
    unsigned int  te;            /* end time: everything off                      */
    char          ce;            /* curtain at the end                            */
} Vac_t;
/* defined before EE_rom: avr-gcc puts the first EEPROM variable at the highest address,
   so the addresses of the version 2 variables stay the same (nothing is lost when updating) */
Vac_t         EEMEM VacE;
EE_t EEMEM EE_rom;
#define Screen_Condition_1   EE.Screen_Condition_1
#define F2                   EE.F2
#define o                    EE.o
#define ch_pass              EE.ch_pass
#define Usere                EE.Usere
#define POL_Eeprom_Variable  EE.POL_Eeprom_Variable
#define Cfg_Ver              EE.Cfg_Ver
#define Ap_Init              EE.Ap_Init

/* SOODEN: installer labels (48 bytes UTF-8 = 24 Persian letters) + icon number, and 12 scenarios.
   These are read/written directly in the EEPROM (only used by the phone commands). */
#define LBL_LEN 48
typedef struct {
    char          st[10];      /* per light: '1' on, '0' off, '2' no change          */
    char          c;           /* curtain: 'O' open, 'C' close, '-' no change         */
    char          tm;          /* timer: 'N' none, 'F' auto-off after, 'D' run after  */
    unsigned int  mins;        /* timer minutes                                       */
    char          name[LBL_LEN + 1];
} Scn_t;
char          EEMEM LblE[12][LBL_LEN + 1];
unsigned char EEMEM LblIcon[12];
Scn_t         EEMEM ScnE[12];

static void ee_clear_tables(void)
{
    unsigned char k;
    for (k = 0; k < 12; k++)
    {
        eeprom_update_byte((uint8_t *)&LblE[k][0], 0);
        eeprom_update_byte(&LblIcon[k], 0xFF);
        eeprom_update_byte((uint8_t *)&ScnE[k].name[0], 0);
    }
    eeprom_update_byte(&VacE.on, 0);
}

static void ee_load(void)
{
    eeprom_read_block(&EE, &EE_rom, sizeof(EE));
    if (EE.Magic1 != 0x50 || EE.Magic2 != 0x0E)
    {   /* first start with this firmware: behave like an erased EEPROM (all 0xFF) */
        memset(&EE, 0xFF, sizeof(EE));
        EE.Magic1 = 0x50; EE.Magic2 = 0x0E;
        ee_clear_tables();
        eeprom_update_block(&EE, &EE_rom, sizeof(EE));
    }
    memcpy(&EE_shadow, &EE, sizeof(EE));
}

static void ee_sync(void)
{
    unsigned int k;
    unsigned char *a = (unsigned char *)&EE, *b = (unsigned char *)&EE_shadow;
    for (k = 0; k < sizeof(EE); k++)
        if (a[k] != b[k]) { eeprom_update_byte((uint8_t *)&EE_rom + k, a[k]); b[k] = a[k]; }
}

//---------------------------Function USART----------------------------------


    ISR(USART0_RX_vect)
     {
         data[i] = UDR0;

         i++;

         data[i] =0;

         if(i >= 250) i =0;
     }


//---------------------------Function TIMER0 25 ms----------------------------------


volatile unsigned int Sleep_Countr =0 , Screen_Countr_1 =0 , Alarm_Time =0 , Number_Countr =1;   /* SOODEN: shared with TIMER0 interrupt */ 
 

  void TIMER0_ON  (void)
      {      
          ASSR=0<<AS0;
          TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (1<<CS01) | (1<<CS00);
          TCNT0=0x3D;
          OCR0=0x00;
      }


  void TIMER0_OFF (void)    
      {      
          ASSR=0<<AS0;
          TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (0<<CS02) | (0<<CS01) | (0<<CS00);
          TCNT0=0x3D;
          OCR0=0x00;
      }


    ISR(TIMER0_OVF_vect)
     {
          TCNT0 = 0x3D;

          if(Sleep_Countr < 60000) Sleep_Countr ++;                          // Sleep (SOODEN: no wrap, timer now runs while asleep)
          Min_Acc += 195; if(Min_Acc >= 468750UL) Min_Acc -= 468750UL , Min_Flag ++;   // SOODEN: exact minutes (195 counts x 128 us per interrupt)
          if(Exit_Ticks) { Sleep_Countr = 0; if(--Exit_Ticks == 0) Exit_Due = 1; }   // SOODEN: Exit countdown

          if(Screen_Countr_1 >= 1) Sleep_Countr =0 , Screen_Countr_1 ++;     // Screen

          if(Number_Countr >= 1)   Sleep_Countr =0 , Number_Countr ++;       // Number

          if(Alarm_Time >= 1)      Sleep_Countr =0 , Alarm_Time ++;          // Alarm
     }


//---------------------------Function  Main----------------------------------


int main(void)
 {

 unsigned char               Screen_Set_1 =0 , L =1;

 unsigned int      chek =0 , time_chek =5000;


 delay_ms(300);


    DDRA  = 0b11111111;
    PORTA = 0b10101010;

    DDRB  = 0b11111101;
    PORTB = 0b01100110;

    DDRC  = 0b11101111;
    PORTC = 0b10111010;

    DDRD  = 0b11111011;
    PORTD = 0b10100010;

    DDRE  = 0b11000010;
    PORTE = 0b11111100;

    DDRF  = 0b11111111;
    PORTF = 0b10011010;

    DDRG  = 0b11111111;
    PORTG = 0b00010010;

 ee_load();      /* SOODEN: read the EEPROM variables into RAM */

 if(o)
  {

      ch_pass[0]='C' , ch_pass[1]='1' , ch_pass[2]='2' , ch_pass[3]='3' , ch_pass[4]='4';

      delay_ms(10);

      for( j = 0 ; j < POL_j ; j++) POL_Eeprom_Variable[j] = POL_Variable[j] , delay_ms(5);

      for( j = 0 ; j < 20 ; j++) Usere[j] ='\0';

      Screen_Condition_1 =0 , delay_ms(5);

      o =0 , F2 =0;
  }

    ch_pass[0]='C';

 // SOODEN: rewrite the key configuration once after flashing this version
 if(Cfg_Ver != 2)
  {
      for( j = 0 ; j < POL_j ; j++) POL_Eeprom_Variable[j] = POL_Variable[j] , delay_ms(5);
      Cfg_Ver = 2 , delay_ms(5);
  }


 if(Red_D) { Red_D =! Red_D ; Led_D ; Dlete_Senario =1;}  


 //---------------------------USART------------------------------------------


        // USART0 initialization
        // Communication Parameters: 8 Data, 1 Stop, No Parity
        // USART0 Receiver: On
        // USART0 Transmitter: On
        // USART0 Mode: Asynchronous
        // USART0 Baud Rate: 9600
        UCSR0A=(0<<RXC0) | (0<<TXC0) | (0<<UDRE0) | (0<<FE0) | (0<<DOR0) | (0<<UPE0) | (0<<U2X0) | (0<<MPCM0);
        UCSR0B=(1<<RXCIE0) | (0<<TXCIE0) | (0<<UDRIE0) | (1<<RXEN0) | (1<<TXEN0) | (0<<UCSZ02) | (0<<RXB80) | (0<<TXB80);
        UCSR0C=(0<<UMSEL0) | (0<<UPM01) | (0<<UPM00) | (0<<USBS0) | (1<<UCSZ01) | (1<<UCSZ00) | (0<<UCPOL0);
        UBRR0H=0x00;
        UBRR0L=0x33;

        // USART1 initialization
        // USART1 disabled
        UCSR1B=(0<<RXCIE1) | (0<<TXCIE1) | (0<<UDRIE1) | (0<<RXEN1) | (0<<TXEN1) | (0<<UCSZ12) | (0<<RXB81) | (0<<TXB81);


 //---------------------------TIMER------------------------------------------


        // Timer/Counter 0 initialization
        // Clock source: System Clock
        // Clock value: 7.813 kHz
        // Mode: Normal top=0xFF
        // OC0 output: Disconnected
        // Timer Period: 24.96 ms
        ASSR=0<<AS0;
        TCCR0=(0<<WGM00) | (0<<COM01) | (0<<COM00) | (0<<WGM01) | (1<<CS02) | (1<<CS01) | (1<<CS00);
        TCNT0=0x3D;
        OCR0=0x00;

        // Timer(s)/Counter(s) Interrupt(s) initialization
        TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (1<<TOIE0);
        ETIMSK=(0<<TICIE3) | (0<<OCIE3A) | (0<<OCIE3B) | (0<<TOIE3) | (0<<OCIE3C) | (0<<OCIE1C);


 //-------------------------------------------------------------------------------------------------------


     for( j = 0 ; j < 17 ; j++) Mac_Ip[j] ='\0';

     for( j = 0 ; j < 16 ; j++) Static_Ip[j] ='\0';

     for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';


     w[0] =0X00 , w[1] =0X00;

     p1[0] =0X00 , p1[1] =0X00 , p1[2] =0X00 , p1[3] ='0' , p1[4] =0X00 , p1[5] =0X00;


     Data_Clean();

     sei();
     
 while(1)
  {
      ee_sync();  /* SOODEN: save changed EEPROM variables */

      Scn_Tick ();   /* SOODEN: scenario timers */
      if(Exit_Due) Exit_Due = 0 , Exit_Run ();   /* SOODEN: Exit countdown finished */

      if(Sleep)
        {

            White (0);
            
            Data_Clean();

            while(Sleep_Countr >= 600)
                {
                    if(Touch || Touch_W || (Red_D && Touch_D))
                        {
                            White (0);

                            if(Red_D) Alarm (1);

                            Sleep_Countr =0 , L =1;
                        }

                    if(Scn_Minutes ())        /* SOODEN: a scenario timer finished: wake up and run it */
                        {
                            White (1);
                            if(Red_D) Alarm (1);
                            Sleep_Countr =0 , L =1;
                        }

                    if(Touch_RF_Sleep || strstr(data , "IPD") || strstr(data , "CONNECT"))
                        {
                            White (1);

                            if(Red_D) Alarm (1);

                            Sleep_Countr =0 , L =1;
                        }


                    while(Alarm_On ==1 && Red_D && Input_Sensur)
                     {
                        if(chek >= time_chek)
                         {
                            White (0);

                            Alarm (4);

                            Sleep_Countr =0 , chek =0 , Alarm_Time =1 , Alarm_On ++;
                         }

                         chek++;
                     }
                        chek=0;

                }

            TIMER0_ON();
        }

      if(Touch && L)
        {
            delay_ms(15);
            
            Data_connected[4] ='U';
            
            if(Touch1)  { Led1;  w[0] ^=0X80 , Send_Fead_Back (1); }

            if(Touch2)  { Led2;  w[0] ^=0X40 , Send_Fead_Back (1); }

            if(Touch3)  { Led3;  w[0] ^=0X20 , Send_Fead_Back (1); }

            if(Touch4)  { Led4;  w[0] ^=0X10 , Send_Fead_Back (1); }

            if(Touch5)  { Led5;  w[0] ^=0X08 , Send_Fead_Back (1); }

            if(Touch6)  { Led6;  w[0] ^=0X04 , Send_Fead_Back (1); }

            if(Touch7)  { Led7;  w[0] ^=0X02 , Send_Fead_Back (1); }

            if(Touch8)  { Led8;  w[0] ^=0X01 , Send_Fead_Back (1); }

            if(Touch9)  { Led9;  w[1] ^=0X80 , Send_Fead_Back (1); }

            if(Touch10) { Led10; w[1] ^=0X40 , Send_Fead_Back (1); }

            if(Touch11) Screen (1);      // SOODEN: key 11 = curtain open


            if(Touch12) Screen (2);      // SOODEN: key 12 = curtain close



        //---------------------------Screen----------------------------------


            // SOODEN: pad 19 (Touch13) = keypad digit 5, handled in Alarm(3)

            // SOODEN: pad 20 (Touch14) = keypad digit 6, handled in Alarm(3)


        //---------------------------Senario----------------------------------


            if(Touch_R) Send_Event ('E') , Scenario_R;     // SOODEN: tell the phones first (Exit waits 15 s)


            if(Touch_C) Send_Event ('L') , Scenario_C;


            if(Touch_L) Scenario_L;


        //---------------------------Alarm_Touch----------------------------------


            if(Touch_D)             Alarm (1) , Number_Countr =1;

            if(Touch_P && !Red_D)   Alarm (2) , Number_Countr =1;

            if(Number)              Alarm (3) , Number_Countr =1;


        //---------------------------RF_Touch------------------------------------


            if(Touch_Learn_ON)    { if(!LLearn)  Led_Learn_ON;    else Led_Learn_OFF; }


            if(Touch_Format_ON)   { if(!LFormat) Led_Format_ON;   else Led_Format_OFF; }


        //---------------------------WiFi_Touch----------------------------------


            if(Touch_W) WiFi(0);

            if(Touch_F) WiFi(9);      // SOODEN: long-press Master = reset panel wifi to sooden / default password


        //------------------------------------------------------------------

            L =0 , Sleep_Countr =0;
        }

      if(!Touch && !L)    L =1;


  //---------------------------Screen--------------------------------

                                                                  
          if(Screen_Countr_1 >= Screen_Condition_Countr_1)   
           {
                if(Red_Par_2 && Screen_Condition_1 <  9) Screen_Condition_1 ++;
                 
                if(Red_Par_1 && Screen_Condition_1 >= 1) Screen_Condition_1 --;

                if(Screen_Condition_1 == 0)  p1[3] ='0' , Screen_Set_1 =1; 
                if(Screen_Condition_1 == 1)  p1[3] ='1'; 
                if(Screen_Condition_1 == 2)  p1[3] ='2'; 
                if(Screen_Condition_1 == 3)  p1[3] ='3'; 
                if(Screen_Condition_1 == 4)  p1[3] ='4'; 
                if(Screen_Condition_1 == 5)  p1[3] ='5'; 
                if(Screen_Condition_1 == 6)  p1[3] ='6'; 
                if(Screen_Condition_1 == 7)  p1[3] ='7'; 
                if(Screen_Condition_1 == 8)  p1[3] ='8'; 
                if(Screen_Condition_1 == 9)  p1[3] ='9' , Screen_Set_1 =1; 
                
                Screen_Condition_Countr_1 += Timer_Screen;   
           }

          if(Screen_Set_1) Screen_Set_1 =0 , Screen (3);


  //---------------------------Alarm----------------------------------


      if(Alarm_On ==0 && Red_D && Alarm_Time >= 1600)
       {
            Alarm_Time =0 , Alarm_On ++ , Dlete_Senario =1;
            
            Alarm_Buzer , delay_ms(30) , Alarm_Buzer;
       }

       while(Alarm_On ==1 && Red_D && Input_Sensur)
        {
            if(chek >= time_chek)
             {
                Alarm (4);

                Sleep_Countr =0 , chek =0 , Alarm_Time =1 , Alarm_On ++;
             }

             chek++;
        }
        chek=0;

       if(Alarm_On ==2 && Red_D && Alarm_Time >= 1200)
        {
            Alarm (4);

            Alarm_Buzer;

            Sleep_Countr =0 , Alarm_Time =1 , Alarm_On ++;
        }

       if(Alarm_On ==3 && Red_D && Alarm_Time >= 12000)
        {
            Alarm_Buzer;

            Sleep_Countr =0 , Alarm_Time =0 , Alarm_On =1;

            Alarm_Cunter++;

            if(Alarm_Cunter >= 3) Led_D , Dlete_Senario =0;

            Alarm (5);
        }


      if(Number_Countr >= 400)
       {
            Alarm (5);
            
            Number_Countr =0;
       }


  //---------------------------WiFi-----------------------------------
          

      if(strstr(data , "WIFI GOT IP"))  Sleep_Countr =0 , WiFi(1);

      if(Read_Ip < 2)                   Sleep_Countr =0 , WiFi(2);

      if(strstr(data , "FAIL"))         Sleep_Countr =0 , WiFi(3);

      if(strstr(data , "0,CONNECT"))    Id_S =0 , Sleep_Countr =0 , Conn[0] =1 , Data_Clean();
      if(strstr(data , "1,CONNECT"))    Id_S =1 , Sleep_Countr =0 , Conn[1] =1 , Data_Clean();
      if(strstr(data , "2,CONNECT"))    Id_S =2 , Sleep_Countr =0 , Conn[2] =1 , Data_Clean();

      if(strstr(data , "+IPD,0"))       Id_S =0 , Sleep_Countr =0 , WiFi(4) , Data_Clean();
      if(strstr(data , "+IPD,1"))       Id_S =1 , Sleep_Countr =0 , WiFi(4) , Data_Clean();
      if(strstr(data , "+IPD,2"))       Id_S =2 , Sleep_Countr =0 , WiFi(4) , Data_Clean();

      if(strstr(data , "0,CLOSED"))     Sleep_Countr =0 , Conn[0] =0 , Data_Clean();
      if(strstr(data , "1,CLOSED"))     Sleep_Countr =0 , Conn[1] =0 , Data_Clean();
      if(strstr(data , "2,CLOSED"))     Sleep_Countr =0 , Conn[2] =0 , Data_Clean();
      // SOODEN: the ESP restarted on its own (e.g. supply dip when many relays switch): restart the server
      if(strstr(data , "ready") && !strstr(data , "+IPD") && Wifi_ON)  Conn[0] =0 , Conn[1] =0 , Conn[2] =0 , Data_Clean() , delay_ms(500) , Wifi_Start();
  }

 }


            
//---------------------------Function----------------------------------



    void White (char Typ)
     {
        if(!Typ)
         {
             White_L , White_R ; delay_ms(100);

            if(!Red_Par_1) White_Par_1 ; if(!Red_Par_2) White_Par_2 ; delay_ms(100);

            if(!Red11) White11 ; if(!Red12) White12 ; delay_ms(100);

            if(!Red9 ) White9  ; if(!Red10) White10 ; delay_ms(100);

            if(!Red7 ) White7  ; if(!Red8 ) White8  ; delay_ms(100); 

            if(!Red5 ) White5  ; if(!Red6 ) White6  ; delay_ms(100); 

            if(!Red3 ) White3  ; if(!Red4 ) White4  ; delay_ms(100); 

             White1 , White2 ; delay_ms(100);           

            if(!Red_D) White_D ; White_P ; delay_ms(100);

             Led_N_OFF;
         }

        if(Typ)
         {
             White_L , White_R;

            if(!Red_Par_1) White_Par_1 ; if(!Red_Par_2) White_Par_2;

            if(!Red11) White11 ; if(!Red12) White12;

            if(!Red9 ) White9  ; if(!Red10) White10;

            if(!Red7 ) White7  ; if(!Red8 ) White8; 

            if(!Red5 ) White5  ; if(!Red6 ) White6; 

            if(!Red3 ) White3  ; if(!Red4 ) White4; 

             White1 , White2;           

            if(!Red_D) White_D ; White_P;

             Led_N_OFF;
         }
     }


        /*
            void Scenario_S (void)
             {
                unsigned char   DY =0;
                
                cli();

                Led_S;

                if(Red1 ) DY =1 , Led1; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red2 ) DY =1 , Led2; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red3 ) DY =1 , Led3; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red4 ) DY =1 , Led4; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red5 ) DY =1 , Led5;                

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red6 ) DY =1 , Led6; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red7 ) DY =1 , Led7; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red8 ) DY =1 , Led8; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red9 ) DY =1 , Led9; 

                if(DY   ) DY =0 , delay_ms(100); 

                if(Red10) DY =1 , Led10; 


                Sleep_POL;


                if(Connected_0) Send_Data (0 , 22);
                
                if(Connected_1) delay_ms(100) , Send_Data (1 , 22);

                sei();
             }
        */


    void Scenario_M (void)
     {  
        unsigned char   DY =0;

        cli();

        if(Led_M)
         {
             if(!Red1 ) DY =1 , Led1; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red2 ) DY =1 , Led2; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red3 ) DY =1 , Led3; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red4 ) DY =1 , Led4; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red5 ) DY =1 , Led5;                

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red6 ) DY =1 , Led6; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red7 ) DY =1 , Led7; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red8 ) DY =1 , Led8; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red9 ) DY =1 , Led9; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red10) DY =1 , Led10; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red11) DY =1 , Led11; 

             if(DY    ) DY =0 , delay_ms(100); 

             if(!Red12) DY =1 , Led12; 

             w[0] =0XFF , w[1] =0XC0;
         }

        else
         {
            Led12;
            
            delay_ms(100);
            
            Led11;
            
            delay_ms(100);
            
            Led10;
            
            delay_ms(100);
            
            Led9;
            
            delay_ms(100); 

            Led8;
            
            delay_ms(100);
            
            Led7;
            
            delay_ms(100); 

            Led6;
            
            delay_ms(100);
            
            Led5;
            
            delay_ms(100);                

            Led4;
            
            delay_ms(100);
            
            Led3;
            
            delay_ms(100); 

            Led2;
            
            delay_ms(100);
            
            Led1; 

            w[0] =0X00 , w[1] =0X00;
         }


        Send_Fead_Back (1);

        sei();
     }


    /* SOODEN: Exit no longer blocks the panel for 15 s (reception was off the whole time).
       Scenario_E() switches the Exit LED on and starts a 15 s countdown in TIMER0;
       Exit_Run() does the original switch-off when the countdown ends. */
    void Scenario_E (void)
     {
        if(Exit_Ticks) return;           /* already counting */
        Led_R;                           /* Exit LED on      */
        Exit_Ticks = 600;                /* 600 x 25 ms = 15 s */
     }
    static void Exit_Run (void)
     {
        unsigned char   DY =0;
        cli();
        Led_R;                           /* Exit LED off     */

        if(Red1 ) DY =1 , Led1; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red2 ) DY =1 , Led2; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red3 ) DY =1 , Led3; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red4 ) DY =1 , Led4; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red5 ) DY =1 , Led5;                

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red6 ) DY =1 , Led6; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red7 ) DY =1 , Led7; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red8 ) DY =1 , Led8; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red9 ) DY =1 , Led9; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red10) DY =1 , Led10; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red11) DY =1 , Led11; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red12) DY =1 , Led12; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red_Par_1) DY =1 , Led_Par_1; 

        if(DY   ) DY =0 , delay_ms(100); 

        if(Red_Par_2) Led_Par_2; 


        w[0] =0X00 , w[1] =0X00;
        
        Send_Fead_Back (1);
        

        delay_ms(100);

        Screen (4);

        sei();
     }


            
//---------------------------Function Screen----------------------------------


     
    void Screen (char Par)
     {
        static int   Start_number =0 , Start_Countr_Open =0 , Start_Countr_Close =0;


        cli();
        
        if(Par == 1)       //OPEN_Screen_1
         {
            if(Red_Par_2)
              { 
                  Led_Par_2; 
                  
                  Start_Countr_Close = Screen_Condition_Countr_1 - Screen_Countr_1;

                  Start_Countr_Open  = Timer_Screen - Start_Countr_Close;

                  Screen_Countr_1 =0 , p1[4] ='S' , Start_number =2; 
              }
            
             else 
              {                 
                  Led_Par_1;

                  if(!Red_Par_1)
                    {                           
                        Start_Countr_Open = Screen_Condition_Countr_1 - Screen_Countr_1;

                        Start_Countr_Close = Timer_Screen - Start_Countr_Open;

                        Screen_Countr_1 =0 , p1[4] ='S' , Start_number =1; 
                    }
                 
                  if(Red_Par_1 && Start_number == 0)
                    {
                        Screen_Condition_Countr_1 = Timer_Screen;

                        p1[4] ='O' , Screen_Countr_1 =1; 
                    }
                 
                  if(Red_Par_1 && Start_number == 1)
                    {
                        Screen_Condition_Countr_1 = Start_Countr_Open;

                        p1[4] ='O' , Screen_Countr_1 =1; 
                    }
                 
                  if(Red_Par_1 && Start_number == 2)
                    {
                        Screen_Condition_Countr_1 = Start_Countr_Open;

                        Screen_Condition_1 ++ , p1[4] ='O' , Screen_Countr_1 =1; 
                    }
              }
         }


        if(Par == 2)       //CLOSE_Screen_1
         {
            if(Red_Par_1)
              {                               
                  Led_Par_1; 
                  
                  Start_Countr_Open  = Screen_Condition_Countr_1 - Screen_Countr_1;

                  Start_Countr_Close = Timer_Screen - Start_Countr_Open;

                  Screen_Countr_1 =0 , p1[4] ='S' , Start_number =1; 
              }
            
             else
              {                       
                  Led_Par_2;

                  if(!Red_Par_2)
                    {                           
                        Start_Countr_Close = Screen_Condition_Countr_1 - Screen_Countr_1;

                        Start_Countr_Open  = Timer_Screen - Start_Countr_Close;

                        Screen_Countr_1 =0 , p1[4] ='S' , Start_number =2; 
                    }
                 
                  if(Red_Par_2 && Start_number == 0)
                    {
                        Screen_Condition_Countr_1 = Timer_Screen;

                        p1[4] ='C' , Screen_Countr_1 =1; 
                    }
                 
                  if(Red_Par_2 && Start_number == 1)
                    {
                        Screen_Condition_Countr_1 = Start_Countr_Close;

                        Screen_Condition_1 -- , p1[4] ='C' , Screen_Countr_1 =1; 
                    }
                 
                  if(Red_Par_2 && Start_number == 2)
                    {
                        Screen_Condition_Countr_1 = Start_Countr_Close;

                        p1[4] ='C' , Screen_Countr_1 =1; 
                    }
              }
         }


        if(Par == 3)       //STOP_Screen_1
         {
            p1[4] ='S';

            Screen_Countr_1 =0 , Start_number =0;
            
            if(Red_Par_1) Led_Par_1;
            
            if(Red_Par_2) Led_Par_2;
         }


        p1[0] ='p' , p1[1] ='1' , p1[2] ='-';            

        Data_connected[4] ='V';
        
        Send_Fead_Back (2);

        sei();
     }


            
//---------------------------Function Alarm----------------------------------



    void Alarm (char Activ)
     {
        cli();

        
        for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';


        sprintf(Data_connected , "@X1Z1of");
        
        if(Activ == 1)       //Start Active/RActive
         {
            Led_N_ON;
               
            if(Red_P) Led_P;

            for(j =0 ; j < 5 ; j++) pass[j] = '0';

            num =0 , Number =1;
         }

        if(Activ == 2)       //Start change Password
         {
            Led_N_ON;

            for(j =0 ; j < 5 ; j++) pass[j] = '0';
            
            pass[0] = 'C';
            
            num =0 , Number =1;
               
            if(Red_P) Number =0;

            Led_P;
         }

        if(Activ == 3)       //Bottun Number
         {
            if(Touch_1 && num <= 3) num++ , pass[num] = '1';

            if(Touch_2 && num <= 3) num++ , pass[num] = '2';

            if(Touch_3 && num <= 3) num++ , pass[num] = '3';

            if(Touch_4 && num <= 3) num++ , pass[num] = '4';

            if(Touch13 && num <= 3) num++ , pass[num] = '5';   // SOODEN: digit 5 = pad 19

            if(Touch14 && num <= 3) num++ , pass[num] = '6';   // SOODEN: digit 6 = pad 20

         }

        if(Activ == 4)       //Clean Number
         {
            Led_N_ON;
               
            for(j =0 ; j < 5 ; j++) pass[j] = '0';

            num =0 , Number =1;
         }

        if(Activ == 5)       //Stop check Password
         {
            if(Red_P) Led_P;

            Led_N_OFF;
               
            for(j =0 ; j < 5 ; j++) pass[j] = '0';

            num =0 , Number =0;
         }

        if(Activ == 6)       //For WiFi Active/RActive
         {
            Led_D;
                
            Alarm_Time =0 , Alarm_On =0 , Alarm_Cunter =0 , Dlete_Senario =0;
                
            if(Red_D) Alarm_Time =1;  

            if(Buzer) Alarm_Buzer;
             

            Led_N_OFF;

            for(j = 1 ; j < 5 ; j++) pass[j] = '0';
            
            Number =0 , num =0;
         }

        if(Activ == 7) Red =1;     //For WiFi FeadBack

         
        if(num == 4)         //Check Password For --> crhange Password || Active/RActive
         {
            if(ch_pass[0] == pass[0])
             {
                for(j = 1 ; j < 5 ; j++) ch_pass[j] = pass[j];

                Led_P;
             }

            if(pass[0] == '0' && ch_pass[1] == pass[1] && ch_pass[2] == pass[2] && ch_pass[3] == pass[3] && ch_pass[4] == pass[4])
             {
                Led_D;
                
                Alarm_Time =0 , Alarm_On =0 , Alarm_Cunter =0 , Dlete_Senario =0;
                
                if(Red_D) Alarm_Time =1;  

                if(Buzer) Alarm_Buzer;
             }

            Led_N_OFF;

            for(j = 1 ; j < 5 ; j++) pass[j] = '0';
            
            Number =0 , num =0;
         }

                    
        // SOODEN: alarm state goes to every connected phone
        if(Red == 1)
         {
            if(Red_D) Data_connected[6] ='n';
            Broadcast (7);
         }


        Red =0;

        sei();
     }


            
//---------------------------Function WiFi----------------------------------



    void WiFi (char Part)
     {
        unsigned char  *ret , s =0 , r =0 , x[14] , Bit =0 , StartBytedata =0 , StartBitdata =0 , StartBytew =0 , StartBitw =0;         
        unsigned char     DY =0;        


       for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';


        if(Part == 0)       //Wifi ON/OFF
         {
            Wifi_ON =! Wifi_ON , Conn[0] =0 , Conn[1] =0 , Conn[2] =0;

            cli();
            
            if(Wifi_ON) Wifi_Start ();
         }


        if(Part == 1)       //Check IP
         {
            delay_ms(2000);

            cli();

            Data_Clean();

            sprintf(str , "AT+CIFSR%c" , 13);

            puts(str);

            Data_Clean();
            
            sei();

            Read_Ip =1;
         }


        if(Part == 2)       //Writ IP
         {
            if(Read_Ip == 0 && strstr(data , "STAMAC"))
             {
                delay_ms(300);

                cli();

                for( j = 0 ; j < 17 ; j++) Mac_Ip[j] =' ';

                ret = strstr(data , "STAMAC");

                s = ret - data;
                 
                s = s + 7;
                
                for(j = 0 ; j < 17 ; j++) { s++; if(data[s] == '"') break; Mac_Ip[j] = data[s]; }

                Read_Ip =1;
             }

            if(Read_Ip == 1 && strstr(data , "STAIP"))
             {
                delay_ms(300);

                cli();

                if(strstr(data , "0.0.0.0"))             
                 {                 
                    sprintf(Data_connected , "@M_S=Repeat\n"); 
                            
                         Reply (12);

                    for( j = 0 ; j < 16 ; j++)  Static_Ip[j] =' '; 
                 }
                
                else
                 {
                    for( j = 0 ; j < 16 ; j++) Static_Ip[j] =' ';

                    ret = strstr(data , "STAIP");

                    s = ret - data;
                     
                    s = s + 6;
                    
                    Data_connected[0] ='@' , Data_connected[1] ='M' , Data_connected[2] ='_' , Data_connected[3] ='S' , Data_connected[4] ='=' ;

                    r =4;

                    for(j = 0 ; j < 16 ; j++)
                     {
                        s++ , r++;
                        
                        if(data[s] == '"') break;
                        
                        Static_Ip[j] = data[s];
                        
                        Data_connected[r] = Static_Ip[j];
                     }
                    
                         Reply (21);
                 }

                Data_Clean();

                Read_Ip =2;                 
             }                                 
         }


        if(Part == 3)       //Fail IP
         {
             cli();                             

             sprintf(Data_connected , "@M_S=Error\n"); 
                
                  Reply (11);
         }


        if(Part == 4)       //+IPD
         {
             Wait_Payload ();   /* SOODEN: was delay_ms(60): long labels/scenarios were cut off */

             cli();

         //---------------------------Config-------------------------------------


             if(strstr(data , "@M_IP"))   Part =5;             

             if(strstr(data , "@M_F_C"))  Part =5;             

             if(strstr(data , "@M_F_T"))  Part =5;             


         //---------------------------POL-------------------------------------


             if(strstr(data , "@TA1U"))  Data_connected[4] ='U' , Send_Fead_Back (1);             

             if(strstr(data , "&TA1U"))  Part =6;             


         //---------------------------Scenario--------------------------------


             if(strstr(data , "!"))  Part =10;


         //---------------------------Screen----------------------------------


             if(strstr(data , "@TA1V"))  Data_connected[4] ='V' , Send_Fead_Back (3);             

             if(strstr(data , "&TA1Vp1O")) Screen (1);       //OPEN_Screen_1       
             if(strstr(data , "&TA1Vp1C")) Screen (2);      //CLOSE_Screen_1       
             if(strstr(data , "&TA1Vp1S")) Screen (3);      //STOPE_Screen_1       


         //---------------------------Alarm--------------------------------


             // SOODEN: arming / disarming from the app needs the code: &X1Z1#1234
             if(strstr(data , "&X1Z1"))
              {
                 for(s = 0 ; s < 245 ; s++) if(data[s] == '&' && data[s+1] == 'X') break;
                 s = s + 5;
                 if(data[s] == '#' && data[s+1] == ch_pass[1] && data[s+2] == ch_pass[2] && data[s+3] == ch_pass[3] && data[s+4] == ch_pass[4])
                      Alarm (6);
                 else Alarm (7);           // wrong / missing code: just report the state
              }

             // SOODEN: new alarm code from the app (only when the alarm is off): &X1P#1234
             if(strstr(data , "&X1P#"))
              {
                 for(s = 0 ; s < 245 ; s++) if(data[s] == '&' && data[s+1] == 'X' && data[s+2] == '1' && data[s+3] == 'P') break;
                 s = s + 5;
                 if(!Red_D && data[s] >= '1' && data[s] <= '6' && data[s+1] >= '1' && data[s+1] <= '6'
                           && data[s+2] >= '1' && data[s+2] <= '6' && data[s+3] >= '1' && data[s+3] <= '6')
                  {
                     ch_pass[1] = data[s]   , delay_ms(5);
                     ch_pass[2] = data[s+1] , delay_ms(5);
                     ch_pass[3] = data[s+2] , delay_ms(5);
                     ch_pass[4] = data[s+3] , delay_ms(5);
                     sprintf(Data_connected , "$PASS=ok$");
                  }
                 else sprintf(Data_connected , "$PASS=no$");
                 Reply (9);
                 Data_Clean();
              }

             // SOODEN: Master and Exit from the app run exactly like the panel keys
             if(strstr(data , "&SCM"))  Data_Clean() , Scenario_M ();
             if(strstr(data , "&SCE"))  Data_Clean() , Send_Event ('E') , Scenario_E ();

             // SOODEN: panel model
             if(strstr(data , "@M_MDL"))
              {
                 sprintf(Data_connected , "$MDL=RF12-L10P1A1E1$");
                 Reply (20);
                 Data_Clean();
              }

             // SOODEN: installer label, write: Lbl#03#16~text#  (key 1..12, icon number optional, text up to 48 bytes)
             if(strstr(data , "Lbl#"))
              {
                 unsigned char n , k , ic = 0xFF;
                 for(s = 0 ; s < 240 ; s++) if(data[s] == 'L' && data[s+1] == 'b' && data[s+2] == 'l' && data[s+3] == '#') break;
                 s = s + 4;
                 n = (data[s] - '0') * 10 + (data[s+1] - '0');
                 if(n >= 1 && n <= 12 && data[s+2] == '#')
                  {
                     s = s + 3;
                     if(data[s] >= '0' && data[s] <= '9' && data[s+1] >= '0' && data[s+1] <= '9' && data[s+2] == '~')
                         ic = (data[s] - '0') * 10 + (data[s+1] - '0') , s = s + 3;
                     for(k = 0 ; k < LBL_LEN ; k++)
                      {
                         if(data[s+k] == '#' || data[s+k] == 0) break;
                         eeprom_update_byte((uint8_t *)&LblE[n-1][k] , data[s+k]);
                      }
                     eeprom_update_byte((uint8_t *)&LblE[n-1][k] , 0);
                     eeprom_update_byte(&LblIcon[n-1] , ic);
                     sprintf((char *)Data_connected , "ok\n");
                     Reply (3);
                  }
                 Data_Clean();
              }

             // SOODEN: installer label, read: @M_LBL#03  ->  $L03#16~text$
             if(strstr(data , "@M_LBL#"))
              {
                 unsigned char n , k , q , ic , ch;
                 for(s = 0 ; s < 240 ; s++) if(data[s] == '@' && data[s+1] == 'M' && data[s+2] == '_' && data[s+3] == 'L') break;
                 s = s + 7;
                 n = (data[s] - '0') * 10 + (data[s+1] - '0');
                 if(n >= 1 && n <= 12)
                  {
                     Data_connected[0] = '$' , Data_connected[1] = 'L';
                     Data_connected[2] = data[s] , Data_connected[3] = data[s+1] , Data_connected[4] = '#';
                     q = 5;
                     ic = eeprom_read_byte(&LblIcon[n-1]);
                     if(ic < 100) Data_connected[q++] = '0' + ic / 10 , Data_connected[q++] = '0' + ic % 10 , Data_connected[q++] = '~';
                     for(k = 0 ; k < LBL_LEN ; k++)
                      {
                         ch = eeprom_read_byte((uint8_t *)&LblE[n-1][k]);
                         if(ch == 0 || ch == 0xFF) break;
                         Data_connected[q++] = ch;
                      }
                     Data_connected[q++] = '$';
                     Reply (q);
                  }
                 Data_Clean();
              }

             // SOODEN: scenario write:
             //         Scn#03#1102222220OF0090#name#  = 10 states ('1' on '0' off '2' no change), curtain O/C/-, timer N/F/D, 4-digit minutes
             if(strstr(data , "Scn#"))
              {
                 unsigned char n , k;
                 for(s = 0 ; s < 230 ; s++) if(data[s] == 'S' && data[s+1] == 'c' && data[s+2] == 'n' && data[s+3] == '#') break;
                 s = s + 4;
                 n = (data[s] - '0') * 10 + (data[s+1] - '0');
                 if(n >= 1 && n <= 12 && data[s+2] == '#' && data[s+19] == '#')
                  {
                     unsigned int mins;
                     s = s + 3;
                     for(k = 0 ; k < 10 ; k++) eeprom_update_byte((uint8_t *)&ScnE[n-1].st[k] , data[s+k]);
                     eeprom_update_byte((uint8_t *)&ScnE[n-1].c  , data[s+10]);
                     eeprom_update_byte((uint8_t *)&ScnE[n-1].tm , data[s+11]);
                     mins = (data[s+12]-'0') * 1000 + (data[s+13]-'0') * 100 + (data[s+14]-'0') * 10 + (data[s+15]-'0');
                     eeprom_update_word(&ScnE[n-1].mins , mins);
                     s = s + 17;
                     for(k = 0 ; k < LBL_LEN ; k++)
                      {
                         if(data[s+k] == '#' || data[s+k] == 0) break;
                         eeprom_update_byte((uint8_t *)&ScnE[n-1].name[k] , data[s+k]);
                      }
                     eeprom_update_byte((uint8_t *)&ScnE[n-1].name[k] , 0);
                     if(k == 0) eeprom_update_byte((uint8_t *)&ScnE[n-1].name[0] , '-') , eeprom_update_byte((uint8_t *)&ScnE[n-1].name[1] , 0);
                     sprintf((char *)Data_connected , "ok\n");
                     Reply (3);
                  }
                 Data_Clean();
              }

             // SOODEN: scenario delete: Scd#03
             if(strstr(data , "Scd#"))
              {
                 unsigned char n;
                 for(s = 0 ; s < 240 ; s++) if(data[s] == 'S' && data[s+1] == 'c' && data[s+2] == 'd' && data[s+3] == '#') break;
                 n = (data[s+4] - '0') * 10 + (data[s+5] - '0');
                 if(n >= 1 && n <= 12) eeprom_update_byte((uint8_t *)&ScnE[n-1].name[0] , 0) , Pend[n-1] = 0 , Pend_Due[n-1] = 0;
                 sprintf((char *)Data_connected , "ok\n");
                 Reply (3);
                 Data_Clean();
              }

             // SOODEN: scenario read: @M_SCN#03  ->  $S03#1102222220OF0090#name$   (empty slot: $S03#-$)
             if(strstr(data , "@M_SCN#"))
              {
                 unsigned char n , k , q , ch;
                 unsigned int mins;
                 for(s = 0 ; s < 240 ; s++) if(data[s] == '@' && data[s+1] == 'M' && data[s+2] == '_' && data[s+3] == 'S') break;
                 s = s + 7;
                 n = (data[s] - '0') * 10 + (data[s+1] - '0');
                 if(n >= 1 && n <= 12)
                  {
                     Data_connected[0] = '$' , Data_connected[1] = 'S';
                     Data_connected[2] = data[s] , Data_connected[3] = data[s+1] , Data_connected[4] = '#';
                     q = 5;
                     ch = eeprom_read_byte((uint8_t *)&ScnE[n-1].name[0]);
                     if(ch == 0 || ch == 0xFF) Data_connected[q++] = '-';
                     else
                      {
                         for(k = 0 ; k < 10 ; k++) Data_connected[q++] = eeprom_read_byte((uint8_t *)&ScnE[n-1].st[k]);
                         Data_connected[q++] = eeprom_read_byte((uint8_t *)&ScnE[n-1].c);
                         Data_connected[q++] = eeprom_read_byte((uint8_t *)&ScnE[n-1].tm);
                         mins = eeprom_read_word(&ScnE[n-1].mins);
                         if(mins > 9999) mins = 9999;
                         Data_connected[q++] = '0' + mins / 1000 , Data_connected[q++] = '0' + (mins / 100) % 10;
                         Data_connected[q++] = '0' + (mins / 10) % 10 , Data_connected[q++] = '0' + mins % 10;
                         Data_connected[q++] = '#';
                         for(k = 0 ; k < LBL_LEN ; k++)
                          {
                             ch = eeprom_read_byte((uint8_t *)&ScnE[n-1].name[k]);
                             if(ch == 0 || ch == 0xFF) break;
                             Data_connected[q++] = ch;
                          }
                      }
                     Data_connected[q++] = '$';
                     Reply (q);
                  }
                 Data_Clean();
              }

             // SOODEN: run a scenario: &RUN#03   cancel its timer: &CAN#03   timers left: @M_PND
             if(strstr(data , "&RUN#"))
              {
                 unsigned char n;
                 for(s = 0 ; s < 240 ; s++) if(data[s] == '&' && data[s+1] == 'R' && data[s+2] == 'U' && data[s+3] == 'N') break;
                 n = (data[s+5] - '0') * 10 + (data[s+6] - '0');
                 Data_Clean();
                 if(n >= 1 && n <= 12) Scn_Start (n - 1);
              }
             if(strstr(data , "&CAN#"))
              {
                 unsigned char n;
                 for(s = 0 ; s < 240 ; s++) if(data[s] == '&' && data[s+1] == 'C' && data[s+2] == 'A' && data[s+3] == 'N') break;
                 n = (data[s+5] - '0') * 10 + (data[s+6] - '0');
                 Data_Clean();
                 if(n >= 1 && n <= 12) Pend[n-1] = 0 , Pend_Due[n-1] = 0 , Scn_Report (n - 1);
              }
             if(strstr(data , "@M_PND"))
              {
                 unsigned char n;
                 Data_Clean();
                 for(n = 0 ; n < 12 ; n++) if(Pend[n]) Scn_Report (n);
              }

             // SOODEN: vacation program and panel clock
             if((ret = (unsigned char *)strstr((char *)data , "&CLK#")))  Clk_Set (ret) , Data_Clean();
             if((ret = (unsigned char *)strstr((char *)data , "Vac#")))   Vac_Write (ret) , Data_Clean();
             if(strstr(data , "@M_VAC"))  Data_Clean() , Vac_Read ();

             if(strstr(data , "@X1Z"))  Alarm (7);


         //---------------------------Elevator-----------------------------


             if(strstr(data,"&TL"))     Data_Clean() , Send_Event ('L') , Led_A;


         //---------------------------Chang Password & Wifi Router-----------------------------


             if(strstr(data , ":*AT")) Part =7;

             if(strstr(data , ":#AT")) Part =8;


         //---------------------------Definition Head Line-----------------------------


             if(strstr(data , "Line#")) Part =11;
         }


        if(Part == 5)       //Config
         {
            if(strstr(data , "@M_IP"))
             {
                 Data_Clean();
                
                 s =0;

                 Data_connected[s] = '%' , s++;

                 for( j = 0 ; j < 17 ; j++) Data_connected[s] = Mac_Ip[j] , s++;


                 Data_connected[s] = '+' , s++;


                 for( j = 0 ; j < 16 ; j++) Data_connected[s] = Static_Ip[j] , s++;


                 Data_connected[s] = '+' , s++;


                 for( j = 0 ; j < 20 ; j++) Data_connected[s] = Usere[j] , s++;


                 Data_connected[s] = '%' , s++;
                

                      Reply (s);
             }


            if(strstr(data , "@M_F_C"))
             {
                 Data_Clean();

                 sprintf(Data_connected , "#T");
                            

                      Reply (2);
             }


            if(strstr(data , "@M_F_T"))
             {
                 for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';
                
                 s =0;
                 for( j = 0 ; j < POL_j ; j++) Data_connected[s] = POL_Eeprom_Variable[j] , s++;     //POL PAR


                      Reply (s);
             }
         }


        if(Part == 6)       //POL
         {                
                for(s = 0 ; s < 250 ; s++) { if(data[s] == 'U') break;}
                                
                s++;
                StartBytedata = s; 

                StartBitdata = 0;
                               
                for(j = 0 ; j < KeysCount ; j++)
                 {
                    Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;     
                    w[StartBytew] ^= (Bit << (7 - StartBitw));  


                    x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;     

                    StartBitdata++;
                    if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                    StartBitw++;
                    if(StartBitw == 8) StartBitw =0 , StartBytew++;
                 }
                                    


                if(x[0] == 1) { if(!Red1) Led1 , DY =1; }

                else if (Red1) Led1 , DY =1;
                            

                if(x[1] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red2) Led2 , DY =1;
                 }

                else if(Red2) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led2 , DY =1;
                 }
                            

                if(x[2] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red3) Led3 , DY =1;
                 }

                else if(Red3) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led3 , DY =1;
                 }
                            

                if(x[3] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red4) Led4 , DY =1;
                 }

                else if(Red4) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led4 , DY =1;
                 }
                            

                if(x[4] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red5) Led5 , DY =1;
                 }

                else if(Red5) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led5 , DY =1;
                 }
                            

                if(x[5] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red6) Led6 , DY =1;
                 }

                else if(Red6) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led6 , DY =1;
                 }
                            

                if(x[6] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red7) Led7 , DY =1;
                 }

                else if(Red7) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led7 , DY =1;
                 }
                            

                if(x[7] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red8) Led8 , DY =1;
                 }

                else if(Red8) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led8 , DY =1;
                 }
                            

                if(x[8] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red9) Led9 , DY =1;
                 }

                else if(Red9) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led9 , DY =1;
                 }
                            

                if(x[9] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red10) Led10;
                 }

                else if(Red10) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led10;
                 }
                            

                if(x[10] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red11) Led11;
                 }

                else if(Red11) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led11;
                 }
                            

                if(x[11] == 1)
                 {            
                    if(DY == 1) delay_ms(100) , DY =0;

                    if(!Red12) Led12;
                 }

                else if(Red12) 
                 {            
                    if(DY == 1)delay_ms(100) , DY =0;

                    Led12;
                 }
                            
                Data_connected[4] ='U';
                Send_Fead_Back (1);
         }


        if(Part == 7)       //Chang Password
         {
             delay_ms(200);
                                        
             cli();
            
             for(s = 0 ; s < 250 ; s++) if(data[s] == '*') break;
            
             for(j = 0 ; j < 80  ; j++) { s++ ; if(data[s] == '*') break ; str[j] = data[s]; }
             str[j] = '\r' , str[j+1] = 0;
             if(str[0]=='A' && str[1]=='T' && str[2]=='+' && str[3]=='C' && str[4]=='W' && str[5]=='S' && str[6]=='A' && str[7]=='P' && str[8]=='=') puts(str);     // SOODEN: only "change wifi name/password"

             delay_ms(5000);

             Data_Clean();
         }


        if(Part == 8)       //Wifi Router
         {
             delay_ms(200);
            
             cli();
           
             for(s = 0 ; s < 250 ; s++) if(data[s] == '#') break;
            
             for(j = 0 ; j < 80  ; j++) { s++ ; if(data[s] == '#') break ; str[j] = data[s]; }
             str[j] = '\r' , str[j+1] = 0;
             for(s = 0 ; s < 250 ; s++) if(data[s] == '#') break;
            
             s = s + 10;

             for( j = 0 ; j < 20 ; j++) Usere[j] ='\0';
            
             for(j = 0 ; j < 20  ; j++) { s++ ; if(data[s] == '"') break ; Usere[j] = data[s]; }
             if(str[0]=='A' && str[1]=='T' && str[2]=='+' && str[3]=='C' && str[4]=='W' && str[5]=='J' && str[6]=='A' && str[7]=='P' && str[8]=='=') puts(str);     // SOODEN: only "join router"
            
             delay_ms(300);

             Data_Clean();
         }


        if(Part == 9)       //Remove Password
         {
            cli();

            Led_Remove_Wifi_Pass;

            Data_Clean();

            sprintf(str , "AT+CWSAP=%csooden%c,%csooden123%c,1,3%c" , 34 , 34 , 34 , 34 , 13);   // SOODEN: reset to default, never open

            puts(str);

            delay_ms(1000);

            Led_Remove_Wifi_Pass;

            Data_Clean();
         }


        if(Part == 10)      //Scenario
         {

                if(strstr(data , "!&"))
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == '&') break;}
                                    
                    s++;
                    StartBytedata = s; 

                    StartBitdata = 0;

                    w[0] =0X00 , w[1] =0X00;
                                   
                    for(j = 0 ; j < Scenario_Count ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;     
                        w[StartBytew] |= (Bit << (7 - StartBitw));  


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;     

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }
                                        


                    if(x[0] == 1) { if(!Red1) Led1 , DY =1; }

                    else if (Red1) Led1 , DY =1;
                                

                    if(x[1] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red2) Led2 , DY =1;
                     }

                    else if(Red2) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led2 , DY =1;
                     }
                                

                    if(x[2] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red3) Led3 , DY =1;
                     }

                    else if(Red3) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led3 , DY =1;
                     }
                                

                    if(x[3] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red4) Led4 , DY =1;
                     }

                    else if(Red4) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led4 , DY =1;
                     }
                                

                    if(x[4] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red5) Led5 , DY =1;
                     }

                    else if(Red5) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led5 , DY =1;
                     }
                                

                    if(x[5] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red6) Led6 , DY =1;
                     }

                    else if(Red6) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led6 , DY =1;
                     }
                                

                    if(x[6] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red7) Led7 , DY =1;
                     }

                    else if(Red7) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led7 , DY =1;
                     }
                                

                    if(x[7] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red8) Led8 , DY =1;
                     }

                    else if(Red8) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led8 , DY =1;
                     }
                                

                    if(x[8] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red9) Led9 , DY =1;
                     }

                    else if(Red9) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led9 , DY =1;
                     }
                                

                    if(x[9] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red10) Led10 , DY =1;
                     }

                    else if(Red10) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led10 , DY =1;
                     }
                                

                    if(x[10] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red11) Led11 , DY =1;
                     }

                    else if(Red11) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led11 , DY =1;
                     }
                                

                    if(x[11] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red12) Led12 , DY =1;
                     }

                    else if(Red12) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led12 , DY =1;
                     }


                    if(Red_Par_1)  Screen (1);

                    if(Red_Par_2)  Screen (2);

                    p1[4] ='S';

                    Screen_Countr_1 =0;

                    Screen_Condition_Countr_1 = Timer_Screen;
                                
                    if(x[12] == 1)  Screen (1);
                                
                    if(x[13] == 1)  Screen (2);

                    Data_Clean();
                 }


                if(strstr(data , "!^T"))
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == 'T') break;}
                                    
                    s++;
                    StartBytedata = s; 

                    StartBitdata = 0;

                    w[0] =0X00 , w[1] =0X00;
                                   
                    for(j = 0 ; j < Scenario_Count ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;     
                        w[StartBytew] |= (Bit << (7 - StartBitw));  


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;     

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }
                                        


                    if(x[0] == 1) { if(!Red1) Led1 , DY =1; }

                    else if (Red1) Led1 , DY =1;
                                

                    if(x[1] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red2) Led2 , DY =1;
                     }

                    else if(Red2) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led2 , DY =1;
                     }
                                

                    if(x[2] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red3) Led3 , DY =1;
                     }

                    else if(Red3) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led3 , DY =1;
                     }
                                

                    if(x[3] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red4) Led4 , DY =1;
                     }

                    else if(Red4) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led4 , DY =1;
                     }
                                

                    if(x[4] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red5) Led5 , DY =1;
                     }

                    else if(Red5) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led5 , DY =1;
                     }
                                

                    if(x[5] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red6) Led6 , DY =1;
                     }

                    else if(Red6) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led6 , DY =1;
                     }
                                

                    if(x[6] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red7) Led7 , DY =1;
                     }

                    else if(Red7) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led7 , DY =1;
                     }
                                

                    if(x[7] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red8) Led8 , DY =1;
                     }

                    else if(Red8) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led8 , DY =1;
                     }
                                

                    if(x[8] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red9) Led9 , DY =1;
                     }

                    else if(Red9) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led9 , DY =1;
                     }
                                

                    if(x[9] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red10) Led10 , DY =1;
                     }

                    else if(Red10) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led10 , DY =1;
                     }
                                

                    if(x[10] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red11) Led11 , DY =1;
                     }

                    else if(Red11) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led11 , DY =1;
                     }
                                

                    if(x[11] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red12) Led12 , DY =1;
                     }

                    else if(Red12) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led12 , DY =1;
                     }


                    if(Red_Par_1)  Screen (1);

                    if(Red_Par_2)  Screen (2);

                    p1[4] ='S';

                    Screen_Countr_1 =0;

                    Screen_Condition_Countr_1 = Timer_Screen;
                                
                    if(x[12] == 1)  Screen (1);
                                
                    if(x[13] == 1)  Screen (2);

                    Data_Clean();
                 }


                if(strstr(data , "!~TA1"))
                 {
                    for(s = 0 ; s < 250 ; s++) { if(data[s] == 'A') break;}
                                    
                    s = s + 2;
                    StartBytedata = s; 

                    StartBitdata = 0;

                    w[0] =0X00 , w[1] =0X00;
                                   
                    for(j = 0 ; j < Scenario_Count ; j++)
                     {
                        Bit = (data[StartBytedata] >> (7 - StartBitdata)) & 1 ;     
                        w[StartBytew] |= (Bit << (7 - StartBitw));  


                        x[j] = (w[StartBytew] >> (7 - StartBitw)) & 1 ;     

                        StartBitdata++;
                        if(StartBitdata == 8) StartBitdata =0 , StartBytedata++;

                        StartBitw++;
                        if(StartBitw == 8) StartBitw =0 , StartBytew++;
                     }
                                        


                    if(x[0] == 1) { if(!Red1) Led1 , DY =1; }

                    else if (Red1) Led1 , DY =1;
                                

                    if(x[1] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red2) Led2 , DY =1;
                     }

                    else if(Red2) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led2 , DY =1;
                     }
                                

                    if(x[2] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red3) Led3 , DY =1;
                     }

                    else if(Red3) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led3 , DY =1;
                     }
                                

                    if(x[3] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red4) Led4 , DY =1;
                     }

                    else if(Red4) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led4 , DY =1;
                     }
                                

                    if(x[4] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red5) Led5 , DY =1;
                     }

                    else if(Red5) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led5 , DY =1;
                     }
                                

                    if(x[5] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red6) Led6 , DY =1;
                     }

                    else if(Red6) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led6 , DY =1;
                     }
                                

                    if(x[6] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red7) Led7 , DY =1;
                     }

                    else if(Red7) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led7 , DY =1;
                     }
                                

                    if(x[7] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red8) Led8 , DY =1;
                     }

                    else if(Red8) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led8 , DY =1;
                     }
                                

                    if(x[8] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red9) Led9 , DY =1;
                     }

                    else if(Red9) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led9 , DY =1;
                     }
                                

                    if(x[9] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red10) Led10 , DY =1;
                     }

                    else if(Red10) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led10 , DY =1;
                     }
                                

                    if(x[10] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red11) Led11 , DY =1;
                     }

                    else if(Red11) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led11 , DY =1;
                     }
                                

                    if(x[11] == 1)
                     {            
                        if(DY == 1) delay_ms(100) , DY =0;

                        if(!Red12) Led12 , DY =1;
                     }

                    else if(Red12) 
                     {            
                        if(DY == 1)delay_ms(100) , DY =0;

                        Led12 , DY =1;
                     }


                    if(Red_Par_1)  Screen (1);

                    if(Red_Par_2)  Screen (2);

                    p1[4] ='S';

                    Screen_Countr_1 =0;

                    Screen_Condition_Countr_1 = Timer_Screen;
                                
                    if(x[12] == 1)  Screen (1);
                                
                    if(x[13] == 1)  Screen (2);

                    Data_Clean();
                 }
         }


        if(Part == 11)      //Head Line
         {
             for(s = 0 ; s < 250 ; s++) if(data[s] == '#') break;
            
             for(j = 7 ; j < (KeysCount + 7)  ; j++) { s++ , POL_Eeprom_Variable[j] = data[s] , delay_ms(5); }
             
                        
             sprintf(Data_connected , "ok\n");
                        
             Reply (3);

             delay_ms(10);

             Data_Clean();
         }


        sei();
     }



    /* SOODEN: start the ESP module's access point + TCP server.
       Also called again when the ESP resets by itself (it prints "ready"),
       because the TCP server does not survive an ESP reset. */
    void Wifi_Start  (void)
     {
        cli();
                delay_ms(300);         

                sprintf(str , "AT+CWMODE=3%c" , 13);

                puts(str);

                delay_ms(300);

                Data_Clean();


                // SOODEN: default access point (only once; later changes come from the app)
                if(Ap_Init != 0x5A)
                 {
                    sprintf(str , "AT+CWSAP=%csooden%c,%csooden123%c,1,3%c" , 34 , 34 , 34 , 34 , 13);
                    puts(str);
                    delay_ms(1500);
                    Data_Clean();
                    Ap_Init = 0x5A;
                 }

                sprintf(str , "AT+CIPMUX=1%c" , 13);

                puts(str);

                delay_ms(300);

                Data_Clean();


                sprintf(str , "AT+CIPSERVER=1,6269%c" , 13);

                puts(str);

                delay_ms(300);

                Data_Clean();


                delay_ms(3000);

                sprintf(str , "AT+CIFSR%c" , 13);

                puts(str);

                sei();

                Read_Ip =0;
     }



    /* SOODEN: "+IPD,<id>,<len>:<payload>" - wait (max ~400 ms) until <len> payload bytes are in data[] */
    static void Wait_Payload (void)
     {
        unsigned int t , len , have;
        char *p , *q , *c;
        delay_ms(5);
        for(t = 0 ; t < 400 ; t++)
         {
            p = strstr((char *)data , "+IPD,");
            if(p)
             {
                q = p + 5;
                while(*q && *q != ',') q++;
                if(*q == ',')
                 {
                    len = (unsigned int)atoi(q + 1);
                    c = q + 1;
                    while(*c && *c != ':') c++;
                    if(*c == ':')
                     {
                        have = (unsigned int)(((char *)data + i) - (c + 1));
                        if(have >= len) { delay_ms(2); return; }
                     }
                 }
             }
            delay_ms(1);
         }
     }

    /* ---------------- SOODEN: scenarios ---------------- */
    static unsigned char Light_On (unsigned char k)
     {
        switch(k)
         {
            case 0: return Red1 ? 1 : 0;  case 1: return Red2 ? 1 : 0;  case 2: return Red3 ? 1 : 0;
            case 3: return Red4 ? 1 : 0;  case 4: return Red5 ? 1 : 0;  case 5: return Red6 ? 1 : 0;
            case 6: return Red7 ? 1 : 0;  case 7: return Red8 ? 1 : 0;  case 8: return Red9 ? 1 : 0;
            default: return Red10 ? 1 : 0;
         }
     }
    static void Light_Toggle (unsigned char k)
     {
        switch(k)
         {
            case 0: Led1; break;  case 1: Led2; break;  case 2: Led3; break;  case 3: Led4; break;
            case 4: Led5; break;  case 5: Led6; break;  case 6: Led7; break;  case 7: Led8; break;
            case 8: Led9; break;  default: Led10; break;
         }
     }
    static void Lights_To_W (void)
     {
        unsigned char k;
        w[0] = 0 , w[1] = 0;
        for(k = 0 ; k < 8 ; k++)  if(Light_On(k)) w[0] |= (0x80 >> k);
        for(k = 8 ; k < 10 ; k++) if(Light_On(k)) w[1] |= (0x80 >> (k - 8));
     }

    /* only_off: 1 = auto-off time reached: switch off the lights this scenario switched on */
    static void Scn_Apply (unsigned char n , unsigned char only_off)
     {
        unsigned char k , st , changed = 0;
        char c;
        for(k = 0 ; k < 10 ; k++)
         {
            st = eeprom_read_byte((uint8_t *)&ScnE[n].st[k]);
            if(only_off) { if(st == '1' && Light_On(k)) Light_Toggle(k) , changed = 1 , delay_ms(100); continue; }
            if(st == '1' && !Light_On(k)) Light_Toggle(k) , changed = 1 , delay_ms(100);
            if(st == '0' &&  Light_On(k)) Light_Toggle(k) , changed = 1 , delay_ms(100);
         }
        if(changed) Lights_To_W () , Send_Fead_Back (1);
        if(only_off) return;
        c = eeprom_read_byte((uint8_t *)&ScnE[n].c);
        if(c == 'O' && !Red_Par_1) { if(Red_Par_2) Screen (2); Screen (1); }
        if(c == 'C' && !Red_Par_2) { if(Red_Par_1) Screen (1); Screen (2); }
     }

    /* $P03#0090$ = scenario 3 has 90 minutes left (0000 = no timer running) */
    void Scn_Report (unsigned char n)
     {
        unsigned int m = Pend[n];
        Data_connected[0] = '$' , Data_connected[1] = 'P';
        Data_connected[2] = '0' + (n + 1) / 10 , Data_connected[3] = '0' + (n + 1) % 10 , Data_connected[4] = '#';
        Data_connected[5] = '0' + m / 1000 , Data_connected[6] = '0' + (m / 100) % 10;
        Data_connected[7] = '0' + (m / 10) % 10 , Data_connected[8] = '0' + m % 10 , Data_connected[9] = '$';
        Broadcast (10);
     }

    void Scn_Start (unsigned char n)
     {
        unsigned char ch = eeprom_read_byte((uint8_t *)&ScnE[n].name[0]);
        char tm;
        unsigned int mins;
        if(ch == 0 || ch == 0xFF) return;
        tm   = eeprom_read_byte((uint8_t *)&ScnE[n].tm);
        mins = eeprom_read_word(&ScnE[n].mins);
        if(tm != 'D') Scn_Apply (n , 0);
        if((tm == 'F' || tm == 'D') && mins > 0 && mins < 10000)
         {
            Pend[n] = mins , Pend_Due[n] = 0;
            Scn_Report (n);
         }
     }

    /* count elapsed minutes; returns 1 when a timer became due */
    static unsigned char Scn_Minutes (void)
     {
        unsigned char k , due = 0 , sreg;
        while(Min_Flag)
         {
            sreg = SREG; cli(); Min_Flag --; SREG = sreg;
            for(k = 0 ; k < 12 ; k++)
                if(Pend[k]) { Pend[k] --; if(Pend[k] == 0) Pend_Due[k] = 1; }
            Vac_Minute ();
         }
        for(k = 0 ; k < 12 ; k++) if(Pend_Due[k]) due = 1;
        if(Vac_Due) due = 1;
        return due;
     }

    /* main loop: run the timers that are due */
    static void Scn_Tick (void)
     {
        unsigned char k;
        if(!Scn_Minutes ()) return;
        if(Vac_Due) Vac_Run ();
        for(k = 0 ; k < 12 ; k++)
         {
            if(!Pend_Due[k]) continue;
            Pend_Due[k] = 0;
            if(eeprom_read_byte((uint8_t *)&ScnE[k].tm) == 'F') Scn_Apply (k , 1);
            else                                               Scn_Apply (k , 0);
            Scn_Report (k);
         }
     }

    /* ---------------- SOODEN: vacation program ---------------- */
    /* one minute passed: advance the clock and look for vacation events at this minute */
    static void Vac_Minute (void)
     {
        unsigned char k , n , d;
        unsigned int night , rel , t;
        if(++Clk_Min >= 1440) Clk_Min = 0 , Clk_Day ++;
        if(!Clk_Ok || Vac_Due) return;
        if(eeprom_read_byte(&VacE.on) != 1) return;
        n = eeprom_read_byte(&VacE.n);
        if(n < 1 || n > VAC_STEPS) return;
        for(d = 0 ; d < 2 ; d++)                     /* tonight, or last night's steps after midnight */
         {
            if(Clk_Day < d) break;
            night = Clk_Day - d;
            if(night < eeprom_read_word(&VacE.d0) || night > eeprom_read_word(&VacE.d1)) continue;
            rel = d * 1440 + Clk_Min;
            if(night == Vac_LastNight && rel == Vac_LastT) continue;   /* clock was set back: no double run */
            for(k = 0 ; k < n ; k++)
             {
                t = eeprom_read_word(&VacE.st[k].t);
                if(t == rel) Vac_Due |= (1 << k);
             }
            if(eeprom_read_word(&VacE.te) == rel) Vac_Due |= 0x80;
            if(Vac_Due) { Vac_Night = night , Vac_LastNight = night , Vac_LastT = rel; return; }
         }
     }

    static void Vac_Curtain (char c)
     {
        if(c == 'O' && !Red_Par_1) { if(Red_Par_2) Screen (2); Screen (1); }
        if(c == 'C' && !Red_Par_2) { if(Red_Par_1) Screen (1); Screen (2); }
     }

    /* lights exactly as mask (bit0 = light 1), one by one */
    static void Vac_Lights (unsigned int mask)
     {
        unsigned char k , want , changed = 0;
        for(k = 0 ; k < 10 ; k++)
         {
            want = (mask >> k) & 1;
            if(want != Light_On(k)) Light_Toggle(k) , changed = 1 , delay_ms(100);
         }
        if(changed) Lights_To_W () , Send_Fead_Back (1);
     }

    /* $VS#2$ = vacation step 2 was run, $VS#E$ = end (all off) */
    static void Vac_Event (char ev)
     {
        Data_connected[0] = '$' , Data_connected[1] = 'V' , Data_connected[2] = 'S';
        Data_connected[3] = '#' , Data_connected[4] = ev , Data_connected[5] = '$';
        Broadcast (6);
     }

    static void Vac_Run (void)
     {
        unsigned char k , due = Vac_Due;
        Vac_Due = 0;
        if(due & 0x80)
         {
            Vac_Lights (0);
            Vac_Curtain (eeprom_read_byte((uint8_t *)&VacE.ce));
            Vac_Event ('E');
            return;
         }
        for(k = VAC_STEPS ; k > 0 ; k--)             /* if two steps share a minute the last one wins */
            if(due & (1 << (k - 1)))
             {
                Vac_Lights (eeprom_read_word(&VacE.st[k-1].mask) & 0x03FF);
                Vac_Curtain (eeprom_read_byte((uint8_t *)&VacE.st[k-1].c));
                Vac_Event ('0' + k);
                return;
             }
     }

    static unsigned int Num_At (unsigned char *p , unsigned char len , unsigned char *ok)
     {
        unsigned int v = 0;
        unsigned char k;
        for(k = 0 ; k < len ; k++)
         {
            if(p[k] < '0' || p[k] > '9') { *ok = 0; return 0; }
            v = v * 10 + (p[k] - '0');
         }
        return v;
     }
    static unsigned int Hex_At (unsigned char *p , unsigned char len , unsigned char *ok)
     {
        unsigned int v = 0;
        unsigned char k , ch;
        for(k = 0 ; k < len ; k++)
         {
            ch = p[k];
            if(ch >= '0' && ch <= '9')      v = v * 16 + (ch - '0');
            else if(ch >= 'A' && ch <= 'F') v = v * 16 + (ch - 'A' + 10);
            else { *ok = 0; return 0; }
         }
        return v;
     }
    static unsigned char Put_Num (unsigned char q , unsigned int v , unsigned char len)
     {
        unsigned char k;
        for(k = len ; k > 0 ; k--) Data_connected[q + k - 1] = '0' + v % 10 , v /= 10;
        return q + len;
     }
    static unsigned char Put_Hex (unsigned char q , unsigned int v , unsigned char len)
     {
        unsigned char k , h;
        for(k = len ; k > 0 ; k--) h = v & 15 , Data_connected[q + k - 1] = h < 10 ? '0' + h : 'A' + h - 10 , v >>= 4;
        return q + len;
     }

    /* Vac#1#09410#09415#3#1200001C1290003-1380000O#1440-#
       on, first night, last night, steps, n x (time 4 digits, lights 3 hex, curtain), #end time, end curtain# */
    static void Vac_Write (unsigned char *p)
     {
        unsigned char ok = 1 , n , k , q = 0;
        unsigned int  v;
        char c;
        p += 3;                                      /* p -> '#' after "Vac" */
        if(p[1] != '0' && p[1] != '1') ok = 0;
        if(p[2] != '#' || p[8] != '#' || p[14] != '#' || p[16] != '#') ok = 0;
        n = p[15] - '0';
        if(n < 1 || n > VAC_STEPS) ok = 0;
        if(ok)
         {
            q = 17 + n * 8;
            if(p[q] != '#' || p[q + 6] != '#') ok = 0;
         }
        if(ok)
         {   /* check everything first, then write */
            Num_At (p + 3 , 5 , &ok) , Num_At (p + 9 , 5 , &ok);
            for(k = 0 ; k < n ; k++)
             {
                v = Num_At (p + 17 + k * 8 , 4 , &ok);  if(v > 2879) ok = 0;
                Hex_At (p + 21 + k * 8 , 3 , &ok);
                c = p[24 + k * 8];  if(c != 'O' && c != 'C' && c != '-') ok = 0;
             }
            v = Num_At (p + q + 1 , 4 , &ok);  if(v > 2879) ok = 0;
            c = p[q + 5];  if(c != 'O' && c != 'C' && c != '-') ok = 0;
         }
        if(ok)
         {
            eeprom_update_byte(&VacE.on , 0);      /* off while writing */
            eeprom_update_word(&VacE.d0 , Num_At (p + 3 , 5 , &ok));
            eeprom_update_word(&VacE.d1 , Num_At (p + 9 , 5 , &ok));
            eeprom_update_byte(&VacE.n , n);
            for(k = 0 ; k < n ; k++)
             {
                eeprom_update_word(&VacE.st[k].t    , Num_At (p + 17 + k * 8 , 4 , &ok));
                eeprom_update_word(&VacE.st[k].mask , Hex_At (p + 21 + k * 8 , 3 , &ok));
                eeprom_update_byte((uint8_t *)&VacE.st[k].c , p[24 + k * 8]);
             }
            eeprom_update_word(&VacE.te , Num_At (p + q + 1 , 4 , &ok));
            eeprom_update_byte((uint8_t *)&VacE.ce , p[q + 5]);
            eeprom_update_byte(&VacE.on , p[1] - '0');
            Vac_LastNight = 0xFFFF , Vac_LastT = 0xFFFF;
         }
        sprintf((char *)Data_connected , ok ? "ok\n" : "no\n");
        Reply (3);
     }

    /* @M_VAC -> $V#1#09410#09415#3#1200001C1290003-1380000O#1440-#1$   (last digit: 1 = panel clock is set) */
    static void Vac_Read (void)
     {
        unsigned char q = 0 , n , k , on;
        Data_connected[q++] = '$' , Data_connected[q++] = 'V' , Data_connected[q++] = '#';
        on = eeprom_read_byte(&VacE.on);
        n  = eeprom_read_byte(&VacE.n);
        if(on > 1 || n < 1 || n > VAC_STEPS) { on = 0; n = 0; }
        Data_connected[q++] = '0' + on , Data_connected[q++] = '#';
        if(n)
         {
            q = Put_Num (q , eeprom_read_word(&VacE.d0) , 5) , Data_connected[q++] = '#';
            q = Put_Num (q , eeprom_read_word(&VacE.d1) , 5) , Data_connected[q++] = '#';
            Data_connected[q++] = '0' + n , Data_connected[q++] = '#';
            for(k = 0 ; k < n ; k++)
             {
                q = Put_Num (q , eeprom_read_word(&VacE.st[k].t) , 4);
                q = Put_Hex (q , eeprom_read_word(&VacE.st[k].mask) & 0x03FF , 3);
                Data_connected[q++] = eeprom_read_byte((uint8_t *)&VacE.st[k].c);
             }
            Data_connected[q++] = '#';
            q = Put_Num (q , eeprom_read_word(&VacE.te) , 4);
            Data_connected[q++] = eeprom_read_byte((uint8_t *)&VacE.ce) , Data_connected[q++] = '#';
         }
        else Data_connected[q++] = '-' , Data_connected[q++] = '#';
        Data_connected[q++] = Clk_Ok ? '1' : '0' , Data_connected[q++] = '$';
        Reply (q);
     }

    /* &CLK#09410#1234#56 = day number, minute of the day, second */
    static void Clk_Set (unsigned char *p)
     {
        unsigned char ok = 1 , sreg;
        unsigned int d , m , sec;
        if(p[4] != '#' || p[10] != '#' || p[15] != '#') return;
        d = Num_At (p + 5 , 5 , &ok) , m = Num_At (p + 11 , 4 , &ok) , sec = Num_At (p + 16 , 2 , &ok);
        if(!ok || m >= 1440 || sec >= 60) return;
        sreg = SREG; cli();
        Clk_Day = d , Clk_Min = m , Min_Acc = (unsigned long)sec * 7812UL , Min_Flag = 0;
        SREG = sreg;
        Clk_Ok = 1;
     }

    /* SOODEN: tell every phone that Exit (E) or Elevator (L) was started: $EV=E$ */
    void Send_Event  (char Ev)
     {
        sprintf((char *)Data_connected , "$EV=%c$" , Ev);
        Broadcast (6);
     }

    void Send_Fead_Back  (char Fead_Back)
     {
        cli();

        Data_connected[0] ='@' , Data_connected[1] ='T' , Data_connected[2] ='A' , Data_connected[3] ='1';
        Data_connected[4] = (Fead_Back == 1) ? 'U' : 'V';     /* SOODEN: header was left over from the previous message */

        if(Fead_Back == 1)  Data_connected[5] = w[0]    , Data_connected[6] = w[1];

        if(Fead_Back == 2)  Data_connected[5] = p1[0]   , Data_connected[6] = p1[1] , Data_connected[7] = p1[2] , Data_connected[8] = p1[3] , Data_connected[9] = p1[4];

        if(Fead_Back == 3)  Data_connected[5] = p1[0]   , Data_connected[6] = p1[1] , Data_connected[7] = p1[2] , Data_connected[8] = p1[3] , Data_connected[9] = p1[4];
                    

        Broadcast (10);     // SOODEN: every connected phone, asker first



        sei();
     }


    // SOODEN: answer only the phone that asked
    void Reply  (unsigned char Cunter)
     {
        if(Conn[Id_S]) Send_Data (Id_S , Cunter);
     }
    // SOODEN: send to every connected phone (asker first, 150 ms gap instead of 1000 ms)
    void Broadcast  (unsigned char Cunter)
     {
        unsigned char k , first =1;
        if(Conn[Id_S]) Send_Data (Id_S , Cunter) , first =0;
        for(k = 0 ; k < 3 ; k++)
         {
            if(k == Id_S || !Conn[k]) continue;
            if(!first) delay_ms(150);
            Send_Data (k , Cunter) , first =0;
         }
     }
    void Send_Data  (char Id , unsigned char Cunter)
     {
        cli();
        Data_Clean();
        sprintf(str , "AT+CIPSEND=%d,%d%c" , Id , Cunter , 13);

        puts(str);

        delay_ms(100);

        Data_Clean();
            
        for(j = 0 ; j < Cunter ; j++) putchar (Data_connected [j]);
            
        Data_Clean();            

        // for( j = 0 ; j < 250 ; j++) Data_connected[j] ='\0';

        sei();
     }

     
    void Data_Clean (void)  
     {
        cli();

        i =0;

        for( j = 0 ; j < 250 ; j++) data[j] ='\0';

        for( j = 0 ; j < 80 ; j++) str[j] ='\0';

        sei();
     }